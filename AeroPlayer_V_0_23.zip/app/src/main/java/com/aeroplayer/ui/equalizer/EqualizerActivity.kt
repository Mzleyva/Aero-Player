package com.aeroplayer.ui.equalizer

import android.content.Context
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import com.aeroplayer.R
import com.aeroplayer.service.PlayerController
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import org.json.JSONObject

class EqualizerActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private val bandSeekBars = mutableListOf<SeekBar>()
    private val bandValueLabels = mutableListOf<TextView>()
    private lateinit var rootLayout: LinearLayout
    private lateinit var customPresetRow: LinearLayout

    private val PREFS_NAME = "eq_custom_presets"
    private val KEY_PRESETS = "presets"
    private val KEY_BAND_LEVELS = "eq_band_levels"
    private val KEY_EQ_ENABLED  = "eq_enabled"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rootLayout = buildUI()
        val scroll = ScrollView(this).apply {
            addView(rootLayout)
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }
        setContentView(scroll)

        val sessionId = PlayerController.getAudioSessionId()
        runCatching {
            equalizer = Equalizer(0, sessionId).also { it.enabled = true }
        }.onFailure {
            Snackbar.make(scroll, "No se pudo inicializar el ecualizador", Snackbar.LENGTH_LONG).show()
            finish()
            return
        }
        val eq = equalizer ?: run { finish(); return }
        populateEqualizer(eq)
        restoreBandLevels(eq)
        loadCustomPresets()
    }

    // ── Build skeleton UI ────────────────────────────────────────────────────
    private fun buildUI(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 16, 4)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            setColorFilter(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            setBackgroundResource(android.R.color.transparent)
            setPadding(16)
            setOnClickListener { finish() }
        }
        val tvTitle = TextView(this).apply {
            text = "Ecualizador"
            textSize = 19f
            typeface = resources.getFont(R.font.inter_bold)
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 4 }
        }
        val swEnable = SwitchMaterial(this).apply {
            isChecked = true
            text = "Activo"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
            thumbTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            trackTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
            setOnCheckedChangeListener { _, checked ->
                equalizer?.enabled = checked
                bandSeekBars.forEach { it.isEnabled = checked }
            }
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(swEnable)
        root.addView(toolbar)
        root.addView(dividerView())

        // System presets section
        root.addView(sectionLabel("Presets del sistema"))
        val sysPresetScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            id = R.id.ids_chip_container  // placeholder id reused
        }
        root.addView(sysPresetScroll)

        // Custom presets section
        val customHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 20, 16, 4)
        }
        customHeader.addView(sectionLabel("Mis presets").also {
            (it.layoutParams as LinearLayout.LayoutParams).apply {
                width = 0; weight = 1f; topMargin = 0
            }
            it.setPadding(0, 0, 0, 0)
        })
        val btnSavePreset = com.google.android.material.button.MaterialButton(
            this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
        ).apply {
            text = "Guardar preset"
            textSize = 12f
            strokeColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            setOnClickListener { showSavePresetDialog() }
        }
        customHeader.addView(btnSavePreset)
        root.addView(customHeader)

        customPresetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 4, 16, 4) }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(customPresetRow)
        })

        root.addView(dividerView())
        root.addView(sectionLabel("Bandas"))

        // Band container placeholder
        root.addView(FrameLayout(this).apply { id = android.R.id.content + 100 })

        // Reset button
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(com.google.android.material.button.MaterialButton(
                this@EqualizerActivity, null,
                com.google.android.material.R.attr.materialButtonOutlinedStyle
            ).apply {
                text = "Restablecer"
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = 24; it.bottomMargin = 32 }
                setOnClickListener { resetBands() }
            })
        })
        return root
    }

    // ── Populate EQ bands ────────────────────────────────────────────────────
    private fun populateEqualizer(eq: Equalizer) {
        // System presets chips
        val sysPresetScroll = rootLayout.findViewById<HorizontalScrollView>(R.id.ids_chip_container)
        val sysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 4, 16, 8) }
        val presetCount = eq.numberOfPresets.toInt()
        if (presetCount > 0) {
            (0 until presetCount).forEach { i ->
                val name = eq.getPresetName(i.toShort())
                sysRow.addView(makeChip(name) {
                    eq.usePreset(i.toShort())
                    refreshBands(eq)
                    toast("Preset: $name")
                })
            }
        } else {
            sysRow.addView(TextView(this).apply {
                text = "No hay presets del sistema disponibles"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8, 8, 8, 8)
            })
        }
        sysPresetScroll?.addView(sysRow)

        // Band level range
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel = levelRange[0].toInt()
        val maxLevel = levelRange[1].toInt()
        val range = (maxLevel - minLevel).coerceAtLeast(1)

        // Bands
        val bandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(12, 8, 12, 8)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 300.dp)
        }
        bandSeekBars.clear(); bandValueLabels.clear()

        (0 until eq.numberOfBands).forEach { i ->
            val band = i.toShort()
            val hz = runCatching { eq.getCenterFreq(band) / 1000 }.getOrDefault(0)
            val freqLabel = if (hz >= 1000) "${hz / 1000}k" else "${hz}Hz"
            val currentLevel = runCatching { eq.getBandLevel(band).toInt() }.getOrDefault(0)

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            }

            val tvDb = TextView(this).apply {
                text = formatDb(currentLevel)
                textSize = 10f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                gravity = Gravity.CENTER
                typeface = resources.getFont(R.font.inter_medium)
            }
            bandValueLabels.add(tvDb)

            val sb = SeekBar(this).apply {
                rotation = -90f
                max = range
                progress = (currentLevel - minLevel).coerceIn(0, range)
                progressTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                thumbTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(240, 36).also { it.topMargin = 4; it.bottomMargin = 4 }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val level = (p + minLevel).toShort()
                        runCatching { eq.setBandLevel(band, level) }
                        tvDb.text = formatDb(level.toInt())
                        tvDb.setTextColor(ContextCompat.getColor(
                            this@EqualizerActivity,
                            when { level > 0 -> R.color.accent_blue; level < 0 -> R.color.accent_pink; else -> R.color.text_secondary }
                        ))
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) { saveBandLevels() }
                })
            }
            bandSeekBars.add(sb)

            val tvFreq = TextView(this).apply {
                text = freqLabel
                textSize = 10f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = 4 }
            }
            col.addView(tvDb); col.addView(sb); col.addView(tvFreq)
            bandContainer.addView(col)
        }

        // Replace placeholder
        val placeholder = rootLayout.findViewById<FrameLayout>(android.R.id.content + 100)
        val idx = (0 until rootLayout.childCount).indexOfFirst { rootLayout.getChildAt(it) == placeholder }
        if (idx >= 0) {
            rootLayout.removeViewAt(idx)
            rootLayout.addView(bandContainer, idx)
        } else {
            rootLayout.addView(bandContainer)
        }
    }

    // ── Custom preset management ─────────────────────────────────────────────
    private fun showSavePresetDialog() {
        val eq = equalizer ?: return
        val input = EditText(this).apply {
            hint = "Nombre del preset"
            setPadding(48, 24, 48, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Guardar preset")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { toast("El nombre no puede estar vacío"); return@setPositiveButton }
                val levels = (0 until eq.numberOfBands).map { i ->
                    runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
                }
                saveCustomPreset(name, levels)
                loadCustomPresets()
                toast("Preset \"$name\" guardado")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveCustomPreset(name: String, levels: List<Int>) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        cleaned.put(JSONObject().apply { put("name", name); put("levels", JSONArray(levels)) })
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun loadCustomPresets() {
        customPresetRow.removeAllViews()
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val presets = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())

        if (presets.length() == 0) {
            customPresetRow.addView(TextView(this).apply {
                text = "Aún no tienes presets guardados"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8, 8, 8, 8)
            })
            return
        }
        for (i in 0 until presets.length()) {
            val obj = presets.getJSONObject(i)
            val name = obj.getString("name")
            val levelsArr = obj.getJSONArray("levels")
            val levels = (0 until levelsArr.length()).map { levelsArr.getInt(it) }

            val chip = makeChip(name, longPress = {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Eliminar preset")
                    .setMessage("¿Eliminar \"$name\"?")
                    .setPositiveButton("Eliminar") { _, _ ->
                        deleteCustomPreset(name); loadCustomPresets(); toast("Preset eliminado")
                    }
                    .setNegativeButton("Cancelar", null).show()
            }) {
                applyCustomPreset(levels); toast("Preset: $name")
            }
            customPresetRow.addView(chip)
        }
    }

    private fun deleteCustomPreset(name: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun applyCustomPreset(levels: List<Int>) {
        val eq = equalizer ?: return
        levels.forEachIndexed { i, level ->
            if (i < eq.numberOfBands) runCatching { eq.setBandLevel(i.toShort(), level.toShort()) }
        }
        refreshBands(eq)
        saveBandLevels()
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun refreshBands(eq: Equalizer) {
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel = levelRange[0].toInt()
        val range = (levelRange[1].toInt() - minLevel).coerceAtLeast(1)
        bandSeekBars.forEachIndexed { i, sb ->
            val level = runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
            sb.progress = (level - minLevel).coerceIn(0, range)
            bandValueLabels.getOrNull(i)?.apply {
                text = formatDb(level)
                setTextColor(ContextCompat.getColor(
                    this@EqualizerActivity,
                    when { level > 0 -> R.color.accent_blue; level < 0 -> R.color.accent_pink; else -> R.color.text_secondary }
                ))
            }
        }
    }

    private fun resetBands() {
        val eq = equalizer ?: return
        (0 until eq.numberOfBands).forEach { i -> runCatching { eq.setBandLevel(i.toShort(), 0) } }
        refreshBands(eq)
        saveBandLevels()
        toast("Ecualizador restablecido")
    }

    // ── Persist / restore band levels ───────────────────────────────────────
    private fun saveBandLevels() {
        val eq = equalizer ?: return
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val levels = (0 until eq.numberOfBands).map { i ->
            runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
        }
        prefs.edit()
            .putString(KEY_BAND_LEVELS, levels.joinToString(","))
            .putBoolean(KEY_EQ_ENABLED, eq.enabled)
            .apply()
    }

    private fun restoreBandLevels(eq: Equalizer) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_BAND_LEVELS, null) ?: return
        val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (levels.size != eq.numberOfBands.toInt()) return
        levels.forEachIndexed { i, level ->
            runCatching { eq.setBandLevel(i.toShort(), level.toShort()) }
        }
        eq.enabled = prefs.getBoolean(KEY_EQ_ENABLED, true)
        refreshBands(eq)
    }

    private fun formatDb(milliDb: Int): String {
        val db = milliDb / 100
        return if (db > 0) "+${db}dB" else "${db}dB"
    }

    private fun makeChip(text: String, longPress: (() -> Unit)? = null, onClick: () -> Unit): Chip {
        return Chip(this).apply {
            this.text = text
            textSize = 12f
            chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            chipStrokeColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            chipStrokeWidth = 1.5f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8 }
            setOnClickListener { onClick() }
            longPress?.let { lp -> setOnLongClickListener { lp(); true } }
        }
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
        typeface = resources.getFont(R.font.inter_medium)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = 20; it.bottomMargin = 4 }
        setPadding(24, 0, 24, 0)
    }

    private fun dividerView(): View = View(this).apply {
        setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.divider))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            .also { it.topMargin = 8; it.bottomMargin = 4 }
    }

    private fun toast(msg: String) = Snackbar.make(rootLayout, msg, Snackbar.LENGTH_SHORT).show()

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        saveBandLevels()
        equalizer?.release()
        equalizer = null
        super.onDestroy()
    }
}
