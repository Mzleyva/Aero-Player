package com.aeroplayer.ui.library

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

/**
 * Explorador de carpetas — navega el árbol de carpetas y reproduce una carpeta
 * completa como playlist. Permite asignar portada personalizada a cada carpeta.
 *
 * Entrada: "root_path" (String) — ruta raíz. Si null usa /storage/emulated/0.
 */
class FolderBrowserActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private lateinit var rv: RecyclerView
    private lateinit var tvPath: TextView
    private lateinit var adapter: FolderAdapter
    private var currentPath: String = "/storage/emulated/0"
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp get() = (this * resources.displayMetrics.density)

    // Prefs para portadas de carpetas
    private val coverPrefs by lazy { getSharedPreferences("folder_covers", MODE_PRIVATE) }

    private var pendingCoverFolder: String? = null
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val folder = pendingCoverFolder ?: return@registerForActivityResult
        if (uri != null) {
            // Persistir URI con permiso permanente
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION)
            coverPrefs.edit().putString(folder, uri.toString()).apply()
            adapter.notifyDataSetChanged()
            Snackbar.make(rv, "Portada asignada ✓", Snackbar.LENGTH_SHORT).show()
        }
        pendingCoverFolder = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        currentPath = intent.getStringExtra("root_path") ?: "/storage/emulated/0"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // ── Toolbar ───────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { navigateUp() }
        }
        tvPath = TextView(this).apply {
            text = currentPath.substringAfterLast("/").ifBlank { "/" }
            textSize = 16f
            setTextColor(getColor(R.color.text_primary))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        // Botón reproducir carpeta completa
        val btnPlayAll = ImageButton(this).apply {
            setImageResource(R.drawable.ic_play)
            imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { playCurrentFolder() }
        }
        toolbar.addView(btnBack)
        toolbar.addView(tvPath)
        toolbar.addView(btnPlayAll)
        root.addView(toolbar)

        // ── RecyclerView en grid 2 col para carpetas, 1 col para canciones ────
        rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@FolderBrowserActivity, 2).apply {
                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(pos: Int): Int =
                        if (adapter?.getItemViewType(pos) == FolderAdapter.TYPE_SONG) 2 else 1
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            setPadding(8.dp, 0, 8.dp, 80.dp)
            clipToPadding = false
        }
        adapter = FolderAdapter(
            onFolderClick    = { folder -> navigateTo(folder.path) },
            onFolderLongTap  = { folder -> showFolderOptions(folder) },
            onSongClick      = { song, all -> PlayerController.playSongs(all, all.indexOf(song)) },
            getCoverUri      = { path -> coverPrefs.getString(path, null)?.let { Uri.parse(it) } }
        )
        rv.adapter = adapter
        root.addView(rv)

        setContentView(root)

        // Observar canciones y renderizar carpeta actual
        viewModel.allSongs.observe(this) { refreshFolder() }
        refreshFolder()
    }

    private fun refreshFolder() {
        val songs = viewModel.allSongs.value ?: emptyList()
        val items = buildFolderItems(currentPath, songs)
        tvPath.text = currentPath.substringAfterLast("/").ifBlank { "/" }
        adapter.submitItems(items)
    }

    private fun buildFolderItems(path: String, allSongs: List<Song>): List<FolderItem> {
        val subFolders = mutableSetOf<String>()
        val songsHere  = mutableListOf<Song>()

        allSongs.forEach { song ->
            val songDir = song.path.substringBeforeLast("/")
            if (songDir == path) {
                songsHere.add(song)
            } else if (songDir.startsWith("$path/")) {
                // Subcarpeta directa
                val relative = songDir.removePrefix("$path/")
                val direct   = relative.substringBefore("/")
                subFolders.add("$path/$direct")
            }
        }

        val items = mutableListOf<FolderItem>()

        // Subcarpetas primero, con conteo y primera carátula
        subFolders.sorted().forEach { subPath ->
            val subSongs = allSongs.filter { it.path.startsWith("$subPath/") ||
                    it.path.substringBeforeLast("/") == subPath }
            val cover = subSongs.firstOrNull()?.albumArtUri
            items.add(FolderItem.Folder(
                name      = subPath.substringAfterLast("/"),
                path      = subPath,
                songCount = subSongs.size,
                coverUri  = cover
            ))
        }

        // Canciones de esta carpeta
        songsHere.sortedBy { it.title.lowercase() }.forEach {
            items.add(FolderItem.SongEntry(it))
        }

        return items
    }

    private fun navigateTo(path: String) {
        currentPath = path
        refreshFolder()
    }

    private fun navigateUp() {
        val parent = currentPath.substringBeforeLast("/")
        if (parent.isNotEmpty() && parent != currentPath && parent.length > 10) {
            navigateTo(parent)
        } else {
            finish()
        }
    }

    private fun playCurrentFolder() {
        val songs = viewModel.allSongs.value ?: return
        val folderSongs = songs.filter {
            it.path.startsWith("$currentPath/") ||
            it.path.substringBeforeLast("/") == currentPath
        }.sortedBy { it.title.lowercase() }

        if (folderSongs.isEmpty()) {
            Snackbar.make(rv, "No hay canciones en esta carpeta", Snackbar.LENGTH_SHORT).show()
            return
        }
        PlayerController.playSongs(folderSongs, 0,
            queueName = currentPath.substringAfterLast("/"))
    }

    private fun showFolderOptions(folder: FolderItem.Folder) {
        val options = arrayOf(
            "▶ Reproducir carpeta",
            "🔀 Reproducir en aleatorio",
            "🖼 Asignar portada",
            "➕ Agregar a playlist"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(folder.name)
            .setItems(options) { _, which ->
                val songs = (viewModel.allSongs.value ?: emptyList()).filter {
                    it.path.startsWith("${folder.path}/") ||
                    it.path.substringBeforeLast("/") == folder.path
                }.sortedBy { it.title.lowercase() }

                when (which) {
                    0 -> PlayerController.playSongs(songs, 0, queueName = folder.name)
                    1 -> PlayerController.playSongs(songs.shuffled(), 0, queueName = folder.name)
                    2 -> { pendingCoverFolder = folder.path; pickImage.launch("image/*") }
                    3 -> addFolderToPlaylist(songs, folder.name)
                }
            }
            .show()
    }

    private fun addFolderToPlaylist(songs: List<Song>, folderName: String) {
        if (songs.isEmpty()) {
            Snackbar.make(rv, "No hay canciones en esta carpeta", Snackbar.LENGTH_SHORT).show()
            return
        }
        // Obtener playlists existentes y mostrar selector
        val db = com.aeroplayer.data.db.AppDatabase.getInstance(this)
        lifecycleScope.launch {
            val playlists = db.playlistDao().getAll()
            val names = playlists.map { it.name }.toTypedArray()
            if (names.isEmpty()) {
                Snackbar.make(rv, "Crea una playlist primero desde la pestaña Biblioteca",
                    Snackbar.LENGTH_LONG).show()
                return@launch
            }
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this@FolderBrowserActivity)
                .setTitle("Añadir carpeta a playlist")
                .setItems(names) { _, idx ->
                    lifecycleScope.launch {
                        val playlist = playlists[idx]
                        songs.forEach { song ->
                            db.playlistDao().addSongToPlaylist(playlist.id, song.id)
                        }
                        Snackbar.make(rv,
                            "${songs.size} canciones añadidas a '${playlist.name}'",
                            Snackbar.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    override fun onBackPressed() = navigateUp()
}

// ── Sealed model ──────────────────────────────────────────────────────────────
sealed class FolderItem {
    data class Folder(
        val name: String, val path: String,
        val songCount: Int, val coverUri: Uri?
    ) : FolderItem()
    data class SongEntry(val song: Song) : FolderItem()
}

// ── Adapter ───────────────────────────────────────────────────────────────────
class FolderAdapter(
    private val onFolderClick:   (FolderItem.Folder) -> Unit,
    private val onFolderLongTap: (FolderItem.Folder) -> Unit,
    private val onSongClick:     (Song, List<Song>)  -> Unit,
    private val getCoverUri:     (String) -> Uri?
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_FOLDER = 0
        const val TYPE_SONG   = 1
    }

    private val items = mutableListOf<FolderItem>()
    private val songs get() = items.filterIsInstance<FolderItem.SongEntry>().map { it.song }

    fun submitItems(list: List<FolderItem>) {
        items.clear(); items.addAll(list); notifyDataSetChanged()
    }

    override fun getItemViewType(pos: Int) =
        if (items[pos] is FolderItem.Folder) TYPE_FOLDER else TYPE_SONG

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density
        return if (viewType == TYPE_FOLDER) FolderVH(buildFolderCard(ctx, dp))
        else SongVH(buildSongRow(ctx, dp))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
        when (val item = items[pos]) {
            is FolderItem.Folder -> (holder as FolderVH).bind(item)
            is FolderItem.SongEntry -> (holder as SongVH).bind(item.song)
        }
    }

    private fun buildFolderCard(ctx: android.content.Context, dp: Float): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
        }
    }

    private fun buildSongRow(ctx: android.content.Context, dp: Float): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (56 * dp).toInt()
            )
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
            isClickable = true; isFocusable = true
        }
    }

    inner class FolderVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        fun bind(folder: FolderItem.Folder) {
            root.removeAllViews()
            val ctx = root.context
            val dp  = ctx.resources.displayMetrics.density

            // Carátula de carpeta
            val iv = android.widget.ImageView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (120 * dp).toInt()
                )
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF1E1E2E.toInt()); cornerRadius = (12 * dp)
                }
                clipToOutline = true
            }
            val cover = getCoverUri(folder.path) ?: folder.coverUri
            Glide.with(iv)
                .load(cover)
                .placeholder(R.drawable.ic_library)
                .centerCrop()
                .into(iv)

            val tvName = android.widget.TextView(ctx).apply {
                text = folder.name
                textSize = 13f
                setTextColor(ctx.getColor(R.color.text_primary))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding((4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), 0)
            }
            val tvCount = android.widget.TextView(ctx).apply {
                text = "${folder.songCount} canción${if (folder.songCount != 1) "es" else ""}"
                textSize = 11f
                setTextColor(ctx.getColor(R.color.text_secondary))
                setPadding((4 * dp).toInt(), 0, (4 * dp).toInt(), (4 * dp).toInt())
            }
            root.addView(iv); root.addView(tvName); root.addView(tvCount)
            root.setOnClickListener { onFolderClick(folder) }
            root.setOnLongClickListener { onFolderLongTap(folder); true }

        }
    }

    inner class SongVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        fun bind(song: Song) {
            root.removeAllViews()
            val ctx = root.context
            val dp  = ctx.resources.displayMetrics.density

            val iv = android.widget.ImageView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (40 * dp).toInt(), (40 * dp).toInt()
                ).also { it.marginEnd = (12 * dp).toInt() }
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = ctx.getDrawable(R.drawable.bg_album_art_small)
                clipToOutline = true
            }
            Glide.with(iv).load(song.albumArtUri).placeholder(R.drawable.ic_music_placeholder)
                .centerCrop().into(iv)

            val texts = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            texts.addView(android.widget.TextView(ctx).apply {
                text = song.title; textSize = 14f
                setTextColor(ctx.getColor(R.color.text_primary))
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            texts.addView(android.widget.TextView(ctx).apply {
                text = song.artist; textSize = 12f
                setTextColor(ctx.getColor(R.color.text_secondary))
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })

            root.addView(iv); root.addView(texts)
            root.setOnClickListener {
                if (song.path.endsWith(".cue", ignoreCase = true)) {
                    root.context.startActivity(android.content.Intent(root.context,
                        com.aeroplayer.ui.CueSheetBrowserActivity::class.java)
                        .putExtra(com.aeroplayer.ui.CueSheetBrowserActivity.EXTRA_CUE_PATH, song.path))
                } else { onSongClick(song, songs) }
            }
        }
    }
}

// CUE sheet support: launch CueSheetBrowserActivity when user taps a .cue file
// Implemented below in the adapter click handler
