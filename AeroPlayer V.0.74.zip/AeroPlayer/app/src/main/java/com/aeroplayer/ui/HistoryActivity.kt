package com.aeroplayer.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.data.db.ListeningHistoryEntity
import com.aeroplayer.service.PlayerController
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }

        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }

        val tvTitle = TextView(this).apply {
            text = "Historial"
            textSize = 20f
            setTextColor(getColor(R.color.text_primary))
            setPadding(12.dp, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnClear = TextView(this).apply {
            text = "Limpiar"
            textSize = 13f
            setTextColor(getColor(R.color.accent_blue))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this@HistoryActivity)
                    .setTitle("Limpiar historial")
                    .setMessage("¿Eliminar todo el historial de reproducción?")
                    .setPositiveButton("Limpiar") { _, _ -> viewModel.clearHistory() }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }

        toolbar.addView(btnBack)
        toolbar.addView(tvTitle)
        toolbar.addView(btnClear)

        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@HistoryActivity)
            setPadding(0, 0, 0, 80.dp)
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        val emptyView = TextView(this).apply {
            text = "Aún no has reproducido ninguna canción.\nComienza a escuchar música."
            textSize = 14f
            setTextColor(getColor(R.color.text_secondary))
            gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(toolbar)
        root.addView(rv)
        root.addView(emptyView)
        setContentView(root)

        val adapter = HistoryAdapter { entry ->
            // Reproducir desde el historial
            val song = entry.toSong()
            PlayerController.playSongs(listOf(song), 0, queueName = "Historial")
        }
        rv.adapter = adapter

        viewModel.listeningHistory.observe(this) { history ->
            adapter.submitList(history)
            rv.visibility       = if (history.isEmpty()) View.GONE else View.VISIBLE
            emptyView.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    private fun ListeningHistoryEntity.toSong() = Song(
        id           = songId,
        title        = title,
        artist       = artist,
        album        = album,
        duration     = duration,
        path         = path,
        albumArtUri  = albumArtUri?.let { Uri.parse(it) },
        uri          = Uri.parse("file://$path"),
        albumId      = 0, trackNumber = 0, year = 0, size = 0
    )
}

private class HistoryAdapter(
    private val onClick: (ListeningHistoryEntity) -> Unit
) : ListAdapter<ListeningHistoryEntity, HistoryAdapter.VH>(HistoryDiff()) {

    private val dateFmt = SimpleDateFormat("dd MMM · HH:mm", Locale.getDefault())

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val iv: ImageView  = root.findViewById(android.R.id.icon)
        val tvTitle: TextView  = root.findViewById(android.R.id.text1)
        val tvSub: TextView    = root.findViewById(android.R.id.text2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp = ctx.resources.displayMetrics.density

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
            isClickable = true
            isFocusable = true
        }

        val size = (46 * dp).toInt()
        val iv = ImageView(ctx).apply {
            id = android.R.id.icon
            layoutParams = LinearLayout.LayoutParams(size, size).also {
                it.marginEnd = (12 * dp).toInt()
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = ctx.getDrawable(R.drawable.bg_album_art_small)
            clipToOutline = true
        }

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvTitle = TextView(ctx).apply {
            id = android.R.id.text1
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_primary))
        }

        val tvSub = TextView(ctx).apply {
            id = android.R.id.text2
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_secondary))
        }

        texts.addView(tvTitle)
        texts.addView(tvSub)
        row.addView(iv)
        row.addView(texts)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = getItem(position)
        holder.tvTitle.text = entry.title
        holder.tvSub.text   = "${entry.artist} · ${dateFmt.format(Date(entry.playedAt))}"
        Glide.with(holder.iv)
            .load(entry.albumArtUri?.let { android.net.Uri.parse(it) })
            .placeholder(R.drawable.ic_music_placeholder)
            .centerCrop()
            .into(holder.iv)
        holder.root.setOnClickListener { onClick(entry) }
    }

    class HistoryDiff : DiffUtil.ItemCallback<ListeningHistoryEntity>() {
        override fun areItemsTheSame(a: ListeningHistoryEntity, b: ListeningHistoryEntity) = a.id == b.id
        override fun areContentsTheSame(a: ListeningHistoryEntity, b: ListeningHistoryEntity) = a == b
    }
}
