package com.aeroplayer.ui.playlist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityCreatePlaylistBinding
import com.aeroplayer.ui.MainViewModel
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class CreatePlaylistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreatePlaylistBinding
    private val viewModel: MainViewModel by viewModels()
    private var selectedCoverUri: Uri? = null

    // Edit mode
    private var editPlaylistId: Long = -1L
    private var editPlaylistName: String = ""
    private var editCoverUri: String? = null

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedCoverUri = it
            Glide.with(this)
                .load(it)
                .centerCrop()
                .placeholder(R.drawable.ic_playlist_placeholder)
                .into(binding.ivPlaylistCover)
            binding.tvAddPhoto.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityCreatePlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)

        readEditExtras()
        setupToolbar()
        setupCoverPicker()
        setupSaveButton()
    }

    private fun readEditExtras() {
        editPlaylistId = intent.getLongExtra("editPlaylistId", -1L)
        editPlaylistName = intent.getStringExtra("editPlaylistName") ?: ""
        editCoverUri = intent.getStringExtra("editCoverUri")

        if (editPlaylistId != -1L) {
            // Edit mode
            binding.tvTitle.text = getString(R.string.edit_playlist)
            binding.etPlaylistName.setText(editPlaylistName)
            binding.btnSave.text = getString(R.string.save_changes)
            editCoverUri?.let { uri ->
                selectedCoverUri = Uri.parse(uri)
                Glide.with(this)
                    .load(uri)
                    .centerCrop()
                    .into(binding.ivPlaylistCover)
                binding.tvAddPhoto.visibility = View.GONE
            }
        }
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }
    }

    private fun setupCoverPicker() {
        binding.coverContainer.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
        binding.btnChangeCover.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            val name = binding.etPlaylistName.text?.toString()?.trim()
            if (name.isNullOrEmpty()) {
                binding.tilPlaylistName.error = getString(R.string.playlist_name_required)
                return@setOnClickListener
            }
            binding.tilPlaylistName.error = null

            val coverUriStr = selectedCoverUri?.toString() ?: editCoverUri

            if (editPlaylistId != -1L) {
                // Update existing
                lifecycleScope.launch {
                    viewModel.updatePlaylistFull(editPlaylistId, name, coverUriStr)
                    setResult(Activity.RESULT_OK)
                    finish()
                }
            } else {
                // Create new
                viewModel.createPlaylist(name, coverUriStr)
                Snackbar.make(binding.root, getString(R.string.playlist_created, name), Snackbar.LENGTH_SHORT).show()
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
    }
}
