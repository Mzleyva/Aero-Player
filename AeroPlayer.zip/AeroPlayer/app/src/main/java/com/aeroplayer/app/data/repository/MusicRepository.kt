package com.aeroplayer.app.data.repository

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.aeroplayer.app.data.db.AeroDatabase
import com.aeroplayer.app.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    private val db = AeroDatabase.getInstance(context)
    private val songDao = db.songDao()
    private val playlistDao = db.playlistDao()

    // ─── Escanear música del dispositivo ───────────────────────────────────
    suspend fun scanDeviceMusic() = withContext(Dispatchers.IO) {
        val songs = mutableListOf<Song>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND " +
                "${MediaStore.Audio.Media.DURATION} > 30000"

        val cursor: Cursor? = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} ASC"
        )

        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val dataCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (it.moveToNext()) {
                val albumId = it.getLong(albumIdCol)
                val artUri = ContentUris.withAppendedId(
                    Uri.parse("content://media/external/audio/albumart"), albumId
                ).toString()

                songs.add(
                    Song(
                        id = it.getLong(idCol),
                        title = it.getString(titleCol) ?: "Desconocido",
                        artist = it.getString(artistCol) ?: "Artista desconocido",
                        album = it.getString(albumCol) ?: "Álbum desconocido",
                        duration = it.getLong(durationCol),
                        path = it.getString(dataCol) ?: "",
                        albumArtUri = artUri
                    )
                )
            }
        }

        if (songs.isNotEmpty()) songDao.insertSongs(songs)
    }

    // ─── Canciones ─────────────────────────────────────────────────────────
    fun getAllSongs(): Flow<List<Song>> = songDao.getAllSongs()
    fun getLikedSongs(): Flow<List<Song>> = songDao.getLikedSongs()
    fun getMostPlayed(limit: Int = 10): Flow<List<Song>> = songDao.getMostPlayed(limit)
    fun getRecentlyPlayed(limit: Int = 10): Flow<List<Song>> = songDao.getRecentlyPlayed(limit)
    fun searchSongs(query: String): Flow<List<Song>> = songDao.searchSongs(query)
    fun getAllArtists(): Flow<List<String>> = songDao.getAllArtists()
    fun getAllAlbums(): Flow<List<String>> = songDao.getAllAlbums()
    fun getSongsByArtist(artist: String): Flow<List<Song>> = songDao.getSongsByArtist(artist)
    fun getSongsByAlbum(album: String): Flow<List<Song>> = songDao.getSongsByAlbum(album)

    suspend fun setLiked(songId: Long, liked: Boolean) = songDao.setLiked(songId, liked)
    suspend fun incrementPlayCount(songId: Long) = songDao.incrementPlayCount(songId)
    suspend fun updateMetadata(songId: Long, title: String, artist: String, album: String) =
        songDao.updateMetadata(songId, title, artist, album)

    // ─── Recomendaciones ───────────────────────────────────────────────────
    suspend fun getRecommendations(limit: Int = 20): List<Song> {
        val mostPlayed = mutableListOf<Song>()
        val liked = mutableListOf<Song>()

        songDao.getMostPlayed(5).collect { mostPlayed.addAll(it) }
        songDao.getLikedSongs().collect { liked.addAll(it) }

        val topArtists = (mostPlayed + liked)
            .groupBy { it.artist }
            .entries.sortedByDescending { it.value.size }
            .take(3)
            .map { it.key }

        val recommendations = mutableListOf<Song>()
        val excludeIds = (mostPlayed + liked).map { it.id }.toSet()

        for (artist in topArtists) {
            val artistSongs = mutableListOf<Song>()
            songDao.getSongsByArtist(artist).collect { artistSongs.addAll(it) }
            recommendations.addAll(artistSongs.filter { it.id !in excludeIds })
        }

        return recommendations.shuffled().take(limit)
    }

    // ─── Playlists ─────────────────────────────────────────────────────────
    fun getAllPlaylists(): Flow<List<Playlist>> = playlistDao.getAllPlaylists()
    fun getSongsInPlaylist(playlistId: Long): Flow<List<Song>> =
        playlistDao.getSongsInPlaylist(playlistId)

    suspend fun createPlaylist(name: String): Long =
        playlistDao.insertPlaylist(Playlist(name = name))

    suspend fun updatePlaylist(playlist: Playlist) = playlistDao.updatePlaylist(playlist)
    suspend fun deletePlaylist(playlist: Playlist) = playlistDao.deletePlaylist(playlist)

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long, order: Int = 0) =
        playlistDao.addSongToPlaylist(PlaylistSongCrossRef(playlistId, songId, order))

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) =
        playlistDao.removeSongFromPlaylist(PlaylistSongCrossRef(playlistId, songId))

    suspend fun updatePlaylistCover(playlistId: Long, uri: String) =
        playlistDao.updateCover(playlistId, uri)
}
