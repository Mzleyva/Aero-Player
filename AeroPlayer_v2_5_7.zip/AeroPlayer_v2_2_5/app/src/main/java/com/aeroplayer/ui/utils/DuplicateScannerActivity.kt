package com.aeroplayer.ui.utils

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityDuplicateScannerBinding
import com.aeroplayer.model.Song
import com.aeroplayer.ui.AccentApplier
import com.aeroplayer.ui.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Escáner de canciones duplicadas.
 *
 * Estrategias de detección:
 * 1. Mismo título + artista (normalizado, sin mayúsculas/acentos)
 * 2. Mismo nombre de archivo (sin extensión)
 * 3. Mismo tamaño de archivo (byte-exact)
 *
 * Muestra grupos de duplicados con info de calidad (bitrate, tamaño, formato)
 * para que el usuario pueda decidir cuál conservar.
 */
class DuplicateScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDuplicateScannerBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: DuplicateGroupAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityDuplicateScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AccentApplier.apply(this, binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnScan.setOnClickListener { startScan() }

        adapter = DuplicateGroupAdapter()
        binding.rvDuplicates.layoutManager = LinearLayoutManager(this)
        binding.rvDuplicates.adapter = adapter
    }

    private fun startScan() {
        binding.progressBar.visibility    = View.VISIBLE
        binding.tvScanStatus.visibility   = View.VISIBLE
        binding.tvScanStatus.text         = "Escaneando biblioteca…"
        binding.btnScan.isEnabled         = false
        binding.rvDuplicates.visibility   = View.GONE

        lifecycleScope.launch {
            val songs = viewModel.allSongs.value ?: emptyList()
            val groups = withContext(Dispatchers.Default) { findDuplicates(songs) }

            binding.progressBar.visibility  = View.GONE
            binding.btnScan.isEnabled       = true
            binding.rvDuplicates.visibility = View.VISIBLE

            if (groups.isEmpty()) {
                binding.tvScanStatus.text = "✅ ¡No se encontraron duplicados!"
            } else {
                val totalDups = groups.sumOf { it.songs.size - 1 }
                binding.tvScanStatus.text =
                    "Se encontraron $totalDups posibles duplicados en ${groups.size} grupos"
                adapter.submitList(groups)
            }
        }
    }

    private fun findDuplicates(songs: List<Song>): List<DuplicateGroup> {
        val groups = mutableListOf<DuplicateGroup>()

        // Estrategia 1: título + artista normalizados
        val byTitleArtist = songs.groupBy { song ->
            normalize("${song.title}|${song.artist}")
        }.filter { it.value.size > 1 }

        byTitleArtist.forEach { (_, dups) ->
            groups.add(DuplicateGroup(
                reason = "Mismo título y artista",
                songs  = dups.sortedByDescending { it.bitrate }
            ))
        }

        // Estrategia 2: mismo tamaño exacto (excluyendo ya encontrados)
        val alreadyFound = byTitleArtist.values.flatten().map { it.id }.toSet()
        val remaining    = songs.filter { it.id !in alreadyFound && it.size > 0 }
        val bySize       = remaining.groupBy { it.size }.filter { it.value.size > 1 }

        bySize.forEach { (_, dups) ->
            groups.add(DuplicateGroup(
                reason = "Mismo tamaño de archivo",
                songs  = dups.sortedByDescending { it.bitrate }
            ))
        }

        // Estrategia 3: mismo nombre de archivo sin extensión
        val byFilename = songs.groupBy { song ->
            song.path.substringAfterLast("/").substringBeforeLast(".").lowercase()
        }.filter { it.value.size > 1 }

        byFilename.forEach { (_, dups) ->
            val ids = dups.map { it.id }.toSet()
            if (!groups.any { g -> g.songs.any { it.id in ids } }) {
                groups.add(DuplicateGroup(
                    reason = "Mismo nombre de archivo",
                    songs  = dups.sortedByDescending { it.bitrate }
                ))
            }
        }

        return groups
    }

    private fun normalize(s: String): String =
        java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
            .replace(Regex("[^\\p{ASCII}]"), "")
            .lowercase()
            .trim()
}

// ── Data ──────────────────────────────────────────────────────────────────────

data class DuplicateGroup(
    val reason: String,
    val songs: List<Song>
)

// ── Adapter ───────────────────────────────────────────────────────────────────

class DuplicateGroupAdapter : ListAdapter<DuplicateGroup, DuplicateGroupAdapter.VH>(DupDiff()) {

    inner class VH(val root: ViewGroup) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_duplicate_group, parent, false) as ViewGroup
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = getItem(position)
        val tvReason = holder.root.findViewById<TextView>(R.id.tvDupReason)
        val container= holder.root.findViewById<ViewGroup>(R.id.containerDupSongs)

        tvReason.text = "📋 ${group.reason}"
        container.removeAllViews()

        group.songs.forEachIndexed { i, song ->
            val tv = TextView(holder.root.context).apply {
                val label = if (i == 0) "  ✅ Mejor calidad" else "  ⚠️ Posible duplicado"
                val fmt   = song.mimeType.substringAfterLast("/").uppercase().take(4)
                val kbps  = if (song.bitrate > 0) "${song.bitrate / 1000}kbps" else "?"
                val mb    = if (song.size > 0) "%.1fMB".format(song.size / 1_000_000.0) else "?"
                text = "$label\n  ${song.title}\n  ${song.path}\n  $fmt · $kbps · $mb"
                textSize = 12f
                setTextColor(if (i == 0) 0xFF4CAF50.toInt() else 0xFFFF9800.toInt())
                setPadding(16, 8, 16, 8)
            }
            container.addView(tv)
        }
    }

    class DupDiff : DiffUtil.ItemCallback<DuplicateGroup>() {
        override fun areItemsTheSame(a: DuplicateGroup, b: DuplicateGroup) =
            a.songs.firstOrNull()?.id == b.songs.firstOrNull()?.id
        override fun areContentsTheSame(a: DuplicateGroup, b: DuplicateGroup) = a == b
    }
}
