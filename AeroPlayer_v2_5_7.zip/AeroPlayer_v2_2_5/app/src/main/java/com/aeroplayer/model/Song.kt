package com.aeroplayer.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val path: String,
    val uri: Uri,
    val albumArtUri: Uri?,
    val trackNumber: Int = 0,
    val discNumber: Int = 0,
    val year: Int = 0,
    val size: Long = 0,
    var isLiked: Boolean = false,
    var playCount: Int = 0,
    /** MIME type del archivo (ej: "audio/flac", "audio/alac", "audio/x-wav"). */
    val mimeType: String = "",
    /** Bitrate en bits/segundo según MediaStore. 0 si no disponible. */
    val bitrate: Int = 0,
    /** Género musical (leído de MediaStore / etiqueta ID3). */
    val genre: String = "",
    /** Compositor (ID3 TCOM / MediaStore.Audio.Media.COMPOSER en API 30+). */
    val composer: String = "",
    /** BPM (beats per minute) de la pista — disponible vía MediaMetadataRetriever. */
    val bpm: Int = 0,
    /** Fecha de añadido a MediaStore (segundos epoch). Evita File.lastModified() en sort. */
    val dateAdded: Long = 0L,
    /** Fecha de última modificación en MediaStore (segundos epoch). */
    val dateModified: Long = 0L,
    /**
     * CUE Sheet: tiempo de inicio de esta pista dentro del archivo de audio base (ms).
     * 0 para canciones normales (no-CUE).
     */
    val cueStartMs: Long = 0L,
    /**
     * CUE Sheet: tiempo de fin de esta pista dentro del archivo de audio base (ms).
     * Long.MAX_VALUE para canciones normales o la última pista de un CUE.
     */
    val cueEndMs: Long = Long.MAX_VALUE
) {
    /** Etiqueta de formato legible para mostrar en UI (FLAC, ALAC, MQA, WAV, MP3…). */
    val formatLabel: String get() = when {
        mimeType.contains("flac", ignoreCase = true)                        -> "FLAC"
        mimeType.contains("alac", ignoreCase = true) ||
            path.endsWith(".alac", ignoreCase = true) ||
            path.endsWith(".m4a",  ignoreCase = true) &&
            mimeType.contains("mp4", ignoreCase = true)                     -> "ALAC"
        mimeType.contains("wav",  ignoreCase = true) ||
            mimeType.contains("wave", ignoreCase = true)                    -> "WAV"
        path.endsWith(".wv",   ignoreCase = true)                           -> "WavPack"
        path.endsWith(".ape",  ignoreCase = true)                           -> "APE"
        path.endsWith(".mqa",  ignoreCase = true)                           -> "MQA"
        mimeType.contains("opus",  ignoreCase = true)                       -> "Opus"
        mimeType.contains("ogg",   ignoreCase = true)                       -> "OGG"
        mimeType.contains("aac",   ignoreCase = true)                       -> "AAC"
        mimeType.contains("mpeg",  ignoreCase = true) ||
            path.endsWith(".mp3",  ignoreCase = true)                       -> "MP3"
        else -> mimeType.substringAfterLast("/").uppercase().take(6).ifBlank { "Audio" }
    }

    /** true si el formato es lossless (sin pérdida). */
    val isLossless: Boolean get() = formatLabel in setOf("FLAC", "ALAC", "WAV", "WavPack", "APE", "MQA")

    /** true si el bitrate supera el umbral Hi-Res (>1411 kbps ≈ CD, >2304 kbps = Hi-Res). */
    val isHiRes: Boolean get() = bitrate > 1_411_000 || isLossless && bitrate > 700_000

    /** Descripción corta para mostrar debajo del título: "FLAC · 1411 kbps" */
    val qualityBadge: String get() {
        val fmt = formatLabel
        val kbps = if (bitrate > 0) "${bitrate / 1000} kbps" else ""
        return listOf(fmt, kbps).filter { it.isNotBlank() }.joinToString(" · ")
    }
}
