package com.aeroplayer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityMainBinding
import com.aeroplayer.cast.CastManager
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.player.MiniPlayerFragment
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.graphics.RenderEffect
import android.graphics.Shader
import android.animation.ValueAnimator
import android.content.res.ColorStateList
import androidx.interpolator.view.animation.FastOutSlowInInterpolator

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    val viewModel: MainViewModel by viewModels()

    private var currentIndicatorColor: Int = 0
    private var indicatorAnimator: ValueAnimator? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val audioGranted = perms[Manifest.permission.READ_MEDIA_AUDIO] == true
            || perms[Manifest.permission.READ_EXTERNAL_STORAGE] == true
        if (audioGranted) viewModel.loadSongs()
        else showPermissionRationale()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        applyThemePreference()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ── FIX: Iconos recortados y píldoras desalineadas ───────────────────
        //
        // CAUSA RAÍZ DEL BUG:
        // El código anterior casteaba binding.bottomNavWrapper.layoutParams a
        // CoordinatorLayout.LayoutParams. Si el padre directo del wrapper en el
        // XML NO es un CoordinatorLayout (puede ser FrameLayout, LinearLayout, etc.)
        // ese cast lanza ClassCastException en runtime. El bottomMargin nunca se
        // aplica → la barra queda pegada al fondo del sistema → Material3 dibuja
        // el indicador pill fuera de los límites visibles → se recorta.
        //
        // TAMBIÉN: sin clipToPadding=false el canvas de la View corta cualquier
        // contenido que intente dibujarse dentro del área de padding, que es
        // exactamente donde vive la píldora activa de Material3.
        //
        // SOLUCIÓN:
        //  1. WindowCompat.setDecorFitsSystemWindows(false) – control manual de insets.
        //  2. clipToPadding=false en el wrapper – la pill se dibuja sin clipear.
        //  3. setPadding() en el wrapper con el inset del sistema + 16dp de margen
        //     visual. Funciona con CUALQUIER tipo de LayoutParams, sin ClassCastException.
        //  4. WindowInsetsCompat.CONSUMED en el root para evitar que NavigationBar
        //     Material3 vuelva a aplicar sus propios insets encima (doble-padding).

        WindowCompat.setDecorFitsSystemWindows(window, false)

        // clipToPadding=false: permite a Material3 dibujar la pill activa
        // en la zona de padding sin que el canvas la recorte.
        binding.bottomNavWrapper.clipToPadding = false

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            // Solo top+lados al root — el bottom lo maneja el wrapper directamente.
            v.setPadding(bars.left, bars.top, bars.right, 0)

            // Aplicar solo el inset de la gesture bar como margin del wrapper (no padding).
            // Esto posiciona la barra sobre la gesture bar del sistema sin agrandarla.
            val lp = binding.bottomNavWrapper.layoutParams
            if (lp is androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams) {
                val dp16 = (16 * resources.displayMetrics.density + 0.5f).toInt()
                lp.bottomMargin = bars.bottom + dp16
                binding.bottomNavWrapper.layoutParams = lp
            }

            // Consumir los insets para que los hijos (NavigationBar) no los
            // vuelvan a procesar y generen doble padding.
            WindowInsetsCompat.CONSUMED
        }

        setupNavigation()
        checkPermissions()
        PlayerController.connect(this)
        CastManager.init(this)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.miniPlayerContainer, MiniPlayerFragment())
                .commit()
        }

        val accentColor = com.aeroplayer.ui.ThemeManager.getAccentColor(this)
        currentIndicatorColor = accentColor
        applyNavIndicatorColor(accentColor, animate = false)

        applyCustomBackground()
        applyBlurToNav()

        // FIX ANIMACIÓN DE CARGA: conectar isScanning al overlay de la activity.
        // El overlay existía en el XML pero nadie lo mostraba/ocultaba.
        viewModel.isScanning.observe(this) { scanning ->
            binding.scanningOverlay?.visibility = if (scanning) View.VISIBLE else View.GONE
        }

        // También mostrar el contador de canciones mientras escanea
        viewModel.allSongs.observe(this) { songs ->
            if (songs != null && (viewModel.isScanning.value == true)) {
                binding.tvScanningCount?.text = "${songs.size} canciones encontradas"
            }
        }

        PlayerController.currentSong.observe(this) { song ->
            val container = binding.miniPlayerContainer
            val divider   = binding.navDivider

            if (song != null && container.visibility != View.VISIBLE) {
                container.visibility = View.VISIBLE
                divider.visibility   = View.VISIBLE
                binding.bottomNavWrapper.translationY = 200f
                binding.bottomNavWrapper.animate()
                    .translationY(0f)
                    .setDuration(300)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(2f))
                    .start()
            } else if (song == null && container.visibility == View.VISIBLE) {
                container.animate()
                    .alpha(0f)
                    .setDuration(150)
                    .withEndAction {
                        container.visibility = View.GONE
                        container.alpha      = 1f
                        divider.visibility   = View.GONE
                    }.start()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        })
    }

    private fun applyCustomBackground() {
        val uri = com.aeroplayer.ui.ThemeManager.getCustomBackground(this)
        if (uri != null) {
            binding.ivCustomBackground?.visibility = View.VISIBLE
            binding.customBgOverlay?.visibility = View.VISIBLE
            com.bumptech.glide.Glide.with(this)
                .load(uri)
                .centerCrop()
                .apply { binding.ivCustomBackground?.let { into(it) } }
        } else {
            binding.ivCustomBackground?.visibility = View.GONE
            binding.customBgOverlay?.visibility = View.GONE
        }
    }

    /**
     * FIX BUG FONDO HOME: HomeFragment usa este método para mostrar su wallpaper de perfil
     * a través del mismo ImageView de la Activity (ivCustomBackground), que está DEBAJO del
     * CoordinatorLayout y es visible desde todos los fragments porque ellos son transparentes.
     * Antes HomeFragment usaba window.setBackgroundDrawable(), que el CoordinatorLayout tapaba
     * completamente con su android:background="@color/background_dark".
     */
    fun setProfileWallpaper(uri: android.net.Uri?) {
        if (uri != null) {
            binding.ivCustomBackground?.visibility = View.VISIBLE
            binding.customBgOverlay?.visibility = View.VISIBLE
            com.bumptech.glide.Glide.with(this)
                .load(uri)
                .centerCrop()
                .apply { binding.ivCustomBackground?.let { into(it) } }
        } else {
            // Sin wallpaper de perfil: restaurar al wallpaper de tema global (si existe) o ocultar
            val themeUri = com.aeroplayer.ui.ThemeManager.getCustomBackground(this)
            if (themeUri != null) {
                binding.ivCustomBackground?.visibility = View.VISIBLE
                binding.customBgOverlay?.visibility = View.VISIBLE
                com.bumptech.glide.Glide.with(this)
                    .load(themeUri)
                    .centerCrop()
                    .apply { binding.ivCustomBackground?.let { into(it) } }
            } else {
                binding.ivCustomBackground?.visibility = View.GONE
                binding.customBgOverlay?.visibility = View.GONE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        com.aeroplayer.service.FolderWatcher.start(this) { _ ->
            viewModel.refreshLibrary()
        }
        applyCustomBackground()
        val accentColor = com.aeroplayer.ui.ThemeManager.getAccentColor(this)
        if (currentIndicatorColor != 0 && accentColor != currentIndicatorColor) {
            currentIndicatorColor = accentColor
            recreate()
            return
        }
        applyNavIndicatorColor(accentColor, animate = false)
        applyYtMusicTabVisibility()
        PlayerController.forceSyncState()
    }

    private fun applyYtMusicTabVisibility() {
        val enabled = getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .getBoolean("yt_music_enabled", false)
        binding.bottomNav.menu.findItem(R.id.ytMusicFragment)?.isVisible = enabled
    }

    private fun applyBlurToNav() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            binding.bottomNavWrapper.setRenderEffect(
                RenderEffect.createBlurEffect(18f, 18f, Shader.TileMode.CLAMP)
            )
        }
    }

    private fun animateIndicatorColor(from: Int, to: Int) {
        if (from == to) return
        indicatorAnimator?.cancel()
        indicatorAnimator = ValueAnimator.ofArgb(from, to).apply {
            duration = 500L
            interpolator = FastOutSlowInInterpolator()
            addUpdateListener { animator ->
                val color = animator.animatedValue as Int
                applyNavIndicatorColor(color, animate = false)
                currentIndicatorColor = color
            }
        }.also { it.start() }
    }

    private fun applyNavIndicatorColor(color: Int, animate: Boolean) {
        binding.bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(color)
    }

    private fun setupNavigation() {
        val navHost = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        binding.bottomNav.setupWithNavController(navHost.navController)
        applyYtMusicTabVisibility()
    }

    private fun checkPermissions() {
        // FIX CARGA DE MÚSICA: separar permiso de AUDIO (obligatorio para cargar canciones)
        // de READ_MEDIA_IMAGES (opcional, solo para wallpapers/portadas del sistema).
        // Antes, si READ_MEDIA_IMAGES no estaba concedido, loadSongs() nunca se llamaba
        // porque "needed" no estaba vacío aunque el audio SÍ estaba permitido.
        val audioPerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        // Permisos opcionales — se piden pero NO bloquean la carga de música
        val optionalPerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            emptyArray()
        }

        val audioGranted = audioPerms.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        // Siempre cargar canciones si el permiso de audio está concedido
        if (audioGranted) viewModel.loadSongs()

        // Pedir los permisos que falten (audio + opcionales juntos en un solo diálogo)
        val needed = (audioPerms + optionalPerms).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
        else if (!audioGranted) {
            // Sin permiso de audio y sin nada que pedir → mostrar rationale
            showPermissionRationale()
        }
    }

    private fun showPermissionRationale() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permiso necesario")
            .setMessage(
                "Aero Player necesita acceso a tus archivos de audio para " +
                "mostrar tu música. Por favor, activa el permiso en Configuración."
            )
            .setPositiveButton("Ir a Configuración") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    }
                )
            }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    private fun applyThemePreference() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val mode  = prefs.getString("theme_mode", "dark") ?: "dark"
        if (mode == "aero") {
            // El tema Aero sigue al sistema para dark/light dentro del tema
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            return
        }
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "auto"  -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                else    -> AppCompatDelegate.MODE_NIGHT_YES
            }
        )
    }

    fun toggleTheme() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val current = prefs.getString("theme_mode", "dark") ?: "dark"
        val next = if (current == "dark") "light" else "dark"
        prefs.edit()
            .putString("theme_mode", next)
            .putBoolean("theme_light", next == "light")
            .apply()
        AppCompatDelegate.setDefaultNightMode(
            if (next == "light") AppCompatDelegate.MODE_NIGHT_NO
            else AppCompatDelegate.MODE_NIGHT_YES
        )
        recreate()
    }

    fun isLightTheme(): Boolean {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val mode = prefs.getString("theme_mode", "dark") ?: "dark"
        return mode == "light"
    }

    private var lastHomeTime = 0L
    private val DOUBLE_HOME_WINDOW_MS = 1_500L

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        checkDoubleHome()
    }

    private fun checkDoubleHome() {
        val now = System.currentTimeMillis()
        if (now - lastHomeTime < DOUBLE_HOME_WINDOW_MS) {
            com.aeroplayer.ui.home.HomeFragment.clearQuickPickCache()
            android.widget.Toast.makeText(
                this, "Selección rápida actualizada", android.widget.Toast.LENGTH_SHORT
            ).show()
            lastHomeTime = 0L
        } else {
            lastHomeTime = now
        }
    }

    override fun onStop() {
        super.onStop()
        com.aeroplayer.service.FolderWatcher.stopAll()
        // FIX SESSION 2: guardar posición exacta cada vez que la app va a background.
        // Antes solo se guardaba al cambiar de canción — si el usuario cerraba la app
        // desde la misma canción, la posición quedaba en 0 y empezaba desde el inicio.
        PlayerController.savePosition()
    }

    override fun onDestroy() {
        indicatorAnimator?.cancel()
        if (isFinishing) PlayerController.disconnect()
        CastManager.release()
        super.onDestroy()
    }
}
