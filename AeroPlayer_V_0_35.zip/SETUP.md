# AeroPlayer — Instrucciones de compilación

## Paso 1: Obtener el gradle-wrapper.jar (necesario una sola vez)

El archivo `gradle/wrapper/gradle-wrapper.jar` no está incluido en el ZIP
porque es un binario. Hay dos formas de obtenerlo:

### Opción A — Android Studio (recomendada)
1. Abre Android Studio
2. `File → Open` → selecciona la carpeta `AeroPlayer`
3. Android Studio detecta que falta el wrapper y lo descarga automáticamente
4. Espera que termine la sincronización de Gradle

### Opción B — Línea de comandos (si tienes Gradle instalado)
```bash
cd AeroPlayer
gradle wrapper --gradle-version 8.4
```

### Opción C — Descargar manualmente
Descarga el JAR desde:
https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar

Colócalo en: `gradle/wrapper/gradle-wrapper.jar`

## Paso 2: Dar permisos al gradlew
```bash
chmod +x gradlew
```

## Paso 3: Compilar
```bash
./gradlew assembleDebug
```
El APK quedará en `app/build/outputs/apk/debug/app-debug.apk`

## Compilar desde GitHub Actions
El workflow de GitHub descarga el wrapper automáticamente.
Crea el archivo `.github/workflows/build.yml` con el contenido
del archivo `github-actions-build.yml` incluido en este proyecto.
