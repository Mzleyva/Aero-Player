package com.aeroplayer.utils

import android.content.Context
import android.media.audiofx.LoudnessEnhancer
import android.util.Log
import com.aeroplayer.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.RandomAccessFile
import kotlin.math.pow

/**
 * Normalización de volumen vía ReplayGain — v1.8.2
 *
 * FIX v1.8.2: implementación real de lectura de tags RG.
 *   Antes: readReplayGainTag() siempre retornaba null porque
 *   MediaMetadataRetriever no expone REPLAYGAIN_TRACK_GAIN.
 *   Ahora: leemos el archivo directamente en binario para extraer
 *   las etiquetas RG de los formatos más comunes:
 *     - ID3v2 (MP3): busca el frame TXXX con "REPLAYGAIN_TRACK_GAIN"
 *     - Vorbis Comment (FLAC/OGG): busca el bloque VORBIS_COMMENT
 *     - APEv2 (APE, WV): busca el tag "REPLAYGAIN_TRACK_GAIN"
 *
 * Estrategia de fallback:
 *   1. Leer tag RG embebido del archivo (real)
 *   2. Estimación por bitrate (aproximada, mejor que nada)
 *   3. Sin cambio de volumen (0 dB)
 */
object ReplayGainManager {

    private const val TAG          = "ReplayGainManager"
    private const val TARGET_LUFS  = -14f
    private const val MAX_BOOST_DB =  12f
    private const val MAX_CUT_DB   = -12f
    private const val READ_LIMIT   = 128_000   // leer hasta 128KB del archivo para tags

    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var currentGainDb: Float = 0f

    fun init(audioSessionId: Int) {
        release()
        if (audioSessionId == 0) return
        runCatching {
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply { enabled = true }
        }.onFailure { Log.w(TAG, "LoudnessEnhancer no disponible: ${it.message}") }
    }

    fun release() {
        runCatching { loudnessEnhancer?.release() }
        loudnessEnhancer = null
        currentGainDb = 0f
    }

    suspend fun applyGain(context: Context, song: Song, mode: Mode = Mode.TRACK): Float? =
        withContext(Dispatchers.IO) {
            val gain = readReplayGainTag(context, song, mode)
                ?: estimateGain(song)
                ?: return@withContext null

            val clamped = gain.coerceIn(MAX_CUT_DB, MAX_BOOST_DB)
            applyGainDb(clamped)
            currentGainDb = clamped
            Log.d(TAG, "RG aplicado: ${clamped}dB para '${song.title}' (fuente: tag real o estimado)")
            clamped
        }

    fun resetGain() { applyGainDb(0f); currentGainDb = 0f }
    fun getCurrentGainDb() = currentGainDb
    enum class Mode { TRACK, ALBUM }

    // ── Lectura real de tags ──────────────────────────────────────────────────

    private fun readReplayGainTag(context: Context, song: Song, mode: Mode): Float? {
        val path = getFilePath(context, song) ?: return null
        return runCatching {
            RandomAccessFile(path, "r").use { raf ->
                val buf = ByteArray(minOf(READ_LIMIT, raf.length().toInt()))
                raf.read(buf)
                // Intentar cada formato
                readId3v2ReplayGain(buf, mode)
                    ?: readVorbisCommentReplayGain(buf, mode)
                    ?: readApev2ReplayGain(buf, mode)
            }
        }.getOrNull()
    }

    /**
     * Lee TXXX frames de ID3v2 buscando REPLAYGAIN_TRACK_GAIN / REPLAYGAIN_ALBUM_GAIN.
     * Soporta ID3v2.3 y ID3v2.4.
     */
    private fun readId3v2ReplayGain(buf: ByteArray, mode: Mode): Float? {
        if (buf.size < 10) return null
        // Verificar magic "ID3"
        if (buf[0] != 'I'.code.toByte() || buf[1] != 'D'.code.toByte() || buf[2] != '3'.code.toByte()) return null

        val version = buf[3].toInt() and 0xFF
        if (version < 3) return null  // ID3v2.2 usa frames de 3 chars — ignoramos

        // Tamaño del tag ID3v2 (syncsafe integer de 4 bytes)
        val tagSize = ((buf[6].toInt() and 0x7F) shl 21) or
                      ((buf[7].toInt() and 0x7F) shl 14) or
                      ((buf[8].toInt() and 0x7F) shl  7) or
                       (buf[9].toInt() and 0x7F)
        val hasExtHeader = (buf[5].toInt() and 0x40) != 0
        var pos = 10 + if (hasExtHeader) readInt32(buf, 10) else 0

        val targetKeys = if (mode == Mode.TRACK)
            listOf("REPLAYGAIN_TRACK_GAIN")
        else
            listOf("REPLAYGAIN_ALBUM_GAIN", "REPLAYGAIN_TRACK_GAIN")

        while (pos + 10 < buf.size && pos < tagSize + 10) {
            val frameId = String(buf, pos, 4, Charsets.ISO_8859_1)
            if (frameId == "\u0000\u0000\u0000\u0000") break

            val frameSize = if (version >= 4)
                syncsafeInt(buf, pos + 4)
            else
                readInt32(buf, pos + 4)

            if (frameSize <= 0 || pos + 10 + frameSize > buf.size) break

            if (frameId == "TXXX") {
                // encoding byte + description null-terminated + value
                val encoding = buf[pos + 10].toInt()
                val nullChar = if (encoding == 1 || encoding == 2) byteArrayOf(0, 0) else byteArrayOf(0)
                val contentStart = pos + 11
                val contentEnd   = pos + 10 + frameSize

                // Encontrar fin de descripción
                var nullPos = contentStart
                if (nullChar.size == 2) {
                    while (nullPos + 1 < contentEnd && !(buf[nullPos] == 0.toByte() && buf[nullPos+1] == 0.toByte())) nullPos += 2
                    nullPos += 2
                } else {
                    while (nullPos < contentEnd && buf[nullPos] != 0.toByte()) nullPos++
                    nullPos++
                }
                val desc = String(buf, contentStart, (nullPos - 1 - contentStart).coerceAtLeast(0),
                    if (encoding == 1 || encoding == 2) Charsets.UTF_16 else Charsets.ISO_8859_1)
                    .uppercase().trim()

                if (nullPos < contentEnd && targetKeys.any { it == desc }) {
                    val value = String(buf, nullPos, contentEnd - nullPos,
                        if (encoding == 1 || encoding == 2) Charsets.UTF_16 else Charsets.ISO_8859_1).trim()
                    return parseGainValue(value)
                }
            }
            pos += 10 + frameSize
        }
        return null
    }

    /**
     * Lee VORBIS_COMMENT de FLAC o OGG buscando REPLAYGAIN_TRACK_GAIN.
     * En FLAC el bloque empieza con 0x04 (VORBIS_COMMENT block type).
     */
    private fun readVorbisCommentReplayGain(buf: ByteArray, mode: Mode): Float? {
        val targetKeys = if (mode == Mode.TRACK)
            listOf("REPLAYGAIN_TRACK_GAIN")
        else
            listOf("REPLAYGAIN_ALBUM_GAIN", "REPLAYGAIN_TRACK_GAIN")

        // Buscar firma FLAC (fLaC)
        var pos = 0
        val flacMagic = byteArrayOf('f'.code.toByte(), 'L'.code.toByte(), 'a'.code.toByte(), 'C'.code.toByte())
        val flacIdx = indexOfBytes(buf, flacMagic)
        if (flacIdx >= 0) {
            pos = flacIdx + 4
            while (pos + 4 < buf.size) {
                val blockHeader = buf[pos].toInt() and 0xFF
                val blockType   = blockHeader and 0x7F
                val isLast      = (blockHeader and 0x80) != 0
                val blockSize   = ((buf[pos+1].toInt() and 0xFF) shl 16) or
                                  ((buf[pos+2].toInt() and 0xFF) shl  8) or
                                   (buf[pos+3].toInt() and 0xFF)
                pos += 4
                if (blockType == 4 && pos + blockSize <= buf.size) {  // VORBIS_COMMENT
                    val result = parseVorbisCommentBlock(buf, pos, blockSize, targetKeys)
                    if (result != null) return result
                }
                pos += blockSize
                if (isLast) break
            }
        }

        // Buscar en OGG (buscar "REPLAYGAIN_TRACK_GAIN=" directamente como string en el buffer)
        for (key in targetKeys) {
            val keyBytes = "$key=".toByteArray(Charsets.UTF_8)
            val idx = indexOfBytes(buf, keyBytes)
            if (idx >= 0) {
                val end = buf.indexOf(0, idx + keyBytes.size).takeIf { it > 0 } ?: minOf(idx + keyBytes.size + 20, buf.size)
                val value = String(buf, idx + keyBytes.size, end - idx - keyBytes.size, Charsets.UTF_8).trim()
                return parseGainValue(value)
            }
        }
        return null
    }

    private fun parseVorbisCommentBlock(buf: ByteArray, start: Int, size: Int, targetKeys: List<String>): Float? {
        var pos = start
        val end = start + size
        if (pos + 4 > end) return null
        val vendorLen = readInt32LE(buf, pos); pos += 4 + vendorLen
        if (pos + 4 > end) return null
        val commentCount = readInt32LE(buf, pos); pos += 4
        repeat(commentCount) {
            if (pos + 4 > end) return null
            val commentLen = readInt32LE(buf, pos); pos += 4
            if (pos + commentLen > end) return null
            val comment = String(buf, pos, commentLen, Charsets.UTF_8).uppercase()
            pos += commentLen
            for (key in targetKeys) {
                if (comment.startsWith("$key=")) {
                    return parseGainValue(comment.removePrefix("$key="))
                }
            }
        }
        return null
    }

    /**
     * Lee APEv2 tags al final del archivo buscando REPLAYGAIN_TRACK_GAIN.
     */
    private fun readApev2ReplayGain(buf: ByteArray, mode: Mode): Float? {
        val targetKeys = if (mode == Mode.TRACK)
            listOf("REPLAYGAIN_TRACK_GAIN")
        else
            listOf("REPLAYGAIN_ALBUM_GAIN", "REPLAYGAIN_TRACK_GAIN")

        // APEv2 header/footer magic: "APETAGEX"
        val magic = "APETAGEX".toByteArray(Charsets.ISO_8859_1)
        var searchPos = buf.size - magic.size
        while (searchPos >= 0) {
            if (indexOfBytes(buf, magic, searchPos) == searchPos) {
                // Encontramos el footer APEv2 — parsear desde ahí hacia atrás
                val itemCount = readInt32LE(buf, searchPos + 12)
                var pos = searchPos - readInt32LE(buf, searchPos + 8) + 32  // saltar header
                if (pos < 0) pos = 0
                repeat(itemCount) {
                    if (pos + 8 > buf.size) return null
                    val valueSize = readInt32LE(buf, pos); pos += 4
                    pos += 4  // flags
                    var keyEnd = pos
                    while (keyEnd < buf.size && buf[keyEnd] != 0.toByte()) keyEnd++
                    val key = String(buf, pos, keyEnd - pos, Charsets.ISO_8859_1).uppercase()
                    pos = keyEnd + 1
                    if (pos + valueSize > buf.size) return null
                    if (targetKeys.contains(key)) {
                        val value = String(buf, pos, valueSize, Charsets.UTF_8).trim()
                        return parseGainValue(value)
                    }
                    pos += valueSize
                }
                break
            }
            searchPos--
        }
        return null
    }

    // ── Utils de parsing ──────────────────────────────────────────────────────

    /** Parsea "-3.21 dB" o "+1.5dB" → Float en dB (convertido desde dB a dB — ya es dB). */
    private fun parseGainValue(raw: String): Float? {
        val clean = raw.trim().uppercase().replace("DB", "").replace("LU", "").trim()
        return clean.toFloatOrNull()?.let { it }
    }

    private fun readInt32(buf: ByteArray, pos: Int): Int {
        if (pos + 3 >= buf.size) return 0
        return ((buf[pos].toInt()   and 0xFF) shl 24) or
               ((buf[pos+1].toInt() and 0xFF) shl 16) or
               ((buf[pos+2].toInt() and 0xFF) shl  8) or
                (buf[pos+3].toInt() and 0xFF)
    }

    private fun readInt32LE(buf: ByteArray, pos: Int): Int {
        if (pos + 3 >= buf.size) return 0
        return  (buf[pos].toInt()   and 0xFF)         or
               ((buf[pos+1].toInt() and 0xFF) shl  8) or
               ((buf[pos+2].toInt() and 0xFF) shl 16) or
               ((buf[pos+3].toInt() and 0xFF) shl 24)
    }

    private fun syncsafeInt(buf: ByteArray, pos: Int): Int {
        if (pos + 3 >= buf.size) return 0
        return ((buf[pos].toInt()   and 0x7F) shl 21) or
               ((buf[pos+1].toInt() and 0x7F) shl 14) or
               ((buf[pos+2].toInt() and 0x7F) shl  7) or
                (buf[pos+3].toInt() and 0x7F)
    }

    private fun indexOfBytes(haystack: ByteArray, needle: ByteArray, start: Int = 0): Int {
        outer@ for (i in start..haystack.size - needle.size) {
            for (j in needle.indices) { if (haystack[i + j] != needle[j]) continue@outer }
            return i
        }
        return -1
    }

    private fun ByteArray.indexOf(b: Byte, from: Int): Int {
        for (i in from until size) { if (this[i] == b) return i }
        return -1
    }

    private fun getFilePath(context: Context, song: Song): String? {
        return runCatching {
            context.contentResolver.openFileDescriptor(song.uri, "r")?.use { pfd ->
                // /proc/self/fd/<fd> → symlink al archivo real
                val fdPath = "/proc/self/fd/${pfd.fd}"
                java.io.File(fdPath).canonicalPath
            }
        }.getOrNull()
    }

    // ── Estimación de ganancia (fallback) ────────────────────────────────────

    private fun estimateGain(song: Song): Float? {
        if (song.duration <= 0) return null
        val bitrateKbps = (song.bitrate / 1000).coerceAtLeast(0)
        return when {
            bitrateKbps == 0  -> null
            bitrateKbps < 128 -> 1.5f
            else              -> 0f
        }
    }

    // ── Aplicación de ganancia ────────────────────────────────────────────────

    private fun applyGainDb(gainDb: Float) {
        val enhancer = loudnessEnhancer ?: return
        runCatching {
            if (gainDb >= 0) {
                enhancer.setTargetGain((gainDb * 100).toInt())
                enhancer.enabled = gainDb > 0f
            } else {
                enhancer.setTargetGain(0); enhancer.enabled = false
                val linearGain = 10f.pow(gainDb / 20f).coerceIn(0f, 1f)
                com.aeroplayer.service.PlayerController.setNormalizationVolume(linearGain)
            }
        }.onFailure { Log.w(TAG, "Error aplicando ganancia: ${it.message}") }
    }

    fun dbToLinear(db: Float) = 10f.pow(db / 20f)
}
