package com.aeroplayer.app.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.app.databinding.*
import com.aeroplayer.app.ui.MainActivity
import com.aeroplayer.app.ui.PlayerActivity
import com.aeroplayer.app.ui.PlaylistDetailActivity
import com.aeroplayer.app.ui.adapters.SongAdapter
import com.aeroplayer.app.ui.adapters.PlaylistAdapter
import com.aeroplayer.app.ui.viewmodel.PlayerViewModel
import kotlinx.coroutines.launch

// ─── HOME ──────────────────────────────────────────────────────────────────
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PlayerViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recentAdapter = SongAdapter { song ->
            viewModel.playSong(song)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        val recommendedAdapter = SongAdapter { song ->
            viewModel.playSong(song)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        val playlistAdapter = PlaylistAdapter { playlist ->
            val intent = Intent(requireContext(), PlaylistDetailActivity::class.java)
            intent.putExtra("playlist_id", playlist.id)
            startActivity(intent)
        }

        binding.rvRecentSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = recentAdapter
        }

        binding.rvRecommended.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = recommendedAdapter
        }

        binding.rvQuickPlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = playlistAdapter
        }

        lifecycleScope.launch {
            viewModel.repository.getRecentlyPlayed(8).collect {
                recentAdapter.submitList(it)
            }
        }

        lifecycleScope.launch {
            viewModel.repository.getAllPlaylists().collect {
                playlistAdapter.submitList(it.take(6))
            }
        }

        lifecycleScope.launch {
            val recs = viewModel.repository.getRecommendations()
            recommendedAdapter.submitList(recs)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

// ─── LIBRARY ───────────────────────────────────────────────────────────────
class LibraryFragment : Fragment() {

    private var _binding: FragmentLibraryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PlayerViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLibraryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val songAdapter = SongAdapter { song ->
            lifecycleScope.launch {
                val allSongs = mutableListOf<com.aeroplayer.app.data.model.Song>()
            }
            viewModel.playSong(song)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        val playlistAdapter = PlaylistAdapter { playlist ->
            val intent = Intent(requireContext(), PlaylistDetailActivity::class.java)
            intent.putExtra("playlist_id", playlist.id)
            startActivity(intent)
        }

        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = songAdapter
        }

        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = playlistAdapter
        }

        // Tabs: Canciones / Playlists / Me gusta
        binding.tabLayout.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab) {
                when (tab.position) {
                    0 -> {
                        binding.rvSongs.visibility = View.VISIBLE
                        binding.rvPlaylists.visibility = View.GONE
                        lifecycleScope.launch {
                            viewModel.repository.getAllSongs().collect { songAdapter.submitList(it) }
                        }
                    }
                    1 -> {
                        binding.rvSongs.visibility = View.GONE
                        binding.rvPlaylists.visibility = View.VISIBLE
                        lifecycleScope.launch {
                            viewModel.repository.getAllPlaylists().collect { playlistAdapter.submitList(it) }
                        }
                    }
                    2 -> {
                        binding.rvSongs.visibility = View.VISIBLE
                        binding.rvPlaylists.visibility = View.GONE
                        lifecycleScope.launch {
                            viewModel.repository.getLikedSongs().collect { songAdapter.submitList(it) }
                        }
                    }
                }
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
        })

        // Cargar canciones por defecto
        lifecycleScope.launch {
            viewModel.repository.getAllSongs().collect { songAdapter.submitList(it) }
        }

        // Botón nueva playlist
        binding.fabNewPlaylist.setOnClickListener {
            showCreatePlaylistDialog()
        }
    }

    private fun showCreatePlaylistDialog() {
        val editText = android.widget.EditText(requireContext())
        editText.hint = "Nombre de la playlist"
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Nueva playlist")
            .setView(editText)
            .setPositiveButton("Crear") { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotEmpty()) {
                    lifecycleScope.launch { viewModel.repository.createPlaylist(name) }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

// ─── SEARCH ────────────────────────────────────────────────────────────────
class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PlayerViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = SongAdapter { song ->
            viewModel.playSong(song)
            startActivity(Intent(requireContext(), PlayerActivity::class.java))
        }

        binding.rvSearchResults.apply {
            layoutManager = LinearLayoutManager(context)
            this.adapter = adapter
        }

        binding.searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { search(it, adapter) }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                if ((newText?.length ?: 0) >= 2) search(newText!!, adapter)
                return true
            }
        })
    }

    private fun search(query: String, adapter: SongAdapter) {
        lifecycleScope.launch {
            viewModel.repository.searchSongs(query).collect { adapter.submitList(it) }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
