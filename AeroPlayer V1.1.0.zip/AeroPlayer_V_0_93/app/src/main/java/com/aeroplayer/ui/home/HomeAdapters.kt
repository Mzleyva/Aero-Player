package com.aeroplayer.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.databinding.ItemSongHorizontalBinding
import com.aeroplayer.databinding.ItemShortcutBinding
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.aeroplayer.R

// ── Quick Pick horizontal song card ─────────────────────────────────────────
class SongHorizontalAdapter(
    private val onClick: (Song, List<Song>) -> Unit
) : ListAdapter<Song, SongHorizontalAdapter.VH>(SongDiff()) {

    inner class VH(val b: ItemSongHorizontalBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivCover.clipToOutline   = true
        b.ivCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text = song.title
        holder.b.tvArtist.text = song.artist
        Glide.with(holder.b.ivCover)
            .load(
                com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
                    ?: song.albumArtUri
            )
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.b.ivCover)
        holder.b.root.setOnClickListener { onClick(song, currentList) }

        // Animación staggered de entrada — solo la primera vez que se muestra
        val tag = holder.b.root.getTag(com.aeroplayer.R.id.tag_animated)
        if (tag == null) {
            holder.b.root.setTag(com.aeroplayer.R.id.tag_animated, true)
            holder.b.root.alpha = 0f
            holder.b.root.translationY = 40f
            holder.b.root.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay((position * 40L).coerceAtMost(400L))
                .setDuration(300)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}

// ── Quick Pick HORIZONTAL adapter — tarjetas con scroll lateral + menú ───────
class SongQuickPickAdapter(
    private val onClick:         (Song, List<Song>) -> Unit,
    private val onAddToQueue:    (Song) -> Unit,
    private val onAddToPlaylist: (Song) -> Unit,
    private val onViewArtist:    (String) -> Unit
) : ListAdapter<Song, SongQuickPickAdapter.VH>(SongQPDiff()) {

    inner class VH(val b: ItemSongHorizontalBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSongHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivCover.clipToOutline   = true
        b.ivCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text  = song.title
        holder.b.tvArtist.text = song.artist

        Glide.with(holder.b.ivCover)
            .load(
                com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
                    ?: song.albumArtUri
            )
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.b.ivCover)

        holder.b.root.setOnClickListener { onClick(song, currentList) }
        holder.b.btnMore.setOnClickListener { v -> showMenu(v, song) }

        // Animación staggered de entrada
        val tag = holder.b.root.getTag(R.id.tag_animated)
        if (tag == null) {
            holder.b.root.setTag(R.id.tag_animated, true)
            holder.b.root.alpha = 0f
            holder.b.root.translationY = 30f
            holder.b.root.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay((position * 40L).coerceAtMost(300L))
                .setDuration(280)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun showMenu(anchor: android.view.View, song: Song) {
        val popup = androidx.appcompat.widget.PopupMenu(anchor.context, anchor, android.view.Gravity.END)
        popup.menu.apply {
            add(0, 0, 0, "🎤  Ver artista")
            add(0, 1, 1, "➕  Agregar a cola")
            add(0, 2, 2, "📋  Agregar a playlist")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                0 -> { onViewArtist(song.artist); true }
                1 -> { onAddToQueue(song); true }
                2 -> { onAddToPlaylist(song); true }
                else -> false
            }
        }
        popup.show()
    }

    class SongQPDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}


// ── Quick Pick GRID adapter (3 columnas, estilo YT Music) ────────────────────
class SongGridAdapter(
    private val onClick: (Song, List<Song>) -> Unit
) : ListAdapter<Song, SongGridAdapter.VH>(SongGridDiff()) {

    inner class VH(val b: com.aeroplayer.databinding.ItemSongGridBinding) :
        RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = com.aeroplayer.databinding.ItemSongGridBinding.inflate(
            LayoutInflater.from(parent.context), parent, false)
        b.ivCover.clipToOutline   = true
        b.ivCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text  = song.title
        holder.b.tvArtist.text = song.artist
        Glide.with(holder.b.ivCover)
            .load(
                com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
                    ?: song.albumArtUri
            )
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.b.ivCover)
        holder.b.root.setOnClickListener { onClick(song, currentList) }

        // Animación staggered de entrada
        val tag = holder.b.root.getTag(R.id.tag_animated)
        if (tag == null) {
            holder.b.root.setTag(R.id.tag_animated, true)
            holder.b.root.alpha = 0f
            holder.b.root.scaleX = 0.92f
            holder.b.root.scaleY = 0.92f
            holder.b.root.animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay((position * 30L).coerceAtMost(300L))
                .setDuration(280)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    class SongGridDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}

// ── Shortcut model ───────────────────────────────────────────────────────────
enum class ShortcutType { PLAYLIST, LIKED, ALBUM }

data class Shortcut(
    val id: Long,
    val name: String,
    val coverUri: String?,
    val type: ShortcutType
)

// ── Shortcut grid adapter ────────────────────────────────────────────────────
class ShortcutAdapter(
    private val onClick: (Shortcut) -> Unit
) : ListAdapter<Shortcut, ShortcutAdapter.VH>(ShortcutDiff()) {

    inner class VH(val b: ItemShortcutBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemShortcutBinding.inflate(LayoutInflater.from(parent.context), parent, false).also { b ->
            b.ivCover.clipToOutline   = true
            b.ivCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        })

    override fun onBindViewHolder(holder: VH, position: Int) {
        val sc = getItem(position)
        holder.b.tvName.text = sc.name
        Glide.with(holder.b.ivCover)
            .load(sc.coverUri)
            .placeholder(R.drawable.ic_playlist_placeholder)
            .error(R.drawable.ic_playlist_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.b.ivCover)
        holder.b.root.setOnClickListener { onClick(sc) }
    }

    class ShortcutDiff : DiffUtil.ItemCallback<Shortcut>() {
        override fun areItemsTheSame(a: Shortcut, b: Shortcut) = a.id == b.id && a.type == b.type
        override fun areContentsTheSame(a: Shortcut, b: Shortcut) = a == b
    }
}
