package com.aeroplayer.ui.playlist

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemPlaylistSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class PlaylistSongsAdapter(
    private val onSongClick: (Song, List<Song>) -> Unit,
    private val onLikeClick: (Song) -> Unit,
    private val onRemoveClick: (Song) -> Unit
) : ListAdapter<Song, PlaylistSongsAdapter.VH>(SongDiff()) {

    inner class VH(val b: ItemPlaylistSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPlaylistSongBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text = song.title
            tvArtist.text = song.artist
            tvDuration.text = FormatUtils.formatDuration(song.duration)

            Glide.with(ivAlbumArt)
                .load(song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivAlbumArt)

            ivLike.setImageResource(
                if (song.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            ivLike.setColorFilter(
                ContextCompat.getColor(
                    root.context,
                    if (song.isLiked) R.color.accent_pink else R.color.text_secondary
                )
            )
            ivLike.setOnClickListener { onLikeClick(song) }

            ivMore.setOnClickListener {
                MaterialAlertDialogBuilder(root.context)
                    .setTitle(song.title)
                    .setItems(arrayOf(
                        root.context.getString(R.string.remove_from_playlist),
                        if (song.isLiked)
                            root.context.getString(R.string.unlike)
                        else
                            root.context.getString(R.string.like)
                    )) { _, which ->
                        when (which) {
                            0 -> onRemoveClick(song)
                            1 -> onLikeClick(song)
                        }
                    }.show()
            }

            root.setOnClickListener { onSongClick(song, currentList) }
        }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
