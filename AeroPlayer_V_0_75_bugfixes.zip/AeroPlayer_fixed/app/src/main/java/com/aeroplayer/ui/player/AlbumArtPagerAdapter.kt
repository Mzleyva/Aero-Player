package com.aeroplayer.ui.player

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemAlbumArtPagerBinding
import com.aeroplayer.utils.AlbumArtUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Adapter para el ViewPager2 de album art en el player.
 *
 * FIX Android 11: la versión anterior llamaba AlbumArtUtils.getAlbumArt() (síncrona, bloqueante)
 * directamente desde onBindViewHolder, que corre en el Main Thread. Esto congelaba el ViewPager
 * al abrir el player y causaba pantalla negra. Ahora usamos solo el cache en memoria (instantáneo)
 * y dejamos que Glide maneje la carga asíncrona desde URI, igual que hacen AIMP y Oto Music.
 */
class AlbumArtPagerAdapter : RecyclerView.Adapter<AlbumArtPagerAdapter.AlbumArtViewHolder>() {

    companion object {
        const val TOTAL_PAGES = 2001
        const val CENTER_PAGE = 1000
    }

    var uriProvider: ((offset: Int) -> Uri?) = { null }

    /**
     * Provee (songId, filePath) para consultar el cache en memoria.
     * NO se usa para carga síncrona — solo para hit de cache instantáneo.
     */
    var pathProvider: ((offset: Int) -> Pair<Long, String>?) = { null }

    /**
     * Provee la URI del GIF Canvas solo para la posición central (canción actual).
     */
    var canvasProvider: (() -> Uri?) = { null }

    inner class AlbumArtViewHolder(val b: ItemAlbumArtPagerBinding) :
        RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumArtViewHolder {
        return AlbumArtViewHolder(
            ItemAlbumArtPagerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun getItemCount() = TOTAL_PAGES

    override fun onViewRecycled(holder: AlbumArtViewHolder) {
        super.onViewRecycled(holder)
        // FIX BUG#2: liberar el GIF de la memoria cuando la página se recicla.
        // Sin esto, páginas fuera de pantalla siguen decodificando frames en RAM.
        Glide.with(holder.b.ivGifCanvas).clear(holder.b.ivGifCanvas)
        holder.b.ivGifCanvas.visibility = View.GONE
        Glide.with(holder.b.ivPagerAlbumArt).clear(holder.b.ivPagerAlbumArt)
    }

    override fun onBindViewHolder(holder: AlbumArtViewHolder, position: Int) {
        val offset    = position - CENTER_PAGE
        val artUri    = uriProvider(offset)
        val gifUri    = if (offset == 0) canvasProvider() else null
        val hasCanvas = gifUri != null

        with(holder.b) {

            // ── Album art ────────────────────────────────────────────────────
            ivPagerAlbumArt.alpha = if (hasCanvas) 0f else 1f

            // FIX: consultar solo el cache en memoria (O(1), no bloquea).
            // Si hay un bitmap cacheado lo usamos directamente.
            // Si no, Glide carga desde URI de forma asíncrona en su propio hilo.
            val songInfo = pathProvider(offset)
            val cached   = if (songInfo != null) AlbumArtUtils.getCached(songInfo.first) else null

            if (cached != null) {
                Glide.with(ivPagerAlbumArt)
                    .load(cached)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .transition(DrawableTransitionOptions.withCrossFade(150))
                    .centerCrop()
                    .into(ivPagerAlbumArt)
            } else {
                // Sin cache: cargar desde URI vía Glide (asíncrono, no bloquea el Main Thread)
                Glide.with(ivPagerAlbumArt)
                    .load(artUri)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .error(R.drawable.ic_music_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .transition(DrawableTransitionOptions.withCrossFade(150))
                    .centerCrop()
                    .into(ivPagerAlbumArt)
            }

            // ── GIF Canvas ───────────────────────────────────────────────────
            if (hasCanvas) {
                ivGifCanvas.visibility = View.VISIBLE
                // FIX BUG#2: limitar tamaño del GIF para prevenir OOM.
                // override() limita el área de decodificación en memoria.
                // fallback() muestra la carátula si el GIF no carga o es demasiado grande.
                Glide.with(ivGifCanvas)
                    .asGif()
                    .load(gifUri)
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
                    .override(720, 720)       // max decode size → previene OOM con GIFs grandes
                    .centerCrop()
                    .error(R.drawable.ic_music_placeholder)
                    .into(ivGifCanvas)
            } else {
                Glide.with(ivGifCanvas).clear(ivGifCanvas)
                ivGifCanvas.visibility = View.GONE
            }
        }
    }
}
