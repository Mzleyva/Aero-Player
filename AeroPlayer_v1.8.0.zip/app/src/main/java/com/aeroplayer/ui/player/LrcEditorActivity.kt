package com.aeroplayer.ui.player

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.service.PlayerController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

/**
 * Editor de letras LRC sincronizadas.
 *
 * Funciones:
 * - Carga el .lrc existente (o empieza vacío)
 * - Lista de líneas editable: texto + tiempo [mm:ss.xx]
 * - "Estampar" tiempo: toca una línea mientras suena la canción → asigna la posición actual
 * - Reordenar líneas con drag
 * - Añadir / eliminar líneas
 * - Guardar como .lrc junto al archivo de audio
 * - Exportar texto plano (sin tiempos) para compartir
 */
class LrcEditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SONG_PATH  = "song_path"
        const val EXTRA_SONG_TITLE = "song_title"
    }

    private lateinit var rvLines: RecyclerView
    private lateinit var adapter: LrcLineAdapter
    private lateinit var songPath: String
    private lateinit var songTitle: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lrc_editor)

        songPath  = intent.getStringExtra(EXTRA_SONG_PATH)  ?: run { finish(); return }
        songTitle = intent.getStringExtra(EXTRA_SONG_TITLE) ?: "Canción"

        findViewById<TextView>(R.id.tvLrcTitle).text = songTitle
        findViewById<ImageButton>(R.id.btnLrcBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnLrcSave).setOnClickListener { saveLrc() }
        findViewById<ImageButton>(R.id.btnLrcAddLine).setOnClickListener { addLine() }

        rvLines = findViewById(R.id.rvLrcLines)
        adapter = LrcLineAdapter(
            onStamp  = { pos -> stampTime(pos) },
            onEdit   = { pos, line -> editLine(pos, line) },
            onDelete = { pos -> adapter.deleteLine(pos) }
        )
        rvLines.layoutManager = LinearLayoutManager(this)
        rvLines.adapter = adapter

        // Drag-to-reorder
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                adapter.moveLine(vh.adapterPosition, t.adapterPosition)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
        }).attachToRecyclerView(rvLines)

        loadLrc()
    }

    // ── Load ──────────────────────────────────────────────────────────────────

    private fun loadLrc() {
        val lrcFile = File(songPath.substringBeforeLast(".") + ".lrc")
        if (!lrcFile.exists()) {
            adapter.submitList(mutableListOf())
            return
        }
        val lines = lrcFile.readLines(Charsets.UTF_8)
            .filter { it.isNotBlank() }
            .mapNotNull { parseLrcLine(it) }
            .toMutableList()
        adapter.submitList(lines)
    }

    private fun parseLrcLine(raw: String): LrcLine? {
        // [mm:ss.xx]text  or  [mm:ss]text
        val match = Regex("""^\[(\d{2}):(\d{2})[.:]?(\d{0,2})](.*)$""").matchEntire(raw.trim())
            ?: return LrcLine(timeMs = -1, text = raw.trim())  // línea sin tiempo (metadato)
        val mm  = match.groupValues[1].toLongOrNull() ?: 0
        val ss  = match.groupValues[2].toLongOrNull() ?: 0
        val cs  = match.groupValues[3].padEnd(2, '0').toLongOrNull() ?: 0
        val ms  = mm * 60_000 + ss * 1_000 + cs * 10
        return LrcLine(timeMs = ms, text = match.groupValues[4])
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    /** Asigna la posición de reproducción actual a la línea en [pos]. */
    private fun stampTime(pos: Int) {
        val currentMs = PlayerController.getCurrentPosition().takeIf { it > 0 } ?: run {
            Toast.makeText(this, "Reproduce una canción primero", Toast.LENGTH_SHORT).show()
            return
        }
        adapter.stampTime(pos, currentMs)
        Toast.makeText(this, formatTime(currentMs), Toast.LENGTH_SHORT).show()
    }

    private fun addLine() {
        val et = EditText(this).apply { hint = "Texto de la línea" }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nueva línea")
            .setView(et)
            .setPositiveButton("Agregar") { _, _ ->
                val text = et.text.toString().trim()
                if (text.isNotEmpty()) adapter.addLine(LrcLine(timeMs = -1, text = text))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun editLine(pos: Int, line: LrcLine) {
        val et = EditText(this).apply { setText(line.text) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Editar línea")
            .setView(et)
            .setPositiveButton("Guardar") { _, _ ->
                val text = et.text.toString().trim()
                if (text.isNotEmpty()) adapter.updateText(pos, text)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveLrc() {
        val lines = adapter.getLines().sortedBy { it.timeMs }
        val sb = StringBuilder()
        sb.appendLine("[ti:$songTitle]")
        sb.appendLine("[re:AeroPlayer LRC Editor]")
        lines.forEach { line ->
            if (line.timeMs >= 0) {
                sb.appendLine("[${formatTime(line.timeMs)}]${line.text}")
            } else {
                sb.appendLine(line.text)
            }
        }
        val lrcFile = File(songPath.substringBeforeLast(".") + ".lrc")
        try {
            lrcFile.writeText(sb.toString(), Charsets.UTF_8)
            Toast.makeText(this, "LRC guardado ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatTime(ms: Long): String {
        val mm = ms / 60_000
        val ss = (ms % 60_000) / 1_000
        val cs = (ms % 1_000) / 10
        return "%02d:%02d.%02d".format(mm, ss, cs)
    }
}

// ── Model ─────────────────────────────────────────────────────────────────────

data class LrcLine(val timeMs: Long, val text: String)

// ── Adapter ───────────────────────────────────────────────────────────────────

class LrcLineAdapter(
    private val onStamp:  (Int) -> Unit,
    private val onEdit:   (Int, LrcLine) -> Unit,
    private val onDelete: (Int) -> Unit
) : ListAdapter<LrcLine, LrcLineAdapter.VH>(LrcDiff()) {

    private val lines = mutableListOf<LrcLine>()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTime:    TextView    = v.findViewById(R.id.tvLrcTime)
        val tvText:    TextView    = v.findViewById(R.id.tvLrcText)
        val btnStamp:  ImageButton = v.findViewById(R.id.btnLrcStamp)
        val btnEdit:   ImageButton = v.findViewById(R.id.btnLrcLineEdit)
        val btnDelete: ImageButton = v.findViewById(R.id.btnLrcDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_lrc_line, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val line = lines[position]
        holder.tvText.text = line.text.ifBlank { "(línea vacía)" }
        holder.tvTime.text = if (line.timeMs >= 0) {
            val mm = line.timeMs / 60_000
            val ss = (line.timeMs % 60_000) / 1_000
            val cs = (line.timeMs % 1_000) / 10
            "[%02d:%02d.%02d]".format(mm, ss, cs)
        } else {
            "[--:--.--]"
        }
        holder.btnStamp.setOnClickListener  { onStamp(holder.adapterPosition) }
        holder.btnEdit.setOnClickListener   { onEdit(holder.adapterPosition, lines[holder.adapterPosition]) }
        holder.btnDelete.setOnClickListener { onDelete(holder.adapterPosition) }
    }

    override fun getItemCount() = lines.size

    fun getLines(): List<LrcLine> = lines.toList()

    override fun submitList(list: List<LrcLine>?) {
        lines.clear()
        if (list != null) lines.addAll(list)
        notifyDataSetChanged()
    }

    fun stampTime(pos: Int, ms: Long) {
        if (pos < 0 || pos >= lines.size) return
        lines[pos] = lines[pos].copy(timeMs = ms)
        notifyItemChanged(pos)
    }

    fun updateText(pos: Int, text: String) {
        if (pos < 0 || pos >= lines.size) return
        lines[pos] = lines[pos].copy(text = text)
        notifyItemChanged(pos)
    }

    fun addLine(line: LrcLine) {
        lines.add(line)
        notifyItemInserted(lines.lastIndex)
    }

    fun deleteLine(pos: Int) {
        if (pos < 0 || pos >= lines.size) return
        lines.removeAt(pos)
        notifyItemRemoved(pos)
    }

    fun moveLine(from: Int, to: Int) {
        val item = lines.removeAt(from)
        lines.add(to, item)
        notifyItemMoved(from, to)
    }

    class LrcDiff : DiffUtil.ItemCallback<LrcLine>() {
        override fun areItemsTheSame(a: LrcLine, b: LrcLine)    = a.timeMs == b.timeMs && a.text == b.text
        override fun areContentsTheSame(a: LrcLine, b: LrcLine) = a == b
    }
}
