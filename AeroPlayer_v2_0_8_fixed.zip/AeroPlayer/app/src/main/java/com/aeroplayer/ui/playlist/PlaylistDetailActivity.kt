package com.aeroplayer.ui.playlist

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityPlaylistDetailBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import android.graphics.Bitmap
import com.aeroplayer.utils.SongBuilder
import android.graphics.drawable.GradientDrawable
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class PlaylistDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistDetailBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var songsAdapter: PlaylistSongsAdapter

    private var playlistId: Long = -1L
    private var playlistName: String = ""

    private var pendingReorder: List<Song>? = null

    /** Lista completa sin filtrar — base para el filtro de búsqueda. */
    private var fullSongList: List<Song> = emptyList()
    private var isSearchVisible = false

    private val editPlaylistLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            // LiveData refresca automáticamente
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playlistId   = intent.getLongExtra("playlistId", -1L)
        playlistName = intent.getStringExtra("playlistName") ?: ""

        if (playlistId == -1L) { finish(); return }

        setupToolbar()
        setupHeader()
        setupRecyclerView()
        setupButtons()
        setupSearch()
        observeSongs()
        observeFavorite()
    }

    // ── Toolbar ──────────────────────────────────────────────────────────────
    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }

        binding.btnMore.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(playlistName)
                .setItems(arrayOf(
                    getString(R.string.edit_playlist),
                    getString(R.string.add_songs),
                    "📤 Exportar como .m3u",
                    "🔀 Reproducir en aleatorio",
                    getString(R.string.delete_playlist)
                )) { _, which ->
                    when (which) {
                        0 -> openEditPlaylist()
                        1 -> openAddSongs()
                        2 -> exportPlaylistM3u()
                        3 -> shufflePlaylist()
                        4 -> confirmDelete()
                    }
                }.show()
        }
    }

    // ── Header con Palette ────────────────────────────────────────────────────
    private fun setupHeader() {
        viewModel.playlists.observe(this) { playlists ->
            val playlist = playlists.find { it.id == playlistId } ?: return@observe
            playlistName = playlist.name
            binding.tvPlaylistTitle.text = playlist.name

            if (playlist.coverUri != null) {
                Glide.with(this)
                    .asBitmap()
                    .load(playlist.coverUri)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(object : CustomTarget<Bitmap>() {
                        override fun onResourceReady(bmp: Bitmap, t: Transition<in Bitmap>?) {
                            binding.ivPlaylistCover.setImageBitmap(bmp)
                            applyPaletteGradient(bmp)
                        }
                        override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
                    })
            } else {
                binding.ivPlaylistCover.setImageResource(R.drawable.ic_playlist_placeholder)
            }
        }
    }

    private fun applyPaletteGradient(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val color = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(
                    ContextCompat.getColor(this, R.color.surface_dark)
                )
            ) ?: ContextCompat.getColor(this, R.color.surface_dark)

            val gradient = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color, ContextCompat.getColor(this, R.color.background_dark))
            )
            binding.headerContainer.background = gradient
        }
    }

    // ── RecyclerView con swipe-to-remove + drag-to-reorder ───────────────────
    private fun setupRecyclerView() {
        songsAdapter = PlaylistSongsAdapter(
            onSongClick  = { song, songs ->
                PlayerController.playSongs(songs, songs.indexOf(song), queueName = playlistName)
                viewModel.incrementPlayCount(song)
},
            onLikeClick  = { song -> viewModel.toggleLike(song) },
            onRemoveClick = { song ->
                viewModel.removeSongFromPlaylist(playlistId, song.id)
                Snackbar.make(binding.root, getString(R.string.song_removed), Snackbar.LENGTH_SHORT)
                    .setAction(getString(R.string.undo)) {
                        viewModel.addSongToPlaylist(playlistId, song)
                    }.show()
            }
        )

        binding.rvPlaylistSongs.apply {
            layoutManager = LinearLayoutManager(this@PlaylistDetailActivity)
            adapter        = songsAdapter
            setHasFixedSize(false) // false porque está dentro de NestedScrollView
        }

        val touchCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            ItemTouchHelper.LEFT
        ) {
            override fun onMove(
                rv: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = vh.bindingAdapterPosition
                val to   = target.bindingAdapterPosition
                if (from < 0 || to < 0) return false

                val mutable = songsAdapter.currentList.toMutableList()
                val moved   = mutable.removeAt(from)
                mutable.add(to, moved)
                pendingReorder = mutable.toList()
                songsAdapter.submitList(mutable)
                return true
            }

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                pendingReorder?.let { ordered ->
                    viewModel.reorderPlaylistSongs(playlistId, ordered)
                    pendingReorder = null
                }
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {
                val pos  = vh.bindingAdapterPosition
                if (pos < 0) return
                val song = songsAdapter.currentList[pos]
                viewModel.removeSongFromPlaylist(playlistId, song.id)
                Snackbar.make(binding.root, getString(R.string.song_removed), Snackbar.LENGTH_SHORT)
                    .setAction(getString(R.string.undo)) {
                        viewModel.addSongToPlaylist(playlistId, song)
                    }.show()
            }
        }
        ItemTouchHelper(touchCallback).attachToRecyclerView(binding.rvPlaylistSongs)
    }

    // ── Botones ──────────────────────────────────────────────────────────────
    private fun setupButtons() {

        // ▶ Play all
        binding.btnPlayAll.setOnClickListener {
            val songs = songsAdapter.currentList
            if (songs.isNotEmpty()) {
                songs.firstOrNull()?.let { viewModel.incrementPlayCount(it) }
                PlayerController.playSongs(songs, 0, queueName = playlistName)
}
        }

        // ➕ Añadir canciones (botón superior de la fila)
        binding.btnAddSongsTop.setOnClickListener { openAddSongs() }

        // ➕ Añadir canciones (estado vacío)
        binding.btnAddSongs.setOnClickListener { openAddSongs() }

        // ✏ Editar playlist
        binding.btnEdit.setOnClickListener { openEditPlaylist() }

        // ❤ Favorita — toggle; la lógica real está en observeFavorite()
        binding.btnFavorite.setOnClickListener {
            viewModel.toggleFavoritePlaylist(playlistId)
        }
    }

    // ── Observar estado "favorita" ────────────────────────────────────────────
    private fun observeFavorite() {
        viewModel.favoritePlaylistIds.observe(this) { favIds ->
            val isFav = playlistId in favIds
            binding.btnFavorite.setImageResource(
                if (isFav) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            // Tint rojo cuando está marcada como favorita
            val tint = if (isFav)
                ContextCompat.getColor(this, R.color.accent_pink)
            else
                ContextCompat.getColor(this, R.color.text_primary)
            binding.btnFavorite.setColorFilter(tint)
        }
    }

    // ── Observar canciones ───────────────────────────────────────────────────
    private fun observeSongs() {
        viewModel.getPlaylistSongs(playlistId).observe(this) { entities ->
            val songs = entities.map { SongBuilder.fromPlaylistSong(it) }
            fullSongList = songs                     // cache para el filtro de búsqueda
            // Si hay búsqueda activa, re-aplicar el filtro sobre la lista nueva
            val query = binding.etSearch.text?.toString()?.trim() ?: ""
            songsAdapter.submitList(if (query.isNotEmpty()) filterSongs(songs, query) else songs)
            val displayCount = if (query.isNotEmpty()) filterSongs(songs, query).size else songs.size
            binding.tvSongCount.text = when (songs.size) {
                0    -> getString(R.string.no_songs)
                1    -> "1 ${getString(R.string.song)}"
                else -> "${songs.size} ${getString(R.string.songs)}"
            }
            binding.emptyState.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
            binding.btnPlayAll.isEnabled  = songs.isNotEmpty()
        }
    }

    // ── Acciones ─────────────────────────────────────────────────────────────
    private fun exportPlaylistM3u() {
        lifecycleScope.launch {
            val path = viewModel.exportPlaylistToM3u(this@PlaylistDetailActivity, playlistId)
            if (path != null) {
                val msg = "Exportado: ${path.substringAfterLast("/")}"
                com.google.android.material.snackbar.Snackbar
                    .make(binding.root, msg, com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
                    .setAction("Compartir") {
                        val uri = androidx.core.content.FileProvider.getUriForFile(
                            this@PlaylistDetailActivity,
                            "${packageName}.provider",
                            java.io.File(path)
                        )
                        startActivity(android.content.Intent.createChooser(
                            android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "audio/x-mpegurl"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Compartir playlist"
                        ))
                    }.show()
            } else {
                com.google.android.material.snackbar.Snackbar
                    .make(binding.root, "Error al exportar", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun shufflePlaylist() {
        val songs = viewModel.allSongs.value ?: return
        val playlistSongs = songs.filter { song ->
            viewModel.playlists.value
                ?.firstOrNull { it.id == playlistId }
                ?.let { true } ?: false
        }
        // Usar el orden de la playlist actual desde el adapter
        val adapterSongs = (binding.rvPlaylistSongs.adapter as? com.aeroplayer.ui.playlist.PlaylistSongsAdapter)
            ?.currentList ?: return
        if (adapterSongs.isEmpty()) return
        com.aeroplayer.service.PlayerController.playSongs(
            adapterSongs.shuffled(), 0, queueName = "$playlistName (aleatorio)"
        )
        com.google.android.material.snackbar.Snackbar
            .make(binding.root, "▶ Reproduciendo en aleatorio",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
    }

    private fun openEditPlaylist() {
        val playlist = viewModel.playlists.value?.find { it.id == playlistId } ?: return
        editPlaylistLauncher.launch(
            Intent(this, CreatePlaylistActivity::class.java).apply {
                putExtra("editPlaylistId",   playlistId)
                putExtra("editPlaylistName", playlist.name)
                putExtra("editCoverUri",     playlist.coverUri)
            }
        )
    }

    private fun openAddSongs() {
        startActivity(
            Intent(this, AddSongsToPlaylistActivity::class.java)
                .putExtra("playlistId", playlistId)
        )
    }

    private fun confirmDelete() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.delete_playlist))
            .setMessage(getString(R.string.delete_playlist_confirm, playlistName))
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                viewModel.deletePlaylist(playlistId)
                finish()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ── Búsqueda dentro de la playlist ───────────────────────────────────────

    /**
     * Maneja la barra de búsqueda colapsable:
     *  • btnSearch  → muestra etSearch + btnSearchClose, oculta btnSearch
     *  • btnSearchClose → colapsa la barra y limpia el filtro
     *  • etSearch.addTextChangedListener → filtra con debounce 150 ms
     */
    private fun setupSearch() {
        binding.btnSearch.setOnClickListener {
            isSearchVisible = true
            binding.btnSearch.visibility     = View.GONE
            binding.etSearch.visibility      = View.VISIBLE
            binding.btnSearchClose.visibility = View.VISIBLE
            binding.etSearch.requestFocus()
            val imm = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
            imm.showSoftInput(binding.etSearch, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }

        binding.btnSearchClose.setOnClickListener {
            collapseSearch()
        }

        // Filtrado con debounce 150 ms usando un Handler
        val searchHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var searchRunnable: Runnable? = null

        binding.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable {
                    val query = s?.toString()?.trim() ?: ""
                    val filtered = if (query.isEmpty()) fullSongList
                                   else filterSongs(fullSongList, query)
                    songsAdapter.submitList(filtered)
                    binding.tvSongCount.text = if (query.isEmpty()) {
                        "${fullSongList.size} ${getString(R.string.songs)}"
                    } else {
                        "${filtered.size} / ${fullSongList.size} ${getString(R.string.songs)}"
                    }
                }
                // FIX BUG4: usar let en lugar de !! para evitar NPE si el Runnable fuera null
                searchRunnable?.let { searchHandler.postDelayed(it, 150) }
            }
        })
    }

    private fun collapseSearch() {
        isSearchVisible = false
        binding.etSearch.text?.clear()
        binding.etSearch.visibility       = View.GONE
        binding.btnSearchClose.visibility  = View.GONE
        binding.btnSearch.visibility      = View.VISIBLE
        val imm = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
        imm.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
        // Restaurar lista completa
        songsAdapter.submitList(fullSongList)
        binding.tvSongCount.text = "${fullSongList.size} ${getString(R.string.songs)}"
    }

    /** Filtra [songs] por título, artista o álbum (case-insensitive). */
    private fun filterSongs(songs: List<Song>, query: String): List<Song> {
        val q = query.lowercase()
        return songs.filter {
            it.title.lowercase().contains(q) ||
            it.artist.lowercase().contains(q) ||
            it.album.lowercase().contains(q)
        }
    }
}
