package com.aeroplayer.timer

import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aeroplayer.service.PlayerController

object SleepTimerManager {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _remainingMs = MutableLiveData(0L)
    val remainingMs: LiveData<Long> = _remainingMs

    private val _isRunning = MutableLiveData(false)
    val isRunning: LiveData<Boolean> = _isRunning

    /** true cuando el timer esperará a que termine la canción actual. */
    private val _afterSong = MutableLiveData(false)
    val afterSong: LiveData<Boolean> = _afterSong

    private var timer: CountDownTimer? = null

    fun start(minutes: Int, afterCurrentSong: Boolean = false) {
        cancel()
        val totalMs = minutes * 60_000L
        mainHandler.post {
            _remainingMs.value = totalMs
            _isRunning.value   = true
            _afterSong.value   = afterCurrentSong
        }
        timer = object : CountDownTimer(totalMs, 1_000) {
            override fun onTick(ms: Long) { mainHandler.post { _remainingMs.value = ms } }
            override fun onFinish() {
                mainHandler.post { _remainingMs.value = 0L; _isRunning.value = false }
                if (afterCurrentSong) {
                    // Esperar que termine la canción actual
                    val ctrl = PlayerController
                    val remaining = (ctrl.getDuration() - ctrl.getCurrentPosition())
                        .coerceAtLeast(0L)
                    mainHandler.postDelayed({ PlayerController.pause() }, remaining)
                } else {
                    PlayerController.pause()
                }
            }
        }.start()
    }

    fun cancel() {
        timer?.cancel(); timer = null
        mainHandler.post { _remainingMs.value = 0L; _isRunning.value = false; _afterSong.value = false }
    }

    fun formatRemaining(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }
}
