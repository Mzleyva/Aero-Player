package com.aeroplayer.ui.equalizer

import android.content.Context
import android.graphics.Color
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.aeroplayer.R
import com.aeroplayer.service.PlayerController
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ecualizador — v1.8.2
 *
 * FIX número de columnas:
 *   - Antes: las bandas se mostraban en un HorizontalScrollView implícito pero
 *     el bandContainer tenía MATCH_PARENT fijo → todas las columnas se comprimían
 *     en el ancho de pantalla sin importar cuántas hubiera, haciendo imposible
 *     distinguirlas con 15 o 20 bandas.
 *   - Ahora: bandContainer vive dentro de un HorizontalScrollView. Con pocas
 *     bandas (≤10) se expande al 100% del ancho. Con más bandas cada columna
 *     tiene un ancho mínimo de 44dp garantizado y el scroll permite ver todas.
 *
 * Mejoras visuales:
 *   - Fondo con gradiente sutil oscuro.
 *   - Sliders verticales con tint dinámico (azul positivo, rosa negativo).
 *   - Curva más alta (120dp).
 *   - Indicador dB animado por banda.
 *   - Secciones con separador visual.
 */
class EqualizerActivity : AppCompatActivity() {

    private var equalizer:   Equalizer?   = null
    private var bassBoost:   BassBoost?   = null
    private var virtualizer: Virtualizer? = null

    private val bandSeekBars    = mutableListOf<SeekBar>()
    private val bandValueLabels = mutableListOf<TextView>()

    private lateinit var rootLayout:       LinearLayout
    private lateinit var customPresetRow:  LinearLayout
    private lateinit var bandContainer:    LinearLayout   // contenedor real de columnas
    private lateinit var bandScrollView:   HorizontalScrollView
    private lateinit var curveView:        EqCurveView

    private val PREFS_NAME      = "eq_custom_presets"
    private val KEY_PRESETS     = "presets"
    private val KEY_BAND_LEVELS = "eq_band_levels"
    private val KEY_EQ_ENABLED  = "eq_enabled"
    private val KEY_BAND_COUNT  = "eq_band_count"
    private val KEY_PROFILE     = "eq_profile"

    // 30 presets en 10 bandas — escalados automáticamente
    private val GENRE_PRESETS = linkedMapOf(
        "Plano"        to listOf( 0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
        "Rock"         to listOf(300,200,100,-100,-200,-200,0,200,300,350),
        "Pop"          to listOf(-100,0,200,300,200,0,-100,-100,-100,-100),
        "Jazz"         to listOf(200,100,0,200,400,300,200,100,200,300),
        "Clásica"      to listOf(0,0,0,0,0,0,-200,-200,-200,-300),
        "Hip-Hop"      to listOf(500,400,100,300,0,-200,-100,100,200,300),
        "Electrónica"  to listOf(400,350,0,-200,-100,0,200,150,400,500),
        "Dance"        to listOf(300,200,-100,-200,0,300,400,300,200,0),
        "R&B"          to listOf(700,400,100,200,0,-100,200,300,300,200),
        "Metal"        to listOf(400,100,300,-100,-300,-100,0,200,500,500),
        "Punk"         to listOf(300,0,-100,-200,-100,0,200,300,400,400),
        "Blues"        to listOf(300,200,100,0,-100,200,300,200,100,200),
        "Reggae"       to listOf(0,0,0,-200,300,400,300,0,0,0),
        "Soul"         to listOf(200,100,0,200,200,0,-100,200,300,200),
        "Country"      to listOf(300,200,100,100,-100,-100,200,300,300,200),
        "Folk"         to listOf(300,200,100,0,0,100,0,200,100,200),
        "Indie"        to listOf(200,100,0,-100,-100,0,100,200,300,400),
        "Lo-Fi"        to listOf(300,400,200,100,-100,-200,-300,-400,-400,-500),
        "Acústica"     to listOf(500,300,200,100,-100,0,0,200,300,400),
        "Vocal"        to listOf(-200,-100,0,100,300,500,400,200,100,0),
        "Podcast"      to listOf(-300,-200,-100,100,500,600,500,300,100,-100),
        "Audiobooks"   to listOf(-200,-100,0,100,400,500,400,200,100,0),
        "Gaming"       to listOf(200,300,400,200,0,-100,100,300,400,500),
        "Cine"         to listOf(300,200,100,0,-100,-100,100,200,300,500),
        "Bass Boost"   to listOf(600,500,400,200,0,-100,-200,-100,0,100),
        "Treble Boost" to listOf(-200,-100,0,0,0,100,200,300,400,500),
        "Sub-Woofer"   to listOf(800,600,400,100,-100,-200,-300,-300,-200,-100),
        "Karaoke"      to listOf(0,0,0,100,300,-800,-800,200,100,0),
        "Medianoche"   to listOf(500,400,200,100,-100,-100,0,100,200,300),
        "Deportes"     to listOf(300,200,100,0,0,100,200,300,400,500)
    )

    private val DEVICE_PROFILES = listOf("General","Auriculares","Bocinas","Bluetooth","Hi-Fi DAC")

    // ── mínimo de dp por columna de banda ────────────────────────────────────
    private val MIN_BAND_COL_DP = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }
        rootLayout = buildUI()
        scroll.addView(rootLayout)
        setContentView(scroll)

        val sessionId = PlayerController.getAudioSessionId()
        if (sessionId == 0) {
            toast("Reproduce una canción primero"); finish(); return
        }
        runCatching {
            equalizer   = Equalizer(0, sessionId).also  { it.enabled = true }
            bassBoost   = BassBoost(0, sessionId).also  { it.enabled = false }
            virtualizer = Virtualizer(0, sessionId).also { it.enabled = false }
        }.onFailure {
            toast("No se pudo inicializar el ecualizador"); finish(); return
        }
        val eq = equalizer ?: run { finish(); return }
        populateBands(eq)
        restoreBandLevels(eq)
        loadCustomPresets()
        loadGenrePresets()
        populateSystemPresets(eq)
    }

    // ── UI ────────────────────────────────────────────────────────────────────
    private fun buildUI(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(4.dp, 4.dp, 16.dp, 4.dp)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            background = null
            setOnClickListener { finish() }
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
        }
        val tvTitle = TextView(this).apply {
            text = "Ecualizador"
            textSize = 20f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        val switchEq = SwitchMaterial(this).apply {
            text = "Activo"
            isChecked = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_EQ_ENABLED, true)
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
            setOnCheckedChangeListener { _, checked ->
                equalizer?.enabled = checked
                bandSeekBars.forEach { it.isEnabled = checked }
                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_EQ_ENABLED, checked).apply()
            }
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(switchEq)
        root.addView(toolbar)

        // ── Perfil de dispositivo ─────────────────────────────────────────────
        root.addView(sectionDivider())
        root.addView(sectionLabel("Perfil de dispositivo"))
        val profileScroll = HorizontalScrollView(this).apply { setPadding(12.dp, 0, 12.dp, 0); isHorizontalScrollBarEnabled = false }
        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4.dp, 4.dp, 4.dp, 4.dp); layoutParams = android.widget.FrameLayout.LayoutParams(android.widget.FrameLayout.LayoutParams.WRAP_CONTENT, android.widget.FrameLayout.LayoutParams.WRAP_CONTENT) }
        val savedProfile = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_PROFILE, "General") ?: "General"
        DEVICE_PROFILES.forEach { p -> profileRow.addView(makeChip(p, selected = p == savedProfile) { switchProfile(p) }) }
        profileScroll.addView(profileRow); root.addView(profileScroll)

        // ── Número de bandas ──────────────────────────────────────────────────
        root.addView(sectionDivider())
        root.addView(sectionLabel("Número de bandas"))
        val bandCounts  = listOf(5, 10, 15, 20)
        val savedCount  = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getInt(KEY_BAND_COUNT, 10)
        val bandCountRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(20.dp, 4.dp, 20.dp, 4.dp)
        }
        val tvBandCount = TextView(this).apply {
            text = "$savedCount bandas"
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val seekBandCount = SeekBar(this).apply {
            max      = bandCounts.size - 1
            progress = bandCounts.indexOf(savedCount).coerceAtLeast(0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    tvBandCount.text = "${bandCounts[p]} bandas"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    val count = bandCounts[progress]
                    getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putInt(KEY_BAND_COUNT, count).apply()
                    equalizer?.let { rebuildBands(it, count) }
                }
            })
        }
        bandCountRow.addView(tvBandCount); bandCountRow.addView(seekBandCount); root.addView(bandCountRow)

        // ── Curva EQ ─────────────────────────────────────────────────────────
        root.addView(sectionDivider())
        curveView = EqCurveView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 120.dp)
            setPadding(16.dp, 8.dp, 16.dp, 0)
        }
        root.addView(curveView)

        // ── Bandas — HorizontalScrollView con ancho mínimo por columna ────────
        //   FIX: antes bandContainer era MATCH_PARENT y todas las columnas se
        //   apretaban en el ancho de pantalla. Ahora cada columna tiene un mínimo
        //   de MIN_BAND_COL_DP y el ScrollView permite desplazar si hacen falta.
        bandScrollView = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 280.dp)
        }
        bandContainer = LinearLayout(this).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.BOTTOM
            setPadding(12.dp, 8.dp, 12.dp, 8.dp)
            // El ancho se recalcula en rebuildBands()
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT)
        }
        bandScrollView.addView(bandContainer)
        root.addView(bandScrollView)

        // Reset button
        val resetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.END
            setPadding(16.dp, 0, 16.dp, 8.dp)
        }
        resetRow.addView(com.google.android.material.button.MaterialButton(this).apply {
            text = "Restablecer"
            textSize = 12f
            setOnClickListener { resetBands() }
        })
        root.addView(resetRow)

        // ── Efectos de audio ─────────────────────────────────────────────────
        root.addView(sectionDivider())
        root.addView(sectionLabel("Efectos de audio"))
        root.addView(buildEffectsRow())

        // ── Presets del sistema ───────────────────────────────────────────────
        root.addView(sectionDivider())
        root.addView(sectionLabel("Presets del sistema"))
        root.addView(HorizontalScrollView(this).apply {
            id = R.id.ids_chip_container
            setPadding(12.dp, 0, 12.dp, 0)
            isHorizontalScrollBarEnabled = false
        })

        // ── Presets de género ─────────────────────────────────────────────────
        root.addView(sectionDivider())
        root.addView(sectionLabel("Presets por género (${GENRE_PRESETS.size})"))
        val genreScroll = HorizontalScrollView(this).apply {
            setPadding(12.dp, 0, 12.dp, 8.dp)
            isHorizontalScrollBarEnabled = false
        }
        val genreRow = LinearLayout(this).apply {
            id = android.R.id.custom
            orientation = LinearLayout.HORIZONTAL
            setPadding(4.dp, 4.dp, 4.dp, 4.dp)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT)
        }
        genreScroll.addView(genreRow); root.addView(genreScroll)

        // ── Mis presets ───────────────────────────────────────────────────────
        root.addView(sectionDivider())
        val customHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(20.dp, 4.dp, 16.dp, 0)
        }
        customHeader.addView(sectionLabel("Mis presets").also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        customHeader.addView(com.google.android.material.button.MaterialButton(this).apply {
            text = "Guardar"
            textSize = 11f
            setOnClickListener { showSavePresetDialog() }
        })
        root.addView(customHeader)
        customPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16.dp, 4.dp, 16.dp, 24.dp)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT)
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(customPresetRow)
        })

        return root
    }

    // ── Bands ─────────────────────────────────────────────────────────────────
    private fun populateBands(eq: Equalizer) {
        val count = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getInt(KEY_BAND_COUNT, 10)
        rebuildBands(eq, count)
    }

    private fun rebuildBands(eq: Equalizer, requestedCount: Int) {
        bandContainer.removeAllViews()
        bandSeekBars.clear(); bandValueLabels.clear()

        val hardwareCount = eq.numberOfBands.toInt()
        val displayCount  = requestedCount.coerceAtMost(hardwareCount).coerceAtLeast(1)

        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel   = levelRange[0].toInt()
        val maxLevel   = levelRange[1].toInt()
        val range      = (maxLevel - minLevel).coerceAtLeast(1)

        // ── FIX: calcular el ancho de cada columna ────────────────────────────
        // Si las columnas caben en pantalla se distribuyen uniformemente.
        // Si no caben, cada columna tiene MIN_BAND_COL_DP y se puede hacer scroll.
        val screenWidthPx   = resources.displayMetrics.widthPixels - 24.dp  // padding total
        val minColPx        = MIN_BAND_COL_DP.dp
        val preferredColPx  = screenWidthPx / displayCount
        val colWidthPx      = maxOf(preferredColPx, minColPx)
        val containerWidth  = colWidthPx * displayCount
        bandContainer.layoutParams = android.widget.FrameLayout.LayoutParams(
            containerWidth, android.widget.FrameLayout.LayoutParams.MATCH_PARENT)

        (0 until displayCount).forEach { i ->
            val hwBand = ((i.toFloat() / displayCount) * hardwareCount).toInt()
                .coerceIn(0, hardwareCount - 1).toShort()

            val hz = runCatching { eq.getCenterFreq(hwBand) / 1000 }.getOrDefault(0)
            val freqLabel = when { hz >= 1000 -> "${hz / 1000}k"; hz > 0 -> "${hz}"; else -> "${i+1}" }
            val currentLevel = runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity     = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(colWidthPx, LinearLayout.LayoutParams.MATCH_PARENT)
            }

            val tvDb = TextView(this).apply {
                text      = formatDb(currentLevel)
                textSize  = 9f
                setTextColor(dbColor(currentLevel))
                gravity   = Gravity.CENTER
            }
            bandValueLabels.add(tvDb)

            val sb = SeekBar(this).apply {
                rotation  = -90f
                max       = range
                progress  = (currentLevel - minLevel).coerceIn(0, range)
                val color = dbColor(currentLevel)
                progressTintList = android.content.res.ColorStateList.valueOf(color)
                thumbTintList    = android.content.res.ColorStateList.valueOf(color)
                // Altura del slider = 200dp rotado 90° → aparece como columna de 200dp
                layoutParams = LinearLayout.LayoutParams(200.dp, 36.dp)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val level = (p + minLevel).toShort()
                        runCatching { eq.setBandLevel(hwBand, level) }
                        tvDb.text = formatDb(level.toInt())
                        tvDb.setTextColor(dbColor(level.toInt()))
                        // Actualizar tint del slider en tiempo real
                        val c = dbColor(level.toInt())
                        progressTintList = android.content.res.ColorStateList.valueOf(c)
                        thumbTintList    = android.content.res.ColorStateList.valueOf(c)
                        updateCurve(eq)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) { saveBandLevels() }
                })
            }
            bandSeekBars.add(sb)

            val tvFreq = TextView(this).apply {
                text      = freqLabel
                textSize  = if (displayCount > 15) 8f else 9f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
                gravity   = Gravity.CENTER
            }
            col.addView(tvDb); col.addView(sb); col.addView(tvFreq)
            bandContainer.addView(col)
        }
        updateCurve(eq)
    }

    private fun updateCurve(eq: Equalizer) {
        val levels = bandSeekBars.indices.map { i ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
        }
        curveView.setLevels(levels)
    }

    // ── Effects row ───────────────────────────────────────────────────────────
    private fun buildEffectsRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 4.dp, 20.dp, 8.dp)
        }
        row.addView(buildSliderRow("Bass Boost", 0, 1000) { s ->
            bassBoost?.setStrength(s.toShort()); bassBoost?.enabled = s > 0
        })
        row.addView(buildSliderRow("Virtualizer (surround)", 0, 1000) { s ->
            virtualizer?.setStrength(s.toShort()); virtualizer?.enabled = s > 0
        })
        return row
    }

    private fun buildSliderRow(label: String, min: Int, max: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(0, 8.dp, 0, 4.dp)
        }
        val tv = TextView(this).apply {
            text = label; textSize = 13f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sb = SeekBar(this).apply {
            this.max = max - min
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p + min) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        row.addView(tv); row.addView(sb); return row
    }

    // ── Genre presets ─────────────────────────────────────────────────────────
    private fun loadGenrePresets() {
        val genreRow = rootLayout.findViewById<LinearLayout>(android.R.id.custom) ?: return
        genreRow.removeAllViews()
        GENRE_PRESETS.forEach { (name, levels10) ->
            genreRow.addView(makeChip(name) { applyScaledPreset(levels10); toast("Preset: $name") })
        }
    }

    private fun applyScaledPreset(levels10: List<Int>) {
        val eq = equalizer ?: return
        val n  = bandSeekBars.size
        (0 until n).forEach { i ->
            val src    = (i.toFloat() / n * 10).toInt().coerceIn(0, 9)
            val level  = levels10[src].toShort()
            val hwBand = ((i.toFloat() / n) * eq.numberOfBands).toInt()
                .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.setBandLevel(hwBand, level) }
        }
        refreshBands(eq); saveBandLevels()
    }

    // ── Device profiles ───────────────────────────────────────────────────────
    private fun switchProfile(profile: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_PROFILE, profile).apply()
        val raw = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString("eq_band_levels_$profile", null)
        val eq  = equalizer ?: return
        if (raw != null) {
            val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
            levels.forEachIndexed { i, level ->
                val hwBand = ((i.toFloat() / levels.size) * eq.numberOfBands).toInt()
                    .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
                runCatching { eq.setBandLevel(hwBand, level.toShort()) }
            }
            refreshBands(eq)
        }
        toast("Perfil: $profile")
    }

    // ── Custom presets ────────────────────────────────────────────────────────
    private fun showSavePresetDialog() {
        val eq    = equalizer ?: return
        val input = EditText(this).apply { hint = "Nombre del preset"; setPadding(48.dp, 24.dp, 48.dp, 8.dp) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Guardar preset")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { toast("El nombre no puede estar vacío"); return@setPositiveButton }
                val levels = bandSeekBars.indices.map { i ->
                    val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands).toInt()
                        .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
                    runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
                }
                saveCustomPreset(name, levels); loadCustomPresets(); toast("\"$name\" guardado")
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun saveCustomPreset(name: String, levels: List<Int>) {
        val prefs    = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned  = JSONArray()
        for (i in 0 until existing.length()) { val o = existing.getJSONObject(i); if (o.getString("name") != name) cleaned.put(o) }
        cleaned.put(JSONObject().apply { put("name", name); put("levels", JSONArray(levels)) })
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun loadCustomPresets() {
        customPresetRow.removeAllViews()
        val prefs   = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val presets = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        if (presets.length() == 0) {
            customPresetRow.addView(TextView(this).apply {
                text = "Sin presets guardados"; textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            }); return
        }
        for (i in 0 until presets.length()) {
            val obj       = presets.getJSONObject(i)
            val name      = obj.getString("name")
            val levelsArr = obj.getJSONArray("levels")
            val levels    = (0 until levelsArr.length()).map { levelsArr.getInt(it) }
            customPresetRow.addView(makeChip(name, longPress = {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Eliminar preset")
                    .setMessage("¿Eliminar \"$name\"?")
                    .setPositiveButton("Eliminar") { _, _ -> deleteCustomPreset(name); loadCustomPresets(); toast("Eliminado") }
                    .setNegativeButton("Cancelar", null).show()
            }) { applyScaledPreset(levels); toast("Preset: $name") })
        }
    }

    private fun deleteCustomPreset(name: String) {
        val prefs    = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned  = JSONArray()
        for (i in 0 until existing.length()) { val o = existing.getJSONObject(i); if (o.getString("name") != name) cleaned.put(o) }
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun refreshBands(eq: Equalizer) {
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel   = levelRange[0].toInt()
        val range      = (levelRange[1].toInt() - minLevel).coerceAtLeast(1)
        bandSeekBars.forEachIndexed { i, sb ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands).toInt()
                .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            val level  = runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
            sb.progress = (level - minLevel).coerceIn(0, range)
            val c = dbColor(level)
            sb.progressTintList = android.content.res.ColorStateList.valueOf(c)
            sb.thumbTintList    = android.content.res.ColorStateList.valueOf(c)
            bandValueLabels.getOrNull(i)?.apply { text = formatDb(level); setTextColor(c) }
        }
        updateCurve(eq)
    }

    private fun resetBands() {
        val eq = equalizer ?: return
        (0 until eq.numberOfBands).forEach { i -> runCatching { eq.setBandLevel(i.toShort(), 0) } }
        refreshBands(eq); saveBandLevels(); toast("Ecualizador restablecido")
    }

    private fun saveBandLevels() {
        val eq      = equalizer ?: return
        val profile = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_PROFILE, "General") ?: "General"
        val levels  = bandSeekBars.indices.map { i ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands).toInt()
                .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
        }
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_BAND_LEVELS, levels.joinToString(","))
            .putString("eq_band_levels_$profile", levels.joinToString(","))
            .putBoolean(KEY_EQ_ENABLED, eq.enabled)
            .apply()
    }

    private fun restoreBandLevels(eq: Equalizer) {
        val prefs  = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw    = prefs.getString(KEY_BAND_LEVELS, null) ?: return
        val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
        levels.forEachIndexed { i, level ->
            val hwBand = ((i.toFloat() / levels.size.coerceAtLeast(1)) * eq.numberOfBands).toInt()
                .coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.setBandLevel(hwBand, level.toShort()) }
        }
        eq.enabled = prefs.getBoolean(KEY_EQ_ENABLED, true)
        refreshBands(eq)
    }

    private fun populateSystemPresets(eq: Equalizer) {
        val scroll = rootLayout.findViewById<HorizontalScrollView>(R.id.ids_chip_container) ?: return
        val row    = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4.dp, 4.dp, 4.dp, 4.dp) }
        val count  = eq.numberOfPresets.toInt()
        if (count > 0) {
            (0 until count).forEach { i ->
                val name = eq.getPresetName(i.toShort())
                row.addView(makeChip(name) { eq.usePreset(i.toShort()); refreshBands(eq); saveBandLevels(); toast("Preset: $name") })
            }
        } else {
            row.addView(TextView(this).apply {
                text = "No hay presets del sistema"; textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            })
        }
        scroll.addView(row)
    }

    private fun dbColor(milliDb: Int) = ContextCompat.getColor(this,
        when { milliDb > 200  -> R.color.accent_blue; milliDb < -200 -> R.color.accent_pink; else -> R.color.text_secondary })

    private fun formatDb(milliDb: Int): String {
        val db = milliDb / 100
        return if (db > 0) "+${db}" else "$db"
    }

    private fun makeChip(text: String, selected: Boolean = false, longPress: (() -> Unit)? = null, onClick: () -> Unit) =
        Chip(this).apply {
            this.text = text; textSize = 12f
            chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                if (selected) ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue)
                else ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
            setTextColor(ContextCompat.getColor(this@EqualizerActivity,
                if (selected) android.R.color.white else R.color.text_primary))
            chipStrokeColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            chipStrokeWidth = 1.5f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8.dp }
            setOnClickListener { onClick() }
            longPress?.let { lp -> setOnLongClickListener { lp(); true } }
        }

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text; textSize = 13f; typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = 12.dp; it.bottomMargin = 4.dp }
        setPadding(24.dp, 0, 24.dp, 0)
    }

    private fun sectionDivider() = View(this).apply {
        setBackgroundColor(0x18FFFFFF)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            .also { it.topMargin = 8.dp }
    }

    private fun toast(msg: String) = Snackbar.make(rootLayout, msg, Snackbar.LENGTH_SHORT).show()
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        saveBandLevels()
        equalizer?.release();   equalizer   = null
        bassBoost?.release();   bassBoost   = null
        virtualizer?.release(); virtualizer = null
        super.onDestroy()
    }
}
