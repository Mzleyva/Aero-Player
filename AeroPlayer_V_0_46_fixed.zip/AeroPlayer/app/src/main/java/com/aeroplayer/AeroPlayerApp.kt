package com.aeroplayer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aeroplayer.utils.CrashLogger

class AeroPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Iniciar el crash logger PRIMERO — antes de cualquier otra cosa
        CrashLogger.init(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK,
                "Reproducción de música",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción de AeroPlayer"
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            // Canal interno de Media3 1.4.1
            val media3Channel = NotificationChannel(
                "default_channel_id",
                "Reproducción de música",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            nm.createNotificationChannel(playbackChannel)
            nm.createNotificationChannel(media3Channel)
        }
    }

    companion object {
        const val CHANNEL_PLAYBACK = "aero_playback_channel"
    }
}
