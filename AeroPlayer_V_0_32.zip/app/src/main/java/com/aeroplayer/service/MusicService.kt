package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.aeroplayer.R
import com.aeroplayer.ui.player.PlayerActivity

class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    // ── Progress notification ─────────────────────────────────────────────
    private val notifHandler = Handler(Looper.getMainLooper())
    private val PROGRESS_CHANNEL = "aero_progress"
    private val PROGRESS_NOTIF_ID = 9001

    private val progressUpdater = object : Runnable {
        override fun run() {
            updateProgressNotification()
            notifHandler.postDelayed(this, 1_000)
        }
    }

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
    }

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()

        createProgressChannel()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) notifHandler.post(progressUpdater)
                else notifHandler.removeCallbacks(progressUpdater)
                updateProgressNotification()
            }
        })
    }

    private fun createProgressChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                PROGRESS_CHANNEL,
                "Progreso de reproducción",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Muestra el progreso de la canción actual"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun updateProgressNotification() {
        if (!player.isPlaying && player.currentPosition == 0L) return
        val duration = player.duration.takeIf { it > 0 } ?: return
        val position = player.currentPosition
        val progress = ((position * 100) / duration).toInt()

        val meta = player.mediaMetadata
        val title  = meta.title?.toString() ?: "Aero Player"
        val artist = meta.artist?.toString() ?: ""

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif = NotificationCompat.Builder(this, PROGRESS_CHANNEL)
            .setSmallIcon(R.drawable.ic_music_placeholder)
            .setContentTitle(title)
            .setContentText(artist)
            .setProgress(100, progress, false)
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(player.isPlaying)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(PROGRESS_NOTIF_ID, notif)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        notifHandler.removeCallbacks(progressUpdater)
        getSystemService(NotificationManager::class.java).cancel(PROGRESS_NOTIF_ID)
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        audioSessionId = 0
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}

