package com.aeroplayer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        LikedSongEntity::class,
        PlaylistEntity::class,
        PlaylistSongEntity::class,
        PlayCountEntity::class,
        SongCanvasEntity::class,
        SongCacheEntity::class,
        ListeningHistoryEntity::class,
        BookmarkEntity::class,
        RadioEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun likedSongDao(): LikedSongDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun playCountDao(): PlayCountDao
    abstract fun songCanvasDao(): SongCanvasDao
    abstract fun songCacheDao(): SongCacheDao
    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun radioDao(): RadioDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        /** Migración 1→2: crea la tabla song_canvas sin destruir datos existentes. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `song_canvas` (
                        `songId` INTEGER NOT NULL PRIMARY KEY,
                        `gifUri` TEXT NOT NULL,
                        `assignedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }


        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `song_cache` (
                        `songId` INTEGER NOT NULL PRIMARY KEY,
                        `title` TEXT NOT NULL,
                        `artist` TEXT NOT NULL,
                        `album` TEXT NOT NULL,
                        `duration` INTEGER NOT NULL,
                        `path` TEXT NOT NULL,
                        `albumArtUri` TEXT,
                        `uri` TEXT NOT NULL,
                        `albumId` INTEGER NOT NULL,
                        `trackNumber` INTEGER NOT NULL,
                        `year` INTEGER NOT NULL,
                        `size` INTEGER NOT NULL,
                        `cachedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `listening_history` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `songId` INTEGER NOT NULL,
                        `title` TEXT NOT NULL,
                        `artist` TEXT NOT NULL,
                        `album` TEXT NOT NULL,
                        `path` TEXT NOT NULL,
                        `albumArtUri` TEXT,
                        `duration` INTEGER NOT NULL DEFAULT 0,
                        `playedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        /**
         * Migración 4→5: sin-op — versión intermedia para mantener cadena de migraciones.
         * Uso: asegura que dispositivos con BD versión 4 puedan migrar directamente a 5.
         */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // No-op: esta versión no agrega tablas ni columnas nuevas.
                // Reservada para compatibilidad de dispositivos con DB v4.
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `bookmarks` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `songId` INTEGER NOT NULL,
                    `title` TEXT NOT NULL,
                    `label` TEXT NOT NULL,
                    `positionMs` INTEGER NOT NULL,
                    `durationMs` INTEGER NOT NULL,
                    `createdAt` INTEGER NOT NULL
                )""")
                db.execSQL("""CREATE TABLE IF NOT EXISTS `online_radios` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `name` TEXT NOT NULL,
                    `streamUrl` TEXT NOT NULL,
                    `genre` TEXT NOT NULL DEFAULT '',
                    `country` TEXT NOT NULL DEFAULT '',
                    `logoUrl` TEXT,
                    `isFavorite` INTEGER NOT NULL DEFAULT 0,
                    `addedAt` INTEGER NOT NULL
                )""")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE listening_history ADD COLUMN durationMs INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aeroplayer.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
