package com.aeroplayer.ui.nova

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║         ANIMATED AURORA VIEW — Tema Aero (aurora + vinilo)                        ║
 * ║                                                                          ║
 * ║  Vista personalizada que dibuja una aurora boreal animada en canvas.    ║
 * ║  Bandas luminosas ondulantes con colores cyan/azul/verde similar a      ║
 * ║  la imagen de referencia del tema Windows Vista Aero.                          ║
 * ║                                                                          ║
 * ║  USO en XML:                                                             ║
 * ║    <com.aeroplayer.ui.nova.AnimatedAuroraView                           ║
 * ║        android:layout_width="match_parent"                              ║
 * ║        android:layout_height="match_parent"                             ║
 * ║        android:visibility="gone" />                                     ║
 * ║                                                                          ║
 * ║  Mostrar/iniciar desde código:                                          ║
 * ║    auroraView.visibility = View.VISIBLE                                 ║
 * ║    (la animación arranca automáticamente al hacerse visible)            ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
class AnimatedAuroraView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // ── Configuración de bandas aurora ────────────────────────────────────────

    /**
     * Cada banda define: posición vertical relativa (0..1), amplitud relativa,
     * velocidad de animación, desfase inicial y color ARGB.
     */
    private data class AuroraBand(
        val yCenter: Float,        // fracción de la altura (0.0 = top, 1.0 = bottom)
        val amplitude: Float,      // amplitud máxima como fracción de la altura
        val bandThickness: Float,  // grosor de la banda como fracción de la altura
        val speedFactor: Float,    // multiplicador de velocidad (1.0 = normal)
        val phaseOffset: Float,    // desfase inicial en radianes
        val color: Int             // color ARGB (alpha incluido para el specular)
    )

    private val bands = listOf(
        // Banda 0: Cyan brillante — la más visible, centro de la pantalla
        AuroraBand(0.48f, 0.12f, 0.22f, 1.0f,  0.0f,           Color.argb(110, 0, 210, 255)),
        // Banda 1: Azul cielo — ancha y lenta, da profundidad
        AuroraBand(0.40f, 0.18f, 0.28f, 0.55f, PI.toFloat(),   Color.argb(90, 20, 100, 240)),
        // Banda 2: Teal/verde-agua — media velocidad, ligeramente baja
        AuroraBand(0.58f, 0.10f, 0.18f, 1.4f,  PI.toFloat() / 2f, Color.argb(80, 0, 180, 140)),
        // Banda 3: Violeta profundo — rápida y sutil, toque de magia
        AuroraBand(0.33f, 0.14f, 0.20f, 0.7f,  PI.toFloat() * 1.5f, Color.argb(55, 110, 60, 200)),
        // Banda 4: Azul medianoche — muy ancha y lenta, capa de fondo
        AuroraBand(0.62f, 0.08f, 0.35f, 0.3f,  PI.toFloat() * 0.7f, Color.argb(50, 0, 60, 160))
    )

    // ── Segmentos para las curvas (más = más suave, pero más costoso) ────────
    private val CURVE_SEGMENTS = 32

    // ── Animación ─────────────────────────────────────────────────────────────
    private var phase = 0f   // fase global de la animación (0..2π cicla infinitamente)
    private var animator: ValueAnimator? = null

    // ── Paints ────────────────────────────────────────────────────────────────
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }
    /** Paint para el fondo — se crea una vez, el shader se actualiza en onSizeChanged */
    private val bgPaint = Paint()

    // ── Estrellas de fondo (pre-calculadas una vez al medir) ─────────────────
    private data class Star(val x: Float, val y: Float, val radius: Float, val alpha: Float)
    private val stars = mutableListOf<Star>()
    private var starsGenerated = false

    // ── Paths reutilizables (evitar alloc en onDraw) ──────────────────────────
    private val bandPath = Path()

    // ── onAttach / onDetach: gestión del ciclo de vida del animator ──────────

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startAnimation()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopAnimation()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) startAnimation() else stopAnimation()
    }

    // ── Arranque y parada de la animación ─────────────────────────────────────

    private fun startAnimation() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, (2f * PI).toFloat()).apply {
            duration = 12_000L          // ciclo completo en 12 segundos
            repeatCount = ValueAnimator.INFINITE
            repeatMode  = ValueAnimator.RESTART
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                phase = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimation() {
        animator?.cancel()
        animator = null
    }

    // ── Generación de estrellas ───────────────────────────────────────────────

    private fun generateStars(w: Int, h: Int) {
        stars.clear()
        val rng = java.util.Random(42L)   // semilla fija → siempre las mismas estrellas
        val count = (w * h / 6000).coerceIn(60, 200)
        repeat(count) {
            val x     = rng.nextFloat() * w
            val y     = rng.nextFloat() * h * 0.75f   // estrellas solo en la mitad superior
            val r     = rng.nextFloat() * 1.6f + 0.4f
            val alpha = rng.nextFloat() * 0.7f + 0.15f
            stars.add(Star(x, y, r, alpha))
        }
        starsGenerated = true
    }

    // ── onSizeChanged: regenerar estrellas cuando cambia el tamaño ──────────

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        starsGenerated = false
        // Recalcular el shader del fondo al cambiar el tamaño
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(
                Color.parseColor("#030A14"),
                Color.parseColor("#060F20"),
                Color.parseColor("#040D1C"),
                Color.parseColor("#020810")
            ),
            floatArrayOf(0f, 0.35f, 0.70f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    // ── onDraw ────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // 1. Fondo: gradiente vertical profundo
        drawBackground(canvas, w, h)

        // 2. Estrellas (pre-calculadas)
        if (!starsGenerated) generateStars(width, height)
        drawStars(canvas)

        // 3. Bandas aurora
        for (band in bands) {
            drawBand(canvas, band, w, h)
        }
    }

    // ── Fondo degradado ────────────────────────────────────────────────────────

    private fun drawBackground(canvas: Canvas, w: Float, h: Float) {
        // Si onSizeChanged aún no corrió (primer frame), inicializar shader
        if (bgPaint.shader == null) {
            bgPaint.shader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(
                    Color.parseColor("#030A14"),
                    Color.parseColor("#060F20"),
                    Color.parseColor("#040D1C"),
                    Color.parseColor("#020810")
                ),
                floatArrayOf(0f, 0.35f, 0.70f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, w, h, bgPaint)
    }

    // ── Dibujo de estrellas ───────────────────────────────────────────────────

    private fun drawStars(canvas: Canvas) {
        for (star in stars) {
            // Pulso sutil sincronizado con la fase global
            val twinkle = (0.6f + 0.4f * sin(phase * 2.5f + star.x * 0.03f)).toFloat()
            starPaint.alpha = (star.alpha * twinkle * 255f).toInt().coerceIn(0, 255)
            canvas.drawCircle(star.x, star.y, star.radius, starPaint)
        }
    }

    // ── Dibujo de una banda aurora ─────────────────────────────────────────────

    private fun drawBand(canvas: Canvas, band: AuroraBand, w: Float, h: Float) {
        val centerY   = band.yCenter * h
        val amplitude = band.amplitude * h
        val thickness = band.bandThickness * h
        val halfThick = thickness / 2f
        val stepX     = w / CURVE_SEGMENTS

        // Calcular los puntos Y de la curva para el borde superior de la banda
        val topY    = FloatArray(CURVE_SEGMENTS + 1)
        val bottomY = FloatArray(CURVE_SEGMENTS + 1)

        for (i in 0..CURVE_SEGMENTS) {
            val x     = i * stepX
            val wave  = sin(
                (x / w) * 2.0 * PI * 1.8 +   // frecuencia espacial
                phase * band.speedFactor +      // fase de tiempo
                band.phaseOffset                // desfase de la banda
            ).toFloat()
            // Segundo armónico suave para más naturalidad
            val wave2 = sin(
                (x / w) * 2.0 * PI * 3.2 +
                phase * band.speedFactor * 1.6f +
                band.phaseOffset + 1.1f
            ).toFloat() * 0.3f

            val midY = centerY + (wave + wave2) * amplitude
            topY[i]    = midY - halfThick * 0.4f
            bottomY[i] = midY + halfThick * 0.6f
        }

        // Construir el Path de la banda (borde superior → borde inferior en reversa)
        bandPath.reset()
        bandPath.moveTo(0f, topY[0])
        for (i in 1..CURVE_SEGMENTS) {
            val xPrev = (i - 1) * stepX
            val xCurr = i * stepX
            val cpX   = (xPrev + xCurr) / 2f
            bandPath.quadTo(xPrev, topY[i - 1], cpX, (topY[i - 1] + topY[i]) / 2f)
        }
        bandPath.lineTo(w, topY[CURVE_SEGMENTS])
        bandPath.lineTo(w, bottomY[CURVE_SEGMENTS])
        for (i in CURVE_SEGMENTS downTo 1) {
            val xPrev = i * stepX
            val xCurr = (i - 1) * stepX
            val cpX   = (xPrev + xCurr) / 2f
            bandPath.quadTo(xPrev, bottomY[i], cpX, (bottomY[i] + bottomY[i - 1]) / 2f)
        }
        bandPath.lineTo(0f, bottomY[0])
        bandPath.close()

        // Shader: degradado vertical transparente → color → transparente
        // centrado en el punto medio de la banda
        val midY0    = (topY[0] + bottomY[0]) / 2f
        val midYLast = (topY[CURVE_SEGMENTS] + bottomY[CURVE_SEGMENTS]) / 2f
        val gradCY   = (midY0 + midYLast) / 2f

        val baseColor = band.color
        val transparent = Color.argb(0,
            Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))

        bandPaint.shader = LinearGradient(
            0f, gradCY - halfThick,
            0f, gradCY + halfThick,
            intArrayOf(transparent, baseColor, baseColor, transparent),
            floatArrayOf(0f, 0.3f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )

        canvas.drawPath(bandPath, bandPaint)
    }
}
