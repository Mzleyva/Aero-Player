package com.aeroplayer.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.collection.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Carga carátulas directamente desde el archivo de audio usando MediaMetadataRetriever.
 * Igual que Oto Music, AIMP y Poweramp — no depende de MediaStore ni de permisos de imágenes.
 */
object AlbumArtUtils {

    // Cache en memoria: hasta 1/8 de la RAM disponible, máx 20MB
    private val memCache: LruCache<Long, Bitmap> = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt().coerceAtMost(20 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }

    // Set de IDs que ya intentamos y no tienen carátula (para no reintentar)
    private val noArtIds = mutableSetOf<Long>()

    /**
     * Obtiene el bitmap de forma síncrona si está en cache, null si no.
     * Usar en onBindViewHolder — no bloquea el hilo principal.
     */
    fun getCached(songId: Long): Bitmap? = memCache.get(songId)

    /**
     * Carga la carátula desde el archivo de audio en un hilo de IO.
     * Llamar desde una coroutine (lifecycleScope o viewModelScope).
     */
    suspend fun loadArt(songId: Long, filePath: String): Bitmap? {
        // Ya en cache
        memCache.get(songId)?.let { return it }
        // Ya sabemos que no tiene carátula
        if (songId in noArtIds) return null

        return withContext(Dispatchers.IO) {
            runCatching {
                MediaMetadataRetriever().use { mmr ->
                    mmr.setDataSource(filePath)
                    val art = mmr.embeddedPicture ?: return@runCatching null
                    BitmapFactory.decodeByteArray(art, 0, art.size)
                }
            }.getOrNull().also { bmp ->
                if (bmp != null) memCache.put(songId, bmp)
                else noArtIds.add(songId)
            }
        }
    }

    /**
     * Versión síncrona — SOLO usar si ya estás en un hilo de IO (Dispatchers.IO).
     */
    fun getAlbumArt(songId: Long, filePath: String): Bitmap? {
        memCache.get(songId)?.let { return it }
        if (songId in noArtIds) return null

        return runCatching {
            MediaMetadataRetriever().use { mmr ->
                mmr.setDataSource(filePath)
                val art = mmr.embeddedPicture ?: return null
                BitmapFactory.decodeByteArray(art, 0, art.size)
            }
        }.getOrNull().also { bmp ->
            if (bmp != null) memCache.put(songId, bmp)
            else noArtIds.add(songId)
        }
    }

    fun clearCache() {
        memCache.evictAll()
        noArtIds.clear()
    }
}
