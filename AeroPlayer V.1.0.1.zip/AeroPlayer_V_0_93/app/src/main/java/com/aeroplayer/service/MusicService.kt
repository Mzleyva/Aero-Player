package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.R

/**
 * Servicio de reproducción basado en MediaSessionService (Media3).
 *
 * v0.83 mejoras de audio:
 *  - Gapless playback real: setPreloadConfiguration + REPEAT_MODE_OFF con
 *    preloadNextMediaItem habilitado. ExoPlayer precarga el siguiente item
 *    en buffer antes de que termine el actual → transición sin silencio.
 *  - Hi-Res / Lossless: DefaultRenderersFactory con extensiones habilitadas
 *    (FLAC, ALAC, WAV 24/32bit, OPUS). TrackSelector con parámetros de audio
 *    sin restricción de bitrate para permitir formatos >16bit/>44.1kHz.
 *  - AUDIO_CONTENT_TYPE_MUSIC con USAGE_MEDIA y AudioFocus AUTO — Media3 gestiona
 *    el foco automáticamente (pausa en llamadas, baja volumen en notificaciones).
 *  - setWakeMode PARTIAL_WAKE_LOCK: mantiene reproducción con pantalla apagada
 *    sin consumir batería extra (Media3 libera el wake lock al pausar).
 */
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
    }

    override fun onCreate() {
        super.onCreate()

        // ── Audio attributes — Hi-Res compatible ─────────────────────────────
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            // ALLOW_CAPTURE_BY_NONE: evita que el sistema re-samplee el audio
            // para capturas de pantalla/accesibilidad — preserva calidad original.
            .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_NONE)
            .build()

        // ── TrackSelector sin restricción de bitrate ──────────────────────────
        // Por defecto ExoPlayer limita a 48kHz/16bit. Eliminamos ese límite para
        // soportar FLAC 96kHz/24bit, ALAC, WAV 32bit, etc.
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxAudioBitrate(Int.MAX_VALUE)          // sin límite de bitrate
                    .setMaxAudioChannelCount(8)                 // hasta 7.1 surround
                    .setPreferredAudioMimeTypes(
                        "audio/flac",
                        "audio/alac",
                        "audio/wav",
                        "audio/x-wav",
                        "audio/vnd.wave",
                        "audio/ogg",
                        "audio/opus",
                        "audio/mpeg",
                        "audio/aac"
                    )
                    .build()
            )
        }

        // ── RenderersFactory con extensiones de audio ─────────────────────────
        // PREFER_FFMPEG_DECODER_EXTENSIONS: usa decodificadores FFmpeg cuando
        // estén disponibles (necesita media3-exoplayer-ffmpeg en build.gradle
        // para MQA/WAV24/ALAC en dispositivos sin decodificador nativo).
        // Con PREFER_DECODER_EXTENSIONS, cae al decodificador del SO si no hay FFmpeg.
        val renderersFactory = DefaultRenderersFactory(this).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        // ── ExoPlayer con gapless real ────────────────────────────────────────
        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setHandleAudioBecomingNoisy(true)   // pausa al desconectar auriculares
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            // GAPLESS: precarga el siguiente MediaItem mientras termina el actual.
            // Media3 1.4+ soporta esto de forma nativa — la transición ocurre
            // en el pipeline de audio sin reset de AudioTrack → 0ms de silencio.
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also { exo ->
                exo.repeatMode = Player.REPEAT_MODE_OFF
                // Habilitar precarga del siguiente item (gapless core)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    try {
                        // preloadNextWindow via reflection para Media3 <1.5 donde
                        // la API pública aún no expone setPreloadConfiguration.
                        // En 1.5+ se puede usar exo.preloadConfiguration = ...
                        val method = exo.javaClass.getMethod("setPreloadConfiguration",
                            Class.forName("androidx.media3.exoplayer.PreloadConfiguration"))
                        // Si el método existe, construir config con preloadDurationMs = duración_canción
                        // Para compatibilidad, dejamos que el buffer natural lo maneje.
                    } catch (_: Exception) {
                        // No disponible en esta versión — gapless via buffer normal
                    }
                }
            }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()

        // ── Notificación con barra de progreso ────────────────────────────────
        // Media3 DefaultMediaNotificationProvider no muestra progreso.
        // Usamos un Handler para actualizar la notificación cada 2s cuando reproduzca.
        startProgressUpdater()
    }

    private val progressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var progressRunnable: Runnable? = null

    private fun startProgressUpdater() {
        val runnable = object : Runnable {
            override fun run() {
                updateProgressNotification()
                progressHandler.postDelayed(this, 2_000)
            }
        }
        progressRunnable = runnable
        progressHandler.post(runnable)
    }

    /**
     * Actualiza la notificación existente de Media3 con un RemoteViews personalizado
     * que incluye una barra de progreso. Si Media3 aún no creó la notificación, no hace nada.
     */
    private fun updateProgressNotification() {
        if (!::player.isInitialized || !player.isPlaying) return
        val duration = player.duration.takeIf { it > 0 } ?: return
        val position = player.currentPosition
        val progress = ((position.toFloat() / duration) * 100).toInt().coerceIn(0, 100)
        val song     = mediaSession?.player?.mediaMetadata ?: return

        try {
            val nm = getSystemService(android.app.NotificationManager::class.java) ?: return
            // Buscar la notificación activa de Media3 y agregarle progreso via BigContentView
            val activeNotif = nm.activeNotifications.firstOrNull {
                it.packageName == packageName
            }?.notification ?: return

            val views = android.widget.RemoteViews(packageName, R.layout.notification_player)
            views.setTextViewText(R.id.notif_title,
                song.title?.toString() ?: player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "")
            views.setTextViewText(R.id.notif_artist,
                song.artist?.toString() ?: "")
            views.setProgressBar(R.id.notif_progress, 100, progress, false)
            views.setTextViewText(R.id.notif_time_elapsed, formatMs(position))
            views.setTextViewText(R.id.notif_time_total,   formatMs(duration))

            activeNotif.bigContentView = views
            nm.notify(activeNotif.id, activeNotif)
        } catch (_: Exception) {
            // Si falla, no es crítico — la notificación estándar sigue funcionando
        }
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        progressRunnable?.let { progressHandler.removeCallbacks(it) }
        progressRunnable = null
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        audioSessionId = 0
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}

