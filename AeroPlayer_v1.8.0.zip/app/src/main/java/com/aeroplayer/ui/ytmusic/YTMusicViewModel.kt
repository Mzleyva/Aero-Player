package com.aeroplayer.ui.ytmusic

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.aeroplayer.data.repository.YTMusicExtractor
import com.aeroplayer.model.Song
import com.aeroplayer.model.YTPlaylist
import com.aeroplayer.model.YTResult
import com.aeroplayer.model.YTSong
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * YTMusicViewModel  —  v1.3.4
 *
 * CORRECCIONES:
 *  - Bug: resolvePlaylistQueue() llamaba playSongs() en cada canción resuelta,
 *    reiniciando la reproducción. Fix: primera canción → playSongs(), el resto
 *    → addToQueue() para extender sin interrumpir.
 *  - Bug: searchJob no se cancelaba si el Fragment se destruía antes de terminar
 *    la búsqueda, causando postValue() sobre LiveData inactivo.
 *    Fix: viewModelScope cancela automáticamente al limpiar el ViewModel.
 *  - Bug: clearSearch() no reseteaba lastQuery, impidiendo relanzar la misma
 *    búsqueda después de limpiar el campo.
 */
class YTMusicViewModel(app: Application) : AndroidViewModel(app) {

    private val extractor = YTMusicExtractor.getInstance(app)

    // ── Search ───────────────────────────────────────────────────────────────

    private val _searchResults = MutableLiveData<List<YTSong>>(emptyList())
    val searchResults: LiveData<List<YTSong>> = _searchResults

    private val _isSearching = MutableLiveData(false)
    val isSearching: LiveData<Boolean> = _isSearching

    private val _searchError = MutableLiveData<String?>(null)
    val searchError: LiveData<String?> = _searchError

    private var searchJob: Job? = null
    private var lastQuery = ""

    fun search(query: String) {
        if (query == lastQuery) return
        lastQuery = query
        searchJob?.cancel()
        if (query.isBlank()) { _searchResults.value = emptyList(); return }

        searchJob = viewModelScope.launch {
            delay(300) // debounce
            _isSearching.value = true
            _searchError.value = null
            when (val r = extractor.search(query)) {
                is YTResult.Success -> _searchResults.value = r.data
                is YTResult.Error   -> { _searchError.value = r.message; _searchResults.value = emptyList() }
                else -> Unit
            }
            _isSearching.value = false
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        lastQuery = ""      // FIX BUG: resetear para poder relanzar la misma query
        _searchResults.value = emptyList()
        _searchError.value = null
        _isSearching.value = false
    }

    // ── Playlist ─────────────────────────────────────────────────────────────

    private val _currentPlaylist = MutableLiveData<YTPlaylist?>(null)
    val currentPlaylist: LiveData<YTPlaylist?> = _currentPlaylist

    private val _isLoadingPlaylist = MutableLiveData(false)
    val isLoadingPlaylist: LiveData<Boolean> = _isLoadingPlaylist

    private val _playlistError = MutableLiveData<String?>(null)
    val playlistError: LiveData<String?> = _playlistError

    fun loadPlaylist(url: String) {
        viewModelScope.launch {
            _isLoadingPlaylist.value = true
            _playlistError.value = null
            when (val r = extractor.getPlaylist(url)) {
                is YTResult.Success -> _currentPlaylist.value = r.data
                is YTResult.Error   -> _playlistError.value = r.message
                else -> Unit
            }
            _isLoadingPlaylist.value = false
        }
    }

    // ── Stream resolution — single song ───────────────────────────────────────

    private val _streamState = MutableLiveData<StreamState>(StreamState.Idle)
    val streamState: LiveData<StreamState> = _streamState

    sealed class StreamState {
        object Idle    : StreamState()
        object Loading : StreamState()
        data class Ready(val song: Song) : StreamState()
        data class Error(val msg: String) : StreamState()
    }

    fun resolveAndPlay(ytSong: YTSong) {
        viewModelScope.launch {
            _streamState.value = StreamState.Loading
            _streamState.value = when (val r = extractor.resolveToSong(ytSong)) {
                is YTResult.Success -> StreamState.Ready(r.data)
                is YTResult.Error   -> StreamState.Error(r.message)
                else -> StreamState.Idle
            }
        }
    }

    fun clearStreamState() { _streamState.value = StreamState.Idle }

    // ── Playlist queue resolution ─────────────────────────────────────────────

    private val _resolvedQueue = MutableLiveData<List<Song>>(emptyList())
    val resolvedQueue: LiveData<List<Song>> = _resolvedQueue

    private val _queueResolutionProgress = MutableLiveData(0 to 0)
    val queueResolutionProgress: LiveData<Pair<Int, Int>> = _queueResolutionProgress

    private var queueJob: Job? = null

    /**
     * Resuelve la lista de [YTSong] en background, canción a canción.
     *
     * FIX BUG: la primera canción resuelta se emite vía [_resolvedQueue] para
     * que el Fragment inicie la reproducción con playSongs(). Las siguientes se
     * añaden directamente con PlayerController.addToQueue() para NO reiniciar
     * la cola cada vez que llega una nueva canción.
     */
    fun resolvePlaylistQueue(songs: List<YTSong>) {
        queueJob?.cancel()
        _resolvedQueue.value = emptyList()
        _queueResolutionProgress.value = 0 to songs.size
        var firstSongEmitted = false

        queueJob = viewModelScope.launch {
            songs.forEachIndexed { idx, ytSong ->
                when (val r = extractor.resolveToSong(ytSong)) {
                    is YTResult.Success -> {
                        if (!firstSongEmitted) {
                            // Emitir la primera canción → Fragment llama playSongs()
                            _resolvedQueue.postValue(listOf(r.data))
                            firstSongEmitted = true
                        } else {
                            // Las siguientes se añaden a la cola activa
                            PlayerController.addToQueue(r.data)
                        }
                        _queueResolutionProgress.postValue((idx + 1) to songs.size)
                    }
                    is YTResult.Error -> {
                        // Canción fallida: omitir y continuar
                        _queueResolutionProgress.postValue((idx + 1) to songs.size)
                    }
                    else -> Unit
                }
            }
        }
    }

    fun cancelQueueResolution() {
        queueJob?.cancel()
        _queueResolutionProgress.value = 0 to 0
    }

    override fun onCleared() {
        super.onCleared()
        extractor.clearStreamCache()
    }
}
