package com.aeroplayer.data.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface LikedSongDao {
    @Query("SELECT * FROM liked_songs ORDER BY likedAt DESC")
    fun getAllLiked(): LiveData<List<LikedSongEntity>>

    @Query("SELECT * FROM liked_songs ORDER BY likedAt DESC")
    suspend fun getAllLikedSync(): List<LikedSongEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(song: LikedSongEntity)

    @Delete
    suspend fun delete(song: LikedSongEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM liked_songs WHERE songId = :id)")
    suspend fun isLiked(id: Long): Boolean

    @Query("DELETE FROM liked_songs WHERE songId = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM liked_songs")
    fun getCount(): LiveData<Int>
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): LiveData<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylistsSync(): List<PlaylistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position")
    fun getSongsForPlaylist(playlistId: Long): LiveData<List<PlaylistSongEntity>>

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position")
    suspend fun getSongsForPlaylistSync(playlistId: Long): List<PlaylistSongEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongToPlaylist(song: PlaylistSongEntity)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    /** FIX: persist reorder — updates the position of a single song entry. */
    @Query("UPDATE playlist_songs SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun updateSongPosition(playlistId: Long, songId: Long, position: Int)

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId")
    fun getSongCount(playlistId: Long): LiveData<Int>

    @Query("SELECT COUNT(*) FROM playlists")
    fun getPlaylistCount(): LiveData<Int>
}

@Dao
interface PlayCountDao {
    @Query("SELECT * FROM play_counts ORDER BY count DESC LIMIT :limit")
    suspend fun getTopPlayed(limit: Int = 20): List<PlayCountEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PlayCountEntity)

    @Query("SELECT * FROM play_counts WHERE songId = :id")
    suspend fun getByid(id: Long): PlayCountEntity?

    @Query("UPDATE play_counts SET count = count + 1, lastPlayed = :time WHERE songId = :id")
    suspend fun increment(id: Long, time: Long = System.currentTimeMillis())
}

/** DAO para los GIF Canvas asignados por el usuario a cada canción. */
@Dao
interface SongCanvasDao {

    @Query("SELECT * FROM song_canvas WHERE songId = :songId")
    suspend fun getCanvas(songId: Long): SongCanvasEntity?

    @Query("SELECT * FROM song_canvas WHERE songId = :songId")
    fun getCanvasLive(songId: Long): LiveData<SongCanvasEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setCanvas(canvas: SongCanvasEntity)

    @Query("DELETE FROM song_canvas WHERE songId = :songId")
    suspend fun deleteCanvas(songId: Long)
}
