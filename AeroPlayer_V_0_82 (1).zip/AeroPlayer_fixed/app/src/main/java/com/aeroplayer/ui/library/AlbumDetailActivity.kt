package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityAlbumDetailBinding
import com.aeroplayer.databinding.ItemPlaylistSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.AccentApplier
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.utils.AlbumArtUtils
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AlbumDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ALBUM_NAME  = "album_name"
        const val EXTRA_ARTIST_NAME = "artist_name"
    }

    private lateinit var binding: ActivityAlbumDetailBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAlbumDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AccentApplier.apply(this, binding.root)

        val albumName  = intent.getStringExtra(EXTRA_ALBUM_NAME)  ?: run { finish(); return }
        val artistName = intent.getStringExtra(EXTRA_ARTIST_NAME) ?: ""

        binding.btnBack.setOnClickListener { finish() }

        viewModel.allSongs.observe(this) { allSongs ->
            val songs = allSongs
                .filter { it.album == albumName && (artistName.isEmpty() || it.artist == artistName) }
                .sortedBy { it.trackNumber }

            binding.tvAlbumName.text   = albumName
            binding.tvAlbumArtist.text = songs.firstOrNull()?.artist ?: artistName
            binding.tvAlbumInfo.text   = "${songs.size} canción${if (songs.size != 1) "es" else ""}"

            loadCover(songs)
            setupSongs(songs)
            setupButtons(songs, albumName)
        }
    }

    private fun loadCover(songs: List<Song>) {
        val repSong = songs.firstOrNull() ?: return

        val cached = AlbumArtUtils.getCached(repSong.id)
        if (cached != null) {
            Glide.with(binding.ivAlbumCover).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade()).into(binding.ivAlbumCover)
            applyPalette(cached)
        } else {
            Glide.with(binding.ivAlbumCover).load(repSong.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .centerCrop()
                .into(binding.ivAlbumCover)

            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    AlbumArtUtils.loadArt(repSong.id, repSong.path, repSong.artist, repSong.album)
                }
                if (bmp != null) {
                    Glide.with(binding.ivAlbumCover).load(bmp).centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade()).into(binding.ivAlbumCover)
                    applyPalette(bmp)
                }
            }
        }
    }

    private fun applyPalette(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val fallback = ContextCompat.getColor(this, R.color.surface_dark)
            val dominant = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(fallback)
            ) ?: fallback
            binding.headerContainer.setBackgroundColor(dominant)
        }
    }

    private fun setupSongs(songs: List<Song>) {
        val adapter = AlbumSongAdapter { song ->
            viewModel.incrementPlayCount(song)
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = binding.tvAlbumName.text.toString())
            startActivity(
                Intent(this, PlayerActivity::class.java),
                ActivityOptions.makeCustomAnimation(this, R.anim.fade_in, R.anim.fade_out).toBundle()
            )
        }
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter
        binding.rvSongs.isNestedScrollingEnabled = false
        adapter.submitList(songs)
    }

    private fun setupButtons(songs: List<Song>, albumName: String) {
        binding.btnPlayAll.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            viewModel.incrementPlayCount(songs.first())
            PlayerController.playSongs(songs, 0, queueName = albumName)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.btnShuffle.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            val shuffled = songs.shuffled()
            viewModel.incrementPlayCount(shuffled.first())
            PlayerController.playSongs(shuffled, 0, queueName = albumName)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}

// ── Adapter de canciones del álbum ────────────────────────────────────────────
class AlbumSongAdapter(
    private val onClick: (Song) -> Unit
) : ListAdapter<Song, AlbumSongAdapter.VH>(SongDiff2()) {

    inner class VH(val b: ItemPlaylistSongBinding) : RecyclerView.ViewHolder(b.root) {
        var artJob: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemPlaylistSongBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onViewRecycled(holder: VH) {
        super.onViewRecycled(holder)
        holder.artJob?.cancel()
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text    = song.title
        holder.b.tvArtist.text   = song.artist
        holder.b.tvDuration.text = FormatUtils.formatDuration(song.duration)

        val cached = AlbumArtUtils.getCached(song.id)
        if (cached != null) {
            Glide.with(holder.b.ivAlbumArt).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivAlbumArt)
        } else {
            Glide.with(holder.b.ivAlbumArt).load(R.drawable.ic_music_placeholder).into(holder.b.ivAlbumArt)
            holder.artJob?.cancel()
            holder.artJob = (holder.b.ivAlbumArt.context as? androidx.lifecycle.LifecycleOwner)
                ?.lifecycleScope?.launch {
                    val bmp = AlbumArtUtils.loadArt(song.id, song.path, song.artist, song.album)
                    if (bmp != null) {
                        Glide.with(holder.b.ivAlbumArt).load(bmp).centerCrop()
                            .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivAlbumArt)
                    } else {
                        Glide.with(holder.b.ivAlbumArt).load(song.albumArtUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .error(R.drawable.ic_music_placeholder).centerCrop().into(holder.b.ivAlbumArt)
                    }
                }
        }

        holder.b.root.setOnClickListener { onClick(song) }
    }

    class SongDiff2 : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
