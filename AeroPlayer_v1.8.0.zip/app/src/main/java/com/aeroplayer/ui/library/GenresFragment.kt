package com.aeroplayer.ui.library

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Pestaña "Géneros" de la biblioteca.
 *
 * Agrupa todas las canciones por género (campo leído de MediaStore / ID3),
 * muestra una cuadrícula de tarjetas con portada representativa y conteo.
 * Al tocar un género abre GenreDetailActivity con la lista de canciones.
 *
 * Canciones sin género aparecen bajo "Sin género".
 */
class GenresFragment : Fragment() {

    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: GenreAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val rv = RecyclerView(requireContext()).apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            setPadding(8.dpToPx(), 8.dpToPx(), 8.dpToPx(), 96.dpToPx())
            clipToPadding = false
        }
        return rv
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = GenreAdapter { genre ->
            startActivity(
                Intent(requireContext(), GenreDetailActivity::class.java).apply {
                    putExtra(GenreDetailActivity.EXTRA_GENRE, genre.name)
                }
            )
        }
        (view as RecyclerView).adapter = adapter

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            val unknownLabel = getString(R.string.genre_unknown)
            val groups = songs
                .groupBy { it.genre.ifBlank { unknownLabel } }
                .entries
                .sortedBy { it.key }
                .map { (name, songList) ->
                    GenreItem(
                        name      = name,
                        count     = songList.size,
                        coverSong = songList.maxByOrNull { it.playCount } ?: songList.first(),
                        songs     = songList
                    )
                }
            adapter.submitList(groups)
        }
    }

    private fun Int.dpToPx() = (this * resources.displayMetrics.density).toInt()
}

// ── Data ─────────────────────────────────────────────────────────────────────

data class GenreItem(
    val name: String,
    val count: Int,
    val coverSong: Song,
    val songs: List<Song>
)

// ── Adapter ──────────────────────────────────────────────────────────────────

class GenreAdapter(
    private val onClick: (GenreItem) -> Unit
) : ListAdapter<GenreItem, GenreAdapter.VH>(GenreDiff()) {

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivCover: ImageView = itemView.findViewById(R.id.ivGenreCover)
        val tvName:  TextView  = itemView.findViewById(R.id.tvGenreName)
        val tvCount: TextView  = itemView.findViewById(R.id.tvGenreCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_genre, parent, false)
        v.findViewById<ImageView>(R.id.ivGenreCover).apply {
            clipToOutline   = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        holder.tvName.text  = item.name
        holder.tvCount.text = "${item.count} canción${if (item.count != 1) "es" else ""}"

        Glide.with(holder.ivCover)
            .load(
                com.aeroplayer.utils.AlbumArtUtils.getCached(item.coverSong.id)
                    ?: item.coverSong.albumArtUri
            )
            .placeholder(R.drawable.ic_music_placeholder)
            .error(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.ivCover)

        holder.itemView.setOnClickListener { onClick(item) }

        // Staggered entrance animation
        val tag = holder.itemView.getTag(R.id.tag_animated)
        if (tag == null) {
            holder.itemView.setTag(R.id.tag_animated, true)
            holder.itemView.alpha   = 0f
            holder.itemView.scaleX  = 0.93f
            holder.itemView.scaleY  = 0.93f
            holder.itemView.animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay((position * 30L).coerceAtMost(300L))
                .setDuration(260)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    class GenreDiff : DiffUtil.ItemCallback<GenreItem>() {
        override fun areItemsTheSame(a: GenreItem, b: GenreItem) = a.name == b.name
        override fun areContentsTheSame(a: GenreItem, b: GenreItem) =
            a.name == b.name && a.count == b.count
    }
}
