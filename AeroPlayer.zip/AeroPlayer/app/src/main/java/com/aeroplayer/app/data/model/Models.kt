package com.aeroplayer.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ─── Canción ───────────────────────────────────────────────────────────────
@Entity(tableName = "songs")
data class Song(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,       // milisegundos
    val path: String,         // ruta del archivo
    val albumArtUri: String?,
    val isLiked: Boolean = false,
    val playCount: Int = 0,
    val lastPlayed: Long = 0  // timestamp
)

// ─── Playlist ──────────────────────────────────────────────────────────────
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val coverUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

// ─── Relación Playlist ↔ Canción ───────────────────────────────────────────
@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songId"]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: Long,
    val order: Int = 0
)

// ─── Letras ────────────────────────────────────────────────────────────────
data class LyricsResponse(
    val lyrics: String?
)
