package com.aeroplayer.data.db

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface LikedSongDao {
    @Query("SELECT * FROM liked_songs ORDER BY likedAt DESC")
    fun getAllLiked(): LiveData<List<LikedSongEntity>>

    @Query("SELECT * FROM liked_songs ORDER BY likedAt DESC")
    suspend fun getAllLikedSync(): List<LikedSongEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(song: LikedSongEntity)

    @Delete
    suspend fun delete(song: LikedSongEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM liked_songs WHERE songId = :id)")
    suspend fun isLiked(id: Long): Boolean

    @Query("DELETE FROM liked_songs WHERE songId = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM liked_songs")
    fun getCount(): LiveData<Int>
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): LiveData<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylistsSync(): List<PlaylistEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position")
    fun getSongsForPlaylist(playlistId: Long): LiveData<List<PlaylistSongEntity>>

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position")
    suspend fun getSongsForPlaylistSync(playlistId: Long): List<PlaylistSongEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSongToPlaylist(song: PlaylistSongEntity)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long)

    /** FIX: persist reorder — updates the position of a single song entry. */
    @Query("UPDATE playlist_songs SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun updateSongPosition(playlistId: Long, songId: Long, position: Int)

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId")
    fun getSongCount(playlistId: Long): LiveData<Int>

    @Query("SELECT COUNT(*) FROM playlists")
    fun getPlaylistCount(): LiveData<Int>

    /** Primer albumArtUri de una playlist (para portada de fallback cuando coverUri es null). */
    @Query("SELECT albumArtUri FROM playlist_songs WHERE playlistId = :playlistId AND albumArtUri IS NOT NULL LIMIT 1")
    suspend fun getFirstAlbumArtUri(playlistId: Long): String?
}

@Dao
interface PlayCountDao {
    @Query("SELECT * FROM play_counts ORDER BY count DESC LIMIT :limit")
    suspend fun getTopPlayed(limit: Int = 20): List<PlayCountEntity>

    @Query("SELECT * FROM play_counts ORDER BY listenTimeMs DESC LIMIT :limit")
    suspend fun getTopByListenTime(limit: Int = 20): List<PlayCountEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: PlayCountEntity)

    @Query("SELECT * FROM play_counts WHERE songId = :id")
    suspend fun getByid(id: Long): PlayCountEntity?

    @Query("UPDATE play_counts SET count = count + 1, lastPlayed = :time WHERE songId = :id")
    suspend fun increment(id: Long, time: Long = System.currentTimeMillis())

    /** Acumula tiempo escuchado en ms además de incrementar el contador. */
    @Query("UPDATE play_counts SET count = count + 1, lastPlayed = :time, listenTimeMs = listenTimeMs + :addedMs WHERE songId = :id")
    suspend fun incrementWithTime(id: Long, addedMs: Long, time: Long = System.currentTimeMillis())

    /** Tiempo total escuchado en ms sumando todas las canciones. */
    @Query("SELECT SUM(listenTimeMs) FROM play_counts")
    suspend fun getTotalListenTimeMs(): Long?

    /** Cantidad de canciones distintas reproducidas alguna vez. */
    @Query("SELECT COUNT(*) FROM play_counts WHERE count > 0")
    suspend fun getUniqueSongsPlayed(): Int

    /** Top canciones reproducidas cuyo lastPlayed fue en el año dado. */
    @Query("""
        SELECT * FROM play_counts
        WHERE lastPlayed >= :yearStart AND lastPlayed < :yearEnd
        ORDER BY count DESC LIMIT :limit
    """)
    suspend fun getTopPlayedInYear(yearStart: Long, yearEnd: Long, limit: Int = 10): List<PlayCountEntity>

    /** Top canciones por tiempo escuchado en el año dado. */
    @Query("""
        SELECT * FROM play_counts
        WHERE lastPlayed >= :yearStart AND lastPlayed < :yearEnd
        ORDER BY listenTimeMs DESC LIMIT :limit
    """)
    suspend fun getTopListenTimeInYear(yearStart: Long, yearEnd: Long, limit: Int = 10): List<PlayCountEntity>

    /** Tiempo total escuchado en el año dado. */
    @Query("SELECT SUM(listenTimeMs) FROM play_counts WHERE lastPlayed >= :yearStart AND lastPlayed < :yearEnd")
    suspend fun getTotalListenTimeMsInYear(yearStart: Long, yearEnd: Long): Long?
}

/** DAO para los GIF Canvas asignados por el usuario a cada canción. */
@Dao
interface SongCanvasDao {

    @Query("SELECT * FROM song_canvas WHERE songId = :songId")
    suspend fun getCanvas(songId: Long): SongCanvasEntity?

    @Query("SELECT * FROM song_canvas WHERE songId = :songId")
    fun getCanvasLive(songId: Long): LiveData<SongCanvasEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setCanvas(canvas: SongCanvasEntity)

    @Query("DELETE FROM song_canvas WHERE songId = :songId")
    suspend fun deleteCanvas(songId: Long)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM listening_history ORDER BY playedAt DESC LIMIT :limit")
    fun getRecentHistory(limit: Int = 200): LiveData<List<ListeningHistoryEntity>>

    @Query("SELECT * FROM listening_history ORDER BY playedAt DESC LIMIT :limit")
    suspend fun getRecentHistorySync(limit: Int = 200): List<ListeningHistoryEntity>

    @Query("SELECT * FROM listening_history GROUP BY songId ORDER BY MAX(playedAt) DESC LIMIT :limit")
    suspend fun getRecentUniqueSongs(limit: Int = 50): List<ListeningHistoryEntity>

    @Insert
    suspend fun insert(entry: ListeningHistoryEntity)

    @Query("DELETE FROM listening_history WHERE id NOT IN (SELECT id FROM listening_history ORDER BY playedAt DESC LIMIT 500)")
    suspend fun trimToLast500()

    @Query("DELETE FROM listening_history")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM listening_history")
    suspend fun count(): Int

    /** Top artistas por cantidad de reproducciones en un rango de tiempo. */
    @Query("""
        SELECT artist, COUNT(*) as playCount
        FROM listening_history
        WHERE playedAt >= :from AND playedAt < :to
        GROUP BY artist
        ORDER BY playCount DESC
        LIMIT :limit
    """)
    suspend fun getTopArtistsInRange(from: Long, to: Long, limit: Int = 5): List<ArtistCount>

    /** Top álbumes por reproducciones en un rango. */
    @Query("""
        SELECT album, artist, COUNT(*) as playCount
        FROM listening_history
        WHERE playedAt >= :from AND playedAt < :to
        GROUP BY album
        ORDER BY playCount DESC
        LIMIT :limit
    """)
    suspend fun getTopAlbumsInRange(from: Long, to: Long, limit: Int = 5): List<AlbumCount>

    /** Total de reproducciones en un rango. */
    @Query("SELECT COUNT(*) FROM listening_history WHERE playedAt >= :from AND playedAt < :to")
    suspend fun getTotalPlaysInRange(from: Long, to: Long): Int

    /** Reproducciones agrupadas por día (últimos N días) para la gráfica diaria.
     *  Retorna pares (dayStart: Long, count: Int) ordenados cronológicamente. */
    @Query("""
        SELECT (playedAt / 86400000) * 86400000 as dayStart, COUNT(*) as playCount
        FROM listening_history
        WHERE playedAt >= :from
        GROUP BY dayStart
        ORDER BY dayStart ASC
    """)
    suspend fun getDailyPlays(from: Long): List<DailyPlayCount>

    /** Tiempo total escuchado por día (ms) — para la gráfica de horas. */
    @Query("""
        SELECT (playedAt / 86400000) * 86400000 as dayStart,
               SUM(durationMs) as totalMs
        FROM listening_history
        WHERE playedAt >= :from AND durationMs > 0
        GROUP BY dayStart
        ORDER BY dayStart ASC
    """)
    suspend fun getDailyListenTime(from: Long): List<DailyListenTime>
}

data class ArtistCount(val artist: String, val playCount: Int)
data class AlbumCount(val album: String, val artist: String, val playCount: Int)
data class DailyPlayCount(val dayStart: Long, val playCount: Int)
data class DailyListenTime(val dayStart: Long, val totalMs: Long)

@Dao
interface SongCacheDao {
    @Query("SELECT * FROM song_cache ORDER BY title ASC")
    suspend fun getAll(): List<SongCacheEntity>

    @Query("SELECT COUNT(*) FROM song_cache")
    suspend fun count(): Int

    @Query("SELECT cachedAt FROM song_cache LIMIT 1")
    suspend fun getLastCachedAt(): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(songs: List<SongCacheEntity>)

    @Query("DELETE FROM song_cache")
    suspend fun clearAll()
}

/** DAO para marcadores de podcasts y audiolibros. */
@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks WHERE songId = :songId ORDER BY positionMs ASC")
    suspend fun getBookmarks(songId: Long): List<BookmarkEntity>

    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): LiveData<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity): Long

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM bookmarks WHERE songId = :songId")
    suspend fun deleteAllForSong(songId: Long)

    /** Última posición guardada para una canción (para "continuar donde se dejó"). */
    @Query("SELECT positionMs FROM bookmarks WHERE songId = :songId AND label = '__last_position__' LIMIT 1")
    suspend fun getLastPosition(songId: Long): Long?

    @Query("INSERT OR REPLACE INTO bookmarks(songId, title, label, positionMs, durationMs, createdAt) VALUES(:songId, :title, '__last_position__', :positionMs, :durationMs, :now)")
    suspend fun saveLastPosition(songId: Long, title: String, positionMs: Long, durationMs: Long, now: Long = System.currentTimeMillis())
}

/** DAO para radios online. */
@Dao
interface RadioDao {
    @Query("SELECT * FROM online_radios ORDER BY isFavorite DESC, name ASC")
    fun getAllRadios(): LiveData<List<RadioEntity>>

    @Query("SELECT * FROM online_radios WHERE isFavorite = 1 ORDER BY name ASC")
    fun getFavoriteRadios(): LiveData<List<RadioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(radio: RadioEntity): Long

    @Query("DELETE FROM online_radios WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE online_radios SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("SELECT * FROM online_radios WHERE genre = :genre ORDER BY name ASC")
    suspend fun getByGenre(genre: String): List<RadioEntity>
}
