package com.aeroplayer.ui

import android.app.Application
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.aeroplayer.R
import com.aeroplayer.data.db.PlayCountEntity
import com.aeroplayer.data.repository.LyricsResult
import com.aeroplayer.data.repository.MusicRepository
import com.aeroplayer.data.repository.SongPagingSource
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MusicRepository(app)

    private val _allSongs = MutableLiveData<List<Song>>()
    val allSongs: LiveData<List<Song>> = _allSongs

    // Indicador de escaneo — true mientras se lee el MediaStore por primera vez
    // _isScanning eliminado — no hay pantalla de carga

    private val _topPlayed = MutableLiveData<List<PlayCountEntity>>()
    val topPlayed: LiveData<List<PlayCountEntity>> = _topPlayed

    // Sesión 9: triggers para Mix diario y Playlist rápida (compartido entre fragments)
    val triggerDailyMix      = androidx.lifecycle.MutableLiveData(false)
    val triggerQuickPlaylist = androidx.lifecycle.MutableLiveData(false)

    private val _searchResults = MutableLiveData<List<Song>>()
    val searchResults: LiveData<List<Song>> = _searchResults

    private val _lyrics = MutableLiveData<String?>()
    val lyrics: LiveData<String?> = _lyrics

    private val _syncedLyrics = MutableLiveData<String?>()
    val syncedLyrics: LiveData<String?> = _syncedLyrics

    /** Non-null when a lyrics fetch failed due to a network error. */
    private val _lyricsError = MutableLiveData<String?>()
    val lyricsError: LiveData<String?> = _lyricsError

    /** True while songs are being loaded from MediaStore. */
    private val _isLoadingSongs = MutableLiveData(false)
    val isLoadingSongs: LiveData<Boolean> = _isLoadingSongs

    val likedSongs    = repo.getLikedSongsLive()
    val likedCount    = repo.getLikedCountLive()
    suspend fun getLikedFirstArtUri(): String? = repo.getLikedFirstArtUri()
    suspend fun getLikedFirstSongId(): Long? = repo.getLikedFirstSongId()
    val playlists     = repo.getAllPlaylistsLive()
    val playlistCount = repo.getPlaylistCountLive()

    // ── Playlists favoritas (persisten en SharedPreferences) ─────────────────
    private val _favoritePlaylistIds = MutableLiveData<Set<Long>>(loadFavoritePlaylistIds())
    val favoritePlaylistIds: LiveData<Set<Long>> = _favoritePlaylistIds

    private fun prefs() = getApplication<Application>()
        .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)

    private fun loadFavoritePlaylistIds(): Set<Long> =
        prefs().getStringSet("favorite_playlist_ids", emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()

    private fun saveFavoritePlaylistIds(ids: Set<Long>) {
        prefs().edit()
            .putStringSet("favorite_playlist_ids", ids.map { it.toString() }.toSet())
            .apply()
    }

    fun toggleFavoritePlaylist(playlistId: Long) {
        val current = _favoritePlaylistIds.value?.toMutableSet() ?: mutableSetOf()
        if (playlistId in current) current.remove(playlistId)
        else current.add(playlistId)
        saveFavoritePlaylistIds(current)
        _favoritePlaylistIds.value = current
    }

    // ── Paging 3 ─────────────────────────────────────────────────────────────
    /**
     * Estado del sort actual de FilesFragment.
     * Cuando cambia, [songsPagingData] emite una nueva página desde el inicio.
     */
    private val _sortedSongs = MutableStateFlow<List<Song>>(emptyList())

    /**
     * Flow de PagingData<Song> para FilesFragment.
     * Cada vez que [_sortedSongs] cambia (nuevo sort o nuevo MediaStore scan)
     * se crea un PagingSource fresco y el Pager emite desde la página 0.
     *
     * [cachedIn] mantiene las páginas en el ViewModel — sobrevive rotaciones
     * sin recargar MediaStore.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    val songsPagingData: Flow<PagingData<Song>> = _sortedSongs
        .flatMapLatest { songs ->
            Pager(
                config = PagingConfig(
                    pageSize           = SongPagingSource.PAGE_SIZE,
                    prefetchDistance   = SongPagingSource.PAGE_SIZE / 2,
                    enablePlaceholders = false
                ),
                pagingSourceFactory  = { repo.getPagingSource(songs) }
            ).flow
        }
        .cachedIn(viewModelScope)

    /** Llamado desde FilesFragment cuando el usuario cambia el sort. */
    fun submitSortedSongs(sorted: List<Song>) {
        _sortedSongs.value = sorted
    }

    // ── MediaStore ContentObserver ────────────────────────────────────────────
    private val observerHandler = Handler(Looper.getMainLooper())
    private var observerRunnable: Runnable? = null
    // FIX CARGA: timestamp del último forceRefresh para evitar bucles de re-escaneo.
    // En algunas ROMs (MIUI, OneUI) MediaStore dispara onChange durante el propio escaneo,
    // creando un ciclo infinito que borra memoryCache y re-escanea constantemente.
    private var lastForceRefreshAt = 0L
    private val MIN_FORCE_REFRESH_INTERVAL_MS = 30_000L // mínimo 30s entre rescans forzados

    private val mediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            // Debounce de 5s: MediaStore puede disparar docenas de eventos seguidos.
            observerRunnable?.let { observerHandler.removeCallbacks(it) }
            val r = Runnable {
                val now = System.currentTimeMillis()
                val isLoading = _isLoadingSongs.value == true
                val tooSoon = (now - lastForceRefreshAt) < MIN_FORCE_REFRESH_INTERVAL_MS
                if (!isLoading && !tooSoon) {
                    lastForceRefreshAt = now
                    viewModelScope.launch { loadSongs(forceRefresh = true) }
                }
            }
            observerRunnable = r
            observerHandler.postDelayed(r, 5000L)
        }
    }

    init {
        // FIX CARGA: NO llamar loadSongs() en init{} sin permiso — el ViewModel se crea
        // antes de que MainActivity muestre el diálogo de permisos. Si MediaStore no tiene
        // permiso devuelve 0 canciones y el ContentObserver queda activo esperando cambios.
        // loadSongs() se llama desde MainActivity.checkPermissions() cuando el permiso está OK.
        // Solo registrar el observer aquí (no causa daño si no hay permiso aún).
        loadTopPlayed()
        getApplication<Application>().contentResolver.registerContentObserver(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            true,
            mediaObserver
        )
    }

    fun loadSongs(forceRefresh: Boolean = false) = viewModelScope.launch {
        _isLoadingSongs.value = true
        // Query directa a MediaStore (igual que Boom Music).
        // No hay overlay de carga: MediaStore responde en <200ms incluso en
        // bibliotecas grandes. El caché en memoria hace warm starts instantáneos.
        val songs = repo.getAllSongs(forceRefresh)
        val hidden    = getHiddenSongIds()
        val excluded  = getExcludedFolders()
        val favorites = getFavoriteFolders()
        _allSongs.value = songs.filter { song ->
            song.id !in hidden &&
            excluded.none { folder -> song.path.startsWith(folder) } &&
            (favorites.isEmpty() || favorites.any { fav -> song.path.startsWith(fav) })
        }
        _isLoadingSongs.value = false

    }

    // ── Canciones ocultas ─────────────────────────────────────────────────────
    fun refreshLibrary() = loadSongs(forceRefresh = true)

    fun getHiddenSongIds(): Set<Long> =
        prefs().getStringSet("hidden_song_ids", emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()

    fun hideSong(songId: Long) {
        val current = getHiddenSongIds().toMutableSet()
        current.add(songId)
        prefs().edit().putStringSet("hidden_song_ids", current.map { it.toString() }.toSet()).apply()
        viewModelScope.launch { loadSongs() }
    }

    fun unhideSong(songId: Long) {
        val current = getHiddenSongIds().toMutableSet()
        current.remove(songId)
        prefs().edit().putStringSet("hidden_song_ids", current.map { it.toString() }.toSet()).apply()
        viewModelScope.launch { loadSongs() }
    }

    fun loadTopPlayed() = viewModelScope.launch {
        _topPlayed.value = repo.getTopPlayedSongs(20)
    }

    private var searchJob: Job? = null

    fun search(query: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(200L) // debounce 200ms
            // FIX RENDIMIENTO: el filtrado se mueve a Dispatchers.Default para no bloquear
            // el main thread con bibliotecas grandes (miles de canciones). El resultado se
            // publica con postValue que es thread-safe.
            val songs = _allSongs.value ?: repo.getAllSongs()
            val q = query.lowercase()
            val filtered = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                songs.filter {
                    it.title.lowercase().contains(q) ||
                    it.artist.lowercase().contains(q) ||
                    it.album.lowercase().contains(q)
                }
            }
            _searchResults.postValue(filtered)
        }
    }

    fun toggleLike(song: Song) = viewModelScope.launch {
        repo.toggleLike(song)
    }

    fun incrementPlayCount(song: Song) = viewModelScope.launch {
        repo.incrementPlayCount(song)
        loadTopPlayed()
    }

    suspend fun getTotalListenTimeMs(): Long = repo.getTotalListenTimeMs()
    suspend fun getUniqueSongsPlayed(): Int  = repo.getUniqueSongsPlayed()
    suspend fun getTopByListenTime(limit: Int = 10) = repo.getTopByListenTime(limit)

    /** Reproducciones por día en los últimos [days] días. */
    suspend fun getDailyPlays(days: Int = 30): List<com.aeroplayer.data.db.DailyPlayCount> =
        repo.getDailyPlays(days)

    /** Tiempo escuchado por día (ms) en los últimos [days] días. */
    suspend fun getDailyListenTime(days: Int = 30): List<com.aeroplayer.data.db.DailyListenTime> =
        repo.getDailyListenTime(days)

    // ── Exportar/Importar .m3u ────────────────────────────────────────────────

    /**
     * Exporta una playlist a formato .m3u extendido (M3U8).
     * @return la ruta del archivo generado, o null si falló.
     */
    suspend fun exportPlaylistToM3u(
        context: android.content.Context,
        playlistId: Long,
        outputDir: java.io.File = java.io.File(
            android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_MUSIC), "AeroPlayer/Playlists")
    ): String? = withContext(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
            val playlist = playlists.value?.firstOrNull { it.id == playlistId } ?: return@runCatching null
            val songs    = repo.getPlaylistSongs(playlistId)
            if (songs.isEmpty()) return@runCatching null

            outputDir.mkdirs()
            val safe = playlist.name.replace(Regex("[^a-zA-Z0-9áéíóúñÁÉÍÓÚÑ _\\-]"), "_")
            val file = java.io.File(outputDir, "$safe.m3u8")

            file.bufferedWriter(Charsets.UTF_8).use { w ->
                w.write("#EXTM3U\n")
                w.write("# Exportado por AeroPlayer — ${playlist.name}\n")
                songs.forEach { song ->
                    val secs = song.duration / 1000
                    w.write("#EXTINF:$secs,${song.artist} - ${song.title}\n")
                    w.write("${song.path}\n")
                }
            }
            file.absolutePath
        }.getOrNull()
    }

    /**
     * Importa un archivo .m3u/.m3u8 y crea una playlist con sus canciones.
     * Empareja por ruta exacta; si no encuentra, intenta emparejar por nombre de archivo.
     * @return el nombre de la playlist creada, o null si falló.
     */
    suspend fun importM3u(
        context: android.content.Context,
        file: java.io.File
    ): String? = withContext(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
            val lines  = file.readLines(Charsets.UTF_8)
            val paths  = lines.filter { !it.startsWith("#") && it.isNotBlank() }
            if (paths.isEmpty()) return@runCatching null

            val allSongs = repo.getAllSongs(false)
            val songMap  = allSongs.associateBy { it.path }
            val nameMap  = allSongs.associateBy { java.io.File(it.path).name.lowercase() }

            val matched = paths.mapNotNull { path ->
                songMap[path]
                    ?: nameMap[java.io.File(path).name.lowercase()]
            }
            if (matched.isEmpty()) return@runCatching null

            val playlistName = file.nameWithoutExtension
            val playlistId   = repo.createPlaylist(playlistName)
            matched.forEach { repo.addSongToPlaylist(playlistId, it) }

            playlistName
        }.getOrNull()
    }

    fun createPlaylist(name: String, coverUri: String? = null) = viewModelScope.launch {
        repo.createPlaylist(name, coverUri)
    }

    fun updatePlaylistFull(id: Long, name: String, coverUri: String? = null) = viewModelScope.launch {
        repo.updatePlaylist(id, name, coverUri)
    }

    fun deletePlaylist(id: Long) = viewModelScope.launch {
        val favs = _favoritePlaylistIds.value?.toMutableSet() ?: mutableSetOf()
        if (id in favs) {
            favs.remove(id)
            saveFavoritePlaylistIds(favs)
            _favoritePlaylistIds.value = favs
        }
        repo.deletePlaylist(id)
    }

    fun addSongToPlaylist(playlistId: Long, song: Song) = viewModelScope.launch {
        repo.addSongToPlaylist(playlistId, song)
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch {
        repo.removeSongFromPlaylist(playlistId, songId)
    }

    fun reorderPlaylistSongs(playlistId: Long, songs: List<Song>) = viewModelScope.launch {
        repo.reorderPlaylistSongs(playlistId, songs)
    }

    fun fetchLyrics(artist: String, title: String, songPath: String = "") = viewModelScope.launch {
        _lyrics.value       = null
        _syncedLyrics.value = null
        _lyricsError.value  = null
        when (val result = repo.getLyricsResponse(artist, title, songPath)) {
            is LyricsResult.Success -> {
                val resp = result.response
                _syncedLyrics.value = resp.syncedLyrics?.takeIf { it.isNotBlank() }
                _lyrics.value = resp.plainLyrics?.takeIf { it.isNotBlank() }
                    ?: resp.syncedLyrics
                        ?.lines()
                        ?.joinToString("\n") { line ->
                            line.replace(Regex("^\\[\\d+:\\d+\\.\\d+]\\s*"), "")
                        }
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
            }
            is LyricsResult.NotFound -> {
                _lyrics.value = null
            }
            is LyricsResult.Error -> {
                _lyricsError.value = result.throwable.message ?: getApplication<Application>().getString(R.string.error_network)
            }
        }
    }

    fun getPlaylistSongs(playlistId: Long)     = repo.getPlaylistSongsLive(playlistId)
    fun getPlaylistSongCount(playlistId: Long) = repo.getPlaylistSongCount(playlistId)

    // FIX SESIÓN 6: portada fallback para playlists sin coverUri propia
    fun getFirstSongCoverInPlaylist(playlistId: Long) = repo.getFirstSongCoverInPlaylist(playlistId)

    // Sesión 9: copiar canciones de una playlist a otra
    fun addSongsFromPlaylist(sourceId: Long, targetId: Long, onDone: (Int) -> Unit) =
        viewModelScope.launch {
            val added = repo.addSongsFromPlaylist(sourceId, targetId)
            onDone(added)
        }
    suspend fun getPlaylistFirstArtUri(playlistId: Long): String? =
        repo.getPlaylistFirstArtUri(playlistId)

    suspend fun getPlaylistFirstSongId(playlistId: Long): Long? =
        repo.getPlaylistFirstSongId(playlistId)

    // ── Historial ─────────────────────────────────────────────────────────────
    val listeningHistory = repo.getHistoryLive(200)

    fun clearHistory() = viewModelScope.launch { repo.clearHistory() }

    // ── Smart Playlists ───────────────────────────────────────────────────────
    /** Construye la lista de canciones para una smart playlist dada. */
    suspend fun getSmartPlaylistSongs(type: SmartPlaylistType): List<Song> =
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            val allSongs = _allSongs.value ?: emptyList()
            val songMap = allSongs.associateBy { it.id }

            when (type) {
                SmartPlaylistType.RECENTLY_PLAYED -> {
                    repo.getRecentUniqueSongs(50).mapNotNull { entry ->
                        songMap[entry.songId] ?: Song(
                            id = entry.songId, title = entry.title,
                            artist = entry.artist, album = entry.album,
                            duration = entry.duration, path = entry.path,
                            albumArtUri = entry.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entry.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.MOST_PLAYED -> {
                    repo.getTopPlayedSongs(50).mapNotNull { entity ->
                        songMap[entity.songId] ?: Song(
                            id = entity.songId, title = entity.title,
                            artist = entity.artist, album = entity.title,
                            duration = 0, path = entity.path,
                            albumArtUri = entity.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entity.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.HISTORY -> {
                    repo.getHistorySync(100).mapNotNull { entry ->
                        songMap[entry.songId] ?: Song(
                            id = entry.songId, title = entry.title,
                            artist = entry.artist, album = entry.album,
                            duration = entry.duration, path = entry.path,
                            albumArtUri = entry.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entry.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.LIKED -> {
                    allSongs.filter { song ->
                        likedSongs.value?.any { it.songId == song.id } == true
                    }
                }
            }
        }

    // ── Excluded folders ──────────────────────────────────────────────────────
    fun getExcludedFolders(): Set<String> =
        prefs().getStringSet("excluded_folders", emptySet()) ?: emptySet()

    fun setExcludedFolders(folders: Set<String>) {
        prefs().edit().putStringSet("excluded_folders", folders).apply()
        viewModelScope.launch { loadSongs() }
    }

    // ── Carpetas favoritas (incluidas manualmente) ────────────────────────────
    /**
     * Devuelve el conjunto de rutas de carpetas marcadas como favoritas.
     * Si no está vacío, SOLO se muestran canciones de esas carpetas (más las que
     * no estén en ninguna carpeta excluida). Útil para SD cards o rutas no estándar.
     */
    fun getFavoriteFolders(): Set<String> =
        prefs().getStringSet("favorite_folders", emptySet()) ?: emptySet()

    fun setFavoriteFolders(folders: Set<String>) {
        prefs().edit().putStringSet("favorite_folders", folders).apply()
        viewModelScope.launch { loadSongs() }
    }

    fun addFavoriteFolder(path: String) {
        val current = getFavoriteFolders().toMutableSet()
        current.add(path.trimEnd('/'))
        setFavoriteFolders(current)
    }

    fun removeFavoriteFolder(path: String) {
        val current = getFavoriteFolders().toMutableSet()
        current.remove(path.trimEnd('/'))
        setFavoriteFolders(current)
    }

    // ── Profile name (persisted) ──────────────────────────────────────────────
    fun getProfileName(): String =
        prefs().getString("profile_name", "") ?: ""

    fun setProfileName(name: String) {
        prefs().edit()
            .putString("profile_name", name.trim())
            .apply()
    }

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /** Asigna el GIF Canvas de la canción con [songId]. */
    fun setCanvas(songId: Long, gifUri: String) = viewModelScope.launch {
        repo.setCanvas(songId, gifUri)
    }

    /** Elimina el GIF Canvas de la canción con [songId]. */
    fun deleteCanvas(songId: Long) = viewModelScope.launch {
        repo.deleteCanvas(songId)
    }

    /**
     * LiveData reactivo del canvas para [songId].
     * El player lo observa — cuando el usuario asigna o elimina un canvas
     * el GIF aparece o desaparece inmediatamente sin necesidad de reiniciar.
     */
    fun getCanvasLive(songId: Long) = repo.getCanvasLive(songId)

    override fun onCleared() {
        super.onCleared()
        observerRunnable?.let { observerHandler.removeCallbacks(it) }
        getApplication<Application>().contentResolver.unregisterContentObserver(mediaObserver)
        // Nota: PlayerController.disconnect() se llama desde MainActivity.onDestroy()
        // con el guard isFinishing — NO aquí, porque onCleared() también se dispara
        // cuando PlayerActivity (que tiene su propio MainViewModel) se destruye,
        // lo que mataría el MediaController mientras la música sigue en MainActivity.
    }
}
