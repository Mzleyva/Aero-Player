package com.aeroplayer.ui.player

import android.app.ActivityOptions
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.SeekBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.cast.CastManager
import com.aeroplayer.timer.SleepTimerManager
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.aeroplayer.databinding.ActivityPlayerBinding
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.graphics.PorterDuff
import android.util.TypedValue
import android.widget.ImageButton
import androidx.core.graphics.ColorUtils
import androidx.media3.common.Player
import com.google.android.material.snackbar.Snackbar

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var queueAdapter: QueueAdapter
    private lateinit var lyricsAdapter: SyncedLyricsAdapter
    private lateinit var albumArtAdapter: AlbumArtPagerAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private var isLyricsVisible = false
    private var isQueueVisible = false
    private var isSidePanelVisible = false

    // Color de acento extraído de la carátula actual — se usa para botones y panel
    private var currentAccentColor: Int = 0
    private var currentLightColor: Int = 0
    // Color dominante actual del fondo degradado — permite animar desde el valor real
    private var currentDominantColor: Int = 0

    // Evita disparar next/previous al programar setCurrentItem internamente
    private var isPagerSettingItem = false

    // ── GIF Canvas ───────────────────────────────────────────────────────────
    /** URI del canvas activo para la canción actual. Null = sin canvas. */
    private var activeCanvasUri: Uri? = null

    /**
     * Picker de GIF: abre el selector del sistema filtrando image/gif.
     * Al elegir un archivo se persiste en Room y se refleja de inmediato
     * en el pager gracias al LiveData del ViewModel.
     */
    private val gifPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val song = PlayerController.currentSong.value ?: return@registerForActivityResult
        // Persistir URI permanentemente para que sobreviva entre sesiones
        contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        viewModel.setCanvas(song.id, uri.toString())
        Snackbar.make(binding.root, getString(R.string.canvas_applied), Snackbar.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupControls()
        setupAlbumPager()
        setupSeekBar()
        setupQueue()
        setupLyrics()
        observePlayer()
    }

    // ── Toolbar ──────────────────────────────────────────────────────────────
    private fun showSpeedDialog() {
        val speeds  = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
        val labels  = arrayOf("0.25×","0.5×","0.75×","1×","1.25×","1.5×","1.75×","2×","3×")
        val current = PlayerController.playbackSpeed.value ?: 1.0f
        val checked = speeds.indexOfFirst { it == current }.takeIf { it >= 0 } ?: 3

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Velocidad de reproducción")
            .setSingleChoiceItems(labels, checked) { dialog, idx ->
                PlayerController.setPlaybackSpeed(speeds[idx])
                dialog.dismiss()
            }
            .show()
    }

    private fun showSleepTimerDialog() {
        val options = mutableListOf("5 min", "10 min", "15 min", "20 min", "30 min", "45 min", "60 min")
        if (SleepTimerManager.isRunning.value == true) options.add(0, "⏹ Cancelar timer")

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Sleep timer")
            .setItems(options.toTypedArray()) { _, idx ->
                if (SleepTimerManager.isRunning.value == true && idx == 0) {
                    SleepTimerManager.cancel()
                } else {
                    val minutes = listOf(5, 10, 15, 20, 30, 45, 60)
                    val pick = if (SleepTimerManager.isRunning.value == true) minutes[idx - 1] else minutes[idx]
                    SleepTimerManager.start(pick)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root,
                        "La música se pausará en $pick min",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
            .show()
    }

    private fun closeWithAnimation() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.fade_in, R.anim.slide_down)
    }

    private fun toggleSidePanel() {
        isSidePanelVisible = !isSidePanelVisible
        val targetX = if (isSidePanelVisible) 0f else 80f * resources.displayMetrics.density
        binding.sideOptionsPanel?.animate()
            ?.translationX(targetX)
            ?.setDuration(280)
            ?.setInterpolator(android.view.animation.DecelerateInterpolator(2f))
            ?.start()
        // Rotar ligeramente el ícono de 3 puntos para feedback visual
        binding.btnMore.animate()
            .rotation(if (isSidePanelVisible) 90f else 0f)
            .setDuration(250)
            .start()
    }

    // ── Album Art Pager ──────────────────────────────────────────────────────
    private fun setupAlbumPager() {
        albumArtAdapter = AlbumArtPagerAdapter()

        // uriProvider: el pager pide el URI para un offset relativo al centro.
        // offset 0 = canción actual, -1 = anterior, +1 = siguiente.
        albumArtAdapter.uriProvider = { offset ->
            val queue = PlayerController.queue.value
            val idx   = PlayerController.currentIndex.value
            if (queue == null || idx == null) null
            else {
                val target = idx + offset
                if (target in queue.indices) queue[target].albumArtUri else null
            }
        }

        // pathProvider: carga carátula directo del archivo (igual que Oto Music)
        albumArtAdapter.pathProvider = { offset ->
            val queue = PlayerController.queue.value
            val idx   = PlayerController.currentIndex.value
            if (queue == null || idx == null) null
            else {
                val target = idx + offset
                if (target in queue.indices) {
                    val song = queue[target]
                    Pair(song.id, song.path)
                } else null
            }
        }

        // canvasProvider: solo para la página central (canción actual).
        albumArtAdapter.canvasProvider = { activeCanvasUri }

        binding.vpAlbumArt?.adapter = albumArtAdapter
        binding.vpAlbumArt?.setCurrentItem(AlbumArtPagerAdapter.CENTER_PAGE, false)

        // Offset visual: las páginas adyacentes asoman ligeramente
        binding.vpAlbumArt?.offscreenPageLimit = 1

        binding.vpAlbumArt?.registerOnPageChangeCallback(
            object : androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    if (isPagerSettingItem) return
                    val delta = position - AlbumArtPagerAdapter.CENTER_PAGE
                    when {
                        delta > 0 -> {
                            repeat(delta) { PlayerController.next() }
                        }
                        delta < 0 -> {
                            repeat(-delta) { PlayerController.previous() }
                        }
                    }
                    // Recentrar silenciosamente para mantener el carrusel infinito
                    isPagerSettingItem = true
                    binding.vpAlbumArt?.setCurrentItem(
                        AlbumArtPagerAdapter.CENTER_PAGE, false
                    )
                    isPagerSettingItem = false
                }
            }
        )
    }

    private fun setupToolbar() {
        // Non-deprecated back press handling
        onBackPressedDispatcher.addCallback(
            this, object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() { closeWithAnimation() }
            }
        )
        binding.btnBack.setOnClickListener { closeWithAnimation() }

        // btnMore abre/cierra el panel lateral de opciones
        binding.btnMore.setOnClickListener {
            toggleSidePanel()
        }
    }

    private fun showSongOptions(song: com.aeroplayer.model.Song) {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(song.title)
            .setItems(arrayOf(
                getString(R.string.add_to_playlist),
                getString(R.string.song_info_title)
            )) { _, which ->
                when (which) {
                    0 -> showAddToPlaylistMenu(song)
                    1 -> showSongInfo(song)
                }
            }
            .show()
    }

    private fun showAddToPlaylistMenu(song: com.aeroplayer.model.Song) {
        val playlists = viewModel.playlists.value
        if (playlists.isNullOrEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, getString(R.string.create_playlist_first), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.add_to_playlist))
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root,
                    getString(R.string.added_to_playlist, playlists[idx].name),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun showSongInfo(song: com.aeroplayer.model.Song) {
        val sizeStr = when {
            song.size >= 1_000_000 -> "%.1f MB".format(song.size / 1_000_000.0)
            song.size >= 1_000     -> "%.1f KB".format(song.size / 1_000.0)
            else                   -> "${song.size} B"
        }
        val durStr = run {
            val s = song.duration / 1000
            "%d:%02d".format(s / 60, s % 60)
        }
        val info = buildString {
            appendLine("🎵  ${song.title}")
            appendLine("🎤  ${song.artist}")
            appendLine("💿  ${song.album}")
            if (song.year > 0) appendLine("📅  ${song.year}")
            if (song.trackNumber > 0) appendLine("🔢  Pista ${song.trackNumber}")
            appendLine("⏱  $durStr")
            if (song.size > 0) appendLine("📦  $sizeStr")
            appendLine("📂  ${song.path}")
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.song_info))
            .setMessage(info.trim())
            .setPositiveButton("OK", null)
            .show()
    }

    // ── Playback controls ────────────────────────────────────────────────────

    /**
     * Dispara vibración táctil suave compatible con API 21+.
     * En API 27+ usa KEYBOARD_TAP (feedback ligero); en versiones anteriores
     * cae a VIRTUAL_KEY que también es breve y no intrusivo.
     */
    private fun View.hapticTap() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun setupControls() {
        binding.btnPlayPause.setOnClickListener { it.hapticTap(); PlayerController.playPause() }
        binding.btnNext.setOnClickListener     { it.hapticTap(); PlayerController.next() }
        binding.btnPrevious.setOnClickListener { it.hapticTap(); PlayerController.previous() }

        binding.btnShuffle.setOnClickListener { it.hapticTap(); PlayerController.toggleShuffle() }
        binding.btnRepeat.setOnClickListener  { it.hapticTap(); PlayerController.toggleRepeat() }

        // btnShuffle2 es el mismo botón pero dentro del panel lateral
        binding.btnShuffle2?.setOnClickListener { PlayerController.toggleShuffle() }

        // 3 puntos inline de song info → también abre el panel lateral
        binding.btnMoreSong?.setOnClickListener { toggleSidePanel() }

        // ❤ Like — guarda directamente en "Me gusta"
        binding.btnLike.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            val willBeLiked = viewModel.likedSongs.value?.none { it.songId == song.id } == true
            updateLikeButton(willBeLiked, animate = true)
            viewModel.toggleLike(song)
            com.google.android.material.snackbar.Snackbar.make(
                binding.root,
                if (willBeLiked) getString(R.string.added_to_liked)
                else getString(R.string.removed_from_liked),
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
        }

        // ➕ Guardar en playlist — despliega playlists existentes + crear nueva
        binding.btnSaveToPlaylist?.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            showSaveToPlaylistDialog(song)
        }

        binding.btnQueue.setOnClickListener { toggleQueue() }

        // Sleep Timer
        binding.btnSleepTimer.setOnClickListener { showSleepTimerDialog() }
        SleepTimerManager.isRunning.observe(this) { running ->
            val activeColor = if (currentAccentColor != 0) currentAccentColor
                              else ContextCompat.getColor(this, R.color.accent_blue)
            val inactiveColor = if (currentLightColor != 0)
                ColorUtils.setAlphaComponent(currentLightColor, 0xAA)
            else ContextCompat.getColor(this, R.color.text_secondary)
            binding.btnSleepTimer.setColorFilter(
                if (running) activeColor else inactiveColor,
                PorterDuff.Mode.SRC_IN
            )
            binding.tvSleepTimerRemaining.visibility = if (running) View.VISIBLE else View.GONE
        }
        SleepTimerManager.remainingMs.observe(this) { ms ->
            if (ms > 0) binding.tvSleepTimerRemaining.text = SleepTimerManager.formatRemaining(ms)
        }

        // Velocidad de reproducción
        binding.btnSpeed.setOnClickListener { showSpeedDialog() }
        PlayerController.playbackSpeed.observe(this) { speed ->
            val label = when {
                speed == 1.0f -> "1×"
                speed % 1 == 0f -> "${speed.toInt()}×"
                else -> "${speed}×"
            }
            binding.btnSpeed.text = label
            binding.btnSpeed.setTextColor(
                getColor(if (speed != 1.0f) R.color.accent_blue else R.color.text_secondary)
            )
        }

        // Chromecast: asociar el botón con el selector de dispositivos
        CastManager.getCastContext()?.let {
            CastButtonFactory.setUpMediaRouteButton(this, binding.btnCast)
        }

        // Ocultar botón Cast si no hay dispositivos disponibles
        CastManager.isAvailable.observe(this) { available ->
            binding.btnCast.visibility = if (available) View.VISIBLE else View.GONE
        }

        // Cuando se está haciendo cast, pausar reproducción local
        CastManager.isCasting.observe(this) { casting ->
            if (casting) {
                val song = PlayerController.currentSong.value
                song?.let { CastManager.castSong(it) }
            }
        }
        binding.btnLyrics.setOnClickListener { toggleLyrics() }

        // Ecualizador in-app
        binding.btnEqualizer.setOnClickListener { openEqualizer() }

        // A-B Repeat
        binding.btnAbRepeat.setOnClickListener {
            PlayerController.cycleABRepeat()
            // Snackbar feedback for each state transition
            val msg = when (PlayerController.abRepeatState.value) {
                PlayerController.ABRepeatState.A_SET     -> getString(R.string.ab_repeat_set_a)
                PlayerController.ABRepeatState.AB_ACTIVE -> getString(R.string.ab_repeat_set_ab)
                else                                     -> getString(R.string.ab_repeat_cleared)
            }
            com.google.android.material.snackbar.Snackbar
                .make(binding.root, msg, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
        PlayerController.abRepeatState.observe(this) { state ->
            val color = when (state) {
                PlayerController.ABRepeatState.OFF       -> R.color.text_secondary
                PlayerController.ABRepeatState.A_SET     -> R.color.accent_yellow
                PlayerController.ABRepeatState.AB_ACTIVE ->
                    // Usar el acento dinámico si disponible, si no el azul por defecto
                    return@observe run {
                        val c = if (currentAccentColor != 0) currentAccentColor
                                else ContextCompat.getColor(this, R.color.accent_blue)
                        binding.btnAbRepeat.setColorFilter(c, PorterDuff.Mode.SRC_IN)
                        binding.btnAbRepeat.alpha = 1f
                    }
            }
            binding.btnAbRepeat.setColorFilter(getColor(color), PorterDuff.Mode.SRC_IN)
            binding.btnAbRepeat.alpha = if (state == PlayerController.ABRepeatState.OFF) 0.5f else 1f
        }

        // Canvas GIF — abre menú: Cambiar / Quitar
        binding.btnCanvas?.setOnClickListener { showCanvasMenu() }
    }

    // ── Save to playlist dialog ──────────────────────────────────────────────
    private fun showSaveToPlaylistDialog(song: com.aeroplayer.model.Song) {
        val playlists = viewModel.playlists.value ?: emptyList()

        // Build items list: existing playlists + "Crear nueva playlist" at bottom
        val items = ArrayList<String>()
        items.add("➕  ${getString(R.string.create_new_playlist)}")
        playlists.forEach { items.add("🎵  ${it.name}") }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.save_to_playlist))
            .setItems(items.toTypedArray()) { _, idx ->
                if (idx == 0) {
                    // Crear nueva playlist y agregar la canción
                    showCreateAndAddPlaylistDialog(song)
                } else {
                    val playlist = playlists[idx - 1]
                    viewModel.addSongToPlaylist(playlist.id, song)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root,
                        getString(R.string.added_to_playlist, playlist.name),
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
            .show()
    }

    private fun showCreateAndAddPlaylistDialog(song: com.aeroplayer.model.Song) {
        val input = android.widget.EditText(this).apply {
            hint = getString(R.string.playlist_name)
            setPadding(48, 24, 48, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.create_new_playlist))
            .setView(input)
            .setPositiveButton(getString(R.string.create_playlist)) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root,
                        getString(R.string.playlist_name_required),
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                    return@setPositiveButton
                }
                // Create playlist, then observe LiveData until the new playlist appears.
                // This is reliable regardless of device speed — no hardcoded delay.
                viewModel.createPlaylist(name)
                viewModel.playlists.observe(this@PlayerActivity) { list ->
                    val created = list?.firstOrNull { it.name == name }
                    if (created != null) {
                        viewModel.addSongToPlaylist(created.id, song)
                        viewModel.playlists.removeObservers(this@PlayerActivity)
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root,
                            getString(R.string.playlist_created, name),
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ── Equalizer ────────────────────────────────────────────────────────────
    private fun openEqualizer() {
        startActivity(android.content.Intent(this, com.aeroplayer.ui.equalizer.EqualizerActivity::class.java))
    }

    // ── SeekBar ──────────────────────────────────────────────────────────────
    private fun setupSeekBar() {
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = PlayerController.getDuration()
                    PlayerController.seekTo((progress.toLong() * duration) / 1000)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) { handler.removeCallbacks(updateRunnable) }
            override fun onStopTrackingTouch(sb: SeekBar) { handler.post(updateRunnable) }
        })
    }

    private fun updateProgress() {
        val pos = PlayerController.getCurrentPosition()
        val dur = PlayerController.getDuration()
        if (dur > 0) {
            binding.seekBar.progress = ((pos * 1000) / dur).toInt()
            binding.tvCurrentTime.text = FormatUtils.formatDuration(pos)
            binding.tvTotalTime.text   = FormatUtils.formatDuration(dur)
        }
        // Karaoke: scroll automático a la línea activa
        if (isLyricsVisible && binding.rvLyrics.visibility == View.VISIBLE) {
            val changed = lyricsAdapter.updateActiveIndex(pos)
            if (changed) {
                val idx = lyricsAdapter.getActiveIndex()
                val lm = binding.rvLyrics.layoutManager as? LinearLayoutManager
                lm?.let {
                    val offset = binding.rvLyrics.height / 2
                    it.scrollToPositionWithOffset(idx, offset)
                }
            }
        }
    }

    // ── Queue ────────────────────────────────────────────────────────────────
    private fun setupQueue() {
        queueAdapter = QueueAdapter(
            onItemClick = { song, index ->
                val songs = PlayerController.queue.value ?: return@QueueAdapter
                PlayerController.playSongs(songs, index)
            },
            onRemoveClick = { index ->
                PlayerController.removeFromQueue(index)
            }
        )
        binding.rvQueue.apply {
            layoutManager = LinearLayoutManager(this@PlayerActivity)
            adapter = queueAdapter
        }
    }

    private fun toggleQueue() {
        isQueueVisible = !isQueueVisible
        val activeColor = if (currentAccentColor != 0) currentAccentColor
                          else ContextCompat.getColor(this, R.color.accent_blue)
        if (isQueueVisible) {
            isLyricsVisible = false
            binding.lyricsContainer.visibility = View.GONE
            binding.queueContainer.visibility = View.VISIBLE
            binding.btnQueue.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
            binding.btnLyrics.clearColorFilter()
            // Reaplicar tint dinámico al lyrics tras limpiar
            if (currentLightColor != 0)
                binding.btnLyrics.setColorFilter(
                    ColorUtils.setAlphaComponent(currentLightColor, 0xAA), PorterDuff.Mode.SRC_IN)
        } else {
            binding.queueContainer.visibility = View.GONE
            binding.btnQueue.clearColorFilter()
            if (currentLightColor != 0)
                binding.btnQueue.setColorFilter(
                    ColorUtils.setAlphaComponent(currentLightColor, 0xAA), PorterDuff.Mode.SRC_IN)
        }
    }

    // ── Lyrics ───────────────────────────────────────────────────────────────

    // ── Lyrics setup ─────────────────────────────────────────────────────────
    private fun setupLyrics() {
        lyricsAdapter = SyncedLyricsAdapter()
        binding.rvLyrics.apply {
            layoutManager = LinearLayoutManager(this@PlayerActivity)
            adapter = lyricsAdapter
        }
    }

    private fun toggleLyrics() {
        isLyricsVisible = !isLyricsVisible
        val activeColor = if (currentAccentColor != 0) currentAccentColor
                          else ContextCompat.getColor(this, R.color.accent_blue)
        if (isLyricsVisible) {
            isQueueVisible = false
            binding.queueContainer.visibility = View.GONE
            binding.lyricsContainer.visibility = View.VISIBLE
            binding.btnLyrics.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
            binding.btnQueue.clearColorFilter()
            if (currentLightColor != 0)
                binding.btnQueue.setColorFilter(
                    ColorUtils.setAlphaComponent(currentLightColor, 0xAA), PorterDuff.Mode.SRC_IN)
            val currentSong = PlayerController.currentSong.value
            if (currentSong != null) {
                showLyricsLoading()
                viewModel.fetchLyrics(currentSong.artist, currentSong.title)
            }
        } else {
            binding.lyricsContainer.visibility = View.GONE
            binding.btnLyrics.clearColorFilter()
            if (currentLightColor != 0)
                binding.btnLyrics.setColorFilter(
                    ColorUtils.setAlphaComponent(currentLightColor, 0xAA), PorterDuff.Mode.SRC_IN)
            // FIX: limpiar letra al cerrar
            binding.tvLyrics.text = ""
            binding.tvLyrics.visibility = View.GONE
            binding.rvLyrics.visibility = View.GONE
        }
    }

    /**
     * Actualiza la barra superior con el nombre de contexto y la posición
     * dentro de la cola, igual a las capturas: "Default" / "#51 · 1/7243".
     */
    private fun updateHeaderPosition() {
        val queue = PlayerController.queue.value ?: return
        val index = PlayerController.currentIndex.value ?: return
        if (queue.isEmpty()) return

        val contextName = PlayerController.queueName.value
            ?: getString(R.string.now_playing)
        binding.tvPlaylistContext?.text = contextName

        val humanPos = index + 1
        val total    = queue.size
        binding.tvArtistTop?.text = "#$humanPos · $humanPos/$total"
    }

    private fun showLyricsLoading() {
        binding.rvLyrics.visibility = View.GONE
        binding.tvLyrics.visibility = View.VISIBLE
        binding.tvLyrics.text = getString(R.string.loading_lyrics)
    }

    // ── Observers ────────────────────────────────────────────────────────────
    private fun observePlayer() {
        PlayerController.currentSong.observe(this) { song ->
            song ?: return@observe
            binding.tvSongTitle.text = song.title
            // isSelected = true activa el scroll marquee en Android
            binding.tvSongTitle.isSelected = true
            binding.tvArtist.text = song.artist
            binding.tvAlbum.text = song.album

            // FIX: al cambiar de canción, limpiar letra vieja y recargar UNA sola vez.
            if (isLyricsVisible) {
                showLyricsLoading()
                viewModel.fetchLyrics(song.artist, song.title)
            }

            // Refrescar solo las 3 páginas visibles del pager (anterior, actual, siguiente)
            // en lugar de invalidar las 2001 con notifyDataSetChanged.
            albumArtAdapter.notifyItemChanged(AlbumArtPagerAdapter.CENTER_PAGE - 1)
            albumArtAdapter.notifyItemChanged(AlbumArtPagerAdapter.CENTER_PAGE)
            albumArtAdapter.notifyItemChanged(AlbumArtPagerAdapter.CENTER_PAGE + 1)

            // Observar el canvas de la nueva canción — limpia el anterior automáticamente
            observeCanvas(song.id)

            // Cargar bitmap para Palette — intentar desde el archivo primero
            val artBitmap = com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
            if (artBitmap != null) {
                applyPaletteBackground(artBitmap)
            } else {
                val artUri = song.albumArtUri
                if (artUri != null) {
                    Glide.with(this)
                        .asBitmap()
                        .load(artUri)
                        .placeholder(R.drawable.ic_music_placeholder)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(object : CustomTarget<Bitmap>() {
                            override fun onResourceReady(resource: Bitmap, t: Transition<in Bitmap>?) {
                                applyPaletteBackground(resource)
                            }
                            override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
                        })
                }
            }

            // Check liked state
            viewModel.likedSongs.value?.let { liked ->
                val isLiked = liked.any { it.songId == song.id }
                updateLikeButton(isLiked)
            }

            // (lyrics reload ya se hace arriba, no duplicar aquí)
        }

        PlayerController.isPlaying.observe(this) { playing ->
            binding.btnPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }

        PlayerController.shuffleMode.observe(this) { shuffle ->
            val activeAlpha  = 1f
            val inactiveAlpha = 0.4f
            binding.btnShuffle.alpha  = if (shuffle) activeAlpha else inactiveAlpha
            binding.btnShuffle2?.alpha = if (shuffle) activeAlpha else inactiveAlpha
            // Reaplicar tint dinámico si ya tenemos color
            if (currentLightColor != 0) {
                val c = currentLightColor
                binding.btnShuffle.setColorFilter(c, PorterDuff.Mode.SRC_IN)
                binding.btnShuffle2?.setColorFilter(c, PorterDuff.Mode.SRC_IN)
            }
        }

        PlayerController.repeatMode.observe(this) { mode ->
            val tint = if (currentLightColor != 0) currentLightColor
                       else ContextCompat.getColor(this, R.color.text_primary)
            when (mode) {
                Player.REPEAT_MODE_OFF -> {
                    binding.btnRepeat.setImageResource(R.drawable.ic_repeat)
                    binding.btnRepeat.alpha = 0.4f
                    binding.btnRepeat.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                }
                Player.REPEAT_MODE_ALL -> {
                    binding.btnRepeat.setImageResource(R.drawable.ic_repeat)
                    binding.btnRepeat.alpha = 1f
                    binding.btnRepeat.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                }
                Player.REPEAT_MODE_ONE -> {
                    binding.btnRepeat.setImageResource(R.drawable.ic_repeat_one)
                    binding.btnRepeat.alpha = 1f
                    binding.btnRepeat.setColorFilter(currentAccentColor.takeIf { it != 0 }
                        ?: ContextCompat.getColor(this, R.color.accent_blue), PorterDuff.Mode.SRC_IN)
                }
            }
        }

        PlayerController.queue.observe(this) { songs ->
            queueAdapter.submitList(songs)
            binding.tvQueueCount.text = "${songs.size} canciones en cola"
            updateHeaderPosition()
        }

        PlayerController.currentIndex.observe(this) { index ->
            queueAdapter.setCurrentIndex(index)
            updateHeaderPosition()
        }

        PlayerController.queueName.observe(this) { updateHeaderPosition() }

        viewModel.likedSongs.observe(this) { liked ->
            val current = PlayerController.currentSong.value ?: return@observe
            updateLikeButton(liked.any { it.songId == current.id })
        }

        viewModel.syncedLyrics.observe(this) { raw ->
            if (raw != null) {
                val lines = parseLrc(raw)
                if (lines.isNotEmpty()) {
                    lyricsAdapter.submitList(lines)
                    binding.rvLyrics.visibility = View.VISIBLE
                    binding.tvLyrics.visibility = View.GONE
                    return@observe
                }
            }
            // Sin letras sincronizadas — esperar al observer de plainLyrics
        }

        viewModel.lyrics.observe(this) { lyrics ->
            if (!isLyricsVisible) return@observe
            if (binding.rvLyrics.visibility == View.VISIBLE) return@observe
            binding.tvLyrics.visibility = View.VISIBLE
            binding.rvLyrics.visibility = View.GONE
            binding.tvLyrics.text = lyrics ?: getString(R.string.lyrics_not_found)
        }

        viewModel.lyricsError.observe(this) { error ->
            if (error.isNullOrBlank() || !isLyricsVisible) return@observe
            // Show the "not found" placeholder in the text view
            binding.tvLyrics.visibility = View.VISIBLE
            binding.rvLyrics.visibility = View.GONE
            binding.tvLyrics.text = getString(R.string.lyrics_not_found)
            // Also show a Snackbar so the user knows it was a network error
            com.google.android.material.snackbar.Snackbar.make(
                binding.root,
                getString(R.string.lyrics_load_error),
                com.google.android.material.snackbar.Snackbar.LENGTH_LONG
            ).setAction(getString(R.string.retry)) {
                val song = PlayerController.currentSong.value ?: return@setAction
                showLyricsLoading()
                viewModel.fetchLyrics(song.artist, song.title)
            }.show()
        }
    }

    private fun updateLikeButton(isLiked: Boolean, animate: Boolean = false) {
        binding.btnLike.setImageResource(
            if (isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
        binding.btnLike.setColorFilter(
            ContextCompat.getColor(
                this,
                if (isLiked) R.color.accent_pink else R.color.text_secondary
            )
        )
        if (animate && isLiked) {
            binding.btnLike.animate()
                .scaleX(1.4f).scaleY(1.4f)
                .setDuration(150)
                .withEndAction {
                    binding.btnLike.animate()
                        .scaleX(1f).scaleY(1f)
                        .setDuration(150)
                        .start()
                }.start()
        }
    }

    private fun applyPaletteBackground(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            if (palette == null) return@generate

            val fallbackDark = ContextCompat.getColor(this, R.color.surface_dark)
            val fallbackBg   = ContextCompat.getColor(this, R.color.background_dark)
            val fallbackText = ContextCompat.getColor(this, R.color.text_primary)

            // ── 1. Color dominante oscuro para el fondo degradado ──────────
            val dominantDark = palette.getDarkVibrantColor(
                palette.getDarkMutedColor(fallbackDark)
            )

            // ── 2. Color vibrante para botones y panel lateral ─────────────
            val vibrant = palette.getVibrantColor(
                palette.getMutedColor(
                    palette.getDominantColor(fallbackText)
                )
            )

            // ── 3. Color claro para texto/iconos encima del panel ──────────
            val lightForIcons = palette.getLightVibrantColor(
                palette.getLightMutedColor(Color.WHITE)
            )

            // Guardamos para reutilizar al abrir/cerrar panel y para animar correctamente
            currentAccentColor  = vibrant
            currentLightColor   = lightForIcons
            currentDominantColor = dominantDark

            // ── 4. Animar el fondo del root (degradado top→bottom) ─────────
            val newGradient = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(dominantDark, fallbackBg)
            )
            val oldBg = binding.root.background
            if (oldBg is GradientDrawable) {
                // Animar transición de fondo anterior al nuevo
                animateBackground(oldBg, dominantDark, fallbackBg)
            } else {
                binding.root.background = newGradient
            }

            // ── 5. Fondo del panel lateral — cápsula con color de paleta ──
            val panelColor = ColorUtils.setAlphaComponent(
                ColorUtils.blendARGB(dominantDark, vibrant, 0.3f), 0xDD
            )
            animatePanelBackground(panelColor)

            // ── 6. Tint de todos los botones del panel lateral ─────────────
            val iconTint = ensureContrast(lightForIcons, panelColor)
            animateButtonTints(iconTint)

            // ── 7. Seekbar progress tint ───────────────────────────────────
            val seekTint = ensureContrast(vibrant, dominantDark)
            animateSeekBarTint(seekTint)

            // ── 8. Halo del album art — color vibrante semitransparente ────
            val glowColor = ColorUtils.setAlphaComponent(
                ColorUtils.blendARGB(dominantDark, vibrant, 0.6f), 0xCC
            )
            ValueAnimator.ofObject(ArgbEvaluator(),
                (binding.viewAlbumGlow?.backgroundTintList
                    ?.defaultColor ?: glowColor),
                glowColor
            ).apply {
                duration = 700
                addUpdateListener { anim ->
                    binding.viewAlbumGlow?.backgroundTintList =
                        android.content.res.ColorStateList.valueOf(anim.animatedValue as Int)
                }
                start()
            }
        }
    }

    /** Hace un color suficientemente visible sobre el fondo dado */
    private fun ensureContrast(color: Int, background: Int): Int {
        val ratio = ColorUtils.calculateContrast(color, background)
        return if (ratio >= 2.5f) color
        else ColorUtils.blendARGB(color, Color.WHITE, 0.6f)
    }

    /** Anima el degradado del fondo raíz de un color al siguiente */
    private fun animateBackground(old: GradientDrawable, toTop: Int, toBottom: Int) {
        // Usar el dominante guardado como punto de partida real; si aún no hay uno
        // (primera canción) caer al color de superficie por defecto.
        val fromTop = if (currentDominantColor != 0) currentDominantColor
                      else ContextCompat.getColor(this, R.color.surface_dark)

        ValueAnimator.ofObject(ArgbEvaluator(), fromTop, toTop).apply {
            duration = 600
            addUpdateListener { anim ->
                val top    = anim.animatedValue as Int
                val bottom = ContextCompat.getColor(this@PlayerActivity, R.color.background_dark)
                binding.root.background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(top, bottom)
                )
            }
            start()
        }
    }

    /** Anima el fondo del panel lateral hacia el nuevo color */
    private fun animatePanelBackground(toColor: Int) {
        val bg = binding.sideOptionsPanel?.background as? GradientDrawable
        val fromColor = if (bg != null) {
            // Intentamos obtener el color actual; si falla usamos el fallback
            try { Color.parseColor("#CC161A22") }
            catch (e: Exception) { Color.parseColor("#CC161A22") }
        } else {
            Color.parseColor("#CC161A22")
        }

        ValueAnimator.ofObject(ArgbEvaluator(), fromColor, toColor).apply {
            duration = 500
            addUpdateListener { anim ->
                val c = anim.animatedValue as Int
                val newBg = GradientDrawable().apply {
                    shape  = GradientDrawable.RECTANGLE
                    cornerRadius = 28f * resources.displayMetrics.density
                    setColor(c)
                    setStroke(
                        (1f * resources.displayMetrics.density).toInt(),
                        ColorUtils.setAlphaComponent(Color.WHITE, 0x22)
                    )
                }
                binding.sideOptionsPanel?.background = newBg
            }
            start()
        }
    }

    /** Anima el tint de iconos en el panel lateral y controles principales */
    private fun animateButtonTints(toColor: Int) {
        val fromColor = if (currentLightColor != 0) currentLightColor
                        else ContextCompat.getColor(this, R.color.text_primary)

        val buttonsToTint = listOfNotNull(
            binding.btnShuffle,
            binding.btnShuffle2,
            binding.btnPrevious,
            binding.btnNext,
            binding.btnPlayPause,
            binding.btnRepeat,
            binding.btnLyrics,
            binding.btnQueue,
            binding.btnBack,
            binding.btnMore,
            binding.btnMoreSong,
            binding.btnSaveToPlaylist,
            binding.btnEqualizer,
            binding.btnCanvas
        )

        // Sleep timer y AB repeat mantienen su color de estado propio
        // los animamos solo si están en estado "off"
        val sleepOff  = SleepTimerManager.isRunning.value != true
        val abOff     = PlayerController.abRepeatState.value == PlayerController.ABRepeatState.OFF

        ValueAnimator.ofObject(ArgbEvaluator(), fromColor, toColor).apply {
            duration = 500
            addUpdateListener { anim ->
                val c = anim.animatedValue as Int
                buttonsToTint.forEach { btn ->
                    try { btn.setColorFilter(c, PorterDuff.Mode.SRC_IN) }
                    catch (_: Exception) {}
                }
                if (sleepOff) {
                    try { binding.btnSleepTimer.setColorFilter(
                        ColorUtils.setAlphaComponent(c, 0xAA), PorterDuff.Mode.SRC_IN)
                    } catch (_: Exception) {}
                }
                if (abOff) {
                    try { binding.btnAbRepeat.setColorFilter(
                        ColorUtils.setAlphaComponent(c, 0xAA), PorterDuff.Mode.SRC_IN)
                    } catch (_: Exception) {}
                }
            }
            start()
        }
    }

    /** Anima el tint de la seekbar hacia el color de acento de la carátula */
    private fun animateSeekBarTint(toColor: Int) {
        val fromColor = if (currentAccentColor != 0) currentAccentColor
                        else ContextCompat.getColor(this, R.color.text_primary)
        ValueAnimator.ofObject(ArgbEvaluator(), fromColor, toColor).apply {
            duration = 500
            addUpdateListener { anim ->
                val c = anim.animatedValue as Int
                try {
                    binding.seekBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(c)
                    binding.seekBar.thumbTintList =
                        android.content.res.ColorStateList.valueOf(c)
                } catch (_: Exception) {}
            }
            start()
        }
    }

    // ── LRC parser ───────────────────────────────────────────────────────────
    private fun parseLrc(raw: String): List<SyncedLyricsAdapter.LyricLine> {
        return runCatching {
            val regex = Regex("""^\[(\d+):(\d+)[.:]?(\d*)\]\s*(.*)$""")
            raw.lines().mapNotNull { line ->
                regex.matchEntire(line.trim())?.let { m ->
                    val min  = m.groupValues[1].toLongOrNull() ?: return@let null
                    val sec  = m.groupValues[2].toLongOrNull() ?: return@let null
                    val ms   = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
                    val text = m.groupValues[4].trim()
                    if (text.isBlank()) null
                    else SyncedLyricsAdapter.LyricLine((min * 60_000) + (sec * 1_000) + ms, text)
                }
            }
        }.getOrElse { emptyList() }
    }

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /**
     * Observa el LiveData del canvas para [songId].
     * Cada vez que cambia la canción se llama de nuevo; el observer anterior
     * se elimina automáticamente porque está ligado al ciclo de vida de la Activity.
     *
     * Cuando el canvas cambia:
     *  • Se actualiza [activeCanvasUri] (leído por el adapter vía canvasProvider)
     *  • Se refresca la página central del pager para mostrar/ocultar el GIF
     *  • El botón btnCanvas recibe un tint de acento si hay canvas activo,
     *    o vuelve a semitransparente si se eliminó
     */
    private fun observeCanvas(songId: Long) {
        viewModel.getCanvasLive(songId).observe(this) { entity ->
            val newUri = entity?.gifUri?.let { Uri.parse(it) }
            activeCanvasUri = newUri

            // Refrescar solo la página central — es la única que muestra canvas
            albumArtAdapter.notifyItemChanged(AlbumArtPagerAdapter.CENTER_PAGE)

            // Actualizar visualmente el botón canvas en el panel lateral
            val hasCanvas = newUri != null
            binding.btnCanvas?.alpha = if (hasCanvas) 1f else 0.5f
            val tint = if (hasCanvas) {
                if (currentAccentColor != 0) currentAccentColor
                else ContextCompat.getColor(this, R.color.accent_blue)
            } else {
                if (currentLightColor != 0) currentLightColor
                else ContextCompat.getColor(this, R.color.text_secondary)
            }
            binding.btnCanvas?.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
        }
    }

    /**
     * Muestra el menú del canvas GIF.
     * Si la canción ya tiene un canvas ofrece "Cambiar" y "Quitar";
     * si no tiene ofrece solo "Agregar Canvas GIF".
     */
    private fun showCanvasMenu() {
        val song = PlayerController.currentSong.value ?: return
        val hasCanvas = activeCanvasUri != null

        val options = if (hasCanvas) {
            arrayOf(
                getString(R.string.canvas_set),
                getString(R.string.canvas_remove)
            )
        } else {
            arrayOf(getString(R.string.canvas_set))
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.canvas_gif))
            .setItems(options) { _, idx ->
                when {
                    // "Cambiar Canvas GIF" — siempre es el primer ítem
                    idx == 0 -> gifPicker.launch("image/gif")
                    // "Quitar Canvas GIF" — solo aparece si hasCanvas, siempre idx == 1
                    hasCanvas && idx == 1 -> {
                        viewModel.deleteCanvas(song.id)
                        Snackbar.make(
                            binding.root,
                            getString(R.string.canvas_removed),
                            Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .show()
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onResume() {
        super.onResume()
        handler.post(updateRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateRunnable)
    }

}
