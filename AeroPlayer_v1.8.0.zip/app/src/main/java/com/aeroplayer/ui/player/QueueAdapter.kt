package com.aeroplayer.ui.player

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemQueueSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.utils.AlbumArtUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class QueueAdapter(
    private val onItemClick   : (Song, Int) -> Unit,
    private val onRemoveClick : (Int) -> Unit,
    private val onOrderChanged: (List<Song>) -> Unit
) : ListAdapter<Song, QueueAdapter.VH>(SongDiff()) {

    private var currentIndex: Int = 0
    var itemTouchHelper: ItemTouchHelper? = null

    // Copia mutable para drag & drop
    private val mutableList = mutableListOf<Song>()

    inner class VH(val b: ItemQueueSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemQueueSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivAlbumArt.clipToOutline   = true
        b.ivAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text  = song.title
            tvArtist.text = song.artist

            val isPlaying = position == currentIndex
            root.alpha = if (isPlaying) 1f else 0.75f
            tvTitle.setTextColor(
                root.context.getColor(
                    if (isPlaying) R.color.accent_blue else R.color.text_primary
                )
            )
            ivNowPlaying.visibility = if (isPlaying) android.view.View.VISIBLE else android.view.View.GONE

            // Cargar carátula con fallback
            val cached = AlbumArtUtils.getCached(song.id)
            Glide.with(ivAlbumArt)
                .load(cached ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .error(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivAlbumArt)

            // Iniciar arrastre al tocar el handle
            ivDragHandle.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    itemTouchHelper?.startDrag(holder)
                }
                false
            }

            ivRemove.setOnClickListener { onRemoveClick(holder.bindingAdapterPosition) }
            root.setOnClickListener    { onItemClick(song, holder.bindingAdapterPosition) }
        }
    }

    fun setCurrentIndex(index: Int) {
        val old = currentIndex
        currentIndex = index
        notifyItemChanged(old)
        notifyItemChanged(index)
    }

    /** Sobrescribir submitList para mantener mutableList sincronizado */
    override fun submitList(list: List<Song>?) {
        mutableList.clear()
        if (list != null) mutableList.addAll(list)
        super.submitList(list?.toList())
    }

    /** Llamado por el ItemTouchHelper al mover un item */
    fun onItemMove(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= mutableList.size || to >= mutableList.size) return
        val item = mutableList.removeAt(from)
        mutableList.add(to, item)
        notifyItemMoved(from, to)
        // Actualizar currentIndex si la canción activa se movió
        currentIndex = when {
            from == currentIndex -> to
            from < currentIndex && to >= currentIndex -> currentIndex - 1
            from > currentIndex && to <= currentIndex -> currentIndex + 1
            else -> currentIndex
        }
    }

    /** Llamado cuando el usuario suelta el item — notificar al PlayerController */
    fun onDropped() {
        onOrderChanged(mutableList.toList())
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}

/** ItemTouchHelper.Callback para drag & drop vertical en la cola */
class QueueDragCallback(private val adapter: QueueAdapter) : ItemTouchHelper.Callback() {

    override fun getMovementFlags(rv: RecyclerView, vh: RecyclerView.ViewHolder) =
        makeMovementFlags(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,  // drag
            0                                             // sin swipe
        )

    override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
        adapter.onItemMove(vh.bindingAdapterPosition, target.bindingAdapterPosition)
        return true
    }

    override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) { /* no swipe */ }

    override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
        super.clearView(rv, vh)
        vh.itemView.alpha = 1f
        adapter.onDropped()
    }

    override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
        super.onSelectedChanged(vh, actionState)
        if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
            vh?.itemView?.alpha = 0.85f
            vh?.itemView?.scaleX = 1.02f
            vh?.itemView?.scaleY = 1.02f
        }
    }

    override fun isLongPressDragEnabled() = false  // Solo por handle, no long-press
}
