package com.aeroplayer.ui.equalizer

import kotlin.math.*

/**
 * SoftwareEqualizer — EQ paramétrico por software con filtros biquad IIR.
 *
 * Implementa N bandas de filtro peaking independientes de las limitaciones
 * del hardware Android (que normalmente tiene solo 5 bandas fijas).
 *
 * Cada banda es un filtro peaking con:
 *   - Frecuencia central configurable
 *   - Ganancia en dB (+/- 15dB)
 *   - Factor Q configurable (anchura de banda)
 *
 * Se aplica en la cadena de procesamiento de audio de ExoPlayer mediante
 * AudioProcessor. El procesamiento es en punto flotante de 32 bits.
 *
 * Usage:
 *   val eq = SoftwareEqualizer(sampleRate = 44100, bandCount = 10)
 *   eq.setBandGain(bandIndex, gainDb)
 *   val processed = eq.process(audioBuffer)
 */
class SoftwareEqualizer(
    private val sampleRate: Int = 44100,
    private val bandCount: Int = 10
) {

    // Frecuencias centrales estándar para N bandas
    private val centerFrequencies: FloatArray = when (bandCount) {
        5  -> floatArrayOf(60f, 250f, 1000f, 4000f, 16000f)
        7  -> floatArrayOf(60f, 170f, 310f, 600f, 1000f, 6000f, 16000f)
        10 -> floatArrayOf(32f, 64f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
        15 -> floatArrayOf(25f,40f,63f,100f,160f,250f,400f,630f,1000f,1600f,2500f,4000f,6300f,10000f,16000f)
        else -> FloatArray(bandCount) { i ->
            20f * (20000f / 20f).pow(i.toFloat() / (bandCount - 1))
        }
    }

    private val gains   = FloatArray(bandCount) { 0f }  // dB
    private val qValues = FloatArray(bandCount) { 1.4f } // Q

    // Coeficientes biquad: [b0, b1, b2, a1, a2] por banda × canal
    private val coeffs = Array(bandCount) { DoubleArray(5) }
    // Estados de filtro: [x1, x2, y1, y2] por banda × canal
    private val stateL = Array(bandCount) { DoubleArray(4) }
    private val stateR = Array(bandCount) { DoubleArray(4) }

    init { recalcAllCoeffs() }

    fun setBandGain(band: Int, gainDb: Float) {
        if (band < 0 || band >= bandCount) return
        gains[band] = gainDb.coerceIn(-15f, 15f)
        recalcCoeffs(band)
    }

    fun setBandQ(band: Int, q: Float) {
        if (band < 0 || band >= bandCount) return
        qValues[band] = q.coerceIn(0.5f, 4f)
        recalcCoeffs(band)
    }

    fun getBandFrequency(band: Int): Float = centerFrequencies.getOrElse(band) { 1000f }
    fun getBandCount() = bandCount
    fun getBandGain(band: Int) = gains.getOrElse(band) { 0f }

    fun resetAll() {
        gains.fill(0f)
        recalcAllCoeffs()
        stateL.forEach { it.fill(0.0) }
        stateR.forEach { it.fill(0.0) }
    }

    /** Procesa un buffer PCM stereo entrelazado (L,R,L,R,...) in-place. */
    fun processFloat(buffer: FloatArray, frames: Int) {
        for (f in 0 until frames) {
            var l = buffer[f * 2].toDouble()
            var r = buffer[f * 2 + 1].toDouble()
            for (b in 0 until bandCount) {
                if (gains[b] == 0f) continue
                val c = coeffs[b]
                val sl = stateL[b]; val sr = stateR[b]
                val newL = c[0]*l + c[1]*sl[0] + c[2]*sl[1] - c[3]*sl[2] - c[4]*sl[3]
                val newR = c[0]*r + c[1]*sr[0] + c[2]*sr[1] - c[3]*sr[2] - c[4]*sr[3]
                sl[1]=sl[0]; sl[0]=l; sl[3]=sl[2]; sl[2]=newL; l=newL
                sr[1]=sr[0]; sr[0]=r; sr[3]=sr[2]; sr[2]=newR; r=newR
            }
            buffer[f * 2]     = l.toFloat().coerceIn(-1f, 1f)
            buffer[f * 2 + 1] = r.toFloat().coerceIn(-1f, 1f)
        }
    }

    private fun recalcAllCoeffs() { (0 until bandCount).forEach { recalcCoeffs(it) } }

    /** Calcula coeficientes de filtro peaking biquad (Audio EQ Cookbook, R. Bristow-Johnson). */
    private fun recalcCoeffs(band: Int) {
        val freq  = centerFrequencies[band].toDouble()
        val gainDb = gains[band].toDouble()
        val q     = qValues[band].toDouble()
        val A     = 10.0.pow(gainDb / 40.0)
        val w0    = 2.0 * PI * freq / sampleRate
        val alpha = sin(w0) / (2.0 * q)
        val cosW  = cos(w0)
        val b0 =  1.0 + alpha * A
        val b1 = -2.0 * cosW
        val b2 =  1.0 - alpha * A
        val a0 =  1.0 + alpha / A
        val a1 = -2.0 * cosW
        val a2 =  1.0 - alpha / A
        coeffs[band][0] = b0 / a0
        coeffs[band][1] = b1 / a0
        coeffs[band][2] = b2 / a0
        coeffs[band][3] = a1 / a0
        coeffs[band][4] = a2 / a0
    }
}
