package com.aeroplayer.ui.player

import android.app.ActivityOptions
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.SeekBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.cast.CastManager
import com.aeroplayer.timer.SleepTimerManager
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.aeroplayer.databinding.ActivityPlayerBinding
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.aeroplayer.utils.ButtonAnimations.animateLike
import com.aeroplayer.utils.ButtonAnimations.animatePlayPause
import com.aeroplayer.utils.ButtonAnimations.animatePulse
import com.aeroplayer.utils.ButtonAnimations.animateRepeatChange
import com.aeroplayer.utils.ButtonAnimations.animateShuffle
import com.aeroplayer.utils.ButtonAnimations.animateSkip
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.graphics.PorterDuff
import android.util.TypedValue
import android.widget.ImageButton
import androidx.core.graphics.ColorUtils
import androidx.media3.common.Player
import com.google.android.material.snackbar.Snackbar
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlayerActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_DELETE_SONG = 1001
    }

    private lateinit var binding: ActivityPlayerBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var queueAdapter: QueueAdapter
    private lateinit var lyricsAdapter: SyncedLyricsAdapter
    private lateinit var albumArtAdapter: AlbumArtPagerAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            val dur = PlayerController.getDuration()
            if (dur > 0) {
                updateProgress()
                handler.postDelayed(this, 500)
            } else {
                // Duración aún no disponible (buffering tras volver de background).
                // Reintentar pronto sin actualizar la UI para no mostrar 00:00.
                handler.postDelayed(this, 200)
            }
        }
    }

    private var isQueueVisible = false
    private var isSidePanelVisible = false

    // Color de acento extraído de la carátula actual — se usa para botones y panel
    private var currentAccentColor: Int = 0
    private var currentLightColor: Int = 0
    // Color dominante actual del fondo degradado — permite animar desde el valor real
    private var currentDominantColor: Int = 0

    // Evita disparar next/previous al programar setCurrentItem internamente
    private var isPagerSettingItem = false

    // ── GIF Canvas ───────────────────────────────────────────────────────────
    /** URI del canvas activo para la canción actual. Null = sin canvas. */
    private var activeCanvasUri: Uri? = null

    /** Job de carga de carátula — se cancela si el usuario cambia de canción antes de terminar. */
    private var artLoadJob: Job? = null

    /**
     * Picker de GIF: abre el selector del sistema filtrando image/gif.
     * Al elegir un archivo se persiste en Room y se refleja de inmediato
     * en el pager gracias al LiveData del ViewModel.
     */
    private val gifPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val song = PlayerController.currentSong.value ?: return@registerForActivityResult
        // ACTION_OPEN_DOCUMENT otorga FLAG_GRANT_PERSISTABLE_URI_PERMISSION.
        // takePersistableUriPermission persiste el acceso entre sesiones.
        try {
            contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // La URI no tiene grant persistible — continuar de todas formas (sesión actual)
        }
        viewModel.setCanvas(song.id, uri.toString())
        Snackbar.make(binding.root, getString(R.string.canvas_applied), Snackbar.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        // Transición animada portada → player (shared element)
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            window.requestFeature(android.view.Window.FEATURE_ACTIVITY_TRANSITIONS)
            window.sharedElementEnterTransition = android.transition.ChangeBounds().apply {
                duration = 350
                interpolator = android.view.animation.DecelerateInterpolator()
            }
            window.sharedElementReturnTransition = android.transition.ChangeBounds().apply {
                duration = 280
                interpolator = android.view.animation.AccelerateInterpolator()
            }
        }
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // FIX Android 16: PlayerActivity usa statusBar transparente para el efecto
        // de portada de pantalla completa. En Android 16 (edge-to-edge obligatorio)
        // hay que declarar explícitamente que la actividad gestiona los insets.
        // El layout activity_player.xml ya usa android:fitsSystemWindows="false" en
        // la raíz, así que solo necesitamos optar por la gestión manual.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Aplicar color de acento a vistas con accent_blue hardcodeado en XML
        com.aeroplayer.ui.AccentApplier.apply(this, binding.root)

        // FIX: aplicar tint blanco inicial a todos los botones del player antes de que
        // se genere la paleta de la carátula. Sin esto, los botones con tint=#FFFFFFFF en XML
        // podrían quedar sin color visible durante el primer frame si algo lo resetea.
        // La paleta lo sobreescribirá con el color dinámico al cargar la portada.
        applyInitialButtonTints()

        setupToolbar()
        setupControls()
        setupAlbumPager()
        setupSeekBar()
        setupQueue()
        setupLyrics()
        observePlayer()
    }

    /** Aplica tint blanco opaco a los botones del player como estado inicial.
     *  Se ejecuta antes de que cargue el arte → evita el flash de botón invisible. */
    private fun applyInitialButtonTints() {
        val white = android.graphics.Color.WHITE
        val semiWhite = android.graphics.Color.argb(0xBF, 255, 255, 255)
        val whiteCsl = android.content.res.ColorStateList.valueOf(white)
        val semiWhiteCsl = android.content.res.ColorStateList.valueOf(semiWhite)

        // Solo ImageButton/ImageView — excluir btnCast (MediaRouteButton) y btnSpeed (TextView)
        val buttons = listOfNotNull(
            binding.btnBack, binding.btnMore,
            binding.btnShuffle, binding.btnPrevious, binding.btnPlayPause,
            binding.btnNext, binding.btnRepeat,
            binding.btnQueue,
            binding.btnMoreSong, binding.btnSaveToPlaylist,
            binding.btnEqualizerPanel, binding.btnAbRepeat,
            binding.btnLike, binding.btnShuffle2,
            binding.btnVisualizer
        )
        buttons.forEach { btn ->
            androidx.core.widget.ImageViewCompat.setImageTintList(btn, whiteCsl)
        }
        // btnSleepTimer arranca semi-transparente (inactivo)
        androidx.core.widget.ImageViewCompat.setImageTintList(binding.btnSleepTimer, semiWhiteCsl)
        // btnAbRepeat también inactivo al inicio
        androidx.core.widget.ImageViewCompat.setImageTintList(binding.btnAbRepeat, semiWhiteCsl)
    }

    // ── Toolbar ──────────────────────────────────────────────────────────────
    private fun showSpeedDialog() {
        val speeds  = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
        val labels  = arrayOf("0.25×","0.5×","0.75×","1×","1.25×","1.5×","1.75×","2×","3×")
        val current = PlayerController.playbackSpeed.value ?: 1.0f
        val checked = speeds.indexOfFirst { it == current }.takeIf { it >= 0 } ?: 3

        val options = arrayOf(
            "⚡ Velocidad",
            "🎵 Tono (pitch)",
            "🎧 Presets de música",
            "🌀 Audio 8D"
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Velocidad y tono")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showSpeedPickerDialog(speeds, labels, checked)
                    1 -> showPitchDialog()
                    2 -> showMusicPresetsDialog()
                    3 -> show8DDialog()
                }
            }
            .show()
    }

    /** Presets de escucha: Nightcore, Slow+Reverb, Ultra Slowed, Daycore. */
    private fun showMusicPresetsDialog() {
        data class Preset(val name: String, val speed: Float, val semitones: Int)
        val presets = listOf(
            Preset("🎵 Normal",            1.0f,  0),
            Preset("⚡ Nightcore",          1.25f, +3),
            Preset("🌙 Slow + Reverb",     0.75f, -2),
            Preset("🐢 Ultra Slowed",      0.5f,  -4),
            Preset("☀️ Daycore",           0.85f, -2),
            Preset("🔥 Hardstyle",         1.5f,  +0),
            Preset("🎹 Pitch Up (+5)",     1.0f,  +5),
            Preset("🎸 Pitch Down (-5)",   1.0f,  -5)
        )
        val labels = presets.map { it.name }.toTypedArray()
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("🎧 Presets de música")
            .setItems(labels) { _, idx ->
                val p = presets[idx]
                // Desactivar pitch lock para poder cambiar tono
                if (PlayerController.pitchLock.value == true) {
                    PlayerController.togglePitchLock()
                }
                PlayerController.setPlaybackSpeed(p.speed)
                PlayerController.setPitchSemitones(p.semitones)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "${p.name} activado", 
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /** Audio 8D: activa/desactiva efecto binaural rotativo. */
    private fun show8DDialog() {
        val is8DActive = PlayerController.is8DAudioActive.value == true
        val msg = if (is8DActive)
            "Audio 8D activo — sonido envolvente binaural\n¿Desactivar?"
        else
            "El audio 8D crea un efecto de sonido rotativo envolvente.\nRequiere auriculares para mejor experiencia."
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("🌀 Audio 8D")
            .setMessage(msg)
            .setPositiveButton(if (is8DActive) "Desactivar" else "Activar 8D") { _, _ ->
                PlayerController.toggle8DAudio()
                val status = if (PlayerController.is8DAudioActive.value == true) "activado 🎧" else "desactivado"
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Audio 8D $status", 
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showSpeedPickerDialog(
        speeds: FloatArray,
        labels: Array<String>,
        checkedIndex: Int
    ) {
        val current = PlayerController.playbackSpeed.value ?: 1.0f
        val checked = speeds.indexOfFirst { it == current }.takeIf { it >= 0 } ?: checkedIndex
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Velocidad de reproducción")
            .setSingleChoiceItems(labels, checked) { dialog, idx ->
                PlayerController.setPlaybackSpeed(speeds[idx])
                dialog.dismiss()
            }
            .show()
    }

    private fun showPitchDialog() {
        val semitones = (-12..12).toList()
        val labels = semitones.map { s ->
            when {
                s < 0  -> "$s semitones"
                s == 0 -> "0 (original)"
                else   -> "+$s semitones"
            }
        }.toTypedArray()
        val pitchLocked = PlayerController.pitchLock.value ?: true
        val currentSemitones = PlayerController.pitchSemitones.value ?: 0
        val checked = semitones.indexOf(currentSemitones).coerceAtLeast(0)

        // Construir vista con checkbox de pitch lock + lista
        val dialogView = layoutInflater.inflate(android.R.layout.select_dialog_singlechoice, null)

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Control de tono")
            .setMessage(if (pitchLocked) "🔒 Pitch correction activo — el tono no cambia con la velocidad"
                        else "🔓 Pitch libre — puedes ajustar el tono manualmente")
            .setSingleChoiceItems(labels, checked) { dialog, idx ->
                if (!pitchLocked) {
                    PlayerController.setPitchSemitones(semitones[idx])
                }
                dialog.dismiss()
            }
            .setPositiveButton(if (pitchLocked) "Desactivar pitch lock" else "Activar pitch lock") { _, _ ->
                PlayerController.togglePitchLock()
                val msg = if (PlayerController.pitchLock.value == true)
                    "🔒 Pitch correction activado"
                else
                    "🔓 Pitch libre activado"
                com.google.android.material.snackbar.Snackbar.make(binding.root, msg,
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showSleepTimerDialog() {
        val isRunning = SleepTimerManager.isRunning.value == true
        val remaining = if (isRunning) SleepTimerManager.remainingMs.value ?: 0L else 0L
        val title = if (isRunning)
            "Sleep timer — ${SleepTimerManager.formatRemaining(remaining)} restantes"
        else "Sleep timer"

        val minutes = listOf(5, 10, 15, 20, 30, 45, 60)
        val options = mutableListOf<String>()
        if (isRunning) options.add("⏹ Cancelar timer")
        options.addAll(minutes.map { "$it min" })
        options.add("Al terminar la canción actual")
        options.add("Tiempo personalizado…")

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setItems(options.toTypedArray()) { _, idx ->
                var offset = 0
                if (isRunning) {
                    if (idx == 0) { SleepTimerManager.cancel(); return@setItems }
                    offset = 1
                }
                val adjustedIdx = idx - offset
                when {
                    adjustedIdx < minutes.size -> {
                        val pick = minutes[adjustedIdx]
                        SleepTimerManager.start(pick)
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, "⏱ La música se pausará en $pick min",
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                    }
                    adjustedIdx == minutes.size -> {
                        // Al terminar la canción
                        SleepTimerManager.start(120, afterCurrentSong = true)
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, "⏱ Se pausará al terminar la canción actual",
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                    }
                    else -> showCustomSleepTimerDialog()
                }
            }
            .show()
    }

    private fun showCustomSleepTimerDialog() {
        val input = com.google.android.material.textfield.TextInputEditText(this).apply {
            hint = "Minutos"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(48, 24, 48, 8)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Tiempo personalizado")
            .setView(input)
            .setPositiveButton("Iniciar") { _, _ ->
                val mins = input.text?.toString()?.toIntOrNull()?.coerceIn(1, 600) ?: return@setPositiveButton
                SleepTimerManager.start(mins)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "⏱ Pausará en $mins min",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun closeWithAnimation() {
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.fade_in, R.anim.slide_down)
    }

    private fun toggleSidePanel() {
        isSidePanelVisible = !isSidePanelVisible
        val dp = resources.displayMetrics.density

        // El contenedor de la portada es el ConstraintLayout padre de albumArtFrame
        val artContainer = binding.albumArtFrame?.parent as? android.view.View

        if (isSidePanelVisible) {
            // Abrir: deslizar panel desde fuera hacia adentro con rebote
            binding.sideOptionsPanel?.visibility = android.view.View.VISIBLE
            binding.sideOptionsPanel?.animate()
                ?.translationX(0f)
                ?.setDuration(380)
                ?.setInterpolator(OvershootInterpolator(1.6f))
                ?.start()

            // Portada: encoger + desplazar a la izquierda para dar espacio al panel
            artContainer?.animate()
                ?.scaleX(0.78f)
                ?.scaleY(0.78f)
                ?.translationX(-28 * dp)
                ?.setDuration(360)
                ?.setInterpolator(DecelerateInterpolator(2.2f))
                ?.start()

            // btnMore: rotar + escalar ligeramente
            binding.btnMore.animate()
                .rotation(135f)
                .scaleX(0.85f)
                .scaleY(0.85f)
                .setDuration(250)
                .start()

            // Animar cada botón del panel con delay escalonado (efecto cascada)
            val buttons = listOfNotNull(
                binding.btnShuffle2, binding.btnAbRepeat,
                binding.btnSleepTimer, binding.btnRepeat, binding.btnEqualizerPanel,
                binding.btnVisualizer
            )
            buttons.forEachIndexed { i, btn ->
                btn.alpha = 0f
                btn.translationX = 24 * dp
                btn.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .setStartDelay((i * 45L))
                    .setDuration(220)
                    .setInterpolator(DecelerateInterpolator(2f))
                    .start()
            }
        } else {
            // Cerrar: slide hacia afuera
            binding.sideOptionsPanel?.animate()
                ?.translationX(72 * dp)
                ?.setDuration(260)
                ?.setInterpolator(AccelerateInterpolator(2f))
                ?.withEndAction {
                    binding.sideOptionsPanel?.visibility = android.view.View.INVISIBLE
                }
                ?.start()

            // Portada: volver a tamaño original con rebote suave
            artContainer?.animate()
                ?.scaleX(1f)
                ?.scaleY(1f)
                ?.translationX(0f)
                ?.setDuration(380)
                ?.setInterpolator(OvershootInterpolator(1.2f))
                ?.start()

            binding.btnMore.animate()
                .rotation(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(220)
                .start()
        }
    }

    // ── Album Art Pager ──────────────────────────────────────────────────────
    private fun setupAlbumPager() {
        albumArtAdapter = AlbumArtPagerAdapter()

        // FIX redondeo: clipToOutline en XML no basta — hay que setear outlineProvider en código
        binding.vpAlbumArt?.let {
            it.clipToOutline = true
            it.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        // uriProvider: el pager pide el URI para un offset relativo al centro.
        // offset 0 = canción actual, -1 = anterior, +1 = siguiente.
        albumArtAdapter.uriProvider = { offset ->
            val queue = PlayerController.queue.value
            val idx   = PlayerController.currentIndex.value
            if (queue == null || idx == null) null
            else {
                val target = idx + offset
                if (target in queue.indices) queue[target].albumArtUri else null
            }
        }

        // pathProvider: carga carátula directo del archivo (igual que Oto Music)
        albumArtAdapter.pathProvider = { offset ->
            val queue = PlayerController.queue.value
            val idx   = PlayerController.currentIndex.value
            if (queue == null || idx == null) null
            else {
                val target = idx + offset
                if (target in queue.indices) {
                    val song = queue[target]
                    Pair(song.id, song.path)
                } else null
            }
        }

        // canvasProvider: solo para la página central (canción actual).
        albumArtAdapter.canvasProvider = {
            val entity = viewModel.getCanvasLive(
                PlayerController.currentSong.value?.id ?: 0L
            ).value
            val gifUri   = entity?.gifUri?.let { Uri.parse(it) }
            val videoUri = entity?.videoUri?.let { Uri.parse(it) }
            gifUri to videoUri
        }

        binding.vpAlbumArt?.adapter = albumArtAdapter
        binding.vpAlbumArt?.setCurrentItem(AlbumArtPagerAdapter.CENTER_PAGE, false)

        // Offset visual: las páginas adyacentes asoman ligeramente
        binding.vpAlbumArt?.offscreenPageLimit = 1

        binding.vpAlbumArt?.registerOnPageChangeCallback(
            object : androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    if (isPagerSettingItem) return
                    val delta = position - AlbumArtPagerAdapter.CENTER_PAGE
                    when {
                        delta > 0 -> {
                            repeat(delta) { PlayerController.next() }
                        }
                        delta < 0 -> {
                            repeat(-delta) { PlayerController.previous() }
                        }
                    }
                    // Recentrar silenciosamente para mantener el carrusel infinito
                    isPagerSettingItem = true
                    binding.vpAlbumArt?.setCurrentItem(
                        AlbumArtPagerAdapter.CENTER_PAGE, false
                    )
                    isPagerSettingItem = false
                }
            }
        )
    }

    private fun setupToolbar() {
        onBackPressedDispatcher.addCallback(
            this, object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() { closeWithAnimation() }
            }
        )
        binding.btnBack.setOnClickListener { closeWithAnimation() }

        // btnMore (arriba) → opciones de canción
        binding.btnMore.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            showSongOptionsMenu(song)
        }

        // FIX panel scroll: posicionar el panel UNA SOLA VEZ cuando se infla la portada.
        // Usamos post() para diferir hasta que la vista tenga dimensiones.
        // NO usar onGlobalLayoutListener en loop: se refireaba en cada scroll y movía el panel.
        binding.albumArtFrame?.post {
            val frame = binding.albumArtFrame ?: return@post
            val panel = binding.sideOptionsPanel ?: return@post
            val root  = binding.playerRoot

            val framePos = IntArray(2)
            frame.getLocationOnScreen(framePos)
            val rootPos = IntArray(2)
            root.getLocationOnScreen(rootPos)

            val frameTopInRoot = framePos[1] - rootPos[1]
            val centeredTop = frameTopInRoot + (frame.height - panel.height) / 2

            val params = panel.layoutParams as? androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams
                ?: return@post
            params.topMargin = centeredTop.coerceAtLeast(0)
            // FIX: usar translationY en vez de topMargin para que no se recalcule con scroll
            panel.layoutParams = params
            // Anclar el panel con translationY fija para que no se desplace al hacer scroll
            panel.translationY = 0f
        }
    }

    // ── Opciones de canción (btnMore arriba) ─────────────────────────────────

    private fun showSongOptionsMenu(song: com.aeroplayer.model.Song) {
        val hasCanvas = activeCanvasUri != null
        val options = mutableListOf(
            "🎵  Cambiar metadatos",
            "🗑️  Eliminar canción",
            "🙈  Ocultar canción",
            "➕  Agregar a playlist",
            "ℹ️  Información",
            "🖼️  Buscar carátula online",
            "🔖  Marcadores",
            "📻  Radios online",
            "🎛️  Colas de reproducción",
            "⬇️  Descargar con YTDLnis",
            if (hasCanvas) "🎞️  Cambiar portada animada" else "🎞️  Agregar portada animada"
        )
        options.add("🌐  Búsqueda de GIF")
        if (hasCanvas) options.add("❌  Quitar portada animada")

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(song.title)
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> showEditMetadataDialog(song)
                    1 -> confirmDeleteSong(song)
                    2 -> confirmHideSong(song)
                    3 -> showAddToPlaylistMenu(song)
                    4 -> showSongInfo(song)
                    5 -> fetchArtworkManually(song)
                    6 -> startActivity(android.content.Intent(this, com.aeroplayer.ui.BookmarksActivity::class.java))
                    7 -> startActivity(android.content.Intent(this, com.aeroplayer.ui.OnlineRadioActivity::class.java))
                    8 -> startActivity(android.content.Intent(this, com.aeroplayer.ui.MultiQueueActivity::class.java))
                    9 -> openYTDLnis(song)
                    10 -> gifPicker.launch(arrayOf("image/gif"))
                    11 -> showKlipySearchDialog(song)
                    12 -> if (hasCanvas) {
                        viewModel.deleteCanvas(song.id)
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, getString(R.string.canvas_removed),
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .show()
    }

    /**
     * Integración con YTDLnis: pide al usuario un link (YouTube, SoundCloud, etc.)
     * y lo pasa directamente a YTDLnis mediante ACTION_SEND.
     * YTDLnis detecta el link y abre su pantalla de descarga automáticamente.
     */
    private fun openYTDLnis(song: com.aeroplayer.model.Song) {
        val query = "${song.artist} - ${song.title}"
        val input = android.widget.EditText(this).apply {
            hint = "https://youtube.com/..."
            setPadding(64, 32, 64, 16)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText("https://www.youtube.com/results?search_query=${android.net.Uri.encode(query)}")
            selectAll()
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("⬇️ Descargar con YTDLnis")
            .setMessage("Pega el link de YouTube, SoundCloud, etc.:")
            .setView(input)
            .setPositiveButton("Enviar a YTDLnis") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isBlank()) return@setPositiveButton
                sendUrlToYTDLnis(url)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun sendUrlToYTDLnis(url: String) {
        // YTDLnis package id oficial
        val ytdlnisPkg = "com.deniscerri.ytdl"

        // Método 1: ACTION_SEND directo al package de YTDLnis (más limpio)
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type  = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, url)
            setPackage(ytdlnisPkg)
        }
        try {
            startActivity(sendIntent)
            return
        } catch (_: android.content.ActivityNotFoundException) {}

        // Método 2: ACTION_VIEW con la URL (algunos builds de YTDLnis lo capturan)
        val viewIntent = android.content.Intent(android.content.Intent.ACTION_VIEW,
            android.net.Uri.parse(url)).apply { setPackage(ytdlnisPkg) }
        try {
            startActivity(viewIntent)
            return
        } catch (_: android.content.ActivityNotFoundException) {}

        // YTDLnis no instalado → ofrecer instalarlo
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("YTDLnis no instalado")
            .setMessage("Instala YTDLnis para descargar música fácilmente.")
            .setPositiveButton("Instalar") { _, _ ->
                val uri = try {
                    android.net.Uri.parse("market://details?id=$ytdlnisPkg")
                } catch (_: Exception) {
                    android.net.Uri.parse("https://play.google.com/store/apps/details?id=$ytdlnisPkg")
                }
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun fetchArtworkManually(song: com.aeroplayer.model.Song) {
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Buscando carátula…",
            com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE
        )
        snack.show()
        lifecycleScope.launch(Dispatchers.IO) {
            // Quitar del caché de "sin arte" para forzar re-búsqueda
            com.aeroplayer.utils.AlbumArtUtils.clearSongFromCache(song.id)
            val bitmap = com.aeroplayer.utils.AlbumArtUtils.loadArt(
                song.id, song.path, song.artist, song.album
            )
            withContext(Dispatchers.Main) {
                snack.dismiss()
                if (bitmap != null) {
                    applyPaletteBackground(bitmap)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Carátula encontrada ✓",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                } else {
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "No se encontró carátula para esta canción",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // Registro para selección de imagen local para portada
    private val pickCoverImage = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { pendingSongForCover?.let { song -> applyCoverFromUri(song, it) } } }
    private var pendingSongForCover: com.aeroplayer.model.Song? = null

    private fun showEditMetadataDialog(song: com.aeroplayer.model.Song) {
        val dp = resources.displayMetrics.density

        val scroll = android.widget.ScrollView(this)
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (16 * dp).toInt(), (20 * dp).toInt(), (16 * dp).toInt())
        }
        scroll.addView(container)

        // ── Portada actual + botones ──────────────────────────────────────────
        val coverRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (12 * dp).toInt() }
        }
        val ivCover = android.widget.ImageView(this).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                (72 * dp).toInt(), (72 * dp).toInt()
            ).also { it.marginEnd = (12 * dp).toInt() }
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            background = getDrawable(R.drawable.bg_album_art)
            clipToOutline = true
        }
        com.bumptech.glide.Glide.with(ivCover).load(song.albumArtUri)
            .placeholder(R.drawable.ic_music_placeholder).centerCrop().into(ivCover)

        val coverButtons = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutParams = android.widget.LinearLayout.LayoutParams(0,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnPickCover = com.google.android.material.button.MaterialButton(this).apply {
            text = "📁 Elegir del dispositivo"
            textSize = 12f
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (4 * dp).toInt() }
            setOnClickListener {
                pendingSongForCover = song
                pickCoverImage.launch("image/*")
            }
        }
        val btnSearchCover = com.google.android.material.button.MaterialButton(this).apply {
            text = "🌐 Buscar en internet"
            textSize = 12f
            setOnClickListener { showCoverSearchDialog(song, ivCover) }
        }
        coverButtons.addView(btnPickCover)
        coverButtons.addView(btnSearchCover)
        coverRow.addView(ivCover)
        coverRow.addView(coverButtons)
        container.addView(coverRow)

        // ── Campos de texto ───────────────────────────────────────────────────
        fun field(hint: String, value: String) = com.google.android.material.textfield.TextInputEditText(this).apply {
            this.hint = hint
            setText(value)
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (8 * dp).toInt() }
        }

        val titleInput  = field("Título",  song.title)
        val artistInput = field("Artista", song.artist)
        val albumInput  = field("Álbum",   song.album)
        val genreInput  = field("Género",  "")   // MediaStore no expone género fácilmente
        val yearInput   = field("Año",     if (song.year > 0) song.year.toString() else "")

        listOf(titleInput, artistInput, albumInput, genreInput, yearInput).forEach {
            container.addView(it)
        }

        // Mostrar calidad actual
        if (song.qualityBadge.isNotBlank()) {
            container.addView(android.widget.TextView(this).apply {
                text = "Formato: ${song.qualityBadge}"
                textSize = 11f
                setTextColor(ContextCompat.getColor(this@PlayerActivity, R.color.text_secondary))
            })
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Editar metadatos")
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ ->
                editSongMetadata(
                    song,
                    newTitle  = titleInput.text?.toString()?.trim()?.ifBlank { song.title  } ?: song.title,
                    newArtist = artistInput.text?.toString()?.trim()?.ifBlank { song.artist } ?: song.artist,
                    newAlbum  = albumInput.text?.toString()?.trim()?.ifBlank { song.album  } ?: song.album,
                    newYear   = yearInput.text?.toString()?.trim()?.toIntOrNull() ?: song.year,
                    newGenre  = genreInput.text?.toString()?.trim()
                )
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /** Busca portadas en internet usando iTunes Search API (libre, sin clave). */
    private fun showCoverSearchDialog(song: com.aeroplayer.model.Song, ivPreview: android.widget.ImageView) {
        val query = "${song.artist} ${song.album}".trim()
        val input = com.google.android.material.textfield.TextInputEditText(this).apply {
            hint = "Artista + Álbum"
            setText(query)
            setPadding(48, 24, 48, 8)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Buscar portada")
            .setMessage("Se buscará en iTunes. Elige la mejor coincidencia.")
            .setView(input)
            .setPositiveButton("Buscar") { _, _ ->
                val q = input.text?.toString()?.trim() ?: return@setPositiveButton
                searchAndShowCovers(song, q, ivPreview)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun searchAndShowCovers(
        song: com.aeroplayer.model.Song,
        query: String,
        ivPreview: android.widget.ImageView
    ) {
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val encoded = java.net.URLEncoder.encode(query, "UTF-8")
                val url = java.net.URL(
                    "https://itunes.apple.com/search?term=$encoded&entity=album&limit=6"
                )
                val json = org.json.JSONObject(url.readText())
                val results = json.getJSONArray("results")
                val urls = (0 until results.length()).mapNotNull { i ->
                    results.getJSONObject(i)
                        .optString("artworkUrl100")
                        .replace("100x100", "600x600")
                        .takeIf { it.isNotBlank() }
                }

                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    if (urls.isEmpty()) {
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, "Sin resultados para \"$query\"",
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                        return@withContext
                    }
                    showCoverPickerDialog(song, urls, ivPreview)
                }
            }.onFailure { e ->
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Error al buscar: ${e.localizedMessage}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showCoverPickerDialog(
        song: com.aeroplayer.model.Song,
        urls: List<String>,
        ivPreview: android.widget.ImageView
    ) {
        val dp = resources.displayMetrics.density
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 3
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
        }
        urls.forEach { url ->
            val iv = android.widget.ImageView(this).apply {
                val size = (96 * dp).toInt()
                layoutParams = android.widget.GridLayout.LayoutParams().apply {
                    width = size; height = size
                    setMargins((4 * dp).toInt(), (4 * dp).toInt(),
                        (4 * dp).toInt(), (4 * dp).toInt())
                }
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = getDrawable(R.drawable.bg_album_art_small)
                clipToOutline = true
            }
            com.bumptech.glide.Glide.with(iv).load(url).centerCrop().into(iv)
            iv.setOnClickListener {
                // Descargar y aplicar la portada seleccionada
                applyCoverFromUrl(song, url, ivPreview)
            }
            grid.addView(iv)
        }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Elige una portada")
            .setView(android.widget.ScrollView(this).apply { addView(grid) })
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ── GIF search (portada animada) ────────────────────────────────────────────

    /**
     * Muestra un diálogo con un campo de búsqueda pre-rellenado con el artista + título.
     * El usuario puede ajustar la query antes de buscar.
     */
    private fun showKlipySearchDialog(song: com.aeroplayer.model.Song) {
        val dp = resources.displayMetrics.density
        val query = "${song.artist} ${song.title}".trim()
        val input = com.google.android.material.textfield.TextInputEditText(this).apply {
            hint = "Buscar GIF…"
            setText(query)
            setPadding((48 * dp / 3).toInt(), (24 * dp / 3).toInt(),
                (48 * dp / 3).toInt(), (8 * dp / 3).toInt())
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("🌐 Búsqueda de portada animada")
            .setMessage("Busca GIFs animados para usarlos como portada animada.")
            .setView(input)
            .setPositiveButton("Buscar") { _, _ ->
                val q = input.text?.toString()?.trim()
                if (!q.isNullOrBlank()) searchKlipyGifs(song, q)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    /**
     * Llama a la API de Klipy en IO y muestra el grid de resultados.
     */
    private fun searchKlipyGifs(song: com.aeroplayer.model.Song, query: String) {
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Buscando GIFs…",
            com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE
        )
        snack.show()
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val (results, _) = com.aeroplayer.data.repository.KlipyGifProvider.search(query)
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    if (results.isEmpty()) {
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, "Sin resultados para \"$query\"",
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                    } else {
                        showKlipyPickerDialog(song, results)
                    }
                }
            }.onFailure { e ->
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Error al buscar GIFs: ${e.localizedMessage}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Muestra un grid de miniaturas de los GIFs encontrados en Klipy.
     * Al tocar uno se descarga y se aplica como canvas de la canción.
     */
    private fun showKlipyPickerDialog(
        song: com.aeroplayer.model.Song,
        results: List<com.aeroplayer.data.repository.KlipyGifProvider.GifResult>
    ) {
        val dp = resources.displayMetrics.density
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 2
            setPadding((8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
        }

        var dialog: androidx.appcompat.app.AlertDialog? = null

        results.forEach { gif ->
            val iv = android.widget.ImageView(this).apply {
                val cellSize = ((resources.displayMetrics.widthPixels - 80 * dp) / 2).toInt()
                val cellHeight = (cellSize * 0.7f).toInt()
                layoutParams = android.widget.GridLayout.LayoutParams().apply {
                    width = cellSize; height = cellHeight
                    setMargins((4 * dp).toInt(), (4 * dp).toInt(),
                        (4 * dp).toInt(), (4 * dp).toInt())
                }
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = getDrawable(R.drawable.bg_album_art_small)
                clipToOutline = true
            }

            // Cargar miniatura animada con Glide (soporta GIF nativo)
            com.bumptech.glide.Glide.with(iv)
                .asGif()
                .load(gif.previewUrl)
                .centerCrop()
                .into(iv)

            iv.setOnClickListener {
                dialog?.dismiss()
                applyKlipyGifAsCanvas(song, gif.gifUrl)
            }
            grid.addView(iv)
        }

        dialog = com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Elige un Canvas GIF")
            .setView(android.widget.ScrollView(this).apply { addView(grid) })
            .setNegativeButton(getString(R.string.cancel), null)
            .create()
        dialog.show()
    }

    /**
     * Descarga el GIF de Klipy y lo guarda localmente en el directorio de la app,
     * luego lo asigna como canvas de [song].
     *
     * El GIF se copia a un archivo privado para que la URI sea estable entre sesiones
     * (las URLs de Tenor expiran con el tiempo).
     */
    private fun applyKlipyGifAsCanvas(song: com.aeroplayer.model.Song, gifUrl: String) {
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Descargando GIF…",
            com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE
        )
        snack.show()
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                // Directorio privado de la app — no necesita permisos de almacenamiento
                val canvasDir = java.io.File(filesDir, "canvas").also { it.mkdirs() }
                val destFile = java.io.File(canvasDir, "canvas_${song.id}.gif")

                // Descargar con Glide al disco (maneja caché y redirecciones)
                val file = com.bumptech.glide.Glide.with(this@PlayerActivity)
                    .asFile()
                    .load(gifUrl)
                    .submit()
                    .get()
                file.copyTo(destFile, overwrite = true)

                val fileUri = android.net.Uri.fromFile(destFile)

                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    viewModel.setCanvas(song.id, fileUri.toString())
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, getString(R.string.canvas_applied),
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }.onFailure { e ->
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Error al descargar el GIF: ${e.localizedMessage}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────

    private fun applyCoverFromUrl(
        song: com.aeroplayer.model.Song,
        url: String,
        ivPreview: android.widget.ImageView
    ) {
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val bitmap = com.bumptech.glide.Glide.with(this@PlayerActivity)
                    .asBitmap().load(url).submit().get()
                saveCoverBitmapToMediaStore(song, bitmap)
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    com.bumptech.glide.Glide.with(ivPreview).load(bitmap).centerCrop().into(ivPreview)
                    viewModel.loadSongs(forceRefresh = true)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Portada actualizada ✓",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Error al aplicar portada: ${e.localizedMessage}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun applyCoverFromUri(song: com.aeroplayer.model.Song, uri: android.net.Uri) {
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val bitmap = com.bumptech.glide.Glide.with(this@PlayerActivity)
                    .asBitmap().load(uri).submit().get()
                saveCoverBitmapToMediaStore(song, bitmap)
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    viewModel.loadSongs(forceRefresh = true)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Portada actualizada ✓",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun saveCoverBitmapToMediaStore(song: com.aeroplayer.model.Song, bitmap: android.graphics.Bitmap) {
        // Guardar el bitmap como bytes JPEG en el cache de portadas del sistema
        val stream = java.io.ByteArrayOutputStream()
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, stream)
        val bytes = stream.toByteArray()
        // Intentar escribir via ParcelFileDescriptor en la URI del álbum
        runCatching {
            val uri = android.net.Uri.withAppendedPath(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                song.id.toString()
            )
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        }
        // También guardar en archivo .jpg junto al audio (para reproductores externos)
        runCatching {
            val coverFile = java.io.File(
                song.path.substringBeforeLast("/"),
                "folder.jpg"
            )
            coverFile.writeBytes(bytes)
        }
        // Invalidar caché de Glide para esta canción
        com.aeroplayer.utils.AlbumArtUtils.invalidateCache(song.id)
    }

    private fun editSongMetadata(
        song: com.aeroplayer.model.Song,
        newTitle: String,
        newArtist: String,
        newAlbum: String  = song.album,
        newYear: Int      = song.year,
        newGenre: String? = null
    ) {
        try {
            val uri = android.net.Uri.withAppendedPath(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                song.id.toString()
            )
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.TITLE,  newTitle)
                put(android.provider.MediaStore.Audio.Media.ARTIST, newArtist)
                put(android.provider.MediaStore.Audio.Media.ALBUM,  newAlbum)
                if (newYear > 0) put(android.provider.MediaStore.Audio.Media.YEAR, newYear)
            }
            contentResolver.update(uri, values, null, null)
            viewModel.loadSongs(forceRefresh = true)
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "Metadatos actualizados ✓",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "No se pudo editar: ${e.localizedMessage}",
                com.google.android.material.snackbar.Snackbar.LENGTH_LONG
            ).show()
        }
    }

    private fun confirmDeleteSong(song: com.aeroplayer.model.Song) {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar canción")
            .setMessage("¿Eliminar \"${song.title}\" del dispositivo? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ -> deleteSongFile(song) }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun deleteSongFile(song: com.aeroplayer.model.Song) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val uri = android.net.Uri.withAppendedPath(
                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    song.id.toString()
                )
                val pendingIntent = android.provider.MediaStore.createDeleteRequest(
                    contentResolver, listOf(uri)
                )
                startIntentSenderForResult(
                    pendingIntent.intentSender, REQUEST_DELETE_SONG, null, 0, 0, 0
                )
            } else {
                val uri = android.net.Uri.withAppendedPath(
                    android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    song.id.toString()
                )
                contentResolver.delete(uri, null, null)
                PlayerController.next()
                viewModel.loadSongs(forceRefresh = true)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Canción eliminada",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
        } catch (e: Exception) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "No se pudo eliminar: ${e.localizedMessage}",
                com.google.android.material.snackbar.Snackbar.LENGTH_LONG
            ).show()
        }
    }

    private fun confirmHideSong(song: com.aeroplayer.model.Song) {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Ocultar canción")
            .setMessage("\"${song.title}\" dejará de aparecer en la biblioteca. Puedes reactivarla desde Configuración.")
            .setPositiveButton("Ocultar") { _, _ ->
                viewModel.hideSong(song.id)
                PlayerController.next()
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Canción ocultada",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showSongOptions(song: com.aeroplayer.model.Song) {
        showSongOptionsMenu(song)
    }

    private fun showAddToPlaylistMenu(song: com.aeroplayer.model.Song) {
        val playlists = viewModel.playlists.value
        if (playlists.isNullOrEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, getString(R.string.create_playlist_first), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.add_to_playlist))
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root,
                    getString(R.string.added_to_playlist, playlists[idx].name),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun showSongInfo(song: com.aeroplayer.model.Song) {
        val sizeStr = when {
            song.size >= 1_000_000 -> "%.1f MB".format(song.size / 1_000_000.0)
            song.size >= 1_000     -> "%.1f KB".format(song.size / 1_000.0)
            else                   -> "${song.size} B"
        }
        val durStr = run {
            val s = song.duration / 1000
            "%d:%02d".format(s / 60, s % 60)
        }
        val info = buildString {
            appendLine("🎵  ${song.title}")
            appendLine("🎤  ${song.artist}")
            appendLine("💿  ${song.album}")
            if (song.genre.isNotBlank())    appendLine("🎸  ${song.genre}")
            if (song.composer.isNotBlank()) appendLine("🖊️  ${song.composer}")
            if (song.year > 0)              appendLine("📅  ${song.year}")
            if (song.discNumber > 0)        appendLine("💿  Disco ${song.discNumber}")
            if (song.trackNumber > 0)       appendLine("🔢  Pista ${song.trackNumber}")
            if (song.bpm > 0)               appendLine("🥁  ${song.bpm} BPM")
            appendLine("⏱  $durStr")
            if (song.size > 0)              appendLine("📦  $sizeStr")
            if (song.mimeType.isNotBlank()) {
                val fmt = song.mimeType.substringAfterLast("/").uppercase()
                val kbps = if (song.bitrate > 0) " · ${song.bitrate / 1000} kbps" else ""
                appendLine("🔊  $fmt$kbps")
            }
            appendLine("📂  ${song.path}")
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.song_info))
            .setMessage(info.trim())
            .setPositiveButton("OK", null)
            .show()
    }

    // ── Playback controls ────────────────────────────────────────────────────

    /**
     * Dispara vibración táctil suave compatible con API 21+.
     * En API 27+ usa KEYBOARD_TAP (feedback ligero); en versiones anteriores
     * cae a VIRTUAL_KEY que también es breve y no intrusivo.
     */
    private fun View.hapticTap() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun setupControls() {
        binding.btnPlayPause.setOnClickListener {
            it.hapticTap()
            it.animatePulse(0.88f)
            PlayerController.playPause()
        }
        binding.btnNext.setOnClickListener {
            it.hapticTap()
            it.animateSkip(forward = true)
            PlayerController.next()
        }
        binding.btnPrevious.setOnClickListener {
            it.hapticTap()
            it.animateSkip(forward = false)
            PlayerController.previous()
        }

        binding.btnShuffle.setOnClickListener {
            it.hapticTap()
            PlayerController.toggleShuffle()
        }
        binding.btnRepeat.setOnClickListener {
            it.hapticTap()
            PlayerController.toggleRepeat()
        }

        // btnShuffle2 es el botón de shuffle dentro del panel lateral
        binding.btnShuffle2?.setOnClickListener { PlayerController.toggleShuffle() }

        // 3 puntos inline de song info → también abre el panel lateral
        binding.btnMoreSong?.setOnClickListener { toggleSidePanel() }

        // ❤ Like — guarda directamente en "Me gusta"
        binding.btnLike.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            val willBeLiked = viewModel.likedSongs.value?.none { it.songId == song.id } == true
            updateLikeButton(willBeLiked, animate = true)
            viewModel.toggleLike(song)
            com.google.android.material.snackbar.Snackbar.make(
                binding.root,
                if (willBeLiked) getString(R.string.added_to_liked)
                else getString(R.string.removed_from_liked),
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
        }

        // ➕ Guardar en playlist — despliega playlists existentes + crear nueva
        binding.btnSaveToPlaylist?.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            showSaveToPlaylistDialog(song)
        }

        binding.btnQueue.setOnClickListener {
            it.animatePulse(0.85f)
            toggleQueue()
        }
        binding.btnCloseQueue?.setOnClickListener { hideQueueOverlay() }

        // Guardar cola actual
        binding.btnSaveQueue?.setOnClickListener {
            val input = com.google.android.material.textfield.TextInputEditText(this).apply {
                hint = "Nombre de la cola"
                setPadding(48, 24, 48, 8)
                val qName = PlayerController.queueName.value
                if (!qName.isNullOrBlank()) setText(qName)
            }
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Guardar cola")
                .setView(input)
                .setPositiveButton("Guardar") { _, _ ->
                    val name = input.text?.toString()?.trim()?.ifBlank { null } ?: return@setPositiveButton
                    PlayerController.saveCurrentQueue(name)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Cola \"$name\" guardada ✓",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }

        // Cargar cola guardada
        binding.btnLoadQueue?.setOnClickListener {
            val names = PlayerController.getSavedQueueNames()
            if (names.isEmpty()) {
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "No hay colas guardadas",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Colas guardadas")
                .setItems(names.toTypedArray()) { _, idx ->
                    val allSongs = viewModel.allSongs.value ?: return@setItems
                    PlayerController.loadSavedQueue(names[idx], allSongs)
                    hideQueueOverlay()
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "▶ ${names[idx]}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                }
                .setNeutralButton("Eliminar…") { _, _ ->
                    showDeleteQueueDialog(names)
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
        // Ecualizador en el panel lateral (3 puntos)
        binding.btnEqualizerPanel?.setOnClickListener { openEqualizer() }

        binding.btnVisualizer?.setOnClickListener {
            startActivity(android.content.Intent(this,
                com.aeroplayer.ui.visualizer.VisualizerActivity::class.java))
        }

        // Sleep Timer
        binding.btnSleepTimer.setOnClickListener { showSleepTimerDialog() }
        SleepTimerManager.isRunning.observe(this) { running ->
            val activeColor = if (currentAccentColor != 0) currentAccentColor
                              else ContextCompat.getColor(this, R.color.accent_blue)
            val inactiveColor = if (currentLightColor != 0)
                ColorUtils.setAlphaComponent(currentLightColor, 0xAA)
            else 0xBFFFFFFF.toInt() // semi-transparent white — iconos sobre fondo oscuro
            binding.btnSleepTimer.setColorFilter(
                if (running) activeColor else inactiveColor,
                PorterDuff.Mode.SRC_IN
            )
            binding.tvSleepTimerRemaining.visibility = if (running) View.VISIBLE else View.GONE
        }
        SleepTimerManager.remainingMs.observe(this) { ms ->
            if (ms > 0) binding.tvSleepTimerRemaining.text = SleepTimerManager.formatRemaining(ms)
        }

        // Velocidad de reproducción
        binding.btnSpeed.setOnClickListener { showSpeedDialog() }
        PlayerController.playbackSpeed.observe(this) { speed ->
            val label = when {
                speed == 1.0f -> "1×"
                speed % 1 == 0f -> "${speed.toInt()}×"
                else -> "${speed}×"
            }
            binding.btnSpeed.text = label
            binding.btnSpeed.setTextColor(
                (if (speed != 1.0f) ContextCompat.getColor(this, R.color.accent_blue) else 0xBFFFFFFF.toInt())
            )
        }

        // Chromecast: asociar el botón con el selector de dispositivos
        CastManager.getCastContext()?.let {
            CastButtonFactory.setUpMediaRouteButton(this, binding.btnCast)
        }

        // Ocultar botón Cast si no hay dispositivos disponibles
        CastManager.isAvailable.observe(this) { available ->
            binding.btnCast.visibility = if (available) View.VISIBLE else View.GONE
        }

        // Cuando se está haciendo cast, pausar reproducción local
        CastManager.isCasting.observe(this) { casting ->
            if (casting) {
                val song = PlayerController.currentSong.value
                song?.let { CastManager.castSong(it) }
            }
        }
        // A-B Repeat — FIX: leer estado ANTES del ciclo para mostrar el estado SIGUIENTE correcto
        binding.btnAbRepeat.setOnClickListener {
            val prevState = PlayerController.abRepeatState.value
            PlayerController.cycleABRepeat()
            val msg = when (prevState) {
                PlayerController.ABRepeatState.OFF       -> getString(R.string.ab_repeat_set_a)
                PlayerController.ABRepeatState.A_SET     -> getString(R.string.ab_repeat_set_ab)
                else                                     -> getString(R.string.ab_repeat_cleared)
            }
            com.google.android.material.snackbar.Snackbar
                .make(binding.root, msg, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
        PlayerController.abRepeatState.observe(this) { state ->
            val color = when (state) {
                PlayerController.ABRepeatState.OFF       -> R.color.icon_on_dark
                PlayerController.ABRepeatState.A_SET     -> R.color.accent_yellow
                PlayerController.ABRepeatState.AB_ACTIVE ->
                    // Usar el acento dinámico si disponible, si no el azul por defecto
                    return@observe run {
                        val c = if (currentAccentColor != 0) currentAccentColor
                                else ContextCompat.getColor(this, R.color.accent_blue)
                        binding.btnAbRepeat.setColorFilter(c, PorterDuff.Mode.SRC_IN)
                        binding.btnAbRepeat.alpha = 1f
                    }
            }
            binding.btnAbRepeat.setColorFilter(getColor(color), PorterDuff.Mode.SRC_IN)
            binding.btnAbRepeat.alpha = if (state == PlayerController.ABRepeatState.OFF) 0.5f else 1f
        }

        // Canvas GIF — abre menú: Cambiar / Quitar
        // Canvas GIF ahora se gestiona desde el menú de opciones de canción (btnMore)
    }

    // ── Save to playlist dialog ──────────────────────────────────────────────
    private fun showSaveToPlaylistDialog(song: com.aeroplayer.model.Song) {
        val playlists = viewModel.playlists.value ?: emptyList()

        // Build items list: existing playlists + "Crear nueva playlist" at bottom
        val items = ArrayList<String>()
        items.add("➕  ${getString(R.string.create_new_playlist)}")
        playlists.forEach { items.add("🎵  ${it.name}") }

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.save_to_playlist))
            .setItems(items.toTypedArray()) { _, idx ->
                if (idx == 0) {
                    // Crear nueva playlist y agregar la canción
                    showCreateAndAddPlaylistDialog(song)
                } else {
                    val playlist = playlists[idx - 1]
                    viewModel.addSongToPlaylist(playlist.id, song)
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root,
                        getString(R.string.added_to_playlist, playlist.name),
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
            .show()
    }

    private fun showCreateAndAddPlaylistDialog(song: com.aeroplayer.model.Song) {
        val input = android.widget.EditText(this).apply {
            hint = getString(R.string.playlist_name)
            setPadding(48, 24, 48, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.create_new_playlist))
            .setView(input)
            .setPositiveButton(getString(R.string.create_playlist)) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root,
                        getString(R.string.playlist_name_required),
                        com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                    ).show()
                    return@setPositiveButton
                }
                // Create playlist, then observe LiveData until the new playlist appears.
                // This is reliable regardless of device speed — no hardcoded delay.
                viewModel.createPlaylist(name)
                viewModel.playlists.observe(this@PlayerActivity) { list ->
                    val created = list?.firstOrNull { it.name == name }
                    if (created != null) {
                        viewModel.addSongToPlaylist(created.id, song)
                        viewModel.playlists.removeObservers(this@PlayerActivity)
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root,
                            getString(R.string.playlist_created, name),
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ── Equalizer ────────────────────────────────────────────────────────────
    private fun openEqualizer() {
        startActivity(android.content.Intent(this, com.aeroplayer.ui.equalizer.EqualizerActivity::class.java))
    }

    // ── SeekBar ──────────────────────────────────────────────────────────────
    private fun setupSeekBar() {
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = PlayerController.getDuration()
                    PlayerController.seekTo((progress.toLong() * duration) / 1000)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) { handler.removeCallbacks(updateRunnable) }
            override fun onStopTrackingTouch(sb: SeekBar) { handler.post(updateRunnable) }
        })
    }

    private fun updateProgress() {
        val pos = PlayerController.getCurrentPosition()
        val dur = PlayerController.getDuration()
        // FIX BUG1: dur puede ser C.TIME_UNSET (-9223372036854775807) o 0 mientras
        // ExoPlayer está en STATE_BUFFERING tras setMediaItems. Solo actualizar
        // si tenemos una duración real positiva para evitar el estado congelado 00:00.
        if (dur > 0) {
            binding.seekBar.progress = ((pos * 1000) / dur).toInt()
            binding.tvCurrentTime.text = FormatUtils.formatDuration(pos)
            binding.tvTotalTime.text   = FormatUtils.formatDuration(dur)
        } else {
            // Buffering: mostrar posición sin duración
            binding.tvCurrentTime.text = FormatUtils.formatDuration(pos.coerceAtLeast(0))
        }
        // Karaoke: scroll automático a la línea activa
        if (binding.rvLyrics.visibility == View.VISIBLE) {
            val changed = lyricsAdapter.updateActiveIndex(pos)
            if (changed) {
                val idx = lyricsAdapter.getActiveIndex()
                val lm = binding.rvLyrics.layoutManager as? LinearLayoutManager
                lm?.let {
                    val offset = binding.rvLyrics.height / 2
                    it.scrollToPositionWithOffset(idx, offset)
                }
            }
        }
    }

    // ── Queue ────────────────────────────────────────────────────────────────
    private fun setupQueue() {
        queueAdapter = QueueAdapter(
            onItemClick = { _, index ->
                val songs = PlayerController.queue.value ?: return@QueueAdapter
                PlayerController.playSongs(songs, index)
            },
            onRemoveClick = { index ->
                PlayerController.removeFromQueue(index)
            },
            onOrderChanged = { reordered ->
                val currentIdx = PlayerController.currentIndex.value ?: 0
                PlayerController.reorderQueue(reordered, currentIdx)
            }
        )

        // Drag & drop
        val dragCallback = QueueDragCallback(queueAdapter)
        val touchHelper  = ItemTouchHelper(dragCallback)
        queueAdapter.itemTouchHelper = touchHelper

        binding.rvQueue.apply {
            layoutManager = LinearLayoutManager(this@PlayerActivity)
            adapter = queueAdapter
        }
        touchHelper.attachToRecyclerView(binding.rvQueue)

        // Controles del card "canción actual" en la cola
        binding.queueBtnPlayPause?.setOnClickListener { PlayerController.playPause() }
        binding.queueBtnPrev?.setOnClickListener      { PlayerController.previous() }
        binding.queueBtnNext?.setOnClickListener      { PlayerController.next() }
    }

    private fun showDeleteQueueDialog(names: List<String>) {
        val checked = BooleanArray(names.size) { false }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar colas")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Eliminar") { _, _ ->
                names.filterIndexed { i, _ -> checked[i] }
                    .forEach { PlayerController.deleteSavedQueue(it) }
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Eliminado",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun toggleQueue() {
        isQueueVisible = !isQueueVisible
        val activeColor = if (currentAccentColor != 0) currentAccentColor
                          else ContextCompat.getColor(this, R.color.accent_blue)
        if (isQueueVisible) {
            // Slide-up desde abajo
            binding.queueContainer.visibility = View.VISIBLE
            binding.queueContainer.animate()
                .translationY(0f)
                .setDuration(300)
                .setInterpolator(android.view.animation.DecelerateInterpolator(2f))
                .start()
            binding.btnQueue.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
        } else {
            hideQueueOverlay()
            binding.btnQueue.clearColorFilter()
            if (currentLightColor != 0)
                binding.btnQueue.setColorFilter(
                    ColorUtils.setAlphaComponent(currentLightColor, 0xAA), PorterDuff.Mode.SRC_IN)
        }
    }

    private fun updateQueueNowPlayingCard(song: com.aeroplayer.model.Song?) {
        if (song == null) return
        binding.queueCurrentTitle?.text  = song.title
        binding.queueCurrentArtist?.text = song.artist
        val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
        binding.queueCurrentArt?.let { iv ->
            Glide.with(iv)
                .load(cached ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .error(R.drawable.ic_music_placeholder)
                .centerCrop()
                .into(iv)
        }
        // Sincronizar icono play/pause
        val isPlaying = PlayerController.isPlaying.value == true
        binding.queueBtnPlayPause?.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun hideQueueOverlay() {
        binding.queueContainer.animate()
            .translationY(binding.queueContainer.height.toFloat() + 200f)
            .setDuration(250)
            .setInterpolator(android.view.animation.AccelerateInterpolator(2f))
            .withEndAction { binding.queueContainer.visibility = View.GONE }
            .start()
        isQueueVisible = false
    }

    // ── Lyrics ───────────────────────────────────────────────────────────────

    // ── Lyrics setup ─────────────────────────────────────────────────────────
    private fun setupLyrics() {
        lyricsAdapter = SyncedLyricsAdapter(
            onLineClick = { timeMs ->
                // Saltar a la posición de la línea de letra pulsada
                PlayerController.seekTo(timeMs)
            }
        )
        binding.rvLyrics.apply {
            layoutManager = LinearLayoutManager(this@PlayerActivity)
            adapter = lyricsAdapter
        }

        // Editor LRC: abre la activity de edición para la canción actual
        binding.btnEditLrc?.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            startActivity(
                android.content.Intent(this, LrcEditorActivity::class.java).apply {
                    putExtra(LrcEditorActivity.EXTRA_SONG_PATH,  song.path)
                    putExtra(LrcEditorActivity.EXTRA_SONG_TITLE, song.title)
                }
            )
        }

        // Guardar letra actual como .lrc junto al audio
        binding.btnEmbedLyrics?.setOnClickListener {
            val song = PlayerController.currentSong.value ?: return@setOnClickListener
            val lyricsText = binding.tvLyrics.text?.toString()?.takeIf { it.isNotBlank() }
                ?: lyricsAdapter.currentList
                    .joinToString("\n") { "[${formatLrcTime(it.timeMs)}]${it.text}" }
                    .takeIf { it.isNotBlank() }
                ?: run {
                    android.widget.Toast.makeText(this, "No hay letra cargada", android.widget.Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            try {
                val lrcFile = java.io.File(song.path.substringBeforeLast(".") + ".lrc")
                lrcFile.writeText(lyricsText, Charsets.UTF_8)
                android.widget.Toast.makeText(this, "Letra guardada como .lrc ✓", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "Error al guardar: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }

        // ── Contador posición en cola ─────────────────────────────────────────
        PlayerController.queuePosition.observe(this) { pos ->
            if (pos.isNotBlank()) binding.tvArtistTop?.text = "♪ $pos"
        }

        // ── Karaoke fullscreen mode ───────────────────────────────────────────
        // Usa un Dialog a pantalla completa para que funcione correctamente
        // sin conflictos con el CoordinatorLayout/NestedScrollView del player
        binding.btnExpandLyrics?.setOnClickListener { showKaraokeDialog() }

        var lastKaraokeTab = 0L
        binding.lyricsContainer?.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastKaraokeTab < 350) showKaraokeDialog()
            lastKaraokeTab = now
        }

        // ── Traducción de letras ──────────────────────────────────────────────
        binding.btnTranslateLyrics?.setOnClickListener {
            val text = if (binding.rvLyrics.visibility == android.view.View.VISIBLE)
                lyricsAdapter.currentList.joinToString("\n") { it.text }
            else binding.tvLyrics.text?.toString() ?: ""
            if (text.isBlank()) {
                com.google.android.material.snackbar.Snackbar.make(binding.root,
                    "No hay letra para traducir",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showTranslationDialog(text)
        }
    }

    private fun formatLrcTime(ms: Long): String {
        val mm = ms / 60_000
        val ss = (ms % 60_000) / 1_000
        val cs = (ms % 1_000) / 10
        return "%02d:%02d.%02d".format(mm, ss, cs)
    }

    private fun toggleLyrics() {
        // El panel de letras siempre está visible — solo cargamos la letra si aún no se ha cargado
        val currentSong = PlayerController.currentSong.value ?: return
        if (binding.tvLyrics.text.isNullOrBlank() &&
            binding.rvLyrics.visibility != View.VISIBLE) {
            showLyricsLoading()
            viewModel.fetchLyrics(currentSong.artist, currentSong.title, currentSong.path)
        }
    }

    private fun hideLyricsOverlay() {
        // Panel siempre visible — limpiar contenido al cambiar de canción
        binding.tvLyrics.text = ""
        binding.tvLyrics.visibility = View.GONE
        binding.rvLyrics.visibility = View.GONE
        binding.lyricsContainer?.visibility = View.GONE  // ocultar si no hay letra
    }

    /**
     * Actualiza la barra superior con el nombre de contexto y la posición
     * dentro de la cola, igual a las capturas: "Default" / "#51 · 1/7243".
     */
    private fun updateHeaderPosition() {
        val queue = PlayerController.queue.value ?: return
        val index = PlayerController.currentIndex.value ?: return
        if (queue.isEmpty()) return

        val contextName = PlayerController.queueName.value
            ?: getString(R.string.now_playing)
        binding.tvPlaylistContext?.text = contextName

        val humanPos = index + 1
        val total    = queue.size
        binding.tvArtistTop?.text = "#$humanPos · $humanPos/$total"
    }

    private fun showLyricsLoading() {
        binding.rvLyrics.visibility = View.GONE
        binding.tvLyrics.visibility = View.VISIBLE
        binding.tvLyrics.text = getString(R.string.loading_lyrics)
    }

    // ── Observers ────────────────────────────────────────────────────────────
    private fun observePlayer() {
        PlayerController.currentSong.observe(this) { song ->
            song ?: return@observe
            binding.tvSongTitle.text = song.title
            binding.tvSongTitle.isSelected = true
            binding.tvArtist.text = song.artist
            binding.tvAlbum.text = song.album

            // Artista clickable → ir al apartado del artista en la librería
            binding.tvArtist.setOnClickListener {
                val intent = android.content.Intent(this,
                    com.aeroplayer.ui.library.ArtistDetailActivity::class.java).apply {
                    putExtra("artist_name", song.artist)
                }
                startActivity(intent)
            }

            // Badge de calidad: "FLAC · 1411 kbps" visible si hay info de formato
            binding.tvQualityBadge?.let { badge ->
                val q = song.qualityBadge
                if (q.isNotBlank() && q != "Audio") {
                    badge.text = q
                    badge.visibility = android.view.View.VISIBLE
                    // Color especial para Hi-Res / Lossless
                    badge.setTextColor(
                        if (song.isHiRes || song.isLossless)
                            ContextCompat.getColor(this, R.color.accent_blue)
                        else
                            ContextCompat.getColor(this, R.color.text_secondary)
                    )
                } else {
                    badge.visibility = android.view.View.GONE
                }
            }

            // BUG FIX letra anterior: limpiar inmediatamente antes de cargar la nueva.
            // Sin esto, la letra anterior permanecía visible hasta que cargaba la nueva,
            // causando que se veía la letra de la canción anterior en la actual.
            lyricsAdapter.submitList(emptyList())
            binding.tvLyrics.text = ""
            hideLyricsOverlay()
            showLyricsLoading()
            viewModel.fetchLyrics(song.artist, song.title, song.path)

            // FIX portada: usar notifyDataSetChanged en lugar de notifyItemChanged.
            // Con notifyItemChanged + stableIds, RecyclerView comparaba IDs y podía
            // saltarse el rebind si consideraba que el item "no cambió".
            // notifyDataSetChanged garantiza rebind completo. Con offscreenPageLimit=1
            // solo redibuja 3 vistas — el costo de performance es idéntico.
            // El post() asegura que PlayerController.currentIndex ya se actualizó
            // antes de que onBindViewHolder lea el queue.
            binding.vpAlbumArt?.post {
                albumArtAdapter.notifyDataSetChanged()
            }

            // Observar el canvas de la nueva canción — limpia el anterior automáticamente
            observeCanvas(song.id)

            // FIX: cargar carátula en hilo IO para no bloquear el Main Thread (causa ANR/reboot).
            // Cancelar cualquier carga previa si el usuario cambió de canción antes de que terminara.
            artLoadJob?.cancel()
            artLoadJob = lifecycleScope.launch {
                // loadArt es suspend y corre en Dispatchers.IO internamente
                val artBitmap = com.aeroplayer.utils.AlbumArtUtils.loadArt(song.id, song.path, song.artist, song.album)
                if (artBitmap != null) {
                    applyPaletteBackground(artBitmap)
                } else {
                    // FIX portada: resetear a 1:1 cuando no hay art para esta canción
                    binding.albumArtFrame?.let { frame ->
                        val params = frame.layoutParams as? androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
                        if (params != null) { params.dimensionRatio = "1:1"; frame.layoutParams = params }
                    }
                    val artUri = song.albumArtUri
                    if (artUri != null) {
                        Glide.with(this@PlayerActivity)
                            .asBitmap()
                            .load(artUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(object : CustomTarget<Bitmap>() {
                                override fun onResourceReady(resource: Bitmap, t: Transition<in Bitmap>?) {
                                    applyPaletteBackground(resource)
                                }
                                override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
                            })
                    } else {
                        // FIX: sin carátula y sin URI → applyPaletteBackground nunca se llama,
                        // currentLightColor queda en 0 y los botones no reciben tint dinámico.
                        // Forzar tint blanco explícito para garantizar visibilidad.
                        applyInitialButtonTints()
                    }
                }
            }

            // Check liked state
            viewModel.likedSongs.value?.let { liked ->
                val isLiked = liked.any { it.songId == song.id }
                updateLikeButton(isLiked)
            }

            // (lyrics reload ya se hace arriba, no duplicar aquí)
        }

        PlayerController.isPlaying.observe(this) { playing ->
            binding.btnPlayPause.animatePlayPause(playing)
            binding.btnPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
            // FIX BUG1: cuando playing pasa a true, el player acaba de entrar en
            // STATE_READY y la duración ya está disponible. Forzar actualización
            // inmediata de la barra de progreso para salir del estado "00:00 --- 00:00".
            if (playing) {
                handler.removeCallbacks(updateRunnable)
                handler.post(updateRunnable)
            }
        }

        PlayerController.shuffleMode.observe(this) { shuffle ->
            val activeAlpha  = 1f
            val inactiveAlpha = 0.4f
            binding.btnShuffle.animateShuffle(shuffle)
            binding.btnShuffle.alpha  = if (shuffle) activeAlpha else inactiveAlpha
            binding.btnShuffle2?.alpha = if (shuffle) activeAlpha else inactiveAlpha
            if (currentLightColor != 0) {
                val c = currentLightColor
                binding.btnShuffle.setColorFilter(c, PorterDuff.Mode.SRC_IN)
                binding.btnShuffle2?.setColorFilter(c, PorterDuff.Mode.SRC_IN)
            }
        }

        PlayerController.repeatMode.observe(this) { mode ->
            val tint = if (currentLightColor != 0) currentLightColor
                       else 0xBFFFFFFF.toInt() // semi-transparent white para repeat en fondo oscuro
            val accentTint = currentAccentColor.takeIf { it != 0 }
                ?: ContextCompat.getColor(this, R.color.accent_blue)
            val intensity = when (mode) {
                Player.REPEAT_MODE_ALL -> 1
                Player.REPEAT_MODE_ONE -> 2
                else -> 0
            }

            // FIX: aplicar el nuevo drawable y color DESPUÉS de que termine la animación
            // de escala. Cambiar setImageResource() a mitad de la animación causaba
            // IllegalStateException / NPE en ViewPropertyAnimator en taps rápidos.
            fun applyRepeatVisuals() {
                when (mode) {
                    Player.REPEAT_MODE_OFF -> {
                        binding.btnRepeat.setImageResource(R.drawable.ic_repeat)
                        binding.btnRepeat.alpha = 0.4f
                        binding.btnRepeat.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                    }
                    Player.REPEAT_MODE_ALL -> {
                        binding.btnRepeat.setImageResource(R.drawable.ic_repeat)
                        binding.btnRepeat.alpha = 1f
                        binding.btnRepeat.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                    }
                    Player.REPEAT_MODE_ONE -> {
                        binding.btnRepeat.setImageResource(R.drawable.ic_repeat_one)
                        binding.btnRepeat.alpha = 1f
                        binding.btnRepeat.setColorFilter(accentTint, PorterDuff.Mode.SRC_IN)
                    }
                }
            }

            // Lanzar animación; los visuales se aplican al terminar
            binding.btnRepeat.animate().cancel()
            binding.btnRepeat.scaleX = 1f
            binding.btnRepeat.scaleY = 1f
            val targetScale = when (intensity) { 2 -> 1.35f; 1 -> 1.2f; else -> 0.9f }
            binding.btnRepeat.animate()
                .scaleX(targetScale).scaleY(targetScale)
                .setDuration(180L)
                .setInterpolator(OvershootInterpolator(3f))
                .withEndAction {
                    applyRepeatVisuals()
                    if (binding.btnRepeat.isAttachedToWindow) {
                        binding.btnRepeat.animate()
                            .scaleX(1f).scaleY(1f)
                            .setDuration(120L)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    }
                }
                .start()
        }

        PlayerController.queue.observe(this) { songs ->
            queueAdapter.submitList(songs)
            binding.tvQueueCount.text = "${songs.size} canciones en cola"
            updateHeaderPosition()
            // Actualizar card de canción actual
            val idx  = PlayerController.currentIndex.value ?: 0
            val song = songs.getOrNull(idx)
            updateQueueNowPlayingCard(song)
        }

        PlayerController.currentIndex.observe(this) { index ->
            queueAdapter.setCurrentIndex(index)
            updateHeaderPosition()
            // Actualizar card de canción actual
            val song = PlayerController.queue.value?.getOrNull(index)
            updateQueueNowPlayingCard(song)
        }

        PlayerController.queueName.observe(this) { updateHeaderPosition() }

        viewModel.likedSongs.observe(this) { liked ->
            val current = PlayerController.currentSong.value ?: return@observe
            updateLikeButton(liked.any { it.songId == current.id })
        }

        viewModel.syncedLyrics.observe(this) { raw ->
            if (raw != null) {
                val lines = parseLrc(raw)
                if (lines.isNotEmpty()) {
                    lyricsAdapter.submitList(lines)
                    binding.lyricsContainer?.visibility = View.VISIBLE
                    // Cache offline: guardar LRC en disco para no repetir llamada a API
                    val currentSongForCache = PlayerController.currentSong.value
                    if (currentSongForCache != null) cacheLyricsLocally(currentSongForCache, raw)
                    binding.rvLyrics.visibility = View.VISIBLE
                    binding.tvLyrics.visibility = View.GONE
                    return@observe
                }
            }
            // Sin letras sincronizadas — esperar al observer de plainLyrics
        }

        viewModel.lyrics.observe(this) { lyrics ->
            if (binding.rvLyrics.visibility == View.VISIBLE) return@observe
            binding.tvLyrics.visibility = View.VISIBLE
            binding.rvLyrics.visibility = View.GONE
            val lyricsText = lyrics ?: ""
            binding.tvLyrics.text = lyricsText
            binding.lyricsContainer?.visibility = if (lyricsText.isNotBlank()) View.VISIBLE else View.GONE
        }

        viewModel.lyricsError.observe(this) { error ->
            if (error.isNullOrBlank()) return@observe
            // Show the "not found" placeholder in the text view
            binding.tvLyrics.visibility = View.VISIBLE
            binding.rvLyrics.visibility = View.GONE
            binding.tvLyrics.text = getString(R.string.lyrics_not_found)
            // Also show a Snackbar so the user knows it was a network error
            com.google.android.material.snackbar.Snackbar.make(
                binding.root,
                getString(R.string.lyrics_load_error),
                com.google.android.material.snackbar.Snackbar.LENGTH_LONG
            ).setAction(getString(R.string.retry)) {
                val song = PlayerController.currentSong.value ?: return@setAction
                showLyricsLoading()
                viewModel.fetchLyrics(song.artist, song.title, song.path)
            }.show()
        }
    }

    private fun updateLikeButton(isLiked: Boolean, animate: Boolean = false) {
        binding.btnLike.setImageResource(
            if (isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
        binding.btnLike.setColorFilter(
            ContextCompat.getColor(
                this,
                // El player siempre tiene fondo oscuro → usar blanco translúcido igual que
                // el resto de botones secundarios (btnMoreSong, btnSaveToPlaylist, etc.)
                if (isLiked) R.color.accent_pink else R.color.icon_on_dark
            )
        )
        if (animate) {
            binding.btnLike.animateLike(isLiked)
        }
    }

    // ── Animadores reutilizables — un solo objeto por tipo, se cancela antes de reusar ──
    // FIX Android 11: crear GradientDrawable nuevo en cada frame del ValueAnimator satura
    // el compositor de la System UI y la crashea. La solución es:
    //   1. Reutilizar el mismo GradientDrawable mutándolo con setColors() en lugar de recrearlo.
    //   2. Tener un único ValueAnimator por tipo y cancelarlo antes de relanzarlo.
    //   3. Usar un solo animador combinado para fondo + glow en lugar de 5 animadores paralelos.

    private var bgDrawable: GradientDrawable? = null
    private var panelDrawable: GradientDrawable? = null
    private var bgAnimator: ValueAnimator? = null
    private var tintAnimator: ValueAnimator? = null
    private var seekAnimator: ValueAnimator? = null
    private var glowAnimator: ValueAnimator? = null
    private var panelAnimator: ValueAnimator? = null

    private fun cancelAllColorAnimators() {
        bgAnimator?.cancel()
        tintAnimator?.cancel()
        seekAnimator?.cancel()
        glowAnimator?.cancel()
        panelAnimator?.cancel()
    }

    private fun applyPaletteBackground(bitmap: Bitmap) {
        // ── Adaptive album art shape ──────────────────────────────────────────
        // FIX portada negra/no adaptativa: la portada estaba forzada a 1:1 en XML.
        // Ahora detectamos si el bitmap es significativamente más alto que ancho
        // (ratio > 1.15, ej. portadas de single 3:4) y ajustamos el ConstraintLayout
        // ratio para que la portada se muestre sin recorte ni relleno negro.
        // Máximo ratio permitido: 4:3 (portrait) para no romper el layout.
        binding.albumArtFrame?.let { frame ->
            val w = bitmap.width.toFloat()
            val h = bitmap.height.toFloat()
            if (w > 0 && h > 0) {
                val ratio = h / w
                val clampedRatio = ratio.coerceIn(0.75f, 1.33f) // entre 4:3 landscape y 4:3 portrait
                val params = frame.layoutParams as? androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
                if (params != null) {
                    // ConstraintLayout usa formato "W:H" para dimensionRatio
                    params.dimensionRatio = "1:${"%.2f".format(clampedRatio)}"
                    frame.layoutParams = params
                }
            }
        }

        // ── Fondo blur: aplicar en hilo de fondo para no bloquear la UI ──────
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val blurred = com.aeroplayer.utils.BlurUtils.blur(this@PlayerActivity, bitmap, 20f)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                binding.ivBlurBackground?.let { iv ->
                    iv.animate().alpha(0f).setDuration(200).withEndAction {
                        iv.setImageBitmap(blurred)
                        iv.animate().alpha(1f).setDuration(400).start()
                    }.start()
                }
            }
        }

        Palette.from(bitmap).generate { palette ->
            if (palette == null) return@generate

            val fallbackDark = ContextCompat.getColor(this, R.color.surface_dark)
            val fallbackBg   = ContextCompat.getColor(this, R.color.background_dark)
            // FIX: los iconos siempre están sobre fondo oscuro → fallback debe ser blanco,
            // NO text_primary (#1A1D26 oscuro) que los haría invisibles cuando la paleta falla.
            val fallbackText = Color.WHITE

            val dominantDark = palette.getDarkVibrantColor(
                palette.getDarkMutedColor(fallbackDark)
            )
            val vibrant = palette.getVibrantColor(
                palette.getMutedColor(palette.getDominantColor(fallbackDark))
            )
            val lightForIcons = palette.getLightVibrantColor(
                palette.getLightMutedColor(Color.WHITE)
            )
            val panelColor = ColorUtils.setAlphaComponent(
                ColorUtils.blendARGB(dominantDark, vibrant, 0.3f), 0xDD
            )
            val iconTint  = ensureContrast(lightForIcons, panelColor)
            val seekTint  = ensureContrast(vibrant, dominantDark)
            val glowColor = ColorUtils.setAlphaComponent(
                ColorUtils.blendARGB(dominantDark, vibrant, 0.6f), 0xCC
            )

            // Guardar para reutilizar en otros lugares
            currentAccentColor   = vibrant
            currentLightColor    = lightForIcons
            // Propagar el color de acento a otros observers (MainActivity → indicador de nav)
            PlayerController.broadcastPaletteAccent(vibrant)

            // Cancelar animaciones previas antes de lanzar las nuevas
            cancelAllColorAnimators()

            // ── El fondo real ahora es el blur; quitar el background del root ──
            currentDominantColor = dominantDark
            binding.root.background = null

            // ── Panel lateral: mismo patrón, mutar en lugar de recrear ─────
            val fromPanel = Color.parseColor("#CC161A22")
            if (panelDrawable == null) {
                panelDrawable = GradientDrawable().apply {
                    shape        = GradientDrawable.RECTANGLE
                    cornerRadius = 28f * resources.displayMetrics.density
                    setColor(fromPanel)
                    setStroke(
                        (1f * resources.displayMetrics.density).toInt(),
                        ColorUtils.setAlphaComponent(Color.WHITE, 0x22)
                    )
                }
                binding.sideOptionsPanel?.background = panelDrawable
            }
            panelAnimator = ValueAnimator.ofObject(ArgbEvaluator(), fromPanel, panelColor).apply {
                duration = 500
                addUpdateListener { anim -> panelDrawable?.setColor(anim.animatedValue as Int) }
                start()
            }

            // ── Tint de botones: un solo animador para todos ───────────────
            val fromTint = if (currentLightColor != 0) currentLightColor else Color.WHITE
            val currentSong = PlayerController.currentSong.value
            val isCurrentlyLiked = currentSong != null &&
                viewModel.likedSongs.value?.any { it.songId == currentSong.id } == true
            // Botones secundarios: tono claro
            val buttonsToTint = listOfNotNull(
                binding.btnShuffle, binding.btnShuffle2,
                binding.btnRepeat,
                binding.btnQueue, binding.btnBack,
                binding.btnMore, binding.btnMoreSong, binding.btnSaveToPlaylist,
                binding.btnEqualizerPanel,
                if (!isCurrentlyLiked) binding.btnLike else null
            )
            // ⏮ ⏸ ⏭ reciben el color MÁS VIVO de la paleta para destacar
            val strongAccent = ensureContrast(
                palette.getVibrantColor(palette.getLightVibrantColor(Color.WHITE)),
                panelColor
            )
            val fromAccent = if (currentAccentColor != 0) currentAccentColor else Color.WHITE
            ValueAnimator.ofObject(ArgbEvaluator(), fromAccent, strongAccent).apply {
                duration = 500
                addUpdateListener { anim ->
                    val c = anim.animatedValue as Int
                    listOf(binding.btnPrevious, binding.btnPlayPause, binding.btnNext).forEach { btn ->
                        try { btn?.setColorFilter(c, PorterDuff.Mode.SRC_IN) } catch (_: Exception) {}
                    }
                }
                start()
            }
            val sleepOff = SleepTimerManager.isRunning.value != true
            val abOff    = PlayerController.abRepeatState.value == PlayerController.ABRepeatState.OFF
            tintAnimator = ValueAnimator.ofObject(ArgbEvaluator(), fromTint, iconTint).apply {
                duration = 500
                addUpdateListener { anim ->
                    val c = anim.animatedValue as Int
                    buttonsToTint.forEach { btn ->
                        try { btn.setColorFilter(c, PorterDuff.Mode.SRC_IN) } catch (_: Exception) {}
                    }
                    if (sleepOff) try {
                        binding.btnSleepTimer.setColorFilter(
                            ColorUtils.setAlphaComponent(c, 0xAA), PorterDuff.Mode.SRC_IN)
                    } catch (_: Exception) {}
                    if (abOff) try {
                        binding.btnAbRepeat.setColorFilter(
                            ColorUtils.setAlphaComponent(c, 0xAA), PorterDuff.Mode.SRC_IN)
                    } catch (_: Exception) {}
                }
                start()
            }

            // ── Seekbar tint ───────────────────────────────────────────────
            val fromSeek = if (currentAccentColor != 0) currentAccentColor else fallbackText
            seekAnimator = ValueAnimator.ofObject(ArgbEvaluator(), fromSeek, seekTint).apply {
                duration = 500
                addUpdateListener { anim ->
                    val c = anim.animatedValue as Int
                    try {
                        binding.seekBar.progressTintList = android.content.res.ColorStateList.valueOf(c)
                        binding.seekBar.thumbTintList    = android.content.res.ColorStateList.valueOf(c)
                    } catch (_: Exception) {}
                }
                start()
            }

            // ── Glow del album art ─────────────────────────────────────────
            val fromGlow = binding.viewAlbumGlow?.backgroundTintList?.defaultColor ?: glowColor
            glowAnimator = ValueAnimator.ofObject(ArgbEvaluator(), fromGlow, glowColor).apply {
                duration = 700
                addUpdateListener { anim ->
                    binding.viewAlbumGlow?.backgroundTintList =
                        android.content.res.ColorStateList.valueOf(anim.animatedValue as Int)
                }
                start()
            }
        }
    }

    /** Hace un color suficientemente visible sobre el fondo dado.
     *  FIX: calculateContrast() lanza IllegalArgumentException si recibe colores
     *  con transparencia. Forzamos alpha=255 en ambos antes de calcular. */
    private fun ensureContrast(color: Int, background: Int): Int {
        val opaqueColor = ColorUtils.setAlphaComponent(color, 255)
        val opaqueBg    = ColorUtils.setAlphaComponent(background, 255)
        val ratio = ColorUtils.calculateContrast(opaqueColor, opaqueBg)
        return if (ratio >= 2.5f) color
        else ColorUtils.blendARGB(color, Color.WHITE, 0.6f)
    }

    // ── LRC parser ───────────────────────────────────────────────────────────
    // ── Modo Karaoke (pantalla completa real) ────────────────────────────────
    /**
     * Abre un diálogo a pantalla completa con las letras sincronizadas.
     * Los controles de reproducción están abajo para acceso fácil.
     * Fondo con color extraído de la portada.
     * Toca cualquier línea para saltar a esa posición (igual que en el player normal).
     */
    private fun showKaraokeDialog() {
        val lines = lyricsAdapter.currentList.ifEmpty { return }
        val bgColor = currentLightColor.takeIf { it != 0 }
            ?.let { androidx.core.graphics.ColorUtils.blendARGB(it, android.graphics.Color.BLACK, 0.72f) }
            ?: 0xFF050510.toInt()

        // Crear un adapter separado para el diálogo con click-to-seek
        val karaokeAdapter = SyncedLyricsAdapter(onLineClick = { ms -> PlayerController.seekTo(ms) })
        karaokeAdapter.submitList(lines)

        // Layout del diálogo
        val ctx = this
        val rootLayout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // RecyclerView con las letras
        val rv = androidx.recyclerview.widget.RecyclerView(ctx).apply {
            layoutManager = androidx.recyclerview.widget.LinearLayoutManager(ctx)
            adapter = karaokeAdapter
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            setPadding(0, 80, 0, 16)
            clipToPadding = false
        }
        rootLayout.addView(rv)

        // Controles de reproducción abajo
        val controls = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(0x33000000)
            setPadding(24, 16, 24, 32)
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val btnPrev = android.widget.ImageButton(ctx).apply {
            setImageResource(R.drawable.ic_skip_previous)
            setColorFilter(0xFFFFFFFF.toInt(), android.graphics.PorterDuff.Mode.SRC_IN)
            background = null; setPadding(24, 16, 24, 16)
            setOnClickListener { PlayerController.previous() }
        }
        val btnPlay = android.widget.ImageButton(ctx).apply {
            setImageResource(if (PlayerController.isPlaying.value == true) R.drawable.ic_pause else R.drawable.ic_play)
            setColorFilter(0xFFFFFFFF.toInt(), android.graphics.PorterDuff.Mode.SRC_IN)
            background = null; setPadding(32, 16, 32, 16)
            setOnClickListener {
                if (PlayerController.isPlaying.value == true) PlayerController.pause()
                else PlayerController.play()
                setImageResource(if (PlayerController.isPlaying.value == true) R.drawable.ic_pause else R.drawable.ic_play)
            }
        }
        val btnNext = android.widget.ImageButton(ctx).apply {
            setImageResource(R.drawable.ic_skip_next)
            setColorFilter(0xFFFFFFFF.toInt(), android.graphics.PorterDuff.Mode.SRC_IN)
            background = null; setPadding(24, 16, 24, 16)
            setOnClickListener { PlayerController.next() }
        }
        controls.addView(btnPrev); controls.addView(btnPlay); controls.addView(btnNext)
        rootLayout.addView(controls)

        // Dialog a pantalla completa
        val dialog = android.app.Dialog(ctx, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.setContentView(rootLayout)
        dialog.window?.apply {
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                      android.view.ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }

        // Auto-scroll sincronizado con la reproducción
        val scrollHandler = android.os.Handler(android.os.Looper.getMainLooper())
        val scrollRunnable = object : Runnable {
            override fun run() {
                if (!dialog.isShowing) return
                val pos = PlayerController.getCurrentPosition()
                val idx = lines.indexOfLast { it.timeMs <= pos }
                if (idx >= 0) {
                    (rv.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
                        ?.scrollToPositionWithOffset(idx, rv.height / 3)
                    karaokeAdapter.updateActiveIndex(pos)
                }
                scrollHandler.postDelayed(this, 250)
            }
        }
        dialog.setOnShowListener { scrollHandler.post(scrollRunnable) }
        dialog.setOnDismissListener { scrollHandler.removeCallbacks(scrollRunnable) }
        dialog.show()
    }

    // ── Traducción de letras ─────────────────────────────────────────────────
    /**
     * Traduce la letra usando la API de MyMemory (gratuita, sin clave, 1000 req/día).
     * Fragmenta el texto en chunks de 500 caracteres para no exceder el límite.
     * El idioma destino por defecto es español (es); el usuario puede cambiarlo.
     */
    private fun showTranslationDialog(text: String) {
        val langs = arrayOf("es - Español", "en - English", "fr - Français",
            "de - Deutsch", "pt - Português", "it - Italiano", "ja - 日本語",
            "ko - 한국어", "zh - 中文", "ru - Русский")
        val codes = arrayOf("es","en","fr","de","pt","it","ja","ko","zh","ru")

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("🌐 Traducir letra")
            .setItems(langs) { _, idx ->
                val targetLang = codes[idx]
                // FIX: pasar el modo "aplicar inline" para mostrar traducción en el player
                translateLyricsAsync(text, targetLang, applyInline = true)
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun translateLyricsAsync(text: String, targetLang: String, applyInline: Boolean = false) {
        // Mostrar spinner mientras traduce
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Traduciendo…", com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE)
        snack.show()

        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                // MyMemory API: gratuita, 1000 req/día, no requiere API key
                // Fragmentar en chunks de 480 chars para no superar el límite
                val chunks = mutableListOf<String>()
                var start = 0
                while (start < text.length) {
                    // Cortar en límite de línea si es posible
                    var end = (start + 480).coerceAtMost(text.length)
                    if (end < text.length) {
                        val nlIdx = text.lastIndexOf('\n', end)
                        if (nlIdx > start) end = nlIdx
                    }
                    chunks.add(text.substring(start, end))
                    start = end
                }

                val translated = StringBuilder()
                val client = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                for (chunk in chunks) {
                    // MyMemory no acepta "auto" como idioma origen
                    // Usar "en" como origen por defecto (la mayoría de letras son en inglés)
                    // Si el texto parece español, usar "es"
                    val srcLang = if (chunk.take(100).any { it in "áéíóúüñ¿¡" }) "es" else "en"
                    val url = "https://api.mymemory.translated.net/get?q=${java.net.URLEncoder.encode(chunk, "UTF-8")}&langpair=$srcLang|$targetLang"
                    val req = okhttp3.Request.Builder().url(url)
                        .header("User-Agent", "AeroPlayer/2.5 lyrics-translator").build()
                    val resp = client.newCall(req).execute()
                    val body = resp.body?.string() ?: continue
                    val json = org.json.JSONObject(body)
                    val responseStatus = json.optInt("responseStatus", 200)
                    val translatedText = if (responseStatus == 200) {
                        json.getJSONObject("responseData").getString("translatedText")
                    } else {
                        // Fallback: mismo chunk sin traducir
                        chunk
                    }
                    if (translated.isNotEmpty()) translated.append("\n")
                    translated.append(translatedText)
                    kotlinx.coroutines.delay(200) // respetar rate limit
                }

                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    if (applyInline) {
                        // FIX traducción: mostrar directamente en el panel de letras del player
                        // en lugar de un diálogo separado. Mucho mejor UX.
                        val translatedStr = translated.toString()
                        // Ocultar letras sincronizadas y mostrar texto plano traducido
                        binding.rvLyrics.visibility = View.GONE
                        binding.tvLyrics.visibility = View.VISIBLE
                        binding.tvLyrics.text = translatedStr
                        binding.lyricsContainer?.visibility = View.VISIBLE

                        // Botón de copiar en Snackbar
                        com.google.android.material.snackbar.Snackbar.make(
                            binding.root, "✓ Traducción aplicada",
                            com.google.android.material.snackbar.Snackbar.LENGTH_LONG
                        ).setAction("Copiar") {
                            val clip = getSystemService(android.content.ClipboardManager::class.java)
                            clip?.setPrimaryClip(android.content.ClipData.newPlainText("letra", translatedStr))
                        }.show()
                    } else {
                        // Fallback: mostrar en diálogo scrollable (usado programáticamente)
                        val tv = android.widget.TextView(this@PlayerActivity).apply {
                            this.text = translated.toString()
                            textSize = 14f
                            setTextColor(0xEEFFFFFF.toInt())
                            setPadding(48, 24, 48, 24)
                            setLineSpacing(0f, 1.6f)
                        }
                        val scroll = android.widget.ScrollView(this@PlayerActivity).apply { addView(tv) }
                        com.google.android.material.dialog.MaterialAlertDialogBuilder(this@PlayerActivity)
                            .setTitle("🌐 Traducción")
                            .setView(scroll)
                            .setPositiveButton("Aplicar") { _, _ ->
                                binding.rvLyrics.visibility = View.GONE
                                binding.tvLyrics.visibility = View.VISIBLE
                                binding.tvLyrics.text = translated.toString()
                                binding.lyricsContainer?.visibility = View.VISIBLE
                            }
                            .setNeutralButton("Copiar") { _, _ ->
                                val clip = getSystemService(android.content.ClipboardManager::class.java)
                                clip?.setPrimaryClip(android.content.ClipData.newPlainText("letra", translated))
                                com.google.android.material.snackbar.Snackbar.make(
                                    binding.root, "Traducción copiada ✓",
                                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                            }
                            .setNegativeButton("Cerrar", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                withContext(kotlinx.coroutines.Dispatchers.Main) {
                    snack.dismiss()
                    com.google.android.material.snackbar.Snackbar.make(
                        binding.root, "Error al traducir: ${e.localizedMessage}",
                        com.google.android.material.snackbar.Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Lyrics offline cache ─────────────────────────────────────────────────
    private fun lyricsDir(): java.io.File =
        java.io.File(filesDir, "lyrics_cache").also { it.mkdirs() }

    private fun lyricsKey(song: com.aeroplayer.model.Song): String {
        val safe = "${song.artist}_${song.title}".replace(Regex("[^a-zA-Z0-9_-]"), "_")
        return "$safe.lrc"
    }

    private fun cacheLyricsLocally(song: com.aeroplayer.model.Song, lrc: String) {
        if (lrc.isBlank()) return
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                java.io.File(lyricsDir(), lyricsKey(song)).writeText(lrc, Charsets.UTF_8)
            } catch (_: Exception) {}
        }
    }

    private fun loadCachedLyrics(song: com.aeroplayer.model.Song): String? {
        return try {
            val f = java.io.File(lyricsDir(), lyricsKey(song))
            if (f.exists() && f.length() > 0) f.readText(Charsets.UTF_8) else null
        } catch (_: Exception) { null }
    }

    private fun parseLrc(raw: String): List<SyncedLyricsAdapter.LyricLine> {
        return runCatching {
            val regex = Regex("""^\[(\d+):(\d+)[.:]?(\d*)\]\s*(.*)$""")
            raw.lines().mapNotNull { line ->
                regex.matchEntire(line.trim())?.let { m ->
                    val min  = m.groupValues[1].toLongOrNull() ?: return@let null
                    val sec  = m.groupValues[2].toLongOrNull() ?: return@let null
                    val ms   = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
                    val text = m.groupValues[4].trim()
                    if (text.isBlank()) null
                    else SyncedLyricsAdapter.LyricLine((min * 60_000) + (sec * 1_000) + ms, text)
                }
            }
        }.getOrElse { emptyList() }
    }

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /**
     * Observa el LiveData del canvas para [songId].
     * Cada vez que cambia la canción se llama de nuevo; el observer anterior
     * se elimina automáticamente porque está ligado al ciclo de vida de la Activity.
     *
     * Cuando el canvas cambia:
     *  • Se actualiza [activeCanvasUri] (leído por el adapter vía canvasProvider)
     *  • Se refresca la página central del pager para mostrar/ocultar el GIF
     */
    private fun observeCanvas(songId: Long) {
        viewModel.getCanvasLive(songId).observe(this) { entity ->
            val gifUri   = entity?.gifUri?.let { Uri.parse(it) }
            val videoUri = entity?.videoUri?.let { Uri.parse(it) }
            activeCanvasUri = gifUri  // mantener para compatibilidad con código que lo usa
            // Actualizar el canvasProvider con ambas URIs
            albumArtAdapter.canvasProvider = { gifUri to videoUri }
            albumArtAdapter.notifyItemChanged(AlbumArtPagerAdapter.CENTER_PAGE)
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    @Deprecated("Needed for MediaStore delete on API 30")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_DELETE_SONG && resultCode == android.app.Activity.RESULT_OK) {
            PlayerController.next()
            viewModel.loadSongs(forceRefresh = true)
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "Canción eliminada",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(updateRunnable)
        handler.post(updateRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateRunnable)
    }

    override fun onDestroy() {
        // FIX: cancelar todos los animadores y jobs al destruir la Activity
        // para no dejar callbacks vivos que intenten modificar views ya destruidas
        cancelAllColorAnimators()
        artLoadJob?.cancel()
        albumArtAdapter.release()  // Sesión 8: liberar MediaPlayer del video canvas
        super.onDestroy()
    }

}
