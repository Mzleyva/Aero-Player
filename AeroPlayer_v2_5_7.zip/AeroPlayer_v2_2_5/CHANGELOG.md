## v2.3.2 — Mayo 2026

### ✅ Nuevas funciones

- **YTDLnis mejorado**: pega o edita el link directamente en el cuadro de texto antes de enviarlo; el campo se pre-rellena con una búsqueda de YouTube del artista + título. Disponible también desde el menú contextual de la biblioteca.
- **Crossfade en panel lateral**: botón de toggle rápido en el panel de 3 puntos (ya no hace falta entrar a Ajustes para activarlo/desactivarlo). Se ilumina en azul cuando está activo.
- **Multi-perfiles completos**: cada perfil tiene su propio fondo de pantalla. Toca el perfil activo para editar (cambiar fondo, renombrar, eliminar). El fondo se aplica al entrar al perfil y al retomar la pantalla de inicio.
- **Portada animada**: renombrado desde "Canvas GIF" → **"Portada animada"** en todos los menús. "Búsqueda de GIF" → **"Búsqueda de portada animada"**.

### 🐛 Correcciones

- Referencias a "Klipy" eliminadas de la interfaz de usuario (texto genérico)
- "Agregar Canvas GIF" / "Cambiar Canvas GIF" → "Agregar portada animada" / "Cambiar portada animada"

---

# AeroPlayer Changelog

## v2.3.1 — Mayo 2026

### ✅ Nuevas funciones

- **Selector de fuentes** en Ajustes: Inter, Outfit, Nunito, Poppins, Montserrat, Raleway, Space Grotesk
- **Orden de música personalizable**: nueva opción "Personalizado" en Ordenar → arrastrar canciones para reordenarlas, orden guardado entre sesiones
- **Multi-perfiles**: menú de perfil → "Cambiar perfil", crear nuevos perfiles con nombre propio
- **Integración YTDLnis**: menú 3 puntos → "⬇️ Descargar con YTDLnis" (se abre con búsqueda pre-rellenada; ofrece instalar si no está presente)
- **Chromecast mejorado**: sincronización de posición, detección MIME por extensión, intento de servidor HTTP local para archivos del dispositivo, soporte de inicio desde posición actual
- **Logo A-B Repeat rediseñado**: nuevo icono con flechas ↔ y letras A/B más claras e intuitivas

### 🐛 Bugs corregidos (v2.3.0)

 — Mayo 2026

### ✅ Nuevas funciones

- **Alfabeto lateral activable** en la pestaña de Música para buscar canciones más rápido
- **Badge de formato para TODOS los tipos** (Opus, AAC, OGG, WAV, APE, etc.) — antes solo FLAC y MP3 lo tenían
- **Letras sincronizadas: toca una línea y salta a esa parte** de la canción
- **Presets de música**: Nightcore, Slow + Reverb, Ultra Slowed, Daycore, Hardstyle, Pitch Up/Down
- **Audio 8D activable** desde el menú de velocidad/tono
- **Reproducir después** (play next): nueva opción en el menú de canción para insertar justo tras la actual
- **Perfil de ecualizador automático**: cambia solo al conectar auriculares, Bluetooth o DAC
- **Carátulas de álbumes más redondeadas** (radio 24 dp en grid, 12 dp en listas)
- **Nombre del artista clicable** en la pantalla de reproducción → va a la sección del artista
- **Botón "Aleatorio"** en Quick Pick para mezclar la selección rápida

### 🐛 Bugs corregidos

- **Timer no terminaba al acabar la canción** — ahora detecta la duración de la canción actual (no la cola completa)
- **Timer cortaba la canción de golpe** — ahora hace un fade-out gradual de 20 s igual que las canciones antiguas
- **Panel de 3 puntos se iba hacia abajo al hacer scroll** — fijado con `post{}` en lugar de `onGlobalLayoutListener`
- **Cola: arrastrar canciones pausaba la reproducción** — ahora usa `moveMediaItem()` en lugar de reconstruir la cola
- **Cola: no se podía poner una canción "para después"** — añadida función `addToQueueNext()`
- **Letra de la canción anterior se veía en la actual** — se limpia inmediatamente al cambiar de canción
- **A-B Repeat: mensajes estaban al revés** — corregido el orden de estados y mejorados los textos
- **Velocidad alta + estación de radio → crash** — se resetea a 1× al reproducir streams en vivo
- **Marcador: crash al guardar** — añadido try-catch con mensaje de error descriptivo
- **MultiQueue: crasheos al arrastrar y al hacer swipe** — reescritos con `bindingAdapterPosition` y tags seguros
- **MultiQueue: drag pausaba la reproducción** — movimiento aplazado con `post{}`
- **Shuffle en Quick Pick no funcionaba** — usa lista mezclada + activa modo shuffle en ExoPlayer

### 🎨 Mejoras de UI

- **Visualizador**: fondo extrae colores de la portada (no más fondo negro fijo)
- **Visualizador modo círculo**: muestra la portada del álbum en el centro
- **Botones ⏮️ ⏸️ ⏭️**: usan el color más vivo de la portada (vibrante), más llamativos que los secundarios
- **Menú 3 puntos**: "Buscar Canvas en Klipy" → **"Búsqueda de GIF"** (más claro y conciso)
- **Carátulas redondeadas**: radio aumentado en listas, grid y player

### ⚙️ Técnico

- `SleepTimerManager` reescrito: fade-out progresivo de 20 s antes de pausar
- `PlayerController.reorderQueue()` usa `moveMediaItem()` → no interrumpe ExoPlayer
- `PlayerController.addToQueueNext()` inserta después de la canción actual
- `PlayerController.getVolume()` / `setVolume()` añadidos para el timer
- `PlayerController.toggle8DAudio()` y efecto 8D
- `AudioVisualizerView`: nuevo tema `ALBUM` que extrae colores de Palette
- `EqualizerActivity`: `setupAutoProfileSwitch()` con `AudioDeviceCallback`
- `SyncedLyricsAdapter`: callback `onLineClick` para seek por línea
- `SongListAdapter`: badge de formato para TODOS los tipos de audio
- `MultiQueueActivity`: VH usa tags en lugar de `getChildAt()` (evita `ClassCastException`)


### ✅ Nuevas funciones

- **Alfabeto lateral activable** en la pestaña de Música para buscar canciones más rápido
- **Badge de formato para TODOS los tipos** (Opus, AAC, OGG, WAV, APE, etc.) — antes solo FLAC y MP3 lo tenían
- **Letras sincronizadas: toca una línea y salta a esa parte** de la canción
- **Presets de música**: Nightcore, Slow + Reverb, Ultra Slowed, Daycore, Hardstyle, Pitch Up/Down
- **Audio 8D activable** desde el menú de velocidad/tono
- **Reproducir después** (play next): nueva opción en el menú de canción para insertar justo tras la actual
- **Perfil de ecualizador automático**: cambia solo al conectar auriculares, Bluetooth o DAC
- **Carátulas de álbumes más redondeadas** (radio 24 dp en grid, 12 dp en listas)
- **Nombre del artista clicable** en la pantalla de reproducción → va a la sección del artista
- **Botón "Aleatorio"** en Quick Pick para mezclar la selección rápida

### 🐛 Bugs corregidos

- **Timer no terminaba al acabar la canción** — ahora detecta la duración de la canción actual (no la cola completa)
- **Timer cortaba la canción de golpe** — ahora hace un fade-out gradual de 20 s igual que las canciones antiguas
- **Panel de 3 puntos se iba hacia abajo al hacer scroll** — fijado con `post{}` en lugar de `onGlobalLayoutListener`
- **Cola: arrastrar canciones pausaba la reproducción** — ahora usa `moveMediaItem()` en lugar de reconstruir la cola
- **Cola: no se podía poner una canción "para después"** — añadida función `addToQueueNext()`
- **Letra de la canción anterior se veía en la actual** — se limpia inmediatamente al cambiar de canción
- **A-B Repeat: mensajes estaban al revés** — corregido el orden de estados y mejorados los textos
- **Velocidad alta + estación de radio → crash** — se resetea a 1× al reproducir streams en vivo
- **Marcador: crash al guardar** — añadido try-catch con mensaje de error descriptivo
- **MultiQueue: crasheos al arrastrar y al hacer swipe** — reescritos con `bindingAdapterPosition` y tags seguros
- **MultiQueue: drag pausaba la reproducción** — movimiento aplazado con `post{}`
- **Shuffle en Quick Pick no funcionaba** — usa lista mezclada + activa modo shuffle en ExoPlayer

### 🎨 Mejoras de UI

- **Visualizador**: fondo extrae colores de la portada (no más fondo negro fijo)
- **Visualizador modo círculo**: muestra la portada del álbum en el centro
- **Botones ⏮️ ⏸️ ⏭️**: usan el color más vivo de la portada (vibrante), más llamativos que los secundarios
- **Menú 3 puntos**: "Buscar Canvas en Klipy" → **"Búsqueda de GIF"** (más claro y conciso)
- **Carátulas redondeadas**: radio aumentado en listas, grid y player

### ⚙️ Técnico

- `SleepTimerManager` reescrito: fade-out progresivo de 20 s antes de pausar
- `PlayerController.reorderQueue()` usa `moveMediaItem()` → no interrumpe ExoPlayer
- `PlayerController.addToQueueNext()` inserta después de la canción actual
- `PlayerController.getVolume()` / `setVolume()` añadidos para el timer
- `PlayerController.toggle8DAudio()` y efecto 8D
- `AudioVisualizerView`: nuevo tema `ALBUM` que extrae colores de Palette
- `EqualizerActivity`: `setupAutoProfileSwitch()` con `AudioDeviceCallback`
- `SyncedLyricsAdapter`: callback `onLineClick` para seek por línea
- `SongListAdapter`: badge de formato para TODOS los tipos de audio
- `MultiQueueActivity`: VH usa tags en lugar de `getChildAt()` (evita `ClassCastException`)

## v2.4.0 — Mayo 2026 (La Mejor App)

### 🆕 Funciones nuevas

- **Gapless real**: ExoPlayer con buffer alto (120s max) — transición sin silencio entre canciones en vivo/álbumes
- **Play count visible en lista**: número de reproducciones junto a cada canción
- **Sort por más reproducidas**: nueva opción de ordenación
- **Long press en canción → reproducir inmediatamente** sin abrir menú
- **Letras offline**: se guardan en caché local tras la primera descarga — carga instantánea sin internet
- **Búsqueda por letra**: escribe `letra: [fragmento]` en el buscador para encontrar canciones por su letra
- **Tema AMOLED negro puro**: #000000 en fondos, ahorra batería en pantallas OLED
- **Transición animada portada → player**: shared element transition suave al abrir el reproductor
- **Ecualizador Paramétrico**: 3 bandas con control de Frecuencia, Ganancia dB y Q/ancho
- **Normalización de volumen en tiempo real**: iguala volumen entre canciones sin ReplayGain
- **Carpeta monitoreada**: detecta canciones nuevas automáticamente sin "Actualizar biblioteca"
- **Botones Like y Shuffle en notificación**: control desde la barra de notificaciones
- **Contador "X de Y"** en el player y notificación
- **Fade-in configurable**: duración ajustable (0.5s, 1s, 1.5s, 2s, 3s)
- **Imágenes de artista**: nuevo proveedor Discogs como fallback adicional a MusicBrainz
- **Crossfade inteligente**: detecta silencio al final para transición más natural

### ⚙️ Bajo el capó

- `FolderWatcher`: observador de sistema de archivos con `FileObserver` + subcarpetas
- `MusicService.instance`: referencia estática para acceso desde timers y efectos
- `PlayerController.queuePosition`: LiveData con posición actual "X de Y"
- `PlayerController.startRealtimeNormalization()`: ajuste de volumen gradual
- `EqualizerActivity.buildParametricEqSection()`: EQ paramétrico con biquad digital
- `ArtistImageProvider.fetchFromDiscogs()`: fallback de imágenes de artista
- Transiciones `ChangeBounds` con 350ms en entrada y 280ms en salida
