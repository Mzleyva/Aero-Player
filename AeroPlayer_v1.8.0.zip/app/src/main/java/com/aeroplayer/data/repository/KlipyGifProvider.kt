package com.aeroplayer.data.repository

import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

/**
 * Proveedor de GIFs animados usando la API pública de Tenor v1.
 *
 * MIGRACIÓN v2 → v1:
 * La clave de googleapis.com/v2 (AIzaSy...) fue revocada por Google y devuelve 400.
 * Tenor v1 (api.tenor.com/v1) sigue activa con la key demo "LIVDSRZULELA".
 *
 * Diferencias estructurales de v1 vs v2:
 *  - URL base: api.tenor.com/v1 (no tenor.googleapis.com/v2)
 *  - "media" es un ARRAY de objetos (no "media_formats" directo)
 *  - No existe "&ar_range=" en v1
 *
 * Para producción registra tu propia clave gratuita en:
 * https://tenor.com/developer/keyregistration
 */
object KlipyGifProvider {

    // Clave demo pública de Tenor v1 — mantenida activa por Google para desarrollo.
    // La key de googleapis.com (v2) fue revocada; LIVDSRZULELA es la demo oficial de v1.
    // Para producción registra tu propia clave en: https://tenor.com/developer/keyregistration
    private const val TENOR_API_KEY = "LIVDSRZULELA"

    private const val BASE_URL = "https://api.tenor.com/v1/search"
    private const val LIMIT = 16
    private const val CONTENT_FILTER = "medium" // off | low | medium | high

    // ── Modelo de resultado ───────────────────────────────────────────────────

    /** Un resultado de GIF con URLs de previsualización y tamaño completo. */
    data class GifResult(
        val id: String,
        /** URL del gif pequeño — thumbnail en el grid (≤ 220 px). */
        val previewUrl: String,
        /** URL del gif de calidad media — se usa como canvas (≈ 480 px). */
        val gifUrl: String,
        /** Título/descripción del GIF. */
        val title: String
    )

    // ── Búsqueda ──────────────────────────────────────────────────────────────

    /**
     * Busca GIFs en Tenor para [query].
     *
     * Debe llamarse en un hilo IO; lanza excepción si hay error de red.
     *
     * @param query  Texto de búsqueda (artista, canción, estado de ánimo…)
     * @param pos    Token de paginación de la llamada anterior (null = primera página).
     * @return       Par (lista de resultados, token para la siguiente página o null).
     */
    fun search(query: String, pos: String? = null): Pair<List<GifResult>, String?> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        // Tenor v1: no soporta "&ar_range=". Los demás params son iguales.
        val sb = StringBuilder(
            "$BASE_URL?key=$TENOR_API_KEY" +
                    "&q=$encoded" +
                    "&limit=$LIMIT" +
                    "&contentfilter=$CONTENT_FILTER" +
                    "&media_filter=tinygif,mediumgif"
        )
        if (pos != null) sb.append("&pos=$pos")

        val connection = URL(sb.toString()).openConnection() as java.net.HttpURLConnection
        connection.connectTimeout = 10_000
        connection.readTimeout    = 10_000
        connection.setRequestProperty("User-Agent", "AeroPlayer/1.2")
        val responseCode = connection.responseCode
        if (responseCode != 200) {
            throw java.io.IOException("Tenor API error $responseCode")
        }
        val json = JSONObject(connection.inputStream.bufferedReader().readText())

        val results = json.getJSONArray("results")
        val list = (0 until results.length()).mapNotNull { i ->
            runCatching {
                val item = results.getJSONObject(i)
                // Tenor v1: "media" es un ARRAY de objetos; el primer elemento tiene los formatos.
                // Tenor v2 (revocada) usaba "media_formats" como objeto directo.
                val mediaArray = item.optJSONArray("media")
                val mediaFormats = mediaArray?.optJSONObject(0) ?: return@mapNotNull null

                val previewUrl = mediaFormats
                    .optJSONObject("tinygif")
                    ?.optString("url") ?: return@mapNotNull null

                val gifUrl = mediaFormats
                    .optJSONObject("mediumgif")
                    ?.optString("url")
                    ?: mediaFormats.optJSONObject("tinygif")?.optString("url")
                    ?: return@mapNotNull null

                GifResult(
                    id = item.optString("id", i.toString()),
                    previewUrl = previewUrl,
                    gifUrl = gifUrl,
                    title = item.optString("title", "")
                )
            }.getOrNull()
        }

        // Tenor v1 usa "next" como cursor de paginación (igual que v2)
        val nextPos = json.optString("next").takeIf { it.isNotBlank() }
        return list to nextPos
    }
}
