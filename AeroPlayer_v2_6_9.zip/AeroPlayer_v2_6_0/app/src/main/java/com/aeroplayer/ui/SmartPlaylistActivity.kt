package com.aeroplayer.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.Transition
import kotlinx.coroutines.launch

/**
 * SmartPlaylistActivity v2 — interfaz propia igual que PlaylistDetailActivity.
 *
 * FIX: antes solo mostraba una lista genérica sin header visual.
 * Ahora tiene:
 *  · Header con collage de 4 portadas (o emoji grande si no hay arte).
 *  · Gradiente Palette desde el arte dominante.
 *  · Título, descripción y conteo de canciones.
 *  · Botones Reproducir todo y Aleatorio.
 *  · Lista de canciones con portada individual.
 */
class SmartPlaylistActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    companion object {
        const val EXTRA_TYPE = "smart_playlist_type"
    }

    // ── Referencias a vistas del header ──────────────────────────────────────
    private lateinit var ivCollage:      ImageView
    private lateinit var headerContainer: android.widget.FrameLayout
    private lateinit var tvTitle:        TextView
    private lateinit var tvDesc:         TextView
    private lateinit var tvCount:        TextView
    private lateinit var btnPlayAll:     android.widget.Button
    private lateinit var btnShuffle:     android.widget.Button
    private lateinit var rv:             RecyclerView
    private lateinit var tvEmpty:        TextView

    private lateinit var type: SmartPlaylistType
    private lateinit var adapter: SmartSongAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        val typeName = intent.getStringExtra(EXTRA_TYPE) ?: SmartPlaylistType.RECENTLY_PLAYED.name
        type = runCatching { SmartPlaylistType.valueOf(typeName) }
            .getOrDefault(SmartPlaylistType.RECENTLY_PLAYED)

        buildUI()
        loadSongs()
    }

    // ── Construcción de la UI ─────────────────────────────────────────────────
    private fun buildUI() {
        val root = androidx.core.widget.NestedScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(getColor(R.color.background_dark))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // ── Header ────────────────────────────────────────────────────────────
        headerContainer = android.widget.FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 300.dp
            )
        }

        // Collage de portadas (o emoji)
        ivCollage = ImageView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        headerContainer.addView(ivCollage)

        // Gradiente encima de la imagen
        val gradientView = View(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, getColor(R.color.background_dark))
            )
        }
        headerContainer.addView(gradientView)

        // Botón atrás
        val btnBack = ImageButton(this).apply {
            val lp = android.widget.FrameLayout.LayoutParams(48.dp, 48.dp).apply {
                topMargin  = 16.dp + statusBarHeight()
                marginStart = 8.dp
            }
            layoutParams = lp
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
            background = null
            setOnClickListener { finish() }
        }
        headerContainer.addView(btnBack)

        // Emoji grande centrado (visible si no hay portadas)
        val tvEmoji = TextView(this).apply {
            val lp = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.CENTER
            )
            layoutParams = lp
            text = type.emoji
            textSize = 64f
            tag = "emoji"
        }
        headerContainer.addView(tvEmoji)

        container.addView(headerContainer)

        // ── Info bajo el header ────────────────────────────────────────────────
        val infoBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 12.dp, 20.dp, 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        tvTitle = TextView(this).apply {
            text = type.titleEs
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.text_primary))
        }

        tvDesc = TextView(this).apply {
            text = type.descriptionEs
            textSize = 13f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, 4.dp, 0, 0)
        }

        tvCount = TextView(this).apply {
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, 4.dp, 0, 12.dp)
        }

        infoBox.addView(tvTitle)
        infoBox.addView(tvDesc)
        infoBox.addView(tvCount)

        // Botones Reproducir / Aleatorio
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(20.dp, 0, 20.dp, 16.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        btnPlayAll = android.widget.Button(this).apply {
            text = "▶  Reproducir"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, 44.dp, 1f).apply {
                marginEnd = 8.dp
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 22.dp.toFloat()
                setColor(ContextCompat.getColor(this@SmartPlaylistActivity, R.color.accent_blue))
            }
        }

        btnShuffle = android.widget.Button(this).apply {
            text = "🔀  Aleatorio"
            textSize = 13f
            setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, 44.dp, 1f)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 22.dp.toFloat()
                setColor(ContextCompat.getColor(this@SmartPlaylistActivity, R.color.surface_dark))
            }
        }

        btnRow.addView(btnPlayAll)
        btnRow.addView(btnShuffle)

        container.addView(infoBox)
        container.addView(btnRow)

        // ── Lista de canciones ────────────────────────────────────────────────
        tvEmpty = TextView(this).apply {
            text = "Aún no hay canciones aquí.\nEmpieza a reproducir música para llenarla."
            textSize = 14f
            setTextColor(getColor(R.color.text_secondary))
            gravity = android.view.Gravity.CENTER
            setPadding(32.dp, 48.dp, 32.dp, 48.dp)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@SmartPlaylistActivity)
            isNestedScrollingEnabled = false
            setPadding(0, 0, 0, 80.dp)
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        container.addView(tvEmpty)
        container.addView(rv)
        root.addView(container)
        setContentView(root)

        // Adapter
        adapter = SmartSongAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = type.titleEs)
            viewModel.incrementPlayCount(song)
        }
        rv.adapter = adapter

        btnPlayAll.setOnClickListener {
            val songs = adapter.currentList
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, queueName = type.titleEs)
                viewModel.incrementPlayCount(songs[0])
            }
        }

        btnShuffle.setOnClickListener {
            val songs = adapter.currentList.shuffled()
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, queueName = type.titleEs)
            }
        }
    }

    // ── Carga de datos ────────────────────────────────────────────────────────
    private fun loadSongs() {
        lifecycleScope.launch {
            val songs = viewModel.getSmartPlaylistSongs(type)
            adapter.submitList(songs)

            val count = songs.size
            tvCount.text = "$count canción${if (count != 1) "es" else ""}"
            rv.visibility    = if (songs.isEmpty()) View.GONE  else View.VISIBLE
            tvEmpty.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE

            // Ocultar emoji si hay canciones con arte
            val hasArt = songs.any { it.albumArtUri != null }
            headerContainer.findViewWithTag<TextView>("emoji")?.visibility =
                if (hasArt) View.GONE else View.VISIBLE

            if (hasArt) buildCollage(songs)
        }

        viewModel.listeningHistory.observe(this) {
            lifecycleScope.launch {
                val songs = viewModel.getSmartPlaylistSongs(type)
                if (songs != adapter.currentList) {
                    adapter.submitList(songs)
                    tvCount.text = "${songs.size} canción${if (songs.size != 1) "es" else ""}"
                }
            }
        }
    }

    // ── Collage de 4 portadas + Palette ──────────────────────────────────────
    private fun buildCollage(songs: List<Song>) {
        // Tomar hasta 4 canciones con arte distinto
        val artSongs = songs
            .distinctBy { it.albumArtUri?.toString() }
            .take(4)

        if (artSongs.size < 2) {
            // Solo 1 portada: mostrarla centrada
            Glide.with(this)
                .asBitmap()
                .load(artSongs.firstOrNull()?.albumArtUri)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(bmp: Bitmap, t: Transition<in Bitmap>?) {
                        ivCollage.setImageBitmap(bmp)
                        applyPalette(bmp)
                    }
                    override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
                })
            return
        }

        // Cargar bitmaps en paralelo y componer el collage
        val bitmaps = arrayOfNulls<Bitmap>(artSongs.size)
        var loaded = 0

        artSongs.forEachIndexed { idx, song ->
            Glide.with(this)
                .asBitmap()
                .load(song.albumArtUri)
                .override(300, 300)
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(bmp: Bitmap, t: Transition<in Bitmap>?) {
                        bitmaps[idx] = bmp
                        loaded++
                        if (loaded == artSongs.size) renderCollage(bitmaps.filterNotNull())
                    }
                    override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {
                        loaded++
                        if (loaded == artSongs.size) renderCollage(bitmaps.filterNotNull())
                    }
                })
        }
    }

    private fun renderCollage(bitmaps: List<Bitmap>) {
        if (bitmaps.isEmpty()) return
        val size = 600
        val half = size / 2
        val result = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint  = Paint(Paint.ANTI_ALIAS_FLAG)

        when (bitmaps.size) {
            1    -> canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[0], size, size, true), 0f, 0f, paint)
            2    -> {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[0], half, size, true), 0f, 0f, paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[1], half, size, true), half.toFloat(), 0f, paint)
            }
            3    -> {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[0], half, size, true), 0f, 0f, paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[1], half, half, true), half.toFloat(), 0f, paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[2], half, half, true), half.toFloat(), half.toFloat(), paint)
            }
            else -> {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[0], half, half, true), 0f, 0f, paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[1], half, half, true), half.toFloat(), 0f, paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[2], half, half, true), 0f, half.toFloat(), paint)
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmaps[3], half, half, true), half.toFloat(), half.toFloat(), paint)
            }
        }

        runOnUiThread {
            ivCollage.setImageBitmap(result)
            applyPalette(result)
        }
    }

    private fun applyPalette(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val accent = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(
                    ContextCompat.getColor(this, R.color.surface_dark)
                )
            ) ?: ContextCompat.getColor(this, R.color.surface_dark)

            val gradient = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(accent, ContextCompat.getColor(this, R.color.background_dark))
            )

            // Remplazar el gradientView dentro del headerContainer
            if (headerContainer.childCount > 1) {
                headerContainer.getChildAt(1).background = gradient
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
    }
}

// ── Adapter de canciones ──────────────────────────────────────────────────────
private class SmartSongAdapter(
    private val onClick: (Song, List<Song>) -> Unit
) : ListAdapter<Song, SmartSongAdapter.VH>(SongDiff()) {

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val iv: ImageView     = root.findViewWithTag("iv")
        val tvTitle: TextView = root.findViewWithTag("title")
        val tvSub: TextView   = root.findViewWithTag("sub")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp = ctx.resources.displayMetrics.density

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            isClickable = true; isFocusable = true
            val tv = android.util.TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            background = ctx.getDrawable(tv.resourceId)
        }

        val size = (52 * dp).toInt()
        val iv = ImageView(ctx).apply {
            tag = "iv"
            layoutParams = LinearLayout.LayoutParams(size, size).also {
                it.marginEnd = (14 * dp).toInt()
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = ctx.getDrawable(R.drawable.bg_album_art_small)
            clipToOutline   = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvTitle = TextView(ctx).apply {
            tag = "title"; textSize = 14f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_primary))
        }

        val tvSub = TextView(ctx).apply {
            tag = "sub"; textSize = 12f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_secondary))
        }

        texts.addView(tvTitle)
        texts.addView(tvSub)
        row.addView(iv)
        row.addView(texts)
        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.tvTitle.text = song.title
        holder.tvSub.text   =
            listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" · ")
        Glide.with(holder.iv)
            .load(song.albumArtUri)
            .placeholder(R.drawable.ic_music_placeholder)
            .error(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.iv)
        holder.root.setOnClickListener { onClick(song, currentList) }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
