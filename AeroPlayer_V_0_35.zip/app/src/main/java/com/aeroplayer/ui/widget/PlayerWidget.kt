package com.aeroplayer.ui.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews
import com.aeroplayer.R
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainActivity
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.AppWidgetTarget
import com.bumptech.glide.request.transition.Transition

class PlayerWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_PLAY_PAUSE = "com.aeroplayer.widget.PLAY_PAUSE"
        const val ACTION_NEXT       = "com.aeroplayer.widget.NEXT"
        const val ACTION_PREV       = "com.aeroplayer.widget.PREV"

        fun update(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, PlayerWidget::class.java))
            if (ids.isEmpty()) return
            val intent = Intent(context, PlayerWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, mgr, it, ids) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PLAY_PAUSE -> PlayerController.playPause()
            ACTION_NEXT       -> PlayerController.next()
            ACTION_PREV       -> PlayerController.previous()
        }
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(ComponentName(context, PlayerWidget::class.java))
        ids.forEach { updateWidget(context, mgr, it, ids) }
    }

    private fun updateWidget(context: Context, mgr: AppWidgetManager, id: Int, ids: IntArray) {
        val views     = RemoteViews(context.packageName, R.layout.widget_player)
        val song      = PlayerController.currentSong.value
        val isPlaying = PlayerController.isPlaying.value == true

        views.setTextViewText(R.id.widgetTitle,  song?.title  ?: context.getString(R.string.app_name))
        views.setTextViewText(R.id.widgetArtist, song?.artist ?: context.getString(R.string.widget_tap_to_play))

        // Barra de progreso (Android 12+ soporta ProgressBar en widgets via RemoteViews)
        val duration = PlayerController.getDuration()
        val position = PlayerController.getCurrentPosition()
        if (duration > 0) {
            val progress = ((position * 100) / duration).toInt().coerceIn(0, 100)
            views.setProgressBar(R.id.widgetProgress, 100, progress, false)
        } else {
            views.setProgressBar(R.id.widgetProgress, 100, 0, false)
        }
        views.setImageViewResource(
            R.id.widgetBtnPlayPause,
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )

        views.setOnClickPendingIntent(R.id.widgetBtnPlayPause, buildPI(context, ACTION_PLAY_PAUSE))
        views.setOnClickPendingIntent(R.id.widgetBtnNext,      buildPI(context, ACTION_NEXT))
        views.setOnClickPendingIntent(R.id.widgetBtnPrev,      buildPI(context, ACTION_PREV))

        val openTarget = if (song != null) PlayerActivity::class.java else MainActivity::class.java
        val openPI = PendingIntent.getActivity(
            context, 0, Intent(context, openTarget),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.widgetAlbumArt, openPI)
        views.setOnClickPendingIntent(R.id.widgetTitle,    openPI)

        // Always apply text/button updates immediately
        mgr.updateAppWidget(id, views)

        // Then asynchronously load album art if available
        if (song?.albumArtUri != null) {
            val awt = object : AppWidgetTarget(context, R.id.widgetAlbumArt, views, *ids) {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    super.onResourceReady(resource, transition)
                    // AppWidgetTarget calls mgr.updateAppWidget internally
                }
                override fun onLoadFailed(errorDrawable: android.graphics.drawable.Drawable?) {
                    views.setImageViewResource(R.id.widgetAlbumArt, R.drawable.ic_music_placeholder)
                    mgr.updateAppWidget(id, views)
                }
            }
            Glide.with(context.applicationContext)
                .asBitmap()
                .load(song.albumArtUri)
                .override(128, 128)
                .centerCrop()
                .into(awt)
        } else {
            views.setImageViewResource(R.id.widgetAlbumArt, R.drawable.ic_music_placeholder)
            mgr.updateAppWidget(id, views)
        }
    }

    private fun buildPI(context: Context, action: String): PendingIntent =
        PendingIntent.getBroadcast(
            context, action.hashCode(),
            Intent(context, PlayerWidget::class.java).apply { this.action = action },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
