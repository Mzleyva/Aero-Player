package com.aeroplayer.ui.visualizer

import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.aeroplayer.R
import com.aeroplayer.service.MusicService
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide

/**
 * VisualizerActivity — v2.1
 * Sesión 4: panel de personalización (velocidad, color, sensibilidad, barras, modo).
 * El panel se muestra/oculta con un toque. Configuración persistida en SharedPrefs.
 */
class VisualizerActivity : AppCompatActivity() {

    private lateinit var visualizerView: AudioVisualizerView
    private lateinit var tvTitle:        TextView
    private lateinit var tvArtist:       TextView
    private lateinit var ivAlbumArt:     ImageView
    private lateinit var settingsPanel:  LinearLayout
    private var panelVisible = false

    private val PREFS = "visualizer_prefs"

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        supportActionBar?.hide()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            )
        }

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val root = FrameLayout(this).apply {
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // Album art fondo
        ivAlbumArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.12f
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        root.addView(ivAlbumArt)

        // Visualizador
        visualizerView = AudioVisualizerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            // Restaurar ajustes guardados
            smoothFactor = prefs.getFloat("smooth", 0.65f)
            sensitivity  = prefs.getFloat("sensitivity", 1.8f)
            barCount     = prefs.getInt("barCount", 80)
            colorTheme   = AudioVisualizerView.ColorTheme.values()[prefs.getInt("theme", 0)]
            mode         = AudioVisualizerView.Mode.values()[prefs.getInt("mode", 0)]
        }
        root.addView(visualizerView)

        // Info superior
        val infoLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 48.dp, 80.dp, 0)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        }
        tvTitle = TextView(this).apply {
            textSize = 19f; setTextColor(getColor(R.color.text_primary))
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MARQUEE; isSelected = true
        }
        tvArtist = TextView(this).apply {
            textSize = 13f; setTextColor(getColor(R.color.text_secondary))
        }
        infoLayout.addView(tvTitle); infoLayout.addView(tvArtist)
        root.addView(infoLayout)

        // Botones: cerrar + ajustes (esquina superior derecha)
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP).also { it.topMargin = 40.dp; it.marginEnd = 8.dp }
        }
        btnRow.addView(makeIconBtn("⚙") { togglePanel() })
        btnRow.addView(makeIconBtn("✕") { finish() })
        root.addView(btnRow)

        // Selector de modo (bottom)
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24.dp)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        }
        val modes = listOf(
            AudioVisualizerView.Mode.BARS   to "▊ Barras",
            AudioVisualizerView.Mode.MIRROR to "⬌ Mirror",
            AudioVisualizerView.Mode.WAVE   to "〜 Onda",
            AudioVisualizerView.Mode.CIRCLE to "◉ Círculo"
        )
        val modeChips = mutableListOf<com.google.android.material.chip.Chip>()
        modes.forEach { (m, label) ->
            val chip = com.google.android.material.chip.Chip(this).apply {
                text = label; textSize = 11f
                chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                    if (m == visualizerView.getMode()) getColor(R.color.accent_blue) else getColor(R.color.surface_card))
                setTextColor(android.graphics.Color.WHITE)
                chipStrokeWidth = 1.2f
                chipStrokeColor = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.marginEnd = 6.dp }
                setOnClickListener {
                    visualizerView.setMode(m)
                    prefs.edit().putInt("mode", m.ordinal).apply()
                    modeChips.forEachIndexed { idx, c ->
                        c.chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                            if (modes[idx].first == m) getColor(R.color.accent_blue) else getColor(R.color.surface_card))
                    }
                }
            }
            modeChips.add(chip); modeRow.addView(chip)
        }
        root.addView(modeRow)

        // ── Panel de personalización ──────────────────────────────────────────
        settingsPanel = buildSettingsPanel(prefs)
        root.addView(settingsPanel)

        // Toque en pantalla muestra/oculta el panel
        root.setOnClickListener { togglePanel() }

        setContentView(root)

        PlayerController.currentSong.observe(this) { song ->
            tvTitle.text  = song?.title  ?: "Sin reproducción"
            tvArtist.text = song?.artist ?: ""
            song?.albumArtUri?.let { Glide.with(this).load(it).into(ivAlbumArt) }
        }
    }

    private fun buildSettingsPanel(prefs: android.content.SharedPreferences): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 16.dp, 20.dp, 16.dp)
            setBackgroundColor(0xDD121212.toInt())
            visibility = android.view.View.GONE
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM).also { it.bottomMargin = 72.dp }

            // ── Velocidad (smooth) ─────────────────────────────────────────
            addView(settingLabel("Velocidad de respuesta"))
            addView(buildSeekRow(
                min = 5, max = 100,
                initial = (prefs.getFloat("smooth", 0.65f) * 100).toInt(),
                labels = listOf("Lento", "Normal", "Rápido")
            ) { v ->
                visualizerView.smoothFactor = v / 100f
                prefs.edit().putFloat("smooth", v / 100f).apply()
            })

            // ── Sensibilidad ───────────────────────────────────────────────
            addView(settingLabel("Sensibilidad"))
            addView(buildSeekRow(
                min = 50, max = 400,
                initial = (prefs.getFloat("sensitivity", 1.8f) * 100).toInt(),
                labels = listOf("Suave", "Normal", "Fuerte")
            ) { v ->
                visualizerView.sensitivity = v / 100f
                prefs.edit().putFloat("sensitivity", v / 100f).apply()
            })

            // ── Número de barras ───────────────────────────────────────────
            addView(settingLabel("Número de barras"))
            val barOptions = listOf(32, 64, 80, 128)
            addView(buildChipRow(
                options = barOptions.map { "$it" },
                selected = barOptions.indexOfFirst { it == prefs.getInt("barCount", 80) }.coerceAtLeast(0)
            ) { idx ->
                val count = barOptions[idx]
                visualizerView.barCount = count
                prefs.edit().putInt("barCount", count).apply()
            })

            // ── Color ──────────────────────────────────────────────────────
            addView(settingLabel("Tema de color"))
            val themeNames = listOf("Aero", "Fuego", "Bosque", "Atardecer", "Blanco", "Acento")
            addView(buildChipRow(
                options = themeNames,
                selected = prefs.getInt("theme", 0)
            ) { idx ->
                visualizerView.colorTheme = AudioVisualizerView.ColorTheme.values()[idx]
                prefs.edit().putInt("theme", idx).apply()
            })
        }
    }

    private fun buildSeekRow(min: Int, max: Int, initial: Int, labels: List<String>, onChange: (Int) -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 4.dp, 0, 8.dp)
            addView(TextView(this@VisualizerActivity).apply {
                text = labels.first(); textSize = 10f
                setTextColor(0x88FFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(44.dp, LinearLayout.LayoutParams.WRAP_CONTENT)
            })
            addView(SeekBar(this@VisualizerActivity).apply {
                this.max = max - min; progress = (initial - min).coerceIn(0, max - min)
                progressTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                thumbTintList    = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p + min) }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
            addView(TextView(this@VisualizerActivity).apply {
                text = labels.last(); textSize = 10f
                setTextColor(0x88FFFFFF.toInt()); gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(44.dp, LinearLayout.LayoutParams.WRAP_CONTENT)
            })
        }
    }

    private fun buildChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit): HorizontalScrollView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4.dp, 0, 8.dp)
        }
        val chips = mutableListOf<com.google.android.material.chip.Chip>()
        options.forEachIndexed { i, label ->
            val chip = com.google.android.material.chip.Chip(this).apply {
                text = label; textSize = 11f
                chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                    if (i == selected) getColor(R.color.accent_blue) else 0x22FFFFFF.toInt())
                setTextColor(android.graphics.Color.WHITE)
                chipStrokeWidth = 1f
                chipStrokeColor = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.marginEnd = 6.dp }
                setOnClickListener {
                    onSelect(i)
                    chips.forEachIndexed { j, c ->
                        c.chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                            if (j == i) getColor(R.color.accent_blue) else 0x22FFFFFF.toInt())
                    }
                }
            }
            chips.add(chip); row.addView(chip)
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(row)
        }
    }

    private fun settingLabel(text: String) = TextView(this).apply {
        this.text = text; textSize = 12f
        setTextColor(0xAAFFFFFF.toInt())
        setPadding(0, 8.dp, 0, 2.dp)
    }

    private fun makeIconBtn(icon: String, onClick: () -> Unit) = TextView(this).apply {
        text = icon; textSize = 18f; setTextColor(0xCCFFFFFF.toInt())
        setPadding(12.dp, 8.dp, 12.dp, 8.dp)
        setOnClickListener { onClick() }
    }

    private fun togglePanel() {
        panelVisible = !panelVisible
        settingsPanel.visibility = if (panelVisible) android.view.View.VISIBLE else android.view.View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (android.content.pm.PackageManager.PERMISSION_GRANTED ==
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)) {
            visualizerView.init(MusicService.audioSessionId)
        } else {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            visualizerView.init(MusicService.audioSessionId)
        } else {
            Toast.makeText(this, "Se necesita permiso de audio para el visualizador", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() { super.onPause(); visualizerView.release() }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
