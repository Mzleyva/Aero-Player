package com.aeroplayer.ui.library

import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityArtistDetailBinding
import com.aeroplayer.databinding.ItemAlbumBinding
import com.aeroplayer.databinding.ItemPlaylistSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.AccentApplier
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.utils.AlbumArtUtils
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.content.Intent
import android.app.ActivityOptions
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import kotlinx.coroutines.Job
import com.aeroplayer.utils.makeCircle

class ArtistDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ARTIST_NAME = "artist_name"
    }

    private lateinit var binding: ActivityArtistDetailBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityArtistDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AccentApplier.apply(this, binding.root)

        // FIX redondeo: foto del artista — makeCircle para recorte circular correcto
        binding.ivArtistPhoto.makeCircle()

        val artistName = intent.getStringExtra(EXTRA_ARTIST_NAME) ?: run { finish(); return }

        setupToolbar()
        observeSongs(artistName)
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }
    }

    private fun observeSongs(artistName: String) {
        viewModel.allSongs.observe(this) { allSongs ->
            val songs  = allSongs.filter { it.artist == artistName }.sortedBy { it.title }
            val albums = songs.groupBy { it.album }.map { (albumName, albumSongs) ->
                Album(
                    name     = albumName,
                    artist   = artistName,
                    coverUri = albumSongs.first().albumArtUri,
                    songs    = albumSongs.sortedBy { it.trackNumber }
                )
            }.sortedBy { it.name.lowercase() }

            binding.tvArtistName.text  = artistName
            binding.tvArtistStats.text = buildString {
                append("${albums.size} álbum${if (albums.size != 1) "es" else ""}")
                append(" · ${songs.size} canción${if (songs.size != 1) "es" else ""}")
            }

            setupPhoto(artistName, songs.firstOrNull())
            setupSongs(songs)
            setupAlbums(albums)
            setupButtons(songs)
        }
    }

    private fun setupPhoto(artistName: String, repSong: Song?) {
        // 1. Mostrar carátula del álbum como placeholder inmediato
        if (repSong != null) {
            val cached = AlbumArtUtils.getCached(repSong.id)
            if (cached != null) {
                Glide.with(binding.ivArtistPhoto).load(cached).circleCrop()
                    .into(binding.ivArtistPhoto)
                applyPaletteFromBitmap(cached)
            } else {
                Glide.with(binding.ivArtistPhoto).load(repSong.albumArtUri)
                    .placeholder(R.drawable.ic_person)
                    .circleCrop()
                    .into(binding.ivArtistPhoto)
            }
        }

        // 2. Buscar foto real del artista en background
        lifecycleScope.launch {
            val artistBitmap = withContext(Dispatchers.IO) {
                com.aeroplayer.data.repository.ArtistImageProvider.fetchArtistImage(artistName)
            }
            if (artistBitmap != null) {
                Glide.with(binding.ivArtistPhoto)
                    .load(artistBitmap)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .circleCrop()
                    .into(binding.ivArtistPhoto)
                applyPaletteFromBitmap(artistBitmap)
            } else if (repSong != null) {
                // Fallback: cargar carátula completa desde archivo
                val bmp = withContext(Dispatchers.IO) {
                    AlbumArtUtils.loadArt(repSong.id, repSong.path, repSong.artist, repSong.album)
                }
                if (bmp != null) {
                    Glide.with(binding.ivArtistPhoto)
                        .load(bmp)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .circleCrop()
                        .into(binding.ivArtistPhoto)
                    applyPaletteFromBitmap(bmp)
                }
            }
        }
    }

    private fun applyPaletteFromBitmap(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val fallback = ContextCompat.getColor(this, R.color.surface_dark)
            val dominant = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(fallback)
            ) ?: fallback
            binding.headerContainer.setBackgroundColor(dominant)
        }
    }

    private fun setupSongs(songs: List<Song>) {
        val adapter = ArtistSongAdapter { song ->
            viewModel.incrementPlayCount(song)
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = song.artist)
            startActivity(
                Intent(this, PlayerActivity::class.java),
                ActivityOptions.makeCustomAnimation(this, R.anim.fade_in, R.anim.fade_out).toBundle()
            )
        }
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter
        binding.rvSongs.isNestedScrollingEnabled = false
        adapter.submitList(songs)
    }

    private fun setupAlbums(albums: List<Album>) {
        val adapter = ArtistAlbumAdapter { album ->
            // Abrir AlbumDetailActivity al tocar un álbum
            val intent = Intent(this, AlbumDetailActivity::class.java).apply {
                putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME, album.name)
                putExtra(AlbumDetailActivity.EXTRA_ARTIST_NAME, album.artist)
            }
            startActivity(intent,
                ActivityOptions.makeCustomAnimation(this, R.anim.slide_in_right, R.anim.slide_out_left).toBundle()
            )
        }
        binding.rvAlbums.layoutManager = GridLayoutManager(this, 2)
        binding.rvAlbums.adapter = adapter
        binding.rvAlbums.isNestedScrollingEnabled = false
        adapter.submitList(albums)
    }

    private fun setupButtons(songs: List<Song>) {
        binding.btnPlayAll.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            viewModel.incrementPlayCount(songs.first())
            PlayerController.playSongs(songs, 0, queueName = binding.tvArtistName.text.toString())
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.btnShuffle.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            val shuffled = songs.shuffled()
            viewModel.incrementPlayCount(shuffled.first())
            PlayerController.playSongs(shuffled, 0, queueName = binding.tvArtistName.text.toString())
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}

// ── Adapter de canciones del artista ─────────────────────────────────────────
class ArtistSongAdapter(
    private val onClick: (Song) -> Unit
) : ListAdapter<Song, ArtistSongAdapter.VH>(SongDiff()) {

    inner class VH(val b: ItemPlaylistSongBinding) : RecyclerView.ViewHolder(b.root) {
        var artJob: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemPlaylistSongBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onViewRecycled(holder: VH) {
        super.onViewRecycled(holder)
        holder.artJob?.cancel()
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text    = song.title
        holder.b.tvArtist.text   = song.album
        holder.b.tvDuration.text = FormatUtils.formatDuration(song.duration)

        val cached = AlbumArtUtils.getCached(song.id)
        if (cached != null) {
            Glide.with(holder.b.ivAlbumArt).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivAlbumArt)
        } else {
            Glide.with(holder.b.ivAlbumArt).load(R.drawable.ic_music_placeholder).into(holder.b.ivAlbumArt)
            holder.artJob?.cancel()
            holder.artJob = (holder.b.ivAlbumArt.context as? androidx.lifecycle.LifecycleOwner)
                ?.lifecycleScope?.launch {
                    val bmp = AlbumArtUtils.loadArt(song.id, song.path, song.artist, song.album)
                    if (bmp != null) {
                        Glide.with(holder.b.ivAlbumArt).load(bmp).centerCrop()
                            .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivAlbumArt)
                    } else {
                        Glide.with(holder.b.ivAlbumArt).load(song.albumArtUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .error(R.drawable.ic_music_placeholder).centerCrop().into(holder.b.ivAlbumArt)
                    }
                }
        }

        holder.b.root.setOnClickListener { onClick(song) }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}

// ── Adapter de álbumes del artista (grid 2 columnas) ─────────────────────────
class ArtistAlbumAdapter(
    private val onClick: (Album) -> Unit
) : ListAdapter<Album, ArtistAlbumAdapter.VH>(AlbumDiff2()) {

    inner class VH(val b: ItemAlbumBinding) : RecyclerView.ViewHolder(b.root) {
        var artJob: Job? = null
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemAlbumBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onViewRecycled(holder: VH) {
        super.onViewRecycled(holder)
        holder.artJob?.cancel()
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val album   = getItem(position)
        val repSong = album.songs.firstOrNull()

        holder.b.tvName.text   = album.name
        holder.b.tvArtist.text = album.artist
        holder.b.tvCount.text  = "${album.songs.size} canciones"

        val cached = if (repSong != null) AlbumArtUtils.getCached(repSong.id) else null
        if (cached != null) {
            holder.artJob?.cancel()
            Glide.with(holder.b.ivCover).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivCover)
        } else {
            Glide.with(holder.b.ivCover).load(R.drawable.ic_music_placeholder).into(holder.b.ivCover)
            holder.artJob?.cancel()
            holder.artJob = (holder.b.ivCover.context as? androidx.lifecycle.LifecycleOwner)
                ?.lifecycleScope?.launch {
                    val bmp = if (repSong != null)
                        AlbumArtUtils.loadArt(repSong.id, repSong.path, repSong.artist, repSong.album)
                    else null
                    if (bmp != null) {
                        Glide.with(holder.b.ivCover).load(bmp).centerCrop()
                            .transition(DrawableTransitionOptions.withCrossFade()).into(holder.b.ivCover)
                    } else {
                        Glide.with(holder.b.ivCover).load(album.coverUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .error(R.drawable.ic_music_placeholder).centerCrop().into(holder.b.ivCover)
                    }
                }
        }

        holder.b.root.setOnClickListener { onClick(album) }
    }

    class AlbumDiff2 : DiffUtil.ItemCallback<Album>() {
        override fun areItemsTheSame(a: Album, b: Album) = a.name == b.name
        override fun areContentsTheSame(a: Album, b: Album) = a == b
    }
}
