package com.aeroplayer.data.repository

import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

/**
 * Proveedor de GIFs animados usando la API de Klipy.
 *
 * Klipy fue creada por ex-empleados de Tenor y tiene una API casi idéntica
 * al Tenor v2 — el endpoint de búsqueda usa los mismos parámetros y devuelve
 * la misma estructura de `media_formats`. Es gratuita y de tier perpetuo.
 *
 * ## Obtener API Key
 * Regístrate en https://klipy.com y obtén tu clave en el Partner Panel.
 * Reemplaza [KLIPY_API_KEY] con tu clave real antes de publicar la app.
 *
 * ## Migración desde Tenor
 * Solo se cambia el BASE_URL: `tenor.googleapis.com/v2` → `api.klipy.com/v2`
 * Los parámetros `key`, `q`, `limit`, `media_filter`, `contentfilter` son iguales.
 */
object KlipyGifProvider {

    // ── Clave de API de Klipy ─────────────────────────────────────────────────
    // Reemplaza este valor con tu clave real del Partner Panel de Klipy.
    // Registro gratuito en: https://klipy.com
    private const val KLIPY_API_KEY = "TU_KLIPY_API_KEY_AQUI"

    private const val BASE_URL = "https://api.klipy.com/v2/search"
    private const val LIMIT = 16
    private const val CONTENT_FILTER = "medium" // off | low | medium | high

    // ── Modelo de resultado ───────────────────────────────────────────────────

    /** Un resultado de GIF con URLs de previsualización y tamaño completo. */
    data class GifResult(
        val id: String,
        /** URL del gif pequeño — thumbnail en el grid (≤ 220 px). */
        val previewUrl: String,
        /** URL del gif de calidad media — se usa como canvas (≈ 480 px). */
        val gifUrl: String,
        /** Título/descripción del GIF. */
        val title: String
    )

    // ── Búsqueda ──────────────────────────────────────────────────────────────

    /**
     * Busca GIFs en Klipy para [query].
     *
     * Debe llamarse en un hilo IO; lanza excepción si hay error de red.
     *
     * @param query  Texto de búsqueda (artista, canción, estado de ánimo…)
     * @param pos    Token de paginación de la llamada anterior (null = primera página).
     * @return       Par (lista de resultados, token para la siguiente página o null).
     */
    fun search(query: String, pos: String? = null): Pair<List<GifResult>, String?> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val sb = StringBuilder(
            "$BASE_URL?key=$KLIPY_API_KEY" +
                    "&q=$encoded" +
                    "&limit=$LIMIT" +
                    "&contentfilter=$CONTENT_FILTER" +
                    "&media_filter=tinygif,mediumgif" +
                    "&ar_range=all"
        )
        if (pos != null) sb.append("&pos=$pos")

        val json = JSONObject(URL(sb.toString()).readText())

        val results = json.getJSONArray("results")
        val list = (0 until results.length()).mapNotNull { i ->
            runCatching {
                val item = results.getJSONObject(i)
                val mediaFormats = item.getJSONObject("media_formats")

                val previewUrl = mediaFormats
                    .optJSONObject("tinygif")
                    ?.optString("url") ?: return@mapNotNull null

                val gifUrl = mediaFormats
                    .optJSONObject("mediumgif")
                    ?.optString("url")
                    ?: mediaFormats.optJSONObject("tinygif")?.optString("url")
                    ?: return@mapNotNull null

                GifResult(
                    id = item.optString("id", i.toString()),
                    previewUrl = previewUrl,
                    gifUrl = gifUrl,
                    title = item.optString("title", "")
                )
            }.getOrNull()
        }

        val nextPos = json.optString("next").takeIf { it.isNotBlank() }
        return list to nextPos
    }
}
