package com.aeroplayer.ui.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.drawable.DrawableCompat
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivitySettingsBinding
import com.aeroplayer.ui.ThemeManager
import com.aeroplayer.ui.onboarding.OnboardingActivity
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        saveAvatar(uri)
        Glide.with(this).load(uri).circleCrop().into(binding.ivProfileAvatar)
    }

    private val backgroundPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        ThemeManager.setCustomBackground(this, uri)
        refreshBackgroundState()
        Toast.makeText(this, "Fondo personalizado aplicado ✓", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        loadProfile()
        setupHistory()
        setupTheme()
        setupAccentColor()
        setupCustomBackground()
        setupCrossfade()
        setupExcludeFolders()
        setupAbout()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.fade_in, R.anim.slide_out_right)
        }
    }

    private fun loadProfile() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val name  = prefs.getString("user_name", "") ?: ""
        val avatar= prefs.getString("user_avatar", null)

        binding.tvProfileName.text = name.ifEmpty { getString(R.string.default_user_name) }
        if (avatar != null) {
            Glide.with(this).load(Uri.parse(avatar)).circleCrop()
                .into(binding.ivProfileAvatar)
        }

        binding.rowProfile.setOnClickListener {
            avatarPicker.launch("image/*")
        }
    }

    private fun saveAvatar(uri: Uri) {
        getSharedPreferences("aero_prefs", MODE_PRIVATE).edit()
            .putString("user_avatar", uri.toString())
            .apply()
    }

    private fun setupTheme() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)

        // Posibles valores guardados: "dark" | "light" | "auto"  (default: "auto")
        fun currentMode() = prefs.getString("theme_mode", "auto") ?: "auto"

        fun labelFor(mode: String) = when (mode) {
            "light" -> getString(R.string.theme_light_label)
            "dark"  -> getString(R.string.theme_dark_label)
            else    -> getString(R.string.theme_auto_label)
        }

        fun applyMode(mode: String) {
            prefs.edit().putString("theme_mode", mode).apply()
            binding.tvThemeCurrent.text = labelFor(mode)
            AppCompatDelegate.setDefaultNightMode(
                when (mode) {
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    "dark"  -> AppCompatDelegate.MODE_NIGHT_YES
                    else    -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }

        // Mostrar estado actual al entrar
        binding.tvThemeCurrent.text = labelFor(currentMode())

        // Opciones del diálogo
        val options = arrayOf(
            getString(R.string.theme_dark_label),
            getString(R.string.theme_light_label),
            getString(R.string.theme_auto_label)
        )
        val optionKeys = arrayOf("dark", "light", "auto")

        binding.rowTheme.setOnClickListener {
            val current = currentMode()
            val checkedIndex = optionKeys.indexOf(current).coerceAtLeast(0)

            MaterialAlertDialogBuilder(this)
                .setTitle("Tema")
                .setSingleChoiceItems(options, checkedIndex) { dialog, which ->
                    applyMode(optionKeys[which])
                    dialog.dismiss()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun setupCrossfade() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        binding.switchCrossfade.isChecked = prefs.getBoolean("crossfade_enabled", false)
        binding.switchCrossfade.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("crossfade_enabled", checked).apply()
        }
    }

    // ── Carpetas excluidas ─────────────────────────────────────────────────
    private fun setupExcludeFolders() {
        refreshExcludedCount()
        binding.rowExcludeFolders.setOnClickListener {
            showExcludeFoldersDialog()
        }
    }

    private fun getExcludedFolders(): MutableSet<String> {
        return getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .getStringSet("excluded_folders", emptySet())
            ?.toMutableSet() ?: mutableSetOf()
    }

    private fun saveExcludedFolders(folders: Set<String>) {
        getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .edit().putStringSet("excluded_folders", folders).apply()
    }

    private fun refreshExcludedCount() {
        val count = getExcludedFolders().size
        binding.tvExcludedCount.text = if (count == 0) {
            getString(R.string.settings_exclude_folders_none)
        } else {
            getString(R.string.settings_exclude_folders_count, count)
        }
    }

    private fun showExcludeFoldersDialog() {
        val folders = getExcludedFolders()
        val items   = folders.toTypedArray()
        val checked = BooleanArray(items.size) { false }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.settings_exclude_folders_title))

        if (items.isEmpty()) {
            builder.setMessage(getString(R.string.settings_exclude_folders_none))
        } else {
            builder.setMultiChoiceItems(items, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            builder.setNegativeButton(getString(R.string.cancel), null)
            builder.setNeutralButton(getString(R.string.delete)) { _, _ ->
                val updated = folders.filterIndexed { i, _ -> !checked[i] }.toSet()
                saveExcludedFolders(updated)
                refreshExcludedCount()
                Toast.makeText(this, getString(R.string.settings_exclude_folders_saved), Toast.LENGTH_SHORT).show()
            }
        }

        builder.setPositiveButton(getString(R.string.settings_exclude_folders_add)) { _, _ ->
            showAddFolderDialog()
        }

        builder.show()
    }

    private fun showAddFolderDialog() {
        val input = TextInputEditText(this).apply {
            hint = getString(R.string.settings_exclude_folders_hint)
            setPadding(48, 32, 48, 16)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.settings_exclude_folders_add))
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                val folder = input.text?.toString()?.trim() ?: ""
                if (folder.isNotEmpty()) {
                    val folders = getExcludedFolders().also { it.add(folder) }
                    saveExcludedFolders(folders)
                    refreshExcludedCount()
                    Toast.makeText(this, getString(R.string.settings_exclude_folders_saved), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun setupHistory() {
        binding.rowHistory?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.HistoryActivity::class.java))
        }
    }

    private fun setupAccentColor() {
        // Mostrar color actual
        val currentKey = ThemeManager.getCurrentAccentKey(this)
        val current = ThemeManager.accentOptions.firstOrNull { it.key == currentKey }
            ?: ThemeManager.accentOptions[0]
        binding.tvAccentCurrent?.text = current.nameEs
        updateAccentPreview(current.color)

        binding.rowAccentColor?.setOnClickListener {
            val names  = ThemeManager.accentOptions.map { it.nameEs }.toTypedArray()
            val keys   = ThemeManager.accentOptions.map { it.key }
            val colors = ThemeManager.accentOptions.map { it.color }
            val checked = keys.indexOf(ThemeManager.getCurrentAccentKey(this)).coerceAtLeast(0)

            MaterialAlertDialogBuilder(this)
                .setTitle("Color de acento")
                .setSingleChoiceItems(names, checked) { dialog, which ->
                    ThemeManager.setAccentColor(this, keys[which])
                    binding.tvAccentCurrent?.text = names[which]
                    updateAccentPreview(colors[which])
                    dialog.dismiss()
                    // Notificar al usuario que reinicie para ver todos los cambios
                    Toast.makeText(this, "Color aplicado. Reinicia la app para ver todos los cambios.", Toast.LENGTH_LONG).show()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun updateAccentPreview(color: Int) {
        binding.vAccentPreview?.let { v ->
            val bg = v.background?.mutate() ?: return
            DrawableCompat.setTint(bg, color)
            v.background = bg
        }
    }

    private fun setupCustomBackground() {
        refreshBackgroundState()
        binding.rowCustomBackground?.setOnClickListener {
            val hasBackground = ThemeManager.hasCustomBackground(this)
            val options = if (hasBackground) {
                arrayOf("Cambiar imagen de fondo", "Quitar fondo personalizado")
            } else {
                arrayOf("Elegir imagen de fondo")
            }
            MaterialAlertDialogBuilder(this)
                .setTitle("Fondo personalizado")
                .setItems(options) { _, which ->
                    when {
                        which == 0 -> backgroundPicker.launch("image/*")
                        hasBackground && which == 1 -> {
                            ThemeManager.clearCustomBackground(this)
                            refreshBackgroundState()
                            Toast.makeText(this, "Fondo eliminado", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .show()
        }
    }

    private fun refreshBackgroundState() {
        binding.tvBackgroundCurrent?.text = if (ThemeManager.hasCustomBackground(this)) {
            "Fondo personalizado activo ✓"
        } else {
            "Sin fondo personalizado"
        }
    }

    private fun setupAbout() {
        binding.tvVersion.text = "${getString(R.string.about_version)} ${com.aeroplayer.BuildConfig.VERSION_NAME}"
        setupCrashLogs()
    }

    private fun setupCrashLogs() {
        binding.btnCopyLogs.setOnClickListener {
            val logs = com.aeroplayer.utils.CrashLogger.readLogs(this)
            if (logs.isBlank()) {
                android.widget.Toast.makeText(this, "No hay crashes registrados ✓", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val clipboard = getSystemService(android.content.ClipboardManager::class.java)
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("AeroPlayer Crash Log", logs))
            android.widget.Toast.makeText(this, "Log copiado al portapapeles", android.widget.Toast.LENGTH_LONG).show()
        }

        binding.btnClearLogs.setOnClickListener {
            com.aeroplayer.utils.CrashLogger.clearLogs(this)
            android.widget.Toast.makeText(this, "Logs borrados", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
