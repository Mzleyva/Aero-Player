package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentFilesBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class SortOrder {
    TITLE, ARTIST, ALBUM, DURATION,
    DATE_ADDED,        // más reciente primero (usa lastModified del archivo)
    YEAR,              // año de lanzamiento
    RECENTLY_EDITED,   // modificado recientemente
    FORMAT             // agrupado por formato (FLAC, MP3, etc.)
}

class FilesFragment : Fragment() {

    private var _binding: FragmentFilesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: SongListAdapter

    private var currentSort = SortOrder.DATE_ADDED

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFilesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSortButton()
        setupShuffleButton()
        observePagingData()
        observeLiked()
        observeLoadState()
    }

    private fun setupRecyclerView() {
        adapter = SongListAdapter(
            viewLifecycleOwner.lifecycleScope,
            onSongClick     = { song, _ ->
                val songs = sortedSongs()
                PlayerController.playSongs(
                    songs, songs.indexOf(song).coerceAtLeast(0),
                    queueName = getString(R.string.tab_files)
                )
                viewModel.incrementPlayCount(song)
            },
            onLikeClick     = { song -> viewModel.toggleLike(song) },
            onAddToPlaylist = { song -> showAddToPlaylistDialog(song) },
            onAddToQueue    = { song -> PlayerController.addToQueue(song) }
        )
        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter       = this@FilesFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupSortButton() {
        binding.btnSort.setOnClickListener {
            val labels = listOf(
                "Por título"              to SortOrder.TITLE,
                "Por artista"             to SortOrder.ARTIST,
                "Por álbum"               to SortOrder.ALBUM,
                "Por duración"            to SortOrder.DURATION,
                "Agregado recientemente"  to SortOrder.DATE_ADDED,
                "Por año"                 to SortOrder.YEAR,
                "Editado recientemente"   to SortOrder.RECENTLY_EDITED,
                "Por formato"             to SortOrder.FORMAT
            )
            val options = labels.map { (label, order) ->
                "$label${if (currentSort == order) " ✓" else ""}"
            }.toTypedArray()

            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Ordenar por")
                .setItems(options) { _, idx ->
                    currentSort = labels[idx].second
                    applySortToViewModel()
                }
                .show()
        }
    }

    /** Botón de reproducción aleatoria de todos los archivos. */
    private fun setupShuffleButton() {
        binding.btnShuffleAll?.setOnClickListener {
            val all = viewModel.allSongs.value ?: return@setOnClickListener
            if (all.isEmpty()) return@setOnClickListener
            val shuffled = all.shuffled()
            PlayerController.playSongs(shuffled, 0, queueName = "Aleatorio")
            Snackbar.make(binding.root,
                "▶ ${shuffled.size} canciones en aleatorio", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun sortedSongs(): List<Song> {
        val all = viewModel.allSongs.value ?: return emptyList()
        return applySortOrder(all, currentSort)
    }

    private fun applySortOrder(all: List<Song>, order: SortOrder): List<Song> = when (order) {
        SortOrder.TITLE           -> all.sortedBy { it.title.lowercase() }
        SortOrder.ARTIST          -> all.sortedBy { it.artist.lowercase() }
        SortOrder.ALBUM           -> all.sortedBy { it.album.lowercase() }
        SortOrder.DURATION        -> all.sortedByDescending { it.duration }
        SortOrder.DATE_ADDED      -> all.sortedByDescending {
            java.io.File(it.path).lastModified()
        }
        SortOrder.YEAR            -> all.sortedByDescending { it.year }
        SortOrder.RECENTLY_EDITED -> all.sortedByDescending {
            java.io.File(it.path).lastModified()
        }
        SortOrder.FORMAT          -> all.sortedWith(
            compareBy({ it.formatLabel }, { it.title.lowercase() })
        )
    }

    private fun observePagingData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.songsPagingData.collectLatest { pagingData ->
                adapter.submitData(pagingData)
            }
        }
        viewModel.allSongs.observe(viewLifecycleOwner) { _ ->
            applySortToViewModel()
        }
    }

    private fun applySortToViewModel() {
        val all = viewModel.allSongs.value ?: return
        val sorted = applySortOrder(all, currentSort)
        val label = when (currentSort) {
            SortOrder.TITLE           -> "título"
            SortOrder.ARTIST          -> "artista"
            SortOrder.ALBUM           -> "álbum"
            SortOrder.DURATION        -> "duración"
            SortOrder.DATE_ADDED      -> "agregado recientemente"
            SortOrder.YEAR            -> "año"
            SortOrder.RECENTLY_EDITED -> "editado recientemente"
            SortOrder.FORMAT          -> "formato"
        }
        viewModel.submitSortedSongs(sorted)
        binding.tvCount.text = "${sorted.size} canciones · $label"
    }

    private fun observeLoadState() {
        viewLifecycleOwner.lifecycleScope.launch {
            adapter.loadStateFlow.collectLatest { states ->
                val refresh = states.refresh
                binding.tvEmpty.visibility =
                    if (refresh is LoadState.NotLoading && adapter.itemCount == 0)
                        View.VISIBLE else View.GONE
            }
        }
    }

    private fun observeLiked() {
        viewModel.likedSongs.observe(viewLifecycleOwner) { liked ->
            adapter.updateLikedIds(liked.map { it.songId }.toSet())
        }
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = viewModel.playlists.value ?: return
        if (playlists.isEmpty()) {
            Snackbar.make(binding.root, "Crea una playlist primero",
                Snackbar.LENGTH_SHORT).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Agregar a playlist")
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                Snackbar.make(binding.root, "Agregado a ${playlists[idx].name}",
                    Snackbar.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
