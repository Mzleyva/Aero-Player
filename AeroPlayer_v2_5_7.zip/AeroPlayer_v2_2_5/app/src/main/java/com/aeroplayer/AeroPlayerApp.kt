package com.aeroplayer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aeroplayer.utils.CrashLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AeroPlayerApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        CrashLogger.init(this)

        // Configurar el canal de Media3 con los atributos correctos ANTES de que
        // Media3 lo cree por su cuenta. Si Media3 lo crea primero con IMPORTANCE_DEFAULT
        // aparecerá el sonido de notificación al cambiar de canción.
        // Si nosotros lo creamos primero con IMPORTANCE_LOW, Media3 usará el nuestro.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            // Media3 DefaultMediaNotificationProvider usa este ID exacto
            val existing = nm.getNotificationChannel("default_channel_id")
            if (existing == null) {
                val ch = NotificationChannel(
                    "default_channel_id",
                    "Reproducción de música",
                    NotificationManager.IMPORTANCE_LOW  // sin sonido, sin vibración
                ).apply {
                    description = "Controles de reproducción de AeroPlayer"
                    setShowBadge(false)
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }

        appScope.launch(Dispatchers.IO) {
            com.aeroplayer.data.repository.ArtworkProvider.init(applicationContext)
            com.aeroplayer.data.repository.ArtistImageProvider.init(applicationContext)
        }
    }
}
