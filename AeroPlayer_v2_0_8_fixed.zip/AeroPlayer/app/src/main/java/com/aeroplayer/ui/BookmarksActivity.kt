package com.aeroplayer.ui

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.data.db.AppDatabase
import com.aeroplayer.data.db.BookmarkEntity
import com.aeroplayer.service.PlayerController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Gestión de marcadores: lista todos los marcadores guardados,
 * permite saltar a la posición marcada o eliminarlos.
 * Se abre desde el menú del player (3 puntos → Marcadores).
 */
class BookmarksActivity : AppCompatActivity() {

    private val db by lazy { AppDatabase.getInstance(this) }
    private lateinit var listContainer: LinearLayout
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        val tvTitle = TextView(this).apply {
            text = "Marcadores"
            textSize = 20f
            setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        // Botón agregar marcador (para la canción actual)
        val btnAdd = ImageButton(this).apply {
            setImageResource(R.drawable.ic_add)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { addBookmarkForCurrentSong() }
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(btnAdd)
        root.addView(toolbar)

        // Hint
        root.addView(TextView(this).apply {
            text = "Toca un marcador para saltar · Long press para eliminar"
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(20.dp, 0, 20.dp, 8.dp)
        })

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listContainer)
        root.addView(scroll)
        setContentView(root)

        // Observar marcadores (excluir posiciones automáticas)
        db.bookmarkDao().getAllBookmarks().observe(this) { all ->
            val visible = all.filter { it.label != "__last_position__" }
            renderBookmarks(visible)
        }
    }

    private fun renderBookmarks(bookmarks: List<BookmarkEntity>) {
        listContainer.removeAllViews()
        if (bookmarks.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "No hay marcadores.\nToca ＋ mientras escuchas para agregar uno."
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(getColor(R.color.text_secondary))
                setPadding(32.dp, 48.dp, 32.dp, 48.dp)
            })
            return
        }
        // Agrupar por canción
        val grouped = bookmarks.groupBy { it.songId }
        grouped.forEach { (_, marks) ->
            val first = marks.first()
            // Cabecera de canción
            listContainer.addView(TextView(this).apply {
                text = first.title
                textSize = 14f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(getColor(R.color.text_primary))
                setPadding(20.dp, 12.dp, 20.dp, 4.dp)
            })
            marks.sortedBy { it.positionMs }.forEach { bm ->
                listContainer.addView(buildBookmarkRow(bm))
            }
        }
    }

    private fun buildBookmarkRow(bm: BookmarkEntity): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20.dp, 10.dp, 20.dp, 10.dp)
            background = android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { getDrawable(it) }
            isClickable = true; isFocusable = true
        }
        val progress = if (bm.durationMs > 0)
            "${(bm.positionMs * 100 / bm.durationMs)}%"
        else formatMs(bm.positionMs)

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = bm.label
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
        })
        texts.addView(TextView(this).apply {
            text = "${formatMs(bm.positionMs)} · $progress"
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
        })

        val btnDel = ImageButton(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(0x88FFFFFF.toInt())
            background = null
            layoutParams = LinearLayout.LayoutParams(36.dp, 36.dp)
            setOnClickListener { confirmDelete(bm) }
        }

        row.addView(texts)
        row.addView(btnDel)

        row.setOnClickListener {
            // Saltar a la posición si la canción está en la cola
            val current = PlayerController.currentSong.value
            if (current?.id == bm.songId) {
                PlayerController.seekTo(bm.positionMs)
                Snackbar.make(listContainer,
                    "Saltando a ${formatMs(bm.positionMs)}", Snackbar.LENGTH_SHORT).show()
            } else {
                Snackbar.make(listContainer,
                    "Reproduce \"${bm.title}\" primero", Snackbar.LENGTH_SHORT).show()
            }
        }
        row.setOnLongClickListener { confirmDelete(bm); true }
        return row
    }

    private fun addBookmarkForCurrentSong() {
        val song = PlayerController.currentSong.value ?: run {
            Snackbar.make(listContainer, "No hay canción reproduciéndose",
                Snackbar.LENGTH_SHORT).show()
            return
        }
        val pos = PlayerController.getCurrentPosition()
        val input = EditText(this).apply {
            hint = "Etiqueta del marcador"
            setText("Marca ${formatMs(pos)}")
            setPadding(48.dp, 24.dp, 48.dp, 8.dp)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Agregar marcador")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val label = input.text?.toString()?.trim()?.ifBlank { "Marca ${formatMs(pos)}" }
                    ?: return@setPositiveButton
                lifecycleScope.launch(Dispatchers.IO) {
                    db.bookmarkDao().insert(BookmarkEntity(
                        songId     = song.id,
                        title      = song.title,
                        label      = label,
                        positionMs = pos,
                        durationMs = PlayerController.getDuration()
                    ))
                    withContext(Dispatchers.Main) {
                        Snackbar.make(listContainer, "Marcador guardado ✓",
                            Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun confirmDelete(bm: BookmarkEntity) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar marcador")
            .setMessage("¿Eliminar \"${bm.label}\"?")
            .setPositiveButton("Eliminar") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) { db.bookmarkDao().delete(bm.id) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
}
