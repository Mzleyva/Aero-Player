package com.aeroplayer.ui.visualizer

import android.content.Context
import android.graphics.*
import android.media.audiofx.Visualizer
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

/**
 * AudioVisualizerView — v2.1
 * Sesión 4 fixes:
 *  - Velocidad de respuesta configurable (smoothFactor): antes fijo en 0.25 → barras
 *    muy lentas. Ahora default 0.65 (mucho más reactivo).
 *  - Paleta de colores completamente personalizable (6 temas + custom).
 *  - Sensibilidad configurable: amplifica el rango útil del FFT.
 *  - Más barras por defecto (80 en lugar de 64) con opción 32/64/80/128.
 *  - captureRate al máximo (antes /2 → animación a la mitad de FPS posibles).
 *  - Modo MIRROR: barras simétricas desde el centro.
 */
class AudioVisualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode       { BARS, WAVE, CIRCLE, MIRROR }
    enum class ColorTheme {
        AERO,       // azul-rosa original
        FIRE,       // naranja-rojo-amarillo
        FOREST,     // verde-esmeralda
        SUNSET,     // morado-naranja-dorado
        MONO_WHITE, // blanco puro
        MONO_ACCENT,// usa accentColor externo
        ALBUM       // colores extraídos de la portada del álbum
    }

    private var visualizer:  Visualizer? = null
    private var fftBytes:    ByteArray  = ByteArray(0)
    private var waveBytes:   ByteArray  = ByteArray(0)
    private var mode:        Mode       = Mode.BARS
    private var smoothedFft: FloatArray = FloatArray(0)

    // ── Parámetros configurables ─────────────────────────────────────────────
    var smoothFactor:  Float      = 0.65f   // 0.1=muy lento … 1.0=sin suavizado
        set(v) { field = v.coerceIn(0.05f, 1f) }
    var sensitivity:   Float      = 1.8f    // amplificación del FFT (1.0=original)
        set(v) { field = v.coerceIn(0.5f, 4f) }
    var barCount:      Int        = 80
        set(v) { field = v.coerceIn(16, 128) }
    var colorTheme:    ColorTheme = ColorTheme.AERO
    var accentColor:   Int        = 0xFF7EC8E3.toInt()  // usado por MONO_ACCENT
    // Colores de la portada del álbum (usados con ColorTheme.ALBUM)
    private var paletteVibrant: Int = 0xFF7EC8E3.toInt()
    private var paletteMuted:   Int = 0xFF5B9BD4.toInt()
    // Bitmap de portada para el modo CIRCLE (mostrado en el centro)
    var albumBitmap: android.graphics.Bitmap? = null

    /** Recibe los colores extraídos por Palette y actualiza el visualizador. */
    fun applyPaletteColor(vibrant: Int, muted: Int) {
        paletteVibrant = vibrant
        paletteMuted   = muted
        colorTheme     = ColorTheme.ALBUM
        invalidate()
    }

    // ── Paints ───────────────────────────────────────────────────────────────
    private val barPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(16f, BlurMaskFilter.Blur.NORMAL)
    }
    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f
    }

    // ── Colors per theme ─────────────────────────────────────────────────────
    private fun themeColors(): IntArray = when (colorTheme) {
        ColorTheme.AERO       -> intArrayOf(0xFF7EC8E3.toInt(), 0xFF5B9BD4.toInt(), 0xFFE879A2.toInt())
        ColorTheme.FIRE       -> intArrayOf(0xFFFF6B00.toInt(), 0xFFFF3D00.toInt(), 0xFFFFD700.toInt())
        ColorTheme.FOREST     -> intArrayOf(0xFF00E676.toInt(), 0xFF00BFA5.toInt(), 0xFF76FF03.toInt())
        ColorTheme.SUNSET     -> intArrayOf(0xFFAA00FF.toInt(), 0xFFFF6D00.toInt(), 0xFFFFD600.toInt())
        ColorTheme.MONO_WHITE -> intArrayOf(0xFFFFFFFF.toInt(), 0xCCFFFFFF.toInt(), 0x88FFFFFF.toInt())
        ColorTheme.MONO_ACCENT-> intArrayOf(accentColor, accentColor and 0x00FFFFFF or 0xCC000000.toInt(), accentColor)
        ColorTheme.ALBUM      -> intArrayOf(paletteVibrant, paletteMuted,
            androidx.core.graphics.ColorUtils.blendARGB(paletteVibrant, paletteMuted, 0.5f))
    }

    fun init(audioSessionId: Int) {
        release()
        if (audioSessionId == 0) return
        runCatching {
            visualizer = Visualizer(audioSessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, sr: Int) {
                        fftBytes = fft; smooth(fft); postInvalidateOnAnimation()
                    }
                    override fun onWaveFormDataCapture(v: Visualizer, wave: ByteArray, sr: Int) {
                        waveBytes = wave
                    }
                // FIX: usar tasa máxima completa (antes /2 → animación a mitad de FPS)
                }, Visualizer.getMaxCaptureRate(), true, true)
                enabled = true
            }
        }
    }

    fun release() { runCatching { visualizer?.enabled = false; visualizer?.release() }; visualizer = null }
    fun setMode(m: Mode) { mode = m; invalidate() }
    fun getMode() = mode

    private fun smooth(fft: ByteArray) {
        val n = fft.size / 2
        if (smoothedFft.size != n) { smoothedFft = FloatArray(n); return }
        for (i in 0 until n) {
            // FIX: aplicar sensibilidad al raw antes de suavizar
            val raw = ((fft[i].toInt() and 0xFF).toFloat() * sensitivity).coerceIn(0f, 255f)
            smoothedFft[i] = smoothedFft[i] * (1f - smoothFactor) + raw * smoothFactor
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (smoothedFft.isEmpty() && waveBytes.isEmpty()) { drawIdle(canvas); return }
        when (mode) {
            Mode.BARS   -> drawBars(canvas, mirror = false)
            Mode.MIRROR -> drawBars(canvas, mirror = true)
            Mode.WAVE   -> drawWave(canvas)
            Mode.CIRCLE -> drawCircle(canvas)
        }
    }

    private fun drawBars(canvas: Canvas, mirror: Boolean) {
        if (smoothedFft.isEmpty()) return
        val fft = smoothedFft
        val w = width.toFloat(); val h = height.toFloat()
        val nBars = minOf(fft.size, barCount)
        val barW = w / nBars; val gap = barW * 0.18f
        val colors = themeColors()

        barPaint.shader = LinearGradient(0f, 0f, 0f, h, colors, null, Shader.TileMode.CLAMP)
        glowPaint.shader = barPaint.shader

        for (i in 0 until nBars) {
            val mag = (fft[i * fft.size / nBars] / 255f).coerceIn(0f, 1f)
            val barH = (mag * h * (if (mirror) 0.45f else 0.9f)).coerceAtLeast(2f)
            val x = i * barW + gap / 2f

            if (mirror) {
                // Barras simétricas desde el centro
                val midY = h / 2f
                val rect = RectF(x, midY - barH, x + barW - gap, midY + barH)
                canvas.drawRoundRect(rect, 3f, 3f, barPaint)
                if (mag > 0.5f) {
                    glowPaint.alpha = ((mag - 0.5f) / 0.5f * 60).toInt()
                    canvas.drawRoundRect(rect, 3f, 3f, glowPaint)
                }
            } else {
                val rect = RectF(x, h - barH, x + barW - gap, h)
                canvas.drawRoundRect(rect, 3f, 3f, barPaint)
                if (mag > 0.55f) {
                    glowPaint.alpha = ((mag - 0.55f) / 0.45f * 70).toInt()
                    canvas.drawRoundRect(rect, 3f, 3f, glowPaint)
                }
            }
        }
    }

    private fun drawWave(canvas: Canvas) {
        if (waveBytes.isEmpty()) return
        val wave = waveBytes
        val w = width.toFloat(); val h = height.toFloat(); val midY = h / 2f
        val step = wave.size.toFloat() / w
        val colors = themeColors()
        wavePaint.shader = LinearGradient(0f, 0f, w, 0f, colors, null, Shader.TileMode.CLAMP)
        val path = Path()
        fun waveY(i: Int): Float {
            val s = ((wave[(i * step).toInt().coerceIn(wave.indices)].toInt() and 0xFF) - 128) / 128f
            return (midY - s * midY * 0.85f).coerceIn(0f, h)
        }
        path.moveTo(0f, waveY(0))
        for (i in 1 until w.toInt()) {
            val prev = PointF((i - 1).toFloat(), waveY(i - 1))
            val cur  = PointF(i.toFloat(), waveY(i))
            val cpx  = (prev.x + cur.x) / 2f
            path.cubicTo(cpx, prev.y, cpx, cur.y, cur.x, cur.y)
        }
        canvas.save(); canvas.clipRect(0f, 0f, w, h)
        canvas.drawPath(path, wavePaint); canvas.restore()
        canvas.drawLine(0f, midY, w, midY, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x22FFFFFF; style = Paint.Style.STROKE; strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f) })
    }

    private fun drawCircle(canvas: Canvas) {
        if (smoothedFft.isEmpty()) return
        val fft = smoothedFft
        val cx = width / 2f; val cy = height / 2f
        val baseR = minOf(cx, cy) * 0.42f
        val energy = fft.take(32).map { it / 255f }.average().toFloat()
        val colors = themeColors()
        circlePaint.shader = SweepGradient(cx, cy,
            intArrayOf(colors[0], colors[1], colors[2], colors[0]), null)
        canvas.drawCircle(cx, cy, baseR + energy * 18f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2.5f; color = colors[0] and 0x88FFFFFF.toInt() or 0x88000000.toInt() })
        val nSpokes = minOf(fft.size, 128)
        for (i in 0 until nSpokes) {
            val angle = (i.toFloat() / nSpokes) * 2f * PI.toFloat()
            val mag   = (fft[i * fft.size / nSpokes] / 255f).coerceIn(0f, 1f)
            val r2    = baseR + mag * baseR * 0.85f
            circlePaint.alpha = (80 + mag * 175).toInt().coerceIn(0, 255)
            canvas.drawLine(
                (cx + baseR * cos(angle)), (cy + baseR * sin(angle)),
                (cx + r2    * cos(angle)), (cy + r2    * sin(angle)),
                circlePaint)
        }
        glowPaint.color = colors[1] and 0x00FFFFFF or 0x44000000.toInt()
        glowPaint.maskFilter = BlurMaskFilter(28f + energy * 28f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(cx, cy, baseR * 0.28f + energy * 14f, glowPaint)

        // Mostrar portada del álbum en el centro del círculo
        val bmp = albumBitmap
        if (bmp != null && !bmp.isRecycled) {
            val centerR = baseR * 0.52f
            val left  = cx - centerR; val top  = cy - centerR
            val right = cx + centerR; val bottom = cy + centerR
            val dst = android.graphics.RectF(left, top, right, bottom)
            val albumPath = android.graphics.Path().apply {
                addOval(dst, android.graphics.Path.Direction.CW)
            }
            canvas.save()
            canvas.clipPath(albumPath)
            canvas.drawBitmap(bmp, null, dst, null)
            canvas.restore()
            // Borde luminoso alrededor de la portada
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 2.5f
                color = colors[0]
                alpha = (140 + energy * 115).toInt().coerceIn(0, 255)
            }
            canvas.drawOval(dst, borderPaint)
        }
    }

    private fun drawIdle(canvas: Canvas) {
        canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x33FFFFFF; style = Paint.Style.STROKE; strokeWidth = 2f
                pathEffect = DashPathEffect(floatArrayOf(8f, 8f), 0f) })
    }
}
