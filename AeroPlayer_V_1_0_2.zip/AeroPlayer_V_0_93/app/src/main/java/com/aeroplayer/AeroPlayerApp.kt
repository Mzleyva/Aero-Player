package com.aeroplayer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aeroplayer.utils.CrashLogger

class AeroPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        CrashLogger.init(this)
        com.aeroplayer.data.repository.ArtworkProvider.init(this)
        com.aeroplayer.data.repository.ArtistImageProvider.init(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            // FIX doble notificación: Media3 DefaultMediaNotificationProvider usa
            // "default_channel_id" internamente. Si creamos un canal DISTINTO y además
            // Media3 crea el suyo, aparecen DOS notificaciones de música simultáneas.
            // Solución: crear UN SOLO canal con el mismo ID que usa Media3, con los
            // atributos que queremos (sin sonido, sin vibración, lockscreen público).
            // Ya no creamos "aero_playback_channel" — ese canal huérfano era la segunda notificación.
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK,           // = "default_channel_id" — mismo que Media3
                "Reproducción de música",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción de AeroPlayer"
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            nm.createNotificationChannel(playbackChannel)
        }
    }

    companion object {
        // Debe coincidir con el ID interno de Media3 DefaultMediaNotificationProvider
        const val CHANNEL_PLAYBACK = "default_channel_id"
    }
}
