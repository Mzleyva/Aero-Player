package com.aeroplayer.ui

import android.app.Activity
import android.content.ContentValues
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Editor de etiquetas por lote.
 * v1.8.2 — FIX PERMISOS:
 *  - Android 10+ (API 29+): usa MediaStore.createWriteRequest para solicitar
 *    permiso de escritura sobre archivos que no son de la app.
 *  - Android 9 y anteriores: WRITE_EXTERNAL_STORAGE ya está en el Manifest.
 *  - RecoverableSecurityException como fallback adicional por si el sistema
 *    rechaza la escritura sin lanzar el diálogo de permiso.
 */
class BatchTagEditorActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val selected = mutableSetOf<Long>()
    private lateinit var adapter: BatchAdapter
    private lateinit var rv: RecyclerView
    private lateinit var tvSelectedCount: TextView
    private lateinit var btnEdit: Button
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    // Cambios pendientes a aplicar después de que el usuario acepte el permiso
    private var pendingBatchChanges: Map<String, String?>? = null
    private var pendingSingleEdit: Triple<Song, String, String>? = null  // song, title, artist+album packed

    /**
     * Launcher para MediaStore.createWriteRequest (Android 10+).
     * Se lanza cuando intentamos editar archivos sin tener permiso de escritura.
     */
    private lateinit var writeRequestLauncher: ActivityResultLauncher<IntentSenderRequest>

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        // Registrar el launcher ANTES de que se configure la UI
        writeRequestLauncher = registerForActivityResult(
            ActivityResultContracts.StartIntentSenderForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                // El usuario aceptó — reintentar la operación pendiente
                pendingBatchChanges?.let { applyBatchEdit(it, retryAfterPermission = true) }
                pendingSingleEdit?.let   { (song, newTitle, combo) ->
                    val parts = combo.split("\u0000", limit = 2)
                    saveSingleEdit(song, newTitle, parts.getOrElse(0) { song.artist }, parts.getOrElse(1) { song.album }, retryAfterPermission = true)
                }
            } else {
                Snackbar.make(rv, "Permiso denegado — no se pudo editar", Snackbar.LENGTH_LONG).show()
            }
            pendingBatchChanges = null
            pendingSingleEdit   = null
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // ── Toolbar ──────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        tvSelectedCount = TextView(this).apply {
            text = "Editor por lote"
            textSize = 18f
            setTextColor(getColor(R.color.text_primary))
            setPadding(12.dp, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnSelectAll = TextView(this).apply {
            text = "Todos"
            textSize = 14f
            setTextColor(getColor(R.color.accent_blue))
            setPadding(8.dp, 8.dp, 0, 8.dp)
        }
        btnEdit = Button(this).apply {
            text = "Editar"
            isEnabled = false
            setPadding(16.dp, 0, 16.dp, 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 40.dp
            ).also { it.marginStart = 8.dp }
        }
        toolbar.addView(btnBack)
        toolbar.addView(tvSelectedCount)
        toolbar.addView(btnSelectAll)
        toolbar.addView(btnEdit)
        root.addView(toolbar)

        // ── Aviso de permisos ─────────────────────────────────────────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            root.addView(TextView(this).apply {
                text = "ℹ️  En Android 10+ se pedirá confirmación para editar cada lote de canciones."
                textSize = 12f
                setTextColor(getColor(R.color.text_secondary))
                setPadding(16.dp, 4.dp, 16.dp, 4.dp)
            })
        }

        // ── RecyclerView ──────────────────────────────────────────────────────
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@BatchTagEditorActivity)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        adapter = BatchAdapter(
            onSelect   = { song -> toggleSelect(song.id) },
            onLongTap  = { song -> showSingleEditDialog(song) },
            isSelected = { id   -> selected.contains(id) }
        )
        rv.adapter = adapter
        root.addView(rv)

        setContentView(root)

        // Cargar canciones
        viewModel.allSongs.observe(this) { songs: List<com.aeroplayer.model.Song> ->
            adapter.submitList(songs)
        }

        btnSelectAll.setOnClickListener {
            val allIds = adapter.currentList.map { it.id }
            if (selected.size == allIds.size) {
                selected.clear()
            } else {
                selected.addAll(allIds)
            }
            adapter.notifyDataSetChanged()
            updateSelectionUI()
        }

        btnEdit.setOnClickListener { showBatchEditDialog() }
    }

    private fun toggleSelect(id: Long) {
        if (selected.contains(id)) selected.remove(id) else selected.add(id)
        adapter.notifyDataSetChanged()
        updateSelectionUI()
    }

    private fun updateSelectionUI() {
        val n = selected.size
        tvSelectedCount.text = if (n == 0) "Editor por lote" else "$n seleccionada${if (n != 1) "s" else ""}"
        btnEdit.isEnabled = n > 0
    }

    // ── Diálogo de edición por lote ───────────────────────────────────────────
    private fun showBatchEditDialog() {
        val fields  = listOf("Artista", "Álbum", "Año", "Género")
        val checked = BooleanArray(fields.size) { false }
        val inputs  = fields.map { hint ->
            TextInputEditText(this).apply { this.hint = hint }
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 8.dp, 24.dp, 0)
        }
        fields.forEachIndexed { i, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                setPadding(0, 4.dp, 0, 4.dp)
            }
            val cb = CheckBox(this).apply {
                this.text = ""
                isChecked = false
                setOnCheckedChangeListener { _, c ->
                    checked[i] = c
                    inputs[i].isEnabled = c
                }
            }
            val til = TextInputLayout(this).apply {
                hint = label
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                addView(inputs[i].also { it.isEnabled = false })
            }
            row.addView(cb); row.addView(til)
            container.addView(row)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Editar ${selected.size} canciones")
            .setMessage("Solo se cambiarán los campos marcados.")
            .setView(container)
            .setPositiveButton("Aplicar") { _, _ ->
                val changes = mapOf(
                    MediaStore.Audio.Media.ARTIST to (if (checked[0]) inputs[0].text?.toString()?.trim() else null),
                    MediaStore.Audio.Media.ALBUM  to (if (checked[1]) inputs[1].text?.toString()?.trim() else null),
                    MediaStore.Audio.Media.YEAR   to (if (checked[2]) inputs[2].text?.toString()?.trim() else null),
                    "genre"                        to (if (checked[3]) inputs[3].text?.toString()?.trim() else null)
                ).filterValues { !it.isNullOrBlank() }

                if (changes.isEmpty()) {
                    Snackbar.make(rv, "No marcaste ningún campo", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                applyBatchEdit(changes)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun applyBatchEdit(changes: Map<String, String?>, retryAfterPermission: Boolean = false) {
        val songs = adapter.currentList.filter { selected.contains(it.id) }
        lifecycleScope.launch(Dispatchers.IO) {
            var ok = 0; var fail = 0
            val needPermission = mutableListOf<Uri>()

            songs.forEach { song ->
                val uri = Uri.withAppendedPath(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id.toString()
                )
                val values = ContentValues().apply {
                    changes[MediaStore.Audio.Media.ARTIST]?.let { put(MediaStore.Audio.Media.ARTIST, it) }
                    changes[MediaStore.Audio.Media.ALBUM]?.let  { put(MediaStore.Audio.Media.ALBUM,  it) }
                    changes[MediaStore.Audio.Media.YEAR]?.let   { put(MediaStore.Audio.Media.YEAR,   it.toIntOrNull() ?: 0) }
                }
                try {
                    val rows = contentResolver.update(uri, values, null, null)
                    if (rows > 0) ok++ else { needPermission.add(uri); fail++ }
                } catch (e: SecurityException) {
                    // Android 10+: puede ser RecoverableSecurityException (subclase de SecurityException)
                    needPermission.add(uri); fail++
                } catch (_: SecurityException) {
                    needPermission.add(uri); fail++
                } catch (_: Exception) {
                    fail++
                }
            }

            withContext(Dispatchers.Main) {
                if (needPermission.isNotEmpty() && !retryAfterPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Solicitar permiso de escritura masiva con createWriteRequest
                    pendingBatchChanges = changes
                    try {
                        val pi = MediaStore.createWriteRequest(contentResolver, needPermission)
                        writeRequestLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    } catch (e: Exception) {
                        Snackbar.make(rv, "No se pudo solicitar permiso: ${e.localizedMessage}", Snackbar.LENGTH_LONG).show()
                    }
                } else {
                    viewModel.loadSongs(forceRefresh = true)
                    selected.clear()
                    adapter.notifyDataSetChanged()
                    updateSelectionUI()
                    val msg = "✓ $ok actualizada${if (ok != 1) "s" else ""}${if (fail > 0) " · $fail sin permiso" else ""}"
                    Snackbar.make(rv, msg, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Edición individual desde long press ───────────────────────────────────
    private fun showSingleEditDialog(song: Song) {
        val titleInput  = TextInputEditText(this).apply { setText(song.title)  }
        val artistInput = TextInputEditText(this).apply { setText(song.artist) }
        val albumInput  = TextInputEditText(this).apply { setText(song.album)  }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 8.dp, 24.dp, 0)
            addView(TextInputLayout(this@BatchTagEditorActivity).apply { hint = "Título";  addView(titleInput)  })
            addView(TextInputLayout(this@BatchTagEditorActivity).apply { hint = "Artista"; addView(artistInput) })
            addView(TextInputLayout(this@BatchTagEditorActivity).apply { hint = "Álbum";   addView(albumInput)  })
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Editar: ${song.title}")
            .setView(container)
            .setPositiveButton("Guardar") { _, _ ->
                val newTitle  = titleInput.text?.toString()?.trim()?.ifBlank  { song.title  } ?: song.title
                val newArtist = artistInput.text?.toString()?.trim()?.ifBlank { song.artist } ?: song.artist
                val newAlbum  = albumInput.text?.toString()?.trim()?.ifBlank  { song.album  } ?: song.album
                saveSingleEdit(song, newTitle, newArtist, newAlbum)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveSingleEdit(song: Song, newTitle: String, newArtist: String, newAlbum: String, retryAfterPermission: Boolean = false) {
        lifecycleScope.launch(Dispatchers.IO) {
            val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id.toString())
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.TITLE,  newTitle)
                put(MediaStore.Audio.Media.ARTIST, newArtist)
                put(MediaStore.Audio.Media.ALBUM,  newAlbum)
            }
            try {
                val rows = contentResolver.update(uri, values, null, null)
                withContext(Dispatchers.Main) {
                    if (rows > 0) {
                        viewModel.loadSongs(forceRefresh = true)
                        Snackbar.make(rv, "✓ Guardado", Snackbar.LENGTH_SHORT).show()
                    } else if (!retryAfterPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        pendingSingleEdit = Triple(song, newTitle, "$newArtist\u0000$newAlbum")
                        try {
                            val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                            writeRequestLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                        } catch (e: Exception) {
                            Snackbar.make(rv, "Error: ${e.localizedMessage}", Snackbar.LENGTH_LONG).show()
                        }
                    } else {
                        Snackbar.make(rv, "No se pudo guardar", Snackbar.LENGTH_SHORT).show()
                    }
                }
            } catch (e: SecurityException) {
                withContext(Dispatchers.Main) {
                    if (!retryAfterPermission && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        pendingSingleEdit = Triple(song, newTitle, "$newArtist\u0000$newAlbum")
                        try {
                            val pi = android.provider.MediaStore.createWriteRequest(
                                contentResolver, listOf(uri)
                            )
                            writeRequestLauncher.launch(
                                IntentSenderRequest.Builder(pi.intentSender).build()
                            )
                        } catch (ex: Exception) {
                            Snackbar.make(rv, "Error de permiso", Snackbar.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Snackbar.make(rv, "Error: ${e.localizedMessage}", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }
}

// ── Adapter ───────────────────────────────────────────────────────────────────
private class BatchAdapter(
    private val onSelect:   (Song)   -> Unit,
    private val onLongTap:  (Song)   -> Unit,
    private val isSelected: (Long)   -> Boolean
) : ListAdapter<Song, BatchAdapter.VH>(SongDiff()) {

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val iv:      android.widget.ImageView = root.getChildAt(0) as android.widget.ImageView
        val tvTitle: TextView                 = (root.getChildAt(1) as LinearLayout).getChildAt(0) as TextView
        val tvSub:   TextView                 = (root.getChildAt(1) as LinearLayout).getChildAt(1) as TextView
        val cbSel:   CheckBox                 = root.getChildAt(2) as CheckBox
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = { n: Int -> (n * ctx.resources.displayMetrics.density).toInt() }
        val iv  = android.widget.ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(48.dp(ctx), 48.dp(ctx)).also { it.marginEnd = 12.dp(ctx) }
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }
        val tvTitle = TextView(ctx).apply { textSize = 14f; setTextColor(ctx.getColor(R.color.text_primary)) }
        val tvSub   = TextView(ctx).apply { textSize = 12f; setTextColor(ctx.getColor(R.color.text_secondary)) }
        val texts   = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(tvTitle); addView(tvSub)
        }
        val cb = CheckBox(ctx).apply { isClickable = false; isFocusable = false }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addView(iv); addView(texts); addView(cb)
        }
        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.tvTitle.text = song.title
        holder.tvSub.text   = "${song.artist} · ${song.album}"
        holder.cbSel.isChecked = isSelected(song.id)
        com.bumptech.glide.Glide.with(holder.iv)
            .load(song.albumArtUri).placeholder(R.drawable.ic_music_placeholder)
            .into(holder.iv)
        holder.root.setBackgroundColor(
            if (isSelected(song.id))
                androidx.core.content.ContextCompat.getColor(holder.root.context, R.color.surface_card)
            else android.graphics.Color.TRANSPARENT
        )
        holder.root.setOnClickListener { onSelect(song) }
        holder.root.setOnLongClickListener { onLongTap(song); true }
    }

    private fun Int.dp(ctx: android.content.Context) = (this * ctx.resources.displayMetrics.density).toInt()
}

private class SongDiff : DiffUtil.ItemCallback<Song>() {
    override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
    override fun areContentsTheSame(a: Song, b: Song) = a == b
}
