package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemArtistBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

data class Artist(
    val name: String,
    val albumCount: Int,
    val songCount: Int,
    val coverUri: android.net.Uri?,
    val songs: List<Song>
)

class ArtistsFragment : Fragment() {

    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val frame = FrameLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(context.getColor(R.color.background_dark))
        }

        val rv = RecyclerView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            layoutManager = LinearLayoutManager(context)
            setPadding(0, 0, 0, 80)
            clipToPadding = false
        }

        val tvEmpty = TextView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            text = "No hay artistas en tu biblioteca"
            setTextColor(context.getColor(R.color.text_secondary))
            textSize = 14f
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        frame.addView(rv)
        frame.addView(tvEmpty)

        val adapter = ArtistListAdapter { artist ->
            val first = artist.songs.firstOrNull()
            if (first != null) viewModel.incrementPlayCount(first)
            PlayerController.playSongs(artist.songs, 0, queueName = artist.songs.firstOrNull()?.artist)
        }
        rv.adapter = adapter

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            val artists = songs
                .groupBy { it.artist }
                .map { (artistName, artistSongs) ->
                    Artist(
                        name       = artistName,
                        albumCount = artistSongs.map { it.album }.distinct().size,
                        songCount  = artistSongs.size,
                        coverUri   = artistSongs.firstOrNull()?.albumArtUri,
                        songs      = artistSongs.sortedBy { it.title }
                    )
                }
                .sortedBy { it.name.lowercase() }
            adapter.submitList(artists)
            // FIX: estado vacío
            tvEmpty.visibility = if (artists.isEmpty()) View.VISIBLE else View.GONE
            rv.visibility      = if (artists.isEmpty()) View.GONE   else View.VISIBLE
        }

        return frame
    }
}

class ArtistListAdapter(
    private val onClick: (Artist) -> Unit
) : ListAdapter<Artist, ArtistListAdapter.VH>(ArtistDiff()) {

    inner class VH(val b: ItemArtistBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemArtistBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val artist = getItem(position)
        holder.b.tvName.text = artist.name
        holder.b.tvInfo.text = buildString {
            append("${artist.albumCount} álbum${if (artist.albumCount != 1) "es" else ""}")
            append(" · ${artist.songCount} canción${if (artist.songCount != 1) "es" else ""}")
        }

        // Intentar cargar imagen del artista:
        // 1. Primero la carátula del álbum del artista (local, inmediato)
        // 2. Luego buscar foto real del artista online en background
        val requestBuilder = Glide.with(holder.b.ivAvatar)
            .load(artist.coverUri)
            .placeholder(R.drawable.ic_person)
            .error(R.drawable.ic_person)
            .transition(DrawableTransitionOptions.withCrossFade())
            .circleCrop()

        // Lanzar búsqueda de imagen de artista en background
        (holder.b.ivAvatar.context as? androidx.lifecycle.LifecycleOwner)?.lifecycleScope?.launch {
            val bitmap = com.aeroplayer.data.repository.ArtistImageProvider
                .fetchArtistImage(artist.name)
            if (bitmap != null) {
                // Mostrar imagen del artista si sigue siendo el mismo item
                val currentArtist = runCatching { getItem(holder.adapterPosition) }.getOrNull()
                if (currentArtist?.name == artist.name) {
                    Glide.with(holder.b.ivAvatar)
                        .load(bitmap)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .circleCrop()
                        .into(holder.b.ivAvatar)
                }
            }
        }

        requestBuilder.into(holder.b.ivAvatar)
        holder.b.root.setOnClickListener { onClick(artist) }
    }

    class ArtistDiff : DiffUtil.ItemCallback<Artist>() {
        override fun areItemsTheSame(a: Artist, b: Artist)    = a.name == b.name
        override fun areContentsTheSame(a: Artist, b: Artist) = a == b
    }
}
