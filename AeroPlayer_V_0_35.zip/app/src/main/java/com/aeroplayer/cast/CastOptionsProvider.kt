package com.aeroplayer.cast

import android.content.Context
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider
import com.google.android.gms.cast.framework.media.CastMediaOptions
import com.google.android.gms.cast.framework.media.MediaIntentReceiver
import com.google.android.gms.cast.framework.media.NotificationOptions
import com.aeroplayer.ui.player.PlayerActivity

/**
 * Proveedor de opciones de Chromecast.
 * Registrado en el Manifest como meta-data para que el SDK lo encuentre automáticamente.
 * Usa el receiver de Default Media App de Google, compatible con cualquier Chromecast.
 */
class CastOptionsProvider : OptionsProvider {

    override fun getCastOptions(context: Context): CastOptions {
        // ID del receptor: DEFAULT_MEDIA_RECEIVER_APP_ID funciona con cualquier
        // Chromecast sin necesidad de registrar una app en Google Cast SDK Console.
        val notificationOptions = NotificationOptions.Builder()
            .setTargetActivityClassName(PlayerActivity::class.java.name)
            .build()

        val mediaOptions = CastMediaOptions.Builder()
            .setNotificationOptions(notificationOptions)
            .setExpandedControllerActivityClassName(PlayerActivity::class.java.name)
            .build()

        return CastOptions.Builder()
            .setReceiverApplicationId("CC1AD845") // Default Media Receiver App ID
            .setCastMediaOptions(mediaOptions)
            .build()
    }

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}
