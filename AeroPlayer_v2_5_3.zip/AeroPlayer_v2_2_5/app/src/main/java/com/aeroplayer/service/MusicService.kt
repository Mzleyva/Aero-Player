package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.exoplayer.upstream.DefaultLoadControl
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.R

/**
 * MusicService — servicio de reproducción limpio basado en Media3 MediaSessionService.
 *
 * DISEÑO DELIBERADAMENTE SIMPLE:
 * Media3 genera la notificación de reproducción automáticamente a través de
 * DefaultMediaNotificationProvider. NO creamos notificaciones manuales, NO usamos
 * setCustomLayout (causaba doble notificación + loop infinito de actualizaciones).
 *
 * Audio:
 *  - Hi-Res / Lossless: extensiones habilitadas (FLAC, ALAC, WAV 24/32bit, OPUS)
 *  - TrackSelector sin restricción de bitrate
 *  - AudioFocus automático (Media3) — pausa en llamadas
 *  - WakeMode LOCAL — pantalla apagada sin consumo extra
 *  - Gapless: buffer alto (120s) para precargar siguiente track sin silencio
 */
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
        @Volatile var instance: MusicService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_NONE)
            .build()

        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxAudioBitrate(Int.MAX_VALUE)
                    .setMaxAudioChannelCount(8)
                    .setPreferredAudioMimeTypes(
                        "audio/flac", "audio/alac", "audio/wav",
                        "audio/x-wav", "audio/vnd.wave", "audio/ogg",
                        "audio/opus", "audio/mpeg", "audio/aac"
                    )
                    .build()
            )
        }

        val renderersFactory = DefaultRenderersFactory(this).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        // Buffer alto para gapless real — Media3 precarga el siguiente item automáticamente
        val loadControl = androidx.media3.exoplayer.upstream.DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                15_000,   // minBufferMs
                120_000,  // maxBufferMs — precarga hasta 2 minutos del siguiente track
                2_500,    // bufferForPlaybackMs
                5_000     // bufferForPlaybackAfterRebufferMs
            )
            .build()

        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Sesión limpia — Media3 maneja la notificación completamente solo.
        // Sin setCustomLayout, sin callbacks extra → una sola notificación, sin loops.
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()

        AudioDeviceEqRouter.register(this)
        instance = this
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        AudioDeviceEqRouter.unregister(this)
        audioSessionId = 0
        instance = null
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}
