package com.aeroplayer.ui.ytmusic

import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemYtSongBinding
import com.aeroplayer.model.YTSong
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Adapter para mostrar resultados de búsqueda de YouTube Music.
 * Reutiliza el layout item_yt_song.xml.
 */
class YTSearchResultsAdapter(
    private val onSongClick: (YTSong) -> Unit,
    private val onAddToQueue: (YTSong) -> Unit
) : ListAdapter<YTSong, YTSearchResultsAdapter.VH>(YTSongDiff()) {

    private var currentQuery: String = ""

    inner class VH(val b: ItemYtSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemYtSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivThumbnail.clipToOutline   = true
        b.ivThumbnail.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text  = highlightQuery(song.title, currentQuery, root.context)
            tvArtist.text = highlightQuery(song.artist, currentQuery, root.context)
            tvDuration.text = formatDuration(song.durationMs)

            Glide.with(ivThumbnail)
                .load(song.thumbnailUrl)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivThumbnail)

            // Badge YT Music
            badgeYtMusic.text = "YT Music"

            ivMore.setOnClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(root.context)
                    .setTitle(song.title)
                    .setItems(arrayOf("Agregar a cola")) { _, which ->
                        if (which == 0) onAddToQueue(song)
                    }.show()
            }

            root.setOnClickListener { onSongClick(song) }
        }
    }

    fun setQuery(query: String) {
        currentQuery = query
        notifyDataSetChanged()
    }

    private fun formatDuration(ms: Long): String {
        if (ms <= 0L) return ""
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return "%d:%02d".format(m, s)
    }

    private fun highlightQuery(text: String, query: String, ctx: android.content.Context): SpannableString {
        val spannable = SpannableString(text)
        if (query.isBlank()) return spannable
        val lower = text.lowercase()
        val lq    = query.lowercase()
        var start = lower.indexOf(lq)
        while (start >= 0) {
            spannable.setSpan(
                ForegroundColorSpan(ContextCompat.getColor(ctx, R.color.accent_blue)),
                start, start + lq.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            start = lower.indexOf(lq, start + 1)
        }
        return spannable
    }

    class YTSongDiff : DiffUtil.ItemCallback<YTSong>() {
        override fun areItemsTheSame(a: YTSong, b: YTSong) = a.id == b.id
        override fun areContentsTheSame(a: YTSong, b: YTSong) = a == b
    }
}
