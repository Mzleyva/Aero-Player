package com.aeroplayer.ui

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.data.db.AppDatabase
import com.aeroplayer.data.db.RadioEntity
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

/**
 * Radios online — usa la API pública radio-browser.info (sin clave).
 * Tabs: Favoritas · Géneros · Buscar · Agregar manual.
 * Reproduce el stream directamente via PlayerController (ExoPlayer soporta HLS/MPEG).
 */
class OnlineRadioActivity : AppCompatActivity() {

    private val db by lazy { AppDatabase.getInstance(this) }
    private lateinit var rv: RecyclerView
    private lateinit var adapter: RadioAdapter
    private lateinit var searchInput: EditText
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    // Géneros predefinidos populares
    private val GENRES = listOf(
        "Pop", "Rock", "Jazz", "Classical", "Electronic",
        "Hip-Hop", "R&B", "Latin", "Country", "News",
        "Sports", "Talk", "Reggae", "Blues", "Metal"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        toolbar.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        })
        toolbar.addView(TextView(this).apply {
            text = "Radios Online"
            textSize = 20f
            setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        })
        toolbar.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_add)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { showAddManualDialog() }
        })
        root.addView(toolbar)

        // Barra de búsqueda
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp, 4.dp, 16.dp, 8.dp)
        }
        searchInput = EditText(this).apply {
            hint = "Buscar emisora…"
            setTextColor(getColor(R.color.text_primary))
            setHintTextColor(getColor(R.color.text_secondary))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF1E1E2E.toInt()); cornerRadius = 24.dp.toFloat()
            }
            setPadding(16.dp, 10.dp, 16.dp, 10.dp)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnSearch = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { searchRadios(searchInput.text.toString().trim()) }
        }
        searchRow.addView(searchInput); searchRow.addView(btnSearch)
        root.addView(searchRow)

        // Tabs de géneros
        val tabLayout = TabLayout(this).apply {
            setBackgroundColor(getColor(R.color.background_dark))
            setTabTextColors(getColor(R.color.text_secondary), getColor(R.color.accent_blue))
            tabMode = TabLayout.MODE_SCROLLABLE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        tabLayout.addTab(tabLayout.newTab().setText("⭐ Favoritas"))
        GENRES.forEach { tabLayout.addTab(tabLayout.newTab().setText(it)) }
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                if (tab.position == 0) loadFavorites()
                else searchByGenre(GENRES[tab.position - 1])
            }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })
        root.addView(tabLayout)

        // Lista
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@OnlineRadioActivity)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            setPadding(0, 0, 0, 80.dp); clipToPadding = false
        }
        adapter = RadioAdapter(
            onPlay      = { radio -> playRadio(radio) },
            onFavorite  = { radio -> toggleFavorite(radio) },
            onDelete    = { radio -> deleteRadio(radio) }
        )
        rv.adapter = adapter
        root.addView(rv)
        setContentView(root)

        // Cargar favoritas al inicio
        loadFavorites()
    }

    // ── Carga de datos ────────────────────────────────────────────────────────

    private fun loadFavorites() {
        db.radioDao().getFavoriteRadios().observe(this) { radios ->
            adapter.submit(radios)
            if (radios.isEmpty()) showEmptyHint("Sin favoritas aún. Busca o agrega una emisora.")
        }
    }

    private fun searchRadios(query: String) {
        if (query.isEmpty()) return
        val url = "https://de1.api.radio-browser.info/json/stations/search?" +
                "name=${java.net.URLEncoder.encode(query, "UTF-8")}&limit=30&order=clickcount&reverse=true"
        fetchAndShow(url)
    }

    private fun searchByGenre(genre: String) {
        val url = "https://de1.api.radio-browser.info/json/stations/bytag/" +
                "${java.net.URLEncoder.encode(genre.lowercase(), "UTF-8")}?limit=30&order=clickcount&reverse=true"
        fetchAndShow(url)
    }

    private fun fetchAndShow(url: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                val json = JSONArray(java.net.URL(url).readText())
                val radios = (0 until json.length()).map { i ->
                    val obj = json.getJSONObject(i)
                    RadioEntity(
                        name      = obj.optString("name").trim().ifBlank { "Sin nombre" },
                        streamUrl = obj.optString("url_resolved").ifBlank { obj.optString("url") },
                        genre     = obj.optString("tags").split(",").firstOrNull()?.trim() ?: "",
                        country   = obj.optString("country"),
                        logoUrl   = obj.optString("favicon").ifBlank { null }
                    )
                }.filter { it.streamUrl.isNotBlank() }
                withContext(Dispatchers.Main) { adapter.submit(radios) }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    Snackbar.make(rv, "Error: ${e.localizedMessage}", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Acciones ──────────────────────────────────────────────────────────────

    private fun playRadio(radio: RadioEntity) {
        if (radio.streamUrl.isBlank()) {
            Snackbar.make(rv, "URL de stream inválida", Snackbar.LENGTH_SHORT).show()
            return
        }
        // Crear un Song con la URL del stream — ExoPlayer lo reproduce directamente
        val streamSong = com.aeroplayer.model.Song(
            id          = radio.id.coerceAtLeast(1L),
            title       = radio.name,
            artist      = radio.country.ifBlank { "Radio Online" },
            album       = radio.genre.ifBlank { "Stream" },
            duration    = 0L,  // live stream, sin duración
            path        = radio.streamUrl,
            uri         = android.net.Uri.parse(radio.streamUrl),
            albumArtUri = radio.logoUrl?.let { android.net.Uri.parse(it) },
            mimeType    = "audio/mpeg"
        )
        PlayerController.playSongs(listOf(streamSong), 0, queueName = radio.name)
        Snackbar.make(rv, "▶ ${radio.name}", Snackbar.LENGTH_SHORT).show()
    }

    private fun toggleFavorite(radio: RadioEntity) {
        lifecycleScope.launch(Dispatchers.IO) {
            if (radio.id == 0L) {
                // Radio de búsqueda — guardar primero
                val newId = db.radioDao().insert(radio.copy(isFavorite = true))
                withContext(Dispatchers.Main) {
                    Snackbar.make(rv, "⭐ ${radio.name} guardada", Snackbar.LENGTH_SHORT).show()
                }
            } else {
                db.radioDao().setFavorite(radio.id, !radio.isFavorite)
                withContext(Dispatchers.Main) {
                    val msg = if (!radio.isFavorite) "⭐ Guardada en favoritas" else "Eliminada de favoritas"
                    Snackbar.make(rv, msg, Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun deleteRadio(radio: RadioEntity) {
        if (radio.id == 0L) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar radio")
            .setMessage("¿Eliminar \"${radio.name}\"?")
            .setPositiveButton("Eliminar") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) { db.radioDao().delete(radio.id) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showAddManualDialog() {
        val dp = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (16 * dp).toInt(), (20 * dp).toInt(), 0)
        }
        val nameInput    = EditText(this).apply { hint = "Nombre de la emisora"; setPadding(4, 8, 4, 8) }
        val urlInput     = EditText(this).apply { hint = "URL del stream (http/https)"; setPadding(4, 8, 4, 8) }
        val genreInput   = EditText(this).apply { hint = "Género (opcional)"; setPadding(4, 8, 4, 8) }
        val countryInput = EditText(this).apply { hint = "País (opcional)"; setPadding(4, 8, 4, 8) }
        listOf(nameInput, urlInput, genreInput, countryInput).forEach { container.addView(it) }

        MaterialAlertDialogBuilder(this)
            .setTitle("Agregar radio manualmente")
            .setView(container)
            .setPositiveButton("Guardar") { _, _ ->
                val name = nameInput.text?.toString()?.trim() ?: ""
                val url  = urlInput.text?.toString()?.trim()  ?: ""
                if (name.isBlank() || url.isBlank()) {
                    Snackbar.make(rv, "Nombre y URL son obligatorios", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                lifecycleScope.launch(Dispatchers.IO) {
                    db.radioDao().insert(RadioEntity(
                        name      = name,
                        streamUrl = url,
                        genre     = genreInput.text?.toString()?.trim() ?: "",
                        country   = countryInput.text?.toString()?.trim() ?: "",
                        isFavorite = true
                    ))
                    withContext(Dispatchers.Main) {
                        Snackbar.make(rv, "Radio guardada ✓", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showEmptyHint(msg: String) {
        // Si el adapter está vacío, mostrar hint
    }
}

// ── Adapter ───────────────────────────────────────────────────────────────────
private class RadioAdapter(
    private val onPlay:     (RadioEntity) -> Unit,
    private val onFavorite: (RadioEntity) -> Unit,
    private val onDelete:   (RadioEntity) -> Unit
) : RecyclerView.Adapter<RadioAdapter.VH>() {

    private val items = mutableListOf<RadioEntity>()

    fun submit(list: List<RadioEntity>) {
        items.clear(); items.addAll(list); notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val ivLogo: ImageView   = root.findViewWithTag("logo")
        val tvName: TextView    = root.findViewWithTag("name")
        val tvSub:  TextView    = root.findViewWithTag("sub")
        val btnFav: ImageButton = root.findViewWithTag("fav")
        val btnDel: ImageButton = root.findViewWithTag("del")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
            isClickable = true; isFocusable = true
        }
        val size = (48 * dp).toInt()
        val iv = ImageView(ctx).apply {
            tag = "logo"
            layoutParams = LinearLayout.LayoutParams(size, size)
                .also { it.marginEnd = (12 * dp).toInt() }
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF1E1E2E.toInt()); cornerRadius = 8 * dp
            }
            clipToOutline = true
        }
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvName = TextView(ctx).apply {
            tag = "name"; textSize = 14f; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_primary))
        }
        val tvSub = TextView(ctx).apply {
            tag = "sub"; textSize = 12f; maxLines = 1
            setTextColor(ctx.getColor(R.color.text_secondary))
        }
        texts.addView(tvName); texts.addView(tvSub)
        val btnFav = ImageButton(ctx).apply {
            tag = "fav"
            setImageResource(R.drawable.ic_bookmark_outline)
            background = null
            layoutParams = LinearLayout.LayoutParams((36 * dp).toInt(), (36 * dp).toInt())
        }
        val btnDel = ImageButton(ctx).apply {
            tag = "del"
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(0x66FFFFFF)
            background = null
            layoutParams = LinearLayout.LayoutParams((36 * dp).toInt(), (36 * dp).toInt())
        }
        row.addView(iv); row.addView(texts); row.addView(btnFav); row.addView(btnDel)
        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val radio = items[pos]
        holder.tvName.text = radio.name
        holder.tvSub.text  = listOf(radio.genre, radio.country)
            .filter { it.isNotBlank() }.joinToString(" · ")
        Glide.with(holder.ivLogo).load(radio.logoUrl)
            .placeholder(R.drawable.ic_play).centerCrop().into(holder.ivLogo)
        holder.btnFav.imageTintList = android.content.res.ColorStateList.valueOf(
            if (radio.isFavorite) 0xFFFFD700.toInt() else 0x88FFFFFF.toInt())
        holder.btnFav.setOnClickListener { onFavorite(radio) }
        holder.btnDel.setOnClickListener { onDelete(radio) }
        holder.root.setOnClickListener { onPlay(radio) }
    }
}
