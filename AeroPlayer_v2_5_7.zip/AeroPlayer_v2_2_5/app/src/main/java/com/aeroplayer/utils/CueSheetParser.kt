package com.aeroplayer.utils

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.aeroplayer.model.Song
import java.io.File

/**
 * CueSheetParser — v1.8.3
 *
 * Lee archivos .cue (embedded o standalone) y genera una lista de Song
 * con los tiempos de inicio/fin de cada pista.
 *
 * Formato soportado:
 *   FILE "album.flac" WAVE
 *     TRACK 01 AUDIO
 *       TITLE "Track Title"
 *       PERFORMER "Artist"
 *       INDEX 01 mm:ss:ff   ← minutos:segundos:frames (75 frames/s)
 *
 * También soporta:
 *   - CUE embebido como tag CUESHEET en Vorbis Comment (FLAC)
 *   - Múltiples FILE dentro del mismo .cue (álbumes multi-archivo)
 *   - REM GENRE, REM DATE, COMMENT para metadatos extra
 */
object CueSheetParser {

    data class CueTrack(
        val trackNumber: Int,
        val title: String,
        val performer: String,
        val audioFilePath: String,     // ruta al archivo de audio correspondiente
        val startMs: Long,             // INDEX 01 convertido a ms
        val endMs: Long,               // calculado como el startMs del track siguiente
        val album: String,
        val albumArtist: String,
        val year: String,
        val genre: String
    )

    data class ParseResult(
        val tracks: List<CueTrack>,
        val errors: List<String>
    )

    // ── Entry points ──────────────────────────────────────────────────────────

    /** Parsea un archivo .cue desde su ruta en disco. */
    fun parseCueFile(cueFilePath: String): ParseResult {
        return runCatching {
            val lines = File(cueFilePath).readLines(Charsets.UTF_8)
            val baseDir = File(cueFilePath).parent ?: ""
            parseLines(lines, baseDir)
        }.getOrElse { e ->
            ParseResult(emptyList(), listOf("Error leyendo archivo: ${e.message}"))
        }
    }

    /** Parsea un CUE embebido en un tag Vorbis (string ya extraído). */
    fun parseEmbeddedCue(cueContent: String, audioFilePath: String): ParseResult {
        val lines = cueContent.lines()
        val result = parseLines(lines, File(audioFilePath).parent ?: "")
        // Para CUE embebidos, si FILE apunta a un nombre relativo, apuntar al audio real
        val fixed = result.tracks.map { t ->
            if (!File(t.audioFilePath).exists()) t.copy(audioFilePath = audioFilePath)
            else t
        }
        return result.copy(tracks = fixed)
    }

    /**
     * Convierte las pistas CUE en objetos Song compatibles con AeroPlayer.
     * Cada Song tendrá:
     *   - path = audioFilePath (el FLAC/MP3 base)
     *   - Un campo extra para indicar cueStart y cueEnd que PlayerController
     *     usa para hacer seekTo al inicio y detener al llegar a cueEnd.
     */
    fun toSongs(tracks: List<CueTrack>, context: Context): List<Song> {
        return tracks.mapIndexed { i, t ->
            // Buscar el Uri de MediaStore para el archivo de audio
            val uri = resolveMediaStoreUri(context, t.audioFilePath)
                ?: Uri.parse("file://${t.audioFilePath}")

            Song(
                id            = -(i + 1L + (t.audioFilePath.hashCode().toLong() shl 16)),
                title         = t.title.ifBlank { "Pista ${t.trackNumber}" },
                artist        = t.performer.ifBlank { t.albumArtist }.ifBlank { "Artista desconocido" },
                album         = t.album.ifBlank { "Álbum desconocido" },
                albumArtUri   = uri,
                uri           = uri,
                path          = t.audioFilePath,
                duration      = (t.endMs - t.startMs).coerceAtLeast(0L),
                bitrate       = 0,
                cueStartMs    = t.startMs,
                cueEndMs      = if (t.endMs > 0L) t.endMs else Long.MAX_VALUE
            )
        }
    }

    // ── Parser interno ────────────────────────────────────────────────────────

    private fun parseLines(lines: List<String>, baseDir: String): ParseResult {
        val errors   = mutableListOf<String>()
        val tracks   = mutableListOf<CueTrack>()

        var albumTitle    = ""
        var albumArtist   = ""
        var albumYear     = ""
        var albumGenre    = ""
        var currentFile   = ""

        // Estado del track en curso
        var trackNum  = 0
        var trackTitle  = ""
        var trackPerf   = ""
        var trackIndex01 = -1L   // en ms

        val rawTracks = mutableListOf<Triple<Int, String, Long>>()  // (num, perf+"|"+title, startMs)
        val rawFiles  = mutableListOf<Pair<Long, String>>()         // (startMs de primera pista del file, filePath)

        fun flushTrack() {
            if (trackNum > 0 && trackIndex01 >= 0L) {
                rawTracks.add(Triple(trackNum, "${trackPerf}|${trackTitle}", trackIndex01))
            }
        }

        for (line in lines) {
            val trimmed = line.trim()
            when {
                trimmed.startsWith("REM DATE", ignoreCase = true) ->
                    albumYear = trimmed.removePrefix("REM DATE").trim().trim('"')
                trimmed.startsWith("REM GENRE", ignoreCase = true) ->
                    albumGenre = trimmed.removePrefix("REM GENRE").trim().trim('"')
                trimmed.startsWith("TITLE", ignoreCase = true) && trackNum == 0 ->
                    albumTitle = trimmed.removePrefix("TITLE").trim().trim('"')
                trimmed.startsWith("PERFORMER", ignoreCase = true) && trackNum == 0 ->
                    albumArtist = trimmed.removePrefix("PERFORMER").trim().trim('"')
                trimmed.startsWith("FILE", ignoreCase = true) -> {
                    flushTrack(); trackNum = 0; trackTitle = ""; trackPerf = ""
                    val match = Regex("""FILE\s+"?(.+?)"?\s+(WAVE|MP3|AIFF|BINARY|MOTOROLA)?$""", RegexOption.IGNORE_CASE)
                        .find(trimmed)
                    currentFile = match?.groupValues?.get(1) ?: trimmed.removePrefix("FILE").trim().trim('"')
                    // Resolver ruta
                    currentFile = if (File(currentFile).isAbsolute) currentFile else "$baseDir${File.separator}$currentFile"
                }
                trimmed.startsWith("TRACK", ignoreCase = true) -> {
                    flushTrack()
                    trackNum   = Regex("""\d+""").find(trimmed)?.value?.toIntOrNull() ?: (rawTracks.size + 1)
                    trackTitle = ""; trackPerf = ""; trackIndex01 = -1L
                }
                trimmed.startsWith("TITLE", ignoreCase = true) && trackNum > 0 ->
                    trackTitle = trimmed.removePrefix("TITLE").trim().trim('"')
                trimmed.startsWith("PERFORMER", ignoreCase = true) && trackNum > 0 ->
                    trackPerf  = trimmed.removePrefix("PERFORMER").trim().trim('"')
                trimmed.startsWith("INDEX 01", ignoreCase = true) -> {
                    val timePart = trimmed.removePrefix("INDEX 01").trim()
                    trackIndex01 = cueTimeToMs(timePart)
                    if (rawFiles.isEmpty() || rawFiles.last().second != currentFile) {
                        rawFiles.add(Pair(trackIndex01, currentFile))
                    }
                }
            }
        }
        flushTrack()

        // Calcular endMs = startMs del siguiente track (o 0 si es el último)
        val fileForTrack = mutableMapOf<Int, String>()
        var fileIdx = 0
        rawTracks.forEachIndexed { i, (num, _, startMs) ->
            while (fileIdx + 1 < rawFiles.size && rawFiles[fileIdx + 1].first <= startMs) fileIdx++
            fileForTrack[i] = rawFiles.getOrElse(fileIdx) { Pair(0L, currentFile) }.second
        }

        rawTracks.forEachIndexed { i, (num, perfTitle, startMs) ->
            val endMs   = rawTracks.getOrNull(i + 1)?.third ?: 0L
            val parts   = perfTitle.split("|", limit = 2)
            val perf    = parts[0]; val title = parts.getOrElse(1) { "" }
            val filePath = fileForTrack[i] ?: currentFile
            tracks.add(CueTrack(
                trackNumber  = num,
                title        = title,
                performer    = perf,
                audioFilePath= filePath,
                startMs      = startMs,
                endMs        = endMs,
                album        = albumTitle,
                albumArtist  = albumArtist,
                year         = albumYear,
                genre        = albumGenre
            ))
        }

        return ParseResult(tracks, errors)
    }

    /** Convierte mm:ss:ff (CUE) → milisegundos. */
    private fun cueTimeToMs(time: String): Long {
        val parts = time.trim().split(":")
        return runCatching {
            val mm = parts[0].toLong()
            val ss = parts[1].toLong()
            val ff = parts[2].toLong()  // frames (0-74, 75/s)
            (mm * 60_000L) + (ss * 1_000L) + (ff * 1000L / 75L)
        }.getOrDefault(0L)
    }

    private fun resolveMediaStoreUri(ctx: Context, filePath: String): Uri? {
        return runCatching {
            ctx.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Audio.Media._ID),
                "${MediaStore.Audio.Media.DATA}=?",
                arrayOf(filePath), null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(0)
                    Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
                } else null
            }
        }.getOrNull()
    }
}
