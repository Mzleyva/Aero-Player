package com.aeroplayer.timer

import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aeroplayer.service.PlayerController

object SleepTimerManager {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _remainingMs = MutableLiveData(0L)
    val remainingMs: LiveData<Long> = _remainingMs

    private val _isRunning = MutableLiveData(false)
    val isRunning: LiveData<Boolean> = _isRunning

    /** true cuando el timer esperará a que termine la canción actual. */
    private val _afterSong = MutableLiveData(false)
    val afterSong: LiveData<Boolean> = _afterSong

    private var timer: CountDownTimer? = null
    private var fadeRunnable: Runnable? = null

    /** Duración del fade-out en ms antes de pausar (simula las canciones antiguas). */
    private const val FADE_DURATION_MS = 20_000L  // 20 segundos de fade
    private const val FADE_INTERVAL_MS = 200L

    fun start(minutes: Int, afterCurrentSong: Boolean = false) {
        cancel()
        val totalMs = minutes * 60_000L
        mainHandler.post {
            _remainingMs.value = totalMs
            _isRunning.value   = true
            _afterSong.value   = afterCurrentSong
        }
        timer = object : CountDownTimer(totalMs, 1_000) {
            override fun onTick(ms: Long) { mainHandler.post { _remainingMs.value = ms } }
            override fun onFinish() {
                mainHandler.post { _remainingMs.value = 0L; _isRunning.value = false }
                if (afterCurrentSong) {
                    // BUG FIX: getDuration() returns total queue duration on some devices.
                    // Use currentSong's duration instead via MediaController.
                    val ctrl = PlayerController
                    val currentPos = ctrl.getCurrentPosition()
                    val songDuration = ctrl.getDuration()
                    // Only wait if we can determine remaining time reliably (duration > 0 and not a stream)
                    val remaining = if (songDuration > 0L && songDuration < 3_600_000L)
                        (songDuration - currentPos).coerceAtLeast(0L)
                    else 0L
                    // Start fade-out near end of song
                    val fadeDelay = (remaining - FADE_DURATION_MS).coerceAtLeast(0L)
                    mainHandler.postDelayed({ startFadeOutAndPause() }, fadeDelay)
                } else {
                    startFadeOutAndPause()
                }
            }
        }.start()
    }

    /**
     * Fade out gradual de 20s antes de pausar — como las canciones antiguas que
     * bajaban el volumen suavemente antes de terminar, evitando el corte abrupto.
     */
    private fun startFadeOutAndPause() {
        val ctrl = PlayerController
        val initialVolume = ctrl.getVolume().coerceAtLeast(0.05f)
        val steps = (FADE_DURATION_MS / FADE_INTERVAL_MS).toInt()
        var step = 0

        val r = object : Runnable {
            override fun run() {
                if (step >= steps) {
                    ctrl.setVolume(0f)
                    ctrl.pause()
                    // Restaurar volumen tras pausar para la próxima reproducción
                    mainHandler.postDelayed({ ctrl.setVolume(1f) }, 500)
                    return
                }
                val fraction = 1f - (step.toFloat() / steps)
                // Curva exponencial suave para fade más natural
                val vol = (initialVolume * fraction * fraction)
                ctrl.setVolume(vol.coerceIn(0f, 1f))
                step++
                mainHandler.postDelayed(this, FADE_INTERVAL_MS)
            }
        }
        fadeRunnable = r
        mainHandler.post(r)
    }

    fun cancel() {
        timer?.cancel(); timer = null
        fadeRunnable?.let { mainHandler.removeCallbacks(it) }; fadeRunnable = null
        PlayerController.setVolume(1f)
        mainHandler.post { _remainingMs.value = 0L; _isRunning.value = false; _afterSong.value = false }
    }

    fun formatRemaining(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d".format(s / 60, s % 60)
    }
}
