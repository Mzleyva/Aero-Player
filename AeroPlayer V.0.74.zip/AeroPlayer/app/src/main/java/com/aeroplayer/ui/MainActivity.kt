package com.aeroplayer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityMainBinding
import com.aeroplayer.cast.CastManager
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.player.MiniPlayerFragment
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.animation.ValueAnimator
import android.content.res.ColorStateList
import androidx.interpolator.view.animation.FastOutSlowInInterpolator

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    val viewModel: MainViewModel by viewModels()

    // Color actual del indicador (para animar transiciones)
    private var currentIndicatorColor: Int = 0
    // FIX: guardar referencia para cancelar antes de relanzar — evita dos animadores
    // corriendo en paralelo cuando MainActivity + PlayerActivity están activos al mismo tiempo
    private var indicatorAnimator: ValueAnimator? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val audioGranted = perms[Manifest.permission.READ_MEDIA_AUDIO] == true
            || perms[Manifest.permission.READ_EXTERNAL_STORAGE] == true
        if (audioGranted) viewModel.loadSongs()
        else showPermissionRationale()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyThemePreference()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        checkPermissions()
        PlayerController.connect(this)
        CastManager.init(this)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.miniPlayerContainer, MiniPlayerFragment())
                .commit()
        }

        // ── Color de acento personalizado ─────────────────────────────────
        val accentColor = com.aeroplayer.ui.ThemeManager.getAccentColor(this)
        currentIndicatorColor = accentColor
        applyNavIndicatorColor(accentColor, animate = false)

        // ── Fondo personalizado ───────────────────────────────────────────
        applyCustomBackground()

        // Aplicar blur al wrapper (API 31+)
        applyBlurToNav()

        // Mostrar/ocultar mini player con animación slide-up/down
        PlayerController.currentSong.observe(this) { song ->
            val container = binding.miniPlayerContainer
            if (song != null && container.visibility != View.VISIBLE) {
                container.translationY = container.height.toFloat().coerceAtLeast(200f)
                container.visibility = View.VISIBLE
                container.animate()
                    .translationY(0f)
                    .setDuration(300)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(2f))
                    .start()
            } else if (song == null && container.visibility == View.VISIBLE) {
                container.animate()
                    .translationY(container.height.toFloat() + 100f)
                    .setDuration(200)
                    .setInterpolator(android.view.animation.AccelerateInterpolator(2f))
                    .withEndAction { container.visibility = View.GONE }
                    .start()
            }

            if (song != null) {
                // Extraer color dominante del álbum y aplicarlo al indicador
                extractPaletteColor(song.albumArtUri?.toString())
            } else {
                // Sin canción → volver al azul
                animateIndicatorColor(
                    currentIndicatorColor,
                    ContextCompat.getColor(this, R.color.accent_blue)
                )
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        })
    }

    // ── Fondo personalizado ───────────────────────────────────────────────────
    private fun applyCustomBackground() {
        val uri = com.aeroplayer.ui.ThemeManager.getCustomBackground(this)
        if (uri != null) {
            binding.ivCustomBackground?.visibility = android.view.View.VISIBLE
            binding.customBgOverlay?.visibility = android.view.View.VISIBLE
            com.bumptech.glide.Glide.with(this)
                .load(uri)
                .centerCrop()
                .into(binding.ivCustomBackground!!)
        } else {
            binding.ivCustomBackground?.visibility = android.view.View.GONE
            binding.customBgOverlay?.visibility = android.view.View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        // Refrescar fondo y color de acento al volver de Settings
        applyCustomBackground()
        val accentColor = com.aeroplayer.ui.ThemeManager.getAccentColor(this)
        applyNavIndicatorColor(accentColor, animate = false)
    }

    // ── Blur (API 31+) ────────────────────────────────────────────────────────
    private fun applyBlurToNav() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            binding.bottomNavWrapper.setRenderEffect(
                RenderEffect.createBlurEffect(18f, 18f, Shader.TileMode.CLAMP)
            )
        }
        // En versiones anteriores el fondo semitransparente del drawable ya da
        // el efecto visual equivalente (bg_bottom_nav.xml)
    }

    // ── Palette → color del indicador ────────────────────────────────────────
    private fun extractPaletteColor(albumArtUri: String?) {
        if (albumArtUri == null) {
            animateIndicatorColor(
                currentIndicatorColor,
                ContextCompat.getColor(this, R.color.accent_blue)
            )
            return
        }

        Glide.with(this)
            .asBitmap()
            .load(albumArtUri)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .override(128, 128) // thumbnail para Palette rápido
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(bmp: Bitmap, t: Transition<in Bitmap>?) {
                    Palette.from(bmp).generate { palette ->
                        val fallback = ContextCompat.getColor(this@MainActivity, R.color.accent_blue)
                        val target = palette?.let {
                            it.getVibrantColor(
                                it.getMutedColor(
                                    it.getDominantColor(fallback)
                                )
                            )
                        } ?: fallback

                        // Asegurar que el color sea lo suficientemente saturado
                        val hsv = FloatArray(3)
                        Color.colorToHSV(target, hsv)
                        hsv[1] = hsv[1].coerceAtLeast(0.4f) // mínimo 40% saturación
                        hsv[2] = hsv[2].coerceAtLeast(0.5f) // mínimo 50% brillo
                        val vivid = Color.HSVToColor(hsv)

                        animateIndicatorColor(currentIndicatorColor, vivid)
                    }
                }
                override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {}
            })
    }

    /**
     * Anima suavemente la transición entre colores del indicador activo.
     */
    private fun animateIndicatorColor(from: Int, to: Int) {
        if (from == to) return
        indicatorAnimator?.cancel()
        indicatorAnimator = ValueAnimator.ofArgb(from, to).apply {
            duration = 500L
            interpolator = FastOutSlowInInterpolator()
            addUpdateListener { animator ->
                val color = animator.animatedValue as Int
                applyNavIndicatorColor(color, animate = false)
                currentIndicatorColor = color
            }
        }.also { it.start() }
    }

    private fun applyNavIndicatorColor(color: Int, animate: Boolean) {
        binding.bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(color)
    }

    // ── Navigation ────────────────────────────────────────────────────────────
    private fun setupNavigation() {
        val navHost = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        binding.bottomNav.setupWithNavController(navHost.navController)
    }

    // ── Permissions ───────────────────────────────────────────────────────────
    private fun checkPermissions() {
        val storagePerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_IMAGES   // necesario para carátulas en Android 13+
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val notifPerms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            emptyArray()
        }
        val needed = (storagePerms + notifPerms).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) viewModel.loadSongs()
        else permissionLauncher.launch(needed.toTypedArray())
    }

    private fun showPermissionRationale() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permiso necesario")
            .setMessage(
                "Aero Player necesita acceso a tus archivos de audio para " +
                "mostrar tu música. Por favor, activa el permiso en Configuración."
            )
            .setPositiveButton("Ir a Configuración") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    }
                )
            }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    // ── Theme ─────────────────────────────────────────────────────────────────
    private fun applyThemePreference() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val mode  = prefs.getString("theme_mode", "dark") ?: "dark"
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "auto"  -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                else    -> AppCompatDelegate.MODE_NIGHT_YES   // "dark" es el default
            }
        )
    }

    fun toggleTheme() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        // Unificar con la clave "theme_mode" que usa SplashActivity
        val current = prefs.getString("theme_mode", "dark") ?: "dark"
        val next = if (current == "dark") "light" else "dark"
        prefs.edit()
            .putString("theme_mode", next)
            .putBoolean("theme_light", next == "light") // mantener compatibilidad
            .apply()
        AppCompatDelegate.setDefaultNightMode(
            if (next == "light") AppCompatDelegate.MODE_NIGHT_NO
            else AppCompatDelegate.MODE_NIGHT_YES
        )
        // Recrear la Activity para que el tema se aplique correctamente
        recreate()
    }

    fun isLightTheme(): Boolean {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val mode = prefs.getString("theme_mode", "dark") ?: "dark"
        return mode == "light"
    }

    // ── Doble toque Home → limpiar caché de selección rápida ─────────────────
    // Android no expone directamente el botón Home, pero sí podemos detectar
    // cuándo la Activity vuelve al frente desde el recents/home launcher.
    // onNewIntent se dispara cuando el usuario toca el ícono de la app estando
    // ya abierta (equivale a presionar Home y volver). Dos toques consecutivos
    // en menos de DOUBLE_HOME_WINDOW_MS limpian el caché.
    private var lastHomeTime = 0L
    private val DOUBLE_HOME_WINDOW_MS = 1_500L

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        // onNewIntent solo se dispara cuando el launcher/recents trae la app al frente
        checkDoubleHome()
    }

    override fun onResume() {
        super.onResume()
        // No llamar checkDoubleHome aquí — se dispara en cada navegación interna
        // y causaría falsos positivos. Solo usamos onNewIntent.
    }

    private fun checkDoubleHome() {
        val now = System.currentTimeMillis()
        if (now - lastHomeTime < DOUBLE_HOME_WINDOW_MS) {
            // Doble toque detectado — limpiar caché
            com.aeroplayer.ui.home.HomeFragment.clearQuickPickCache()
            android.widget.Toast.makeText(
                this, "Selección rápida actualizada", android.widget.Toast.LENGTH_SHORT
            ).show()
            lastHomeTime = 0L
        } else {
            lastHomeTime = now
        }
    }

    override fun onDestroy() {
        indicatorAnimator?.cancel()
        if (isFinishing) PlayerController.disconnect()
        CastManager.release()
        super.onDestroy()
    }
}
