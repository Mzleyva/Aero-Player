package com.aeroplayer.ui

import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.data.db.AlbumCount
import com.aeroplayer.data.db.AppDatabase
import com.aeroplayer.data.db.ArtistCount
import com.aeroplayer.data.db.PlayCountEntity
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Recopilación anual al estilo Spotify Wrapped.
 * Muestra: tiempo total, canciones únicas, top 5 artistas,
 * top 5 álbumes y top 5 canciones del año seleccionado.
 * Cada sección aparece con animación de entrada escalonada.
 */
class YearlyWrapActivity : AppCompatActivity() {

    private val db by lazy { AppDatabase.getInstance(this) }
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val year = intent.getIntExtra("year", currentYear)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0A0A0F.toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // ── Header ────────────────────────────────────────────────────────────
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24.dp, 56.dp, 24.dp, 32.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
            background = null
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.gravity = Gravity.START }
            setOnClickListener { finish() }
        }
        val tvYear = TextView(this).apply {
            text = year.toString()
            textSize = 72f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            alpha = 0f
        }
        val tvSubtitle = TextView(this).apply {
            text = "Tu año en música"
            textSize = 18f
            setTextColor(0xAAFFFFFF.toInt())
            gravity = Gravity.CENTER
            alpha = 0f
        }
        header.addView(btnBack)
        header.addView(tvYear)
        header.addView(tvSubtitle)
        root.addView(header)

        // Secciones (se poblarán con datos)
        val sectionsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 80.dp)
        }
        root.addView(sectionsContainer)
        scroll.addView(root)
        setContentView(scroll)

        // Animar header
        tvYear.animate().alpha(1f).translationYBy(-20f).setDuration(600)
            .setInterpolator(DecelerateInterpolator()).setStartDelay(200).start()
        tvSubtitle.animate().alpha(1f).setDuration(500).setStartDelay(500).start()

        // Cargar y mostrar datos
        lifecycleScope.launch {
            val cal = Calendar.getInstance()
            cal.set(year, Calendar.JANUARY, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
            val yearStart = cal.timeInMillis
            cal.set(year + 1, Calendar.JANUARY, 1, 0, 0, 0)
            val yearEnd = cal.timeInMillis

            val totalMs      = db.playCountDao().getTotalListenTimeMsInYear(yearStart, yearEnd) ?: 0L
            val topSongs     = db.playCountDao().getTopPlayedInYear(yearStart, yearEnd, 5)
            val topArtists   = db.historyDao().getTopArtistsInRange(yearStart, yearEnd, 5)
            val topAlbums    = db.historyDao().getTopAlbumsInRange(yearStart, yearEnd, 5)
            val totalPlays   = db.historyDao().getTotalPlaysInRange(yearStart, yearEnd)

            runOnUiThread {
                var delay = 600L

                // ── Tarjetas de resumen ───────────────────────────────────────
                addSection(sectionsContainer, delay) {
                    buildSummaryRow(formatDuration(totalMs), "$totalPlays reproducciones")
                }
                delay += 200

                // ── Top Artistas ──────────────────────────────────────────────
                if (topArtists.isNotEmpty()) {
                    addSection(sectionsContainer, delay) {
                        buildRankSection("🎤 Tus artistas", topArtists.map {
                            RankItem(it.artist, "${it.playCount} reproduccion${if (it.playCount != 1) "es" else ""}", null)
                        })
                    }
                    delay += 200
                }

                // ── Top Álbumes ───────────────────────────────────────────────
                if (topAlbums.isNotEmpty()) {
                    addSection(sectionsContainer, delay) {
                        buildRankSection("💿 Tus álbumes", topAlbums.map {
                            RankItem(it.album, "${it.artist} · ${it.playCount} veces", null)
                        })
                    }
                    delay += 200
                }

                // ── Top Canciones ─────────────────────────────────────────────
                if (topSongs.isNotEmpty()) {
                    addSection(sectionsContainer, delay) {
                        buildSongsSection("🎵 Tus canciones", topSongs)
                    }
                    delay += 200
                }

                // ── Pie ───────────────────────────────────────────────────────
                addSection(sectionsContainer, delay) { buildFooter(year) }
            }
        }
    }

    // ── Helpers de construcción de UI ─────────────────────────────────────────

    private fun addSection(container: LinearLayout, delayMs: Long, build: () -> View) {
        val view = build()
        view.alpha = 0f
        view.translationY = 40f
        container.addView(view)
        handler.postDelayed({
            view.animate()
                .alpha(1f).translationY(0f)
                .setDuration(500)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }, delayMs)
    }

    private fun buildSummaryRow(timeLabel: String, playsLabel: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(20.dp, 8.dp, 20.dp, 8.dp)
        }
        row.addView(summaryCard("⏱ Tiempo total", timeLabel, 0xFF1DB954.toInt()))
        row.addView(summaryCard("▶️ Reproducciones", playsLabel, 0xFF5B9BD4.toInt()))
        return row
    }

    private fun summaryCard(label: String, value: String, accentColor: Int): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16.dp, 20.dp, 16.dp, 20.dp)
            setBackgroundColor(0xFF1A1A2E.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.setMargins(8.dp, 8.dp, 8.dp, 8.dp) }
        }
        // Esquinas redondeadas via outline
        card.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFF1A1A2E.toInt())
            cornerRadius = 16.dp.toFloat()
        }
        card.addView(TextView(this).apply {
            text = value
            textSize = 28f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(accentColor)
            gravity = Gravity.CENTER
        })
        card.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(0xAAFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4.dp, 0, 0)
        })
        return card
    }

    data class RankItem(val title: String, val subtitle: String, val artUri: String?)

    private fun buildRankSection(sectionTitle: String, items: List<RankItem>): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 16.dp, 20.dp, 8.dp)
        }
        container.addView(TextView(this).apply {
            text = sectionTitle
            textSize = 22f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 12.dp)
        })
        items.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 10.dp, 0, 10.dp)
            }
            row.addView(TextView(this).apply {
                text = "${i + 1}"
                textSize = 20f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(if (i == 0) 0xFFFFD700.toInt() else 0x88FFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(36.dp, LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
            })
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.marginStart = 8.dp }
            }
            texts.addView(TextView(this).apply {
                text = item.title
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            texts.addView(TextView(this).apply {
                text = item.subtitle
                textSize = 12f
                setTextColor(0x88FFFFFF.toInt())
            })
            row.addView(texts)
            container.addView(row)

            // Separador
            if (i < items.lastIndex) {
                container.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    ).also { it.marginStart = 44.dp }
                    setBackgroundColor(0x22FFFFFF)
                })
            }
        }
        return wrapInCard(container)
    }

    private fun buildSongsSection(sectionTitle: String, songs: List<PlayCountEntity>): View {
        val items = songs.map { s ->
            RankItem(s.title, "${s.artist} · ${s.count} veces", s.albumArtUri)
        }
        return buildRankSection(sectionTitle, items)
    }

    private fun buildFooter(year: Int): View {
        val messages = listOf(
            "Gracias por escuchar música con AeroPlayer 🎧",
            "Otro año lleno de buenas canciones ✨",
            "La música es el soundtrack de tu vida 🎶"
        )
        return TextView(this).apply {
            text = messages.random()
            textSize = 14f
            setTextColor(0x88FFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(32.dp, 24.dp, 32.dp, 48.dp)
        }
    }

    private fun wrapInCard(inner: View): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp, 8.dp, 16.dp, 8.dp)
            addView(inner.also {
                it.background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF111122.toInt())
                    cornerRadius = 20.dp.toFloat()
                }
                (it as? LinearLayout)?.setPadding(20.dp, 16.dp, 20.dp, 16.dp)
            })
        }
    }

    private fun formatDuration(ms: Long): String {
        if (ms <= 0L) return "0 min"
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
