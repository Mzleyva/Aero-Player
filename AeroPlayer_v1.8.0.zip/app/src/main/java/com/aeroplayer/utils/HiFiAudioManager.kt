package com.aeroplayer.utils

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi

/**
 * Detecta y configura chips Hi-Fi y DACs USB externos.
 *
 * En Android, el acceso a hardware Hi-Fi se logra vía:
 *  1. AudioManager.getDevices() — lista dispositivos de salida incluyendo USB DACs.
 *  2. AudioAttributes con CONTENT_TYPE_MUSIC + USAGE_MEDIA ya configurado en MusicService.
 *  3. En algunos fabricantes (LG Quad DAC, ESS Sabre) se activa vía AudioEffect o
 *     propiedades del sistema (vendor-specific).
 *
 * Esta clase expone la detección y permite al usuario elegir el dispositivo de salida
 * cuando hay múltiples disponibles.
 */
object HiFiAudioManager {

    private const val TAG = "HiFiAudioManager"

    data class AudioOutputDevice(
        val id: Int,
        val name: String,
        val type: Int,
        val isHiRes: Boolean,
        val maxChannels: Int,
        val sampleRates: IntArray,
        val encodings: IntArray
    ) {
        val typeLabel: String get() = when (type) {
            AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE        -> "USB DAC"
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_WIRED_HEADSET      -> "Jack 3.5mm"
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO      -> "Bluetooth"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER    -> "Altavoz interno"
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE   -> "Auricular interno"
            AudioDeviceInfo.TYPE_HDMI               -> "HDMI"
            AudioDeviceInfo.TYPE_LINE_ANALOG         -> "Línea analógica"
            else                                    -> "Desconocido ($type)"
        }

        /** true si el dispositivo soporta audio de alta resolución (>44.1kHz o >16bit). */
        fun supportsHiRes(): Boolean {
            val hiResSampleRates = sampleRates.any { it >= 96000 }
            val hiResEncoding    = encodings.any { enc ->
                enc == android.media.AudioFormat.ENCODING_PCM_24BIT_PACKED ||
                enc == android.media.AudioFormat.ENCODING_PCM_32BIT ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    enc == android.media.AudioFormat.ENCODING_PCM_FLOAT)
            }
            return hiResSampleRates || hiResEncoding
        }
    }

    /**
     * Devuelve todos los dispositivos de salida de audio disponibles.
     * Requiere API 23+.
     */
    fun getOutputDevices(context: Context): List<AudioOutputDevice> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return emptyList()
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { info ->
            AudioOutputDevice(
                id          = info.id,
                name        = info.productName?.toString() ?: info.type.toString(),
                type        = info.type,
                isHiRes     = false, // calculado después
                maxChannels = info.channelCounts.maxOrNull() ?: 2,
                sampleRates = info.sampleRates,
                encodings   = info.encodings
            ).let { it.copy(isHiRes = it.supportsHiRes()) }
        }
    }

    /**
     * Detecta si hay un DAC USB conectado.
     */
    fun hasUsbDac(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return false
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }

    /**
     * Detecta si el dispositivo tiene un chip Hi-Fi conocido.
     * Basado en propiedades del sistema de fabricantes comunes.
     */
    fun detectHiFiChip(): HiFiChip {
        val model = Build.MODEL.lowercase()
        val brand = Build.BRAND.lowercase()
        val hw    = Build.HARDWARE.lowercase()

        return when {
            // LG Quad DAC (V20, V30, V40, G7, G8...)
            brand.contains("lge") && (
                model.contains("v20") || model.contains("v30") ||
                model.contains("v40") || model.contains("v50") ||
                model.contains("g7")  || model.contains("g8")
            ) -> HiFiChip.LG_QUAD_DAC

            // Sony Hi-Res (Xperia 1, 5 series)
            brand.contains("sony") && (
                model.contains("xq-") || model.contains("so-")
            ) -> HiFiChip.SONY_HIRES

            // Samsung Exynos con Cirrus Logic
            brand.contains("samsung") && (
                model.contains("s8") || model.contains("s9") ||
                model.contains("note8") || model.contains("note9")
            ) -> HiFiChip.SAMSUNG_CIRRUS

            // OnePlus con DAC dedicado
            brand.contains("oneplus") -> HiFiChip.ONEPLUS_DAC

            // Dispositivo genérico con USB DAC
            else -> HiFiChip.GENERIC
        }
    }

    /**
     * Intenta activar el modo Hi-Res para chips conocidos.
     * Para LG Quad DAC usa AudioEffect vendor-specific.
     * Para el resto documenta las instrucciones para el usuario.
     */
    fun activateHiFiMode(context: Context): HiFiActivationResult {
        val chip = detectHiFiChip()
        return when (chip) {
            HiFiChip.LG_QUAD_DAC -> {
                // LG Quad DAC se activa vía com.lge.app.music.HiFi o configuración de sistema
                // Intentamos vía AudioEffect
                val activated = runCatching {
                    val sessionId = com.aeroplayer.service.PlayerController.getAudioSessionId()
                    if (sessionId != 0) {
                        // UUID del efecto Hi-Fi de LG (documentado por la comunidad XDA)
                        val LG_HIFI_UUID = java.util.UUID.fromString("49415341-0000-1000-8000-0002a5d5c51b")
                        // AudioEffect constructor is package-private; use reflection to instantiate
                        val ctor = android.media.audiofx.AudioEffect::class.java
                            .getDeclaredConstructor(
                                java.util.UUID::class.java,
                                java.util.UUID::class.java,
                                Int::class.java,
                                Int::class.java
                            ).also { it.isAccessible = true }
                        val effect = ctor.newInstance(
                            LG_HIFI_UUID,
                            java.util.UUID.fromString("f27317f4-c984-4de6-9a90-545759495bf2"),
                            0, sessionId
                        ) as android.media.audiofx.AudioEffect
                        effect.enabled = true
                        true
                    } else false
                }.getOrDefault(false)
                if (activated) HiFiActivationResult.ACTIVATED
                else HiFiActivationResult.REQUIRES_SYSTEM_SETTING
            }
            HiFiChip.SONY_HIRES ->
                HiFiActivationResult.REQUIRES_SYSTEM_SETTING
            else ->
                HiFiActivationResult.NOT_NEEDED
        }
    }

    /** Descripción de cómo activar Hi-Fi en cada chip. */
    fun getActivationInstructions(context: Context): String {
        return when (detectHiFiChip()) {
            HiFiChip.LG_QUAD_DAC ->
                "Ve a Ajustes → Sonido → Calidad de audio → activa 'Quad DAC' y elige calidad Hi-Fi."
            HiFiChip.SONY_HIRES ->
                "Ve a Ajustes → Sonido → Audio de alta resolución y activa 'DSEE Ultimate'."
            HiFiChip.SAMSUNG_CIRRUS ->
                "Ve a Ajustes → Sonido → Calidad de sonido y activa 'Dolby Atmos' o 'UHQ Upscaler'."
            HiFiChip.ONEPLUS_DAC ->
                "Ve a Ajustes → Sonido → Audio de alta calidad y activa 'Hi-Res Audio'."
            HiFiChip.GENERIC -> {
                if (hasUsbDac(context))
                    "DAC USB detectado. AeroPlayer ya lo usa automáticamente vía el sistema de audio."
                else
                    "No se detectó hardware Hi-Fi dedicado. El audio se reproduce con el DAC estándar del dispositivo."
            }
        }
    }

    enum class HiFiChip { LG_QUAD_DAC, SONY_HIRES, SAMSUNG_CIRRUS, ONEPLUS_DAC, GENERIC }
    enum class HiFiActivationResult { ACTIVATED, REQUIRES_SYSTEM_SETTING, NOT_NEEDED, ERROR }
}
