package com.aeroplayer.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.aeroplayer.utils.AlbumArtUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class QuickPickPageAdapter(
    private val onClick:         (Song, List<Song>) -> Unit,
    private val onAddToQueue:    (Song) -> Unit,
    private val onAddToPlaylist: (Song) -> Unit,
    private val onViewArtist:    (String) -> Unit
) : RecyclerView.Adapter<QuickPickPageAdapter.PageVH>() {

    companion object {
        const val PAGE_SIZE = 4
    }

    // Scope para cargar carátulas en background — vive mientras el adapter existe
    private val artScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var songs: List<Song> = emptyList()

    fun submitList(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }

    fun getCurrentList(): List<Song> = songs

    override fun getItemCount(): Int =
        if (songs.isEmpty()) 0 else (songs.size + PAGE_SIZE - 1) / PAGE_SIZE

    inner class PageVH(val container: LinearLayout) : RecyclerView.ViewHolder(container)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val container = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT,
                RecyclerView.LayoutParams.WRAP_CONTENT
            )
        }
        return PageVH(container)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        // Asegurar ancho completo
        (holder.container.layoutParams as? RecyclerView.LayoutParams)?.let { lp ->
            val rv = holder.container.parent as? RecyclerView
            if (rv != null && rv.width > 0) { lp.width = rv.width; holder.container.layoutParams = lp }
        }

        holder.container.removeAllViews()
        val startIdx = position * PAGE_SIZE
        val endIdx   = minOf(startIdx + PAGE_SIZE, songs.size)

        for (i in startIdx until endIdx) {
            val song = songs[i]
            val rowView = LayoutInflater.from(holder.container.context)
                .inflate(R.layout.item_quick_pick_row, holder.container, false)

            val ivCover = rowView.findViewById<ImageView>(R.id.ivCover)
            // FIX redondeo
            ivCover.clipToOutline   = true
            ivCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            val cached = AlbumArtUtils.getCached(song.id)
            if (cached != null) {
                Glide.with(ivCover.context).load(cached)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .centerCrop().into(ivCover)
            } else {
                // Mostrar placeholder y cargar en background
                Glide.with(ivCover.context).load(R.drawable.ic_music_placeholder).into(ivCover)
                val songId   = song.id
                val songPath = song.path
                artScope.launch {
                    val bmp = withContext(Dispatchers.IO) {
                        AlbumArtUtils.loadArt(songId, songPath)
                    }
                    if (bmp != null && ivCover.isAttachedToWindow) {
                        Glide.with(ivCover.context).load(bmp)
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .centerCrop().into(ivCover)
                    } else if (bmp == null) {
                        // Fallback a URI de MediaStore
                        val artUri = songs.find { it.id == songId }?.albumArtUri
                        if (artUri != null && ivCover.isAttachedToWindow) {
                            Glide.with(ivCover.context).load(artUri)
                                .placeholder(R.drawable.ic_music_placeholder)
                                .error(R.drawable.ic_music_placeholder)
                                .centerCrop().into(ivCover)
                        }
                    }
                }
            }

            rowView.findViewById<android.widget.TextView>(R.id.tvTitle).text  = song.title
            rowView.findViewById<android.widget.TextView>(R.id.tvArtist).text = song.artist
            rowView.setOnClickListener { onClick(song, songs) }
            rowView.findViewById<android.widget.ImageButton>(R.id.btnMore)
                .setOnClickListener { v -> showMenu(v, song) }

            holder.container.addView(rowView)
        }
    }

    private fun showMenu(anchor: View, song: Song) {
        val popup = androidx.appcompat.widget.PopupMenu(anchor.context, anchor, android.view.Gravity.END)
        val castAvailable = com.aeroplayer.cast.CastManager.isAvailable.value == true
        popup.menu.apply {
            add(0, 0, 0, "🎤  Ver artista")
            add(0, 1, 1, "➕  Agregar a cola")
            add(0, 2, 2, "📋  Agregar a playlist")
            if (castAvailable) add(0, 3, 3, "📺  Enviar a dispositivo")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                0 -> { onViewArtist(song.artist); true }
                1 -> { onAddToQueue(song); true }
                2 -> { onAddToPlaylist(song); true }
                3 -> { com.aeroplayer.cast.CastManager.castSong(song); true }
                else -> false
            }
        }
        popup.show()
    }
}
