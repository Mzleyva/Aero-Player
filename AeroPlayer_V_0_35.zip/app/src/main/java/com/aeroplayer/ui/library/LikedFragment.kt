package com.aeroplayer.ui.library

import com.aeroplayer.R

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.databinding.FragmentLikedBinding
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.utils.SongBuilder
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingData
import kotlinx.coroutines.launch

class LikedFragment : Fragment() {

    private var _binding: FragmentLikedBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: SongListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLikedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeLiked()
        setupPlayAll()
    }

    private fun setupRecyclerView() {
        adapter = SongListAdapter(
            onSongClick     = { song, getList ->
                val songs = getList()
                PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.tab_liked))
                viewModel.incrementPlayCount(song)
                startActivity(
                    Intent(requireContext(), PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(
                        requireContext(), R.anim.slide_up, R.anim.fade_out
                    ).toBundle()
                )
            },
            onLikeClick     = { song -> viewModel.toggleLike(song) },
            onAddToPlaylist = { song -> showAddToPlaylistDialog(song) },
            onAddToQueue    = { song -> PlayerController.addToQueue(song) }
        )
        binding.rvLiked.apply {
            layoutManager = LinearLayoutManager(context)
            adapter       = this@LikedFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun observeLiked() {
        viewModel.likedSongs.observe(viewLifecycleOwner) { entities ->
            val songs = entities.map { SongBuilder.fromLiked(it) }
            // PagingDataAdapter requiere PagingData.from() para listas estáticas
            viewLifecycleOwner.lifecycleScope.launch {
                adapter.submitData(PagingData.from(songs))
            }
            binding.tvEmpty.visibility    = if (songs.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text          = "${songs.size} canciones"
            binding.btnPlayAll.visibility = if (songs.isNotEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun setupPlayAll() {
        binding.btnPlayAll.setOnClickListener {
            val songs = adapter.snapshot().items.filterNotNull()
            if (songs.isNotEmpty()) {
                songs.firstOrNull()?.let { viewModel.incrementPlayCount(it) }
                PlayerController.playSongs(songs, 0, queueName = getString(R.string.tab_liked))
                startActivity(
                    Intent(requireContext(), PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(
                        requireContext(), R.anim.slide_up, R.anim.fade_out
                    ).toBundle()
                )
            }
        }
    }

    private fun showAddToPlaylistDialog(song: com.aeroplayer.model.Song) {
        val playlists = viewModel.playlists.value ?: return
        if (playlists.isEmpty()) return
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Agregar a playlist")
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
