package com.aeroplayer.utils

import android.content.Context
import android.net.Uri
import com.aeroplayer.model.Song
import java.util.concurrent.TimeUnit

object FormatUtils {

    fun formatDuration(ms: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return "%d:%02d".format(minutes, seconds)
    }

    fun formatDurationLong(ms: Long): String {
        val hours = TimeUnit.MILLISECONDS.toHours(ms)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds)
        else "%d:%02d".format(minutes, seconds)
    }

    fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
            bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
            else -> "$bytes B"
        }
    }
}

object SongUtils {

    fun songToMediaUri(song: Song): Uri = song.uri

    fun cleanArtistName(raw: String): String {
        return raw.replace(Regex("<.*?>"), "").trim()
    }
}
