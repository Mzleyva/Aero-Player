package com.aeroplayer.service

import android.content.Context
import android.os.FileObserver
import android.util.Log
import kotlinx.coroutines.*

/**
 * FolderWatcher — monitorea las carpetas de música en tiempo real.
 *
 * Usa FileObserver para detectar archivos nuevos (.mp3, .flac, .opus, etc.)
 * y notifica a MainViewModel para actualizar la biblioteca automáticamente.
 * Esto evita que el usuario tenga que "Actualizar biblioteca" manualmente.
 */
object FolderWatcher {

    private const val TAG = "FolderWatcher"
    private val observers = mutableListOf<FileObserver>()
    private var onNewFileCallback: ((String) -> Unit)? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val AUDIO_EXTENSIONS = setOf(
        ".mp3", ".flac", ".ogg", ".opus", ".m4a", ".aac",
        ".wav", ".wv", ".ape", ".alac", ".aif", ".aiff"
    )

    fun start(context: Context, onNewFile: (String) -> Unit) {
        onNewFileCallback = onNewFile
        stopAll()

        // Obtener carpetas de música configuradas
        val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
        val savedFolders = prefs.getStringSet("watch_folders", null)
            ?: setOf(
                android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_MUSIC).absolutePath,
                android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS).absolutePath
            )

        savedFolders.forEach { folderPath ->
            val folder = java.io.File(folderPath)
            if (!folder.exists() || !folder.isDirectory) return@forEach
            watchFolder(folder)
        }

        Log.d(TAG, "Watching ${observers.size} folder(s) for new music")
    }

    private fun watchFolder(folder: java.io.File) {
        val observer = object : FileObserver(folder.absolutePath,
            CREATE or CLOSE_WRITE or MOVED_TO) {
            override fun onEvent(event: Int, path: String?) {
                if (path == null) return
                val lower = path.lowercase()
                if (AUDIO_EXTENSIONS.any { lower.endsWith(it) }) {
                    val fullPath = "${folder.absolutePath}/$path"
                    Log.d(TAG, "New audio file detected: $fullPath")
                    scope.launch(Dispatchers.Main) {
                        // Pequeño delay para que el archivo termine de escribirse
                        delay(1_500)
                        onNewFileCallback?.invoke(fullPath)
                    }
                }
            }
        }
        observer.startWatching()
        observers.add(observer)

        // Observar subcarpetas también (un nivel)
        folder.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
            val subObserver = object : FileObserver(sub.absolutePath, CREATE or CLOSE_WRITE or MOVED_TO) {
                override fun onEvent(event: Int, path: String?) {
                    if (path == null) return
                    val lower = path.lowercase()
                    if (AUDIO_EXTENSIONS.any { lower.endsWith(it) }) {
                        scope.launch(Dispatchers.Main) {
                            delay(1_500)
                            onNewFileCallback?.invoke("${sub.absolutePath}/$path")
                        }
                    }
                }
            }
            subObserver.startWatching()
            observers.add(subObserver)
        }
    }

    fun stopAll() {
        observers.forEach { it.stopWatching() }
        observers.clear()
    }

    fun addWatchFolder(context: Context, path: String) {
        val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
        val current = prefs.getStringSet("watch_folders", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        current.add(path)
        prefs.edit().putStringSet("watch_folders", current).apply()
        watchFolder(java.io.File(path))
    }
}
