package com.aeroplayer.ui

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Editor de etiquetas por lote.
 * Permite seleccionar varias canciones y cambiar artista, álbum o año a todas a la vez,
 * o editar título/artista de cada canción individualmente.
 */
class BatchTagEditorActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val selected = mutableSetOf<Long>()   // IDs seleccionados
    private lateinit var adapter: BatchAdapter
    private lateinit var rv: RecyclerView
    private lateinit var tvSelectedCount: TextView
    private lateinit var btnEdit: Button
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // ── Toolbar ──────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        tvSelectedCount = TextView(this).apply {
            text = "Editor por lote"
            textSize = 18f
            setTextColor(getColor(R.color.text_primary))
            setPadding(12.dp, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        // Seleccionar/deseleccionar todos
        val btnSelectAll = TextView(this).apply {
            text = "Todos"
            textSize = 13f
            setTextColor(getColor(R.color.accent_blue))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { toggleSelectAll() }
        }
        toolbar.addView(btnBack)
        toolbar.addView(tvSelectedCount)
        toolbar.addView(btnSelectAll)
        root.addView(toolbar)

        // ── Hint ─────────────────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text = "Mantén pulsado para editar individualmente · Toca para seleccionar"
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(20.dp, 0, 20.dp, 8.dp)
        })

        // ── Lista ─────────────────────────────────────────────────────────────
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@BatchTagEditorActivity)
            setPadding(0, 0, 0, 80.dp)
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        adapter = BatchAdapter(
            onSelect   = { song -> toggleSelect(song) },
            onLongTap  = { song -> showSingleEditDialog(song) },
            isSelected = { id  -> selected.contains(id) }
        )
        rv.adapter = adapter
        root.addView(rv)

        // ── Botón de edición por lote ─────────────────────────────────────────
        btnEdit = Button(this).apply {
            text = "Editar seleccionadas (0)"
            isEnabled = false
            setBackgroundColor(getColor(R.color.accent_blue))
            setTextColor(getColor(android.R.color.white))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 52.dp
            ).also { it.setMargins(16.dp, 8.dp, 16.dp, 16.dp) }
            setOnClickListener { showBatchEditDialog() }
        }
        root.addView(btnEdit)

        setContentView(root)

        viewModel.allSongs.observe(this) { songs ->
            adapter.submitList(songs.sortedBy { it.title.lowercase() })
        }
    }

    private fun toggleSelect(song: Song) {
        if (selected.contains(song.id)) selected.remove(song.id)
        else selected.add(song.id)
        adapter.notifyDataSetChanged()
        updateSelectionUI()
    }

    private fun toggleSelectAll() {
        val all = adapter.currentList.map { it.id }
        if (selected.containsAll(all)) selected.clear()
        else selected.addAll(all)
        adapter.notifyDataSetChanged()
        updateSelectionUI()
    }

    private fun updateSelectionUI() {
        val n = selected.size
        tvSelectedCount.text = if (n == 0) "Editor por lote" else "$n seleccionada${if (n != 1) "s" else ""}"
        btnEdit.text    = "Editar seleccionadas ($n)"
        btnEdit.isEnabled = n > 0
    }

    // ── Diálogo de edición por lote ───────────────────────────────────────────

    private fun showBatchEditDialog() {
        val fields = arrayOf("Artista", "Álbum", "Año", "Género")
        val checked = BooleanArray(fields.size) { false }

        val inputs = fields.map { label ->
            TextInputEditText(this).apply { hint = label }
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 8.dp, 24.dp, 0)
        }

        fields.forEachIndexed { i, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 4.dp, 0, 4.dp)
            }
            val cb = CheckBox(this).apply {
                setTextColor(getColor(R.color.text_primary))
                text = label
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setOnCheckedChangeListener { _, c -> checked[i] = c; inputs[i].isEnabled = c }
            }
            inputs[i].isEnabled = false
            inputs[i].layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            row.addView(cb)
            row.addView(inputs[i])
            container.addView(row)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Editar ${selected.size} canciones")
            .setMessage("Solo se cambiarán los campos marcados. El resto queda igual.")
            .setView(container)
            .setPositiveButton("Aplicar") { _, _ ->
                val changes = mapOf(
                    MediaStore.Audio.Media.ARTIST to (if (checked[0]) inputs[0].text?.toString()?.trim() else null),
                    MediaStore.Audio.Media.ALBUM  to (if (checked[1]) inputs[1].text?.toString()?.trim() else null),
                    MediaStore.Audio.Media.YEAR   to (if (checked[2]) inputs[2].text?.toString()?.trim() else null),
                    "genre"                        to (if (checked[3]) inputs[3].text?.toString()?.trim() else null)
                ).filterValues { !it.isNullOrBlank() }

                if (changes.isEmpty()) {
                    Snackbar.make(rv, "No marcaste ningún campo", Snackbar.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                applyBatchEdit(changes)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun applyBatchEdit(changes: Map<String, String?>) {
        val songs = adapter.currentList.filter { selected.contains(it.id) }
        lifecycleScope.launch(Dispatchers.IO) {
            var ok = 0; var fail = 0
            songs.forEach { song ->
                try {
                    val uri = Uri.withAppendedPath(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id.toString()
                    )
                    val values = ContentValues().apply {
                        changes[MediaStore.Audio.Media.ARTIST]?.let { put(MediaStore.Audio.Media.ARTIST, it) }
                        changes[MediaStore.Audio.Media.ALBUM]?.let  { put(MediaStore.Audio.Media.ALBUM,  it) }
                        changes[MediaStore.Audio.Media.YEAR]?.let   { put(MediaStore.Audio.Media.YEAR,   it.toIntOrNull() ?: 0) }
                    }
                    val rows = contentResolver.update(uri, values, null, null)
                    if (rows > 0) ok++ else fail++
                } catch (e: Exception) { fail++ }
            }
            withContext(Dispatchers.Main) {
                viewModel.loadSongs(forceRefresh = true)
                selected.clear()
                adapter.notifyDataSetChanged()
                updateSelectionUI()
                Snackbar.make(rv, "✓ $ok actualizada${if (ok != 1) "s" else ""}${if (fail > 0) " · $fail error${if (fail != 1) "es" else ""}" else ""}",
                    Snackbar.LENGTH_LONG).show()
            }
        }
    }

    // ── Edición individual desde long press ───────────────────────────────────

    private fun showSingleEditDialog(song: Song) {
        val titleInput  = TextInputEditText(this).apply { setText(song.title);  hint = "Título"  }
        val artistInput = TextInputEditText(this).apply { setText(song.artist); hint = "Artista" }
        val albumInput  = TextInputEditText(this).apply { setText(song.album);  hint = "Álbum"   }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 8.dp, 24.dp, 0)
            addView(titleInput)
            addView(artistInput)
            addView(albumInput)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Editar: ${song.title}")
            .setView(container)
            .setPositiveButton("Guardar") { _, _ ->
                val newTitle  = titleInput.text?.toString()?.trim()?.ifBlank { song.title  } ?: song.title
                val newArtist = artistInput.text?.toString()?.trim()?.ifBlank { song.artist } ?: song.artist
                val newAlbum  = albumInput.text?.toString()?.trim()?.ifBlank { song.album  } ?: song.album
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        val uri = Uri.withAppendedPath(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id.toString()
                        )
                        val values = ContentValues().apply {
                            put(MediaStore.Audio.Media.TITLE,  newTitle)
                            put(MediaStore.Audio.Media.ARTIST, newArtist)
                            put(MediaStore.Audio.Media.ALBUM,  newAlbum)
                        }
                        contentResolver.update(uri, values, null, null)
                        withContext(Dispatchers.Main) {
                            viewModel.loadSongs(forceRefresh = true)
                            Snackbar.make(rv, "✓ Guardado", Snackbar.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            Snackbar.make(rv, "Error: ${e.localizedMessage}", Snackbar.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}

// ── Adapter ───────────────────────────────────────────────────────────────────

private class BatchAdapter(
    private val onSelect:   (Song)   -> Unit,
    private val onLongTap:  (Song)   -> Unit,
    private val isSelected: (Long)   -> Boolean
) : ListAdapter<Song, BatchAdapter.VH>(SongDiff()) {

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val iv:       android.widget.ImageView = root.findViewById(android.R.id.icon)
        val tvTitle:  TextView                 = root.findViewById(android.R.id.text1)
        val tvSub:    TextView                 = root.findViewById(android.R.id.text2)
        val checkbox: CheckBox                 = root.findViewById(android.R.id.checkbox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
            isClickable = true
            isFocusable = true
        }

        val cb = CheckBox(ctx).apply {
            id = android.R.id.checkbox
            isClickable = false  // el click lo maneja el row
            layoutParams = LinearLayout.LayoutParams((32 * dp).toInt(), (32 * dp).toInt())
        }

        val size = (44 * dp).toInt()
        val iv = android.widget.ImageView(ctx).apply {
            id = android.R.id.icon
            layoutParams = LinearLayout.LayoutParams(size, size).also {
                it.marginEnd = (12 * dp).toInt(); it.marginStart = (8 * dp).toInt()
            }
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            background = ctx.getDrawable(R.drawable.bg_album_art_small)
            clipToOutline = true
        }

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(ctx).apply {
            id = android.R.id.text1
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_primary))
        }
        val tvSub = TextView(ctx).apply {
            id = android.R.id.text2
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_secondary))
        }
        texts.addView(tvTitle)
        texts.addView(tvSub)
        row.addView(cb)
        row.addView(iv)
        row.addView(texts)
        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.tvTitle.text  = song.title
        holder.tvSub.text    = "${song.artist} · ${song.album}"
        holder.checkbox.isChecked = isSelected(song.id)
        holder.root.alpha = if (isSelected(song.id)) 1f else 0.75f
        Glide.with(holder.iv)
            .load(song.albumArtUri)
            .placeholder(R.drawable.ic_music_placeholder)
            .centerCrop()
            .into(holder.iv)
        holder.root.setOnClickListener     { onSelect(song) }
        holder.root.setOnLongClickListener { onLongTap(song); true }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song)    = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
