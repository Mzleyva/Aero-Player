package com.aeroplayer.service

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * VisualizerAudioProcessor — v2.5.0
 *
 * AudioProcessor de Media3/ExoPlayer que intercepta las muestras PCM
 * del pipeline de audio ANTES de que lleguen al hardware.
 *
 * NO usa android.media.audiofx.Visualizer → NO necesita RECORD_AUDIO.
 *
 * Expone dos SharedFlow:
 *  - [fftFlow]  : magnitudes FFT suavizadas (FloatArray de 256 bins)
 *  - [waveFlow] : waveform normalizado (FloatArray de 512 muestras)
 */
@UnstableApi
class VisualizerAudioProcessor : AudioProcessor {

    companion object {
        private const val FFT_SIZE  = 512   // potencia de 2
        private const val WAVE_SIZE = 512
        private const val SMOOTH    = 0.20f // factor de suavizado exponencial

        // Singleton para acceder desde AudioVisualizerView sin DI
        val instance = VisualizerAudioProcessor()

        private val _fftFlow  = MutableSharedFlow<FloatArray>(replay = 1, extraBufferCapacity = 4)
        private val _waveFlow = MutableSharedFlow<FloatArray>(replay = 1, extraBufferCapacity = 4)

        val fftFlow:  SharedFlow<FloatArray> = _fftFlow.asSharedFlow()
        val waveFlow: SharedFlow<FloatArray> = _waveFlow.asSharedFlow()
    }

    // ── Estado interno ────────────────────────────────────────────────────────
    private var inputFormat: AudioFormat = AudioFormat.NOT_SET
    private var active = false
    private var buffer: ByteBuffer = ByteBuffer.allocate(0)
    private var outputBuffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER

    // Acumulador de muestras para FFT/wave
    private val sampleAccum = FloatArray(FFT_SIZE)
    private var accumIdx    = 0

    // FFT suavizada (solo la mitad positiva del espectro)
    private var smoothedFft = FloatArray(FFT_SIZE / 2)

    // ── AudioProcessor API ────────────────────────────────────────────────────

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        // Aceptar cualquier formato PCM que ExoPlayer produzca
        inputFormat = inputAudioFormat
        active = inputAudioFormat != AudioFormat.NOT_SET
        return inputAudioFormat  // pass-through: no modificamos el audio
    }

    override fun isActive(): Boolean = active

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!active || !inputBuffer.hasRemaining()) return

        // Copiar para no consumir el buffer original (pass-through)
        val copy = inputBuffer.duplicate().order(ByteOrder.nativeOrder())

        val bytesPerSample = inputFormat.encoding.let {
            when (it) {
                android.media.AudioFormat.ENCODING_PCM_16BIT -> 2
                android.media.AudioFormat.ENCODING_PCM_FLOAT -> 4
                else -> 2
            }
        }
        val channels = inputFormat.channelCount.coerceAtLeast(1)

        while (copy.remaining() >= bytesPerSample * channels) {
            // Leer solo el canal izquierdo (o el primero)
            val sample = when (bytesPerSample) {
                4    -> copy.float                               // FLOAT [-1, 1]
                else -> copy.short.toFloat() / Short.MAX_VALUE  // 16-bit
            }
            // Descartar los demás canales de este frame
            repeat(channels - 1) {
                if (bytesPerSample == 4) copy.float else copy.short
            }

            sampleAccum[accumIdx++] = sample

            if (accumIdx >= FFT_SIZE) {
                accumIdx = 0
                processChunk(sampleAccum.copyOf())
            }
        }

        // Pass-through: exponemos el buffer de entrada como salida sin cambios
        outputBuffer = inputBuffer
    }

    override fun queueEndOfStream() {
        // Nada especial necesario para el visualizador
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean = outputBuffer === AudioProcessor.EMPTY_BUFFER

    override fun flush() {
        accumIdx = 0
        outputBuffer = AudioProcessor.EMPTY_BUFFER
    }

    override fun reset() {
        flush()
        smoothedFft = FloatArray(FFT_SIZE / 2)
        inputFormat = AudioFormat.NOT_SET
        active = false
    }

    // ── Procesamiento ─────────────────────────────────────────────────────────

    private fun processChunk(samples: FloatArray) {
        // Waveform: downsample a WAVE_SIZE puntos
        val wave = FloatArray(WAVE_SIZE) { i ->
            samples[(i.toLong() * samples.size / WAVE_SIZE).toInt()]
                .coerceIn(-1f, 1f)
        }
        _waveFlow.tryEmit(wave)

        // FFT: aplicar ventana Hann y calcular magnitudes
        val windowed = applyHann(samples)
        val magnitudes = fft(windowed)

        // Suavizado exponencial
        for (i in magnitudes.indices) {
            smoothedFft[i] = smoothedFft[i] * (1f - SMOOTH) + magnitudes[i] * SMOOTH
        }
        _fftFlow.tryEmit(smoothedFft.copyOf())
    }

    /** Ventana de Hann para reducir spectral leakage */
    private fun applyHann(samples: FloatArray): FloatArray {
        val n = samples.size
        return FloatArray(n) { i ->
            val w = 0.5f * (1f - cos(2f * PI.toFloat() * i / (n - 1)))
            samples[i] * w
        }
    }

    /**
     * FFT in-place (Cooley-Tukey, radix-2, iterativa).
     * Devuelve magnitudes normalizadas [0, 1] para los bins positivos.
     */
    private fun fft(input: FloatArray): FloatArray {
        val n = input.size
        val re = input.copyOf()
        val im = FloatArray(n)

        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { re[i] = re[j].also { re[j] = re[i] }; im[i] = im[j].also { im[j] = im[i] } }
        }

        // FFT iterativa
        var len = 2
        while (len <= n) {
            val halfLen = len / 2
            val ang = 2.0 * PI / len
            val wRe = cos(ang).toFloat(); val wIm = -sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var curRe = 1f; var curIm = 0f
                for (k in 0 until halfLen) {
                    val uRe = re[i + k];          val uIm = im[i + k]
                    val vRe = re[i + k + halfLen]; val vIm = im[i + k + halfLen]
                    val tRe = curRe * vRe - curIm * vIm
                    val tIm = curRe * vIm + curIm * vRe
                    re[i + k]          = uRe + tRe; im[i + k]          = uIm + tIm
                    re[i + k + halfLen]= uRe - tRe; im[i + k + halfLen]= uIm - tIm
                    val nextRe = curRe * wRe - curIm * wIm
                    curIm = curRe * wIm + curIm * wRe; curRe = nextRe
                }
                i += len
            }
            len = len shl 1
        }

        // Magnitudes normalizadas (solo bins positivos, escala logarítmica)
        val half = n / 2
        val maxMag = (2f / n)
        return FloatArray(half) { i ->
            val mag = sqrt(re[i] * re[i] + im[i] * im[i]) * maxMag
            // Escala log para que las frecuencias bajas no dominen todo
            (log10(1f + mag * 9f)).coerceIn(0f, 1f)
        }
    }
}
