package com.aeroplayer.ui.nova

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║          VINYL DISC VIEW — Tema Aero (aurora + vinilo)                            ║
 * ║                                                                          ║
 * ║  Vista que dibuja un disco de vinilo giratorio con la carátula del      ║
 * ║  álbum en el centro. Reproduce el efecto visual de la imagen de         ║
 * ║  referencia del tema Windows Vista Aero.                                        ║
 * ║                                                                          ║
 * ║  Capas (de afuera a adentro):                                            ║
 * ║    1. Sombra exterior con glow azul                                      ║
 * ║    2. Disco negro con surcos/ranuras concéntricas                        ║
 * ║    3. Aro metálico especular                                              ║
 * ║    4. Zona de etiqueta central con la carátula                           ║
 * ║    5. Agujero central simulado                                           ║
 * ║    6. Highlight de brillo (mitad superior del vinilo)                    ║
 * ║                                                                          ║
 * ║  USO en XML:                                                             ║
 * ║    <com.aeroplayer.ui.nova.VinylDiscView                                ║
 * ║        android:id="@+id/vinylDiscView"                                  ║
 * ║        android:layout_width="match_parent"                              ║
 * ║        android:layout_height="match_parent"                             ║
 * ║        android:visibility="gone" />                                     ║
 * ║                                                                          ║
 * ║  USO en código:                                                          ║
 * ║    vinylDiscView.setAlbumArt(bitmap)                                    ║
 * ║    vinylDiscView.setSpinning(true)                                      ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
class VinylDiscView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // ── Estado público ────────────────────────────────────────────────────────
    private var albumArtBitmap: Bitmap? = null
    private var isSpinning = false

    // ── Animación ─────────────────────────────────────────────────────────────
    private var spinAnimator: ObjectAnimator? = null
    private var currentDegrees = 0f   // rotación actual del disco (no de la vista entera)

    // ── Paints ────────────────────────────────────────────────────────────────

    /** Sombra/glow exterior azul */
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.OUTER)
    }

    /** Cuerpo negro del vinilo */
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0D0D0D")
    }

    /** Surcos — líneas concéntricas finas */
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.7f
    }

    /** Aro metálico */
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    /** Zona de etiqueta central (base) */
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    /** Agujero central */
    private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0A0A0A")
    }

    /** Highlight de reflexión superior */
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // ── Paths y Rects reutilizables ───────────────────────────────────────────
    private val clipPath    = Path()
    private val artMatrix   = Matrix()
    private val artPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }

    /** Líneas de difracción radiales (surcos del vinilo) */
    private val diffractionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.4f
        color = Color.argb(12, 80, 140, 255)
    }
    /** Overlay oscuro sobre la carátula circular (aspecto de etiqueta de vinilo) */
    private val overlayPaint = Paint().apply {
        color = Color.argb(50, 0, 0, 0)
        style = Paint.Style.FILL
    }
    /** Borde de la zona de etiqueta */
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(80, 100, 150, 220)
    }

    // ── API pública ───────────────────────────────────────────────────────────

    fun setAlbumArt(bitmap: Bitmap?) {
        albumArtBitmap = bitmap
        invalidate()
    }

    fun setSpinning(spinning: Boolean) {
        isSpinning = spinning
        if (spinning) startSpin() else pauseSpin()
    }

    // ── Ciclo de vida del animator ────────────────────────────────────────────

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isSpinning) startSpin()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        spinAnimator?.cancel()
    }

    private fun startSpin() {
        if (spinAnimator?.isRunning == true) return
        spinAnimator?.cancel()
        spinAnimator = ObjectAnimator.ofFloat(this, "discRotation", currentDegrees, currentDegrees + 360f).apply {
            duration = 6_000L            // una vuelta completa cada 6 segundos
            repeatCount = ObjectAnimator.INFINITE
            repeatMode  = ObjectAnimator.RESTART
            interpolator = LinearInterpolator()
            start()
        }
    }

    private fun pauseSpin() {
        spinAnimator?.pause()
    }

    /**
     * Propiedad animable usada por ObjectAnimator.
     * Se aplica como rotación solo al disco (no a la vista entera).
     */
    @Suppress("unused")
    fun setDiscRotation(degrees: Float) {
        currentDegrees = degrees % 360f
        invalidate()
    }

    @Suppress("unused")
    fun getDiscRotation(): Float = currentDegrees

    // ── onDraw ────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        val radius = (minOf(w, h) / 2f) * 0.88f   // deja margen para el glow

        // Guardar canvas y aplicar rotación del disco
        canvas.save()
        canvas.rotate(currentDegrees, cx, cy)

        // 1. Glow exterior azul
        drawGlow(canvas, cx, cy, radius)

        // 2. Cuerpo del vinilo
        canvas.drawCircle(cx, cy, radius, discPaint)

        // 3. Surcos concéntricos
        drawGrooves(canvas, cx, cy, radius)

        // 4. Aro metálico entre surcos y zona de etiqueta
        val ringRadius = radius * 0.47f
        drawMetalRing(canvas, cx, cy, ringRadius)

        // 5. Zona de etiqueta con carátula (o placeholder)
        drawLabel(canvas, cx, cy, radius * 0.42f)

        // 6. Agujero central
        canvas.drawCircle(cx, cy, radius * 0.045f, holePaint)

        canvas.restore()

        // 7. Highlight de brillo (post-rotación para que sea fijo)
        drawHighlight(canvas, cx, cy, radius)
    }

    // ── Glow azul exterior ────────────────────────────────────────────────────

    private fun drawGlow(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        glowPaint.color = Color.argb(100, 30, 120, 255)
        canvas.drawCircle(cx, cy, radius, glowPaint)
    }

    // ── Surcos del vinilo ─────────────────────────────────────────────────────

    private fun drawGrooves(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val outerGroove = radius * 0.96f
        val innerGroove = radius * 0.50f
        val grooveCount = 28

        for (i in 0 until grooveCount) {
            val t = i.toFloat() / grooveCount.toFloat()
            val r = innerGroove + t * (outerGroove - innerGroove)

            // Alternar entre surco oscuro y pista ligeramente más clara
            val alpha = if (i % 3 == 0) 55 else 30
            val lightness = if (i % 3 == 0) 28 else 18
            groovePaint.color = Color.argb(alpha, lightness, lightness, lightness + 8)
            canvas.drawCircle(cx, cy, r, groovePaint)
        }

        // Líneas radiales muy sutiles (simulan difracción de la luz)
        val step = 15
        for (angle in 0 until 360 step step) {
            val radAngle = Math.toRadians(angle.toDouble()).toFloat()
            val cos = kotlin.math.cos(radAngle)
            val sin = kotlin.math.sin(radAngle)
            canvas.drawLine(
                cx + cos * innerGroove, cy + sin * innerGroove,
                cx + cos * outerGroove, cy + sin * outerGroove,
                diffractionPaint
            )
        }
    }

    // ── Aro metálico ──────────────────────────────────────────────────────────

    private fun drawMetalRing(canvas: Canvas, cx: Float, cy: Float, ringRadius: Float) {
        // Anillo exterior del label: efecto metálico con gradiente
        ringPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.argb(200, 120, 160, 200),
                Color.argb(255, 200, 220, 240),
                Color.argb(180, 80, 120, 160),
                Color.argb(255, 200, 220, 240),
                Color.argb(200, 120, 160, 200)
            ),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
        )
        ringPaint.strokeWidth = 3.5f
        canvas.drawCircle(cx, cy, ringRadius, ringPaint)

        // Segundo anillo interno fino
        ringPaint.strokeWidth = 1.2f
        ringPaint.shader = null
        ringPaint.color = Color.argb(60, 150, 180, 220)
        canvas.drawCircle(cx, cy, ringRadius * 0.92f, ringPaint)
    }

    // ── Zona de etiqueta del disco ────────────────────────────────────────────

    private fun drawLabel(canvas: Canvas, cx: Float, cy: Float, labelRadius: Float) {
        val art = albumArtBitmap

        if (art != null) {
            // Recortar en círculo y dibujar el bitmap
            clipPath.reset()
            clipPath.addCircle(cx, cy, labelRadius, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clipPath)

            // Escalar el bitmap para que llene el círculo de la etiqueta
            val scale = (labelRadius * 2f) / minOf(art.width, art.height).toFloat()
            val scaledW = art.width * scale
            val scaledH = art.height * scale
            artMatrix.setScale(scale, scale)
            artMatrix.postTranslate(cx - scaledW / 2f, cy - scaledH / 2f)
            canvas.drawBitmap(art, artMatrix, artPaint)

            // Overlay oscuro sutil para aspecto de etiqueta de vinilo
            canvas.drawCircle(cx, cy, labelRadius, overlayPaint)
            canvas.restore()

        } else {
            // Sin carátula: degradado radial placeholder azul oscuro
            labelPaint.shader = RadialGradient(
                cx, cy - labelRadius * 0.2f, labelRadius,
                intArrayOf(
                    Color.parseColor("#1A3260"),
                    Color.parseColor("#0D1E40"),
                    Color.parseColor("#070E20")
                ),
                floatArrayOf(0f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, labelRadius, labelPaint)
        }

        // Borde de la etiqueta
        canvas.drawCircle(cx, cy, labelRadius, edgePaint)
    }

    // ── Highlight superior (fijo, sin rotar) ──────────────────────────────────

    private fun drawHighlight(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        // Media luna en la parte superior del disco (simula reflexión de luz)
        highlightPaint.shader = RadialGradient(
            cx, cy - radius * 0.4f, radius * 0.7f,
            intArrayOf(
                Color.argb(50, 255, 255, 255),
                Color.argb(20, 200, 220, 255),
                Color.argb(0, 100, 160, 220)
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, highlightPaint)
    }
}
