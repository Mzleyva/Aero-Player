# 🚀 Guía de lanzamiento — AeroPlayer

## 1. Crear el Keystore (una sola vez)

Ejecuta este comando en tu PC con Java instalado:

```bash
keytool -genkey -v \
  -keystore aeroplayer.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias aeroplayer \
  -dname "CN=AeroPlayer, OU=Dev, O=AeroPlayer, L=Ciudad, S=Estado, C=MX"
```

Guarda la contraseña que elijas — la necesitarás siempre.

---

## 2. Convertir el keystore a Base64

```bash
base64 aeroplayer.jks > aeroplayer_base64.txt
```

---

## 3. Configurar Secrets en GitHub

Ve a tu repositorio → **Settings → Secrets and variables → Actions → New repository secret**

Añade estos 4 secrets:

| Secret | Valor |
|--------|-------|
| `KEYSTORE_BASE64` | Contenido de `aeroplayer_base64.txt` |
| `KEYSTORE_PASSWORD` | Contraseña del keystore |
| `KEY_ALIAS` | `aeroplayer` |
| `KEY_PASSWORD` | Contraseña de la clave (puede ser la misma) |

---

## 4. Compilar el APK de Release

**Opción A — GitHub Actions (recomendado):**
```
GitHub → Actions → Build & Release → Run workflow → release
```

**Opción B — Localmente:**
```bash
export KEYSTORE_PATH=aeroplayer.jks
export KEYSTORE_PASSWORD=tu_contraseña
export KEY_ALIAS=aeroplayer
export KEY_PASSWORD=tu_contraseña

./gradlew assembleRelease
```
APK en: `app/build/outputs/apk/release/app-release.apk`

**Opción C — Release automático por tag:**
```bash
git tag v1.0.0
git push origin v1.0.0
```
GitHub Actions crea el Release automáticamente con el APK y el AAB adjuntos.

---

## 5. Para subir a Google Play Store

Usa el **AAB** (Android App Bundle), no el APK:
```
app/build/outputs/bundle/release/app-release.aab
```

---

## 6. Compilación local sin keystore (solo debug)

```bash
chmod +x gradlew
./gradlew assembleDebug
```
APK en: `app/build/outputs/apk/debug/app-debug.apk`
