package com.aeroplayer.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aeroplayer.app.data.api.LyricsClient
import com.aeroplayer.app.data.model.Song
import com.aeroplayer.app.data.repository.MusicRepository
import com.aeroplayer.app.service.AudioService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    val repository = MusicRepository(app)

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _progress = MutableStateFlow(0L)
    val progress: StateFlow<Long> = _progress

    private val _lyrics = MutableStateFlow<String?>(null)
    val lyrics: StateFlow<String?> = _lyrics

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    fun connectService() {
        val token = SessionToken(
            getApplication(),
            android.content.ComponentName(getApplication(), AudioService::class.java)
        )
        controllerFuture = MediaController.Builder(getApplication(), token).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(playerListener)
        }, MoreExecutors.directExecutor())
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val tag = mediaItem?.localConfiguration?.tag as? Song
            if (tag != null) {
                _currentSong.value = tag
                viewModelScope.launch {
                    repository.incrementPlayCount(tag.id)
                    fetchLyrics(tag.artist, tag.title)
                }
            }
        }
    }

    fun playSong(song: Song, queue: List<Song> = emptyList()) {
        val ctrl = controller ?: return
        _queue.value = if (queue.isEmpty()) listOf(song) else queue

        val items = _queue.value.map { s ->
            MediaItem.Builder()
                .setUri(Uri.parse(s.path))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(s.title)
                        .setArtist(s.artist)
                        .setAlbumTitle(s.album)
                        .build()
                )
                .setTag(s)
                .build()
        }

        val startIndex = _queue.value.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        ctrl.setMediaItems(items, startIndex, 0)
        ctrl.prepare()
        ctrl.play()
        _currentSong.value = song
        viewModelScope.launch { fetchLyrics(song.artist, song.title) }
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
    }

    fun skipNext() { controller?.seekToNextMediaItem() }
    fun skipPrevious() { controller?.seekToPreviousMediaItem() }

    fun seekTo(position: Long) { controller?.seekTo(position) }

    fun toggleShuffle() {
        val newVal = !_shuffleEnabled.value
        _shuffleEnabled.value = newVal
        controller?.shuffleModeEnabled = newVal
    }

    fun cycleRepeat() {
        val next = when (_repeatMode.value) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        _repeatMode.value = next
        controller?.repeatMode = next
    }

    fun toggleLike(song: Song) {
        viewModelScope.launch {
            repository.setLiked(song.id, !song.isLiked)
        }
    }

    private suspend fun fetchLyrics(artist: String, title: String) {
        _lyrics.value = null
        try {
            val response = LyricsClient.api.getLyrics(artist, title)
            _lyrics.value = response.lyrics?.trim()
        } catch (e: Exception) {
            _lyrics.value = "No se encontraron letras para esta canción."
        }
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }
}
