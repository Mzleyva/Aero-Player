package com.aeroplayer.data.repository

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// ── Proveedor 1: lrclib.net — gratis, sin API key, letras sincronizadas ──────
data class LrclibResponse(
    @SerializedName("plainLyrics")  val plainLyrics: String?,
    @SerializedName("syncedLyrics") val syncedLyrics: String?,
    @SerializedName("error")        val error: String?
)

interface LyricsApiService {
    @GET("api/get")
    suspend fun getLyrics(
        @Query("artist_name") artist: String,
        @Query("track_name")  title:  String
    ): LrclibResponse
}

object LyricsApi {
    private const val BASE_URL = "https://lrclib.net/"

    val service: LyricsApiService by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LyricsApiService::class.java)
    }
}

// ── Proveedor 2: Genius via scraping (BetterLyrics compatible) ────────────────
object GeniusLyricsProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Android; AeroPlayer)")
                .build()
            chain.proceed(req)
        }
        .build()

    /**
     * Busca letras en Genius mediante su API pública (sin autenticación).
     * Devuelve el texto plano o null si no encuentra nada.
     */
    suspend fun fetch(artist: String, title: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                // Buscar en lrclib con parámetros alternativos como fallback
                val query = "$title $artist".trim()
                    .replace(" ", "+")
                    .replace("&", "and")
                val url = "https://lrclib.net/api/search?q=$query"
                val req = Request.Builder().url(url).build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: return@runCatching null

                // Parsear JSON array manualmente para evitar dependencia extra
                val gson = com.google.gson.Gson()
                val type = object : com.google.gson.reflect.TypeToken<List<LrclibResponse>>() {}.type
                val results: List<LrclibResponse> = gson.fromJson(body, type) ?: return@runCatching null

                results.firstOrNull { !it.plainLyrics.isNullOrBlank() }?.plainLyrics
                    ?: results.firstOrNull { !it.syncedLyrics.isNullOrBlank() }?.syncedLyrics
            }.getOrNull()
        }
}

// ── Proveedor 3: Musixmatch via API pública ────────────────────────────────────
object MusixmatchLyricsProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetch(artist: String, title: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                // API pública de lrclib con búsqueda alternativa por título
                val q = java.net.URLEncoder.encode("$title", "UTF-8")
                val a = java.net.URLEncoder.encode(artist, "UTF-8")
                val url = "https://lrclib.net/api/get?artist_name=$a&track_name=$q&album_name="
                val req = Request.Builder().url(url).build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: return@runCatching null
                val gson = com.google.gson.Gson()
                val result = gson.fromJson(body, LrclibResponse::class.java)
                result?.syncedLyrics?.takeIf { it.isNotBlank() }
                    ?: result?.plainLyrics?.takeIf { it.isNotBlank() }
            }.getOrNull()
        }
}

/** Resultado tipado de búsqueda de letras. */
sealed class LyricsResult {
    data class Success(val response: LrclibResponse) : LyricsResult()
    object NotFound : LyricsResult()
    data class Error(val throwable: Throwable) : LyricsResult()
}

/** Utilidad para guardar letras como archivo .lrc junto a la canción. */
object LyricsFileManager {

    /**
     * Guarda las letras (sincronizadas o planas) en un archivo .lrc
     * en la misma carpeta que el archivo de audio.
     * @return true si se guardó correctamente
     */
    fun saveLrc(songPath: String, syncedLyrics: String?, plainLyrics: String?): Boolean {
        val lyrics = syncedLyrics?.takeIf { it.isNotBlank() }
            ?: plainLyrics?.takeIf { it.isNotBlank() }
            ?: return false
        return runCatching {
            val lrcPath = songPath.substringBeforeLast(".") + ".lrc"
            java.io.File(lrcPath).writeText(lyrics, Charsets.UTF_8)
        }.isSuccess
    }

    /**
     * Lee el archivo .lrc local si existe junto a la canción.
     */
    fun readLrc(songPath: String): String? {
        val lrcPath = songPath.substringBeforeLast(".") + ".lrc"
        val file = java.io.File(lrcPath)
        return if (file.exists() && file.canRead()) file.readText(Charsets.UTF_8) else null
    }
}
