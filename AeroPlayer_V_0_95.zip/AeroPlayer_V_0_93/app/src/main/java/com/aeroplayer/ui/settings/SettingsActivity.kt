package com.aeroplayer.ui.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.drawable.DrawableCompat
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivitySettingsBinding
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.ThemeManager
import com.aeroplayer.ui.onboarding.OnboardingActivity
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        saveAvatar(uri)
        Glide.with(this).load(uri).circleCrop().into(binding.ivProfileAvatar)
    }

    private val backgroundPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        ThemeManager.setCustomBackground(this, uri)
        refreshBackgroundState()
        Toast.makeText(this, "Fondo personalizado aplicado ✓", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Aplicar color de acento a todas las vistas del layout
        com.aeroplayer.ui.AccentApplier.apply(this, binding.root)

        setupToolbar()
        loadProfile()
        setupHistory()
        setupStats()
        setupBatchTagEditor()
        setupTheme()
        setupAccentColor()
        setupCustomBackground()
        setupCrossfade()
        setupSmartShuffle()
        setupFadeIn()
        setupExcludeFolders()
        setupFavoriteFolders()
        setupReplayGain()
        setupFolderBrowser()
        setupHiFi()
        setupCarMode()
        setupDuplicateScanner()
        setupBackup()
        setupAbout()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.fade_in, R.anim.slide_out_right)
        }
    }

    private fun loadProfile() {
        val prefs  = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val name   = prefs.getString("user_name", "") ?: ""
        val avatar = prefs.getString("user_avatar", null)

        binding.tvProfileName.text = name.ifEmpty { getString(R.string.default_user_name) }

        // Cargar avatar con verificación de permisos persistentes
        if (avatar != null) {
            val avatarUri = Uri.parse(avatar)
            val hasPermission = contentResolver.persistedUriPermissions
                .any { it.uri == avatarUri && it.isReadPermission }
            if (hasPermission) {
                Glide.with(this).load(avatarUri).circleCrop()
                    .error(R.drawable.ic_person)
                    .into(binding.ivProfileAvatar)
            } else {
                // Intentar cargar igual (puede funcionar en la misma sesión)
                Glide.with(this).load(avatarUri).circleCrop()
                    .error(R.drawable.ic_person)
                    .into(binding.ivProfileAvatar)
            }
        }

        // Al tocar la fila: menú con opciones de nombre y foto
        binding.rowProfile.setOnClickListener {
            val options = arrayOf("✏️  Cambiar nombre", "📷  Cambiar foto de perfil")
            MaterialAlertDialogBuilder(this)
                .setTitle("Perfil")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> showEditNameDialog()
                        1 -> avatarPicker.launch("image/*")
                    }
                }
                .show()
        }
    }

    private fun showEditNameDialog() {
        val prefs      = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val currentName = prefs.getString("user_name", "") ?: ""

        val input = android.widget.EditText(this).apply {
            setText(currentName)
            hint      = getString(R.string.default_user_name)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setPadding(48, 24, 48, 8)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Nombre de usuario")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim()
                prefs.edit().putString("user_name", newName).apply()
                binding.tvProfileName.text =
                    newName.ifEmpty { getString(R.string.default_user_name) }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()

        // Abrir teclado automáticamente
        input.requestFocus()
        input.postDelayed({
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 100)
    }

    private fun saveAvatar(uri: Uri) {
        getSharedPreferences("aero_prefs", MODE_PRIVATE).edit()
            .putString("user_avatar", uri.toString())
            .apply()
    }

    private fun setupTheme() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)

        // Posibles valores guardados: "dark" | "light" | "auto"  (default: "auto")
        fun currentMode() = prefs.getString("theme_mode", "auto") ?: "auto"

        fun labelFor(mode: String) = when (mode) {
            "light" -> getString(R.string.theme_light_label)
            "dark"  -> getString(R.string.theme_dark_label)
            else    -> getString(R.string.theme_auto_label)
        }

        fun applyMode(mode: String) {
            prefs.edit().putString("theme_mode", mode).apply()
            binding.tvThemeCurrent.text = labelFor(mode)
            AppCompatDelegate.setDefaultNightMode(
                when (mode) {
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    "dark"  -> AppCompatDelegate.MODE_NIGHT_YES
                    else    -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }

        // Mostrar estado actual al entrar
        binding.tvThemeCurrent.text = labelFor(currentMode())

        // Opciones del diálogo
        val options = arrayOf(
            getString(R.string.theme_dark_label),
            getString(R.string.theme_light_label),
            getString(R.string.theme_auto_label)
        )
        val optionKeys = arrayOf("dark", "light", "auto")

        binding.rowTheme.setOnClickListener {
            val current = currentMode()
            val checkedIndex = optionKeys.indexOf(current).coerceAtLeast(0)

            MaterialAlertDialogBuilder(this)
                .setTitle("Tema")
                .setSingleChoiceItems(options, checkedIndex) { dialog, which ->
                    applyMode(optionKeys[which])
                    dialog.dismiss()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun setupCarMode() {
        binding.rowCarMode?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.carmode.CarModeActivity::class.java))
        }
    }

    private fun setupDuplicateScanner() {
        binding.rowDuplicateScanner?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.utils.DuplicateScannerActivity::class.java))
        }
    }

    private fun setupBackup() {
        binding.rowBackupExport?.setOnClickListener {
            val ts  = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.getDefault())
                .format(java.util.Date())
            val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(android.content.Intent.EXTRA_TITLE, "AeroPlayer_backup_$ts.json")
            }
            startActivityForResult(intent, REQUEST_BACKUP_EXPORT)
        }
        binding.rowBackupImport?.setOnClickListener {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
            startActivityForResult(intent, REQUEST_BACKUP_IMPORT)
        }
    }

    private fun setupSmartShuffle() {
        val sw = binding.switchSmartShuffle ?: return
        sw.isChecked = prefs.getBoolean("smart_shuffle_enabled", false)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("smart_shuffle_enabled", checked).apply()
            PlayerController.setSmartShuffle(checked)
        }
    }

    private fun setupFadeIn() {
        val sw = binding.switchFadeIn ?: return
        sw.isChecked = prefs.getBoolean("fade_in_enabled", false)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("fade_in_enabled", checked).apply()
            val durationMs = prefs.getLong("fade_in_duration_ms", 1_500L)
            PlayerController.setFadeIn(checked, durationMs)
        }
    }

    private fun setupCrossfade() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)

        // Switch on/off
        binding.switchCrossfade.isChecked = prefs.getBoolean("crossfade_enabled", false)
        binding.switchCrossfade.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("crossfade_enabled", checked).apply()
            PlayerController.setCrossfadeEnabled(checked)
            // Mostrar/ocultar opciones avanzadas
            binding.rowCrossfadeOptions?.visibility = if (checked) View.VISIBLE else View.GONE
        }
        binding.rowCrossfadeOptions?.visibility =
            if (binding.switchCrossfade.isChecked) View.VISIBLE else View.GONE

        // Duración y curva
        refreshCrossfadeSubtitle()
        binding.rowCrossfadeOptions?.setOnClickListener { showCrossfadeOptionsDialog() }
    }

    private fun refreshCrossfadeSubtitle() {
        val prefs    = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val durationMs = prefs.getLong("crossfade_duration_ms", 2_000L)
        val curveKey   = prefs.getString("fade_curve", "EQUAL_POWER") ?: "EQUAL_POWER"
        val curveLabel = when (curveKey) {
            "LINEAR"      -> "Lineal"
            "EASE_IN"     -> "Entrada suave"
            "EASE_OUT"    -> "Salida suave"
            "EQUAL_POWER" -> "Equal Power (natural)"
            else          -> "Equal Power"
        }
        val seconds = durationMs / 1000f
        val label = if (seconds == seconds.toLong().toFloat())
            "${seconds.toLong()}s · $curveLabel"
        else
            "${seconds}s · $curveLabel"
        binding.tvCrossfadeSubtitle?.text = label
    }

    private fun showCrossfadeOptionsDialog() {
        val prefs      = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val currentMs  = prefs.getLong("crossfade_duration_ms", 2_000L)
        val curveKey   = prefs.getString("fade_curve", "EQUAL_POWER") ?: "EQUAL_POWER"

        val view = layoutInflater.inflate(android.R.layout.activity_list_item, null)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 16.dp, 24.dp, 8.dp)
        }

        // Slider de duración 1s–12s
        val tvDuration = TextView(this).apply {
            text = "Duración: ${currentMs / 1000}s"
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
        }
        val seekBar = android.widget.SeekBar(this).apply {
            max = 11        // 1..12 segundos
            progress = ((currentMs / 1000) - 1).toInt().coerceIn(0, 11)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                    tvDuration.text = "Duración: ${p + 1}s"
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
            })
        }

        // Selector de curva
        val tvCurveLabel = TextView(this).apply {
            text = "Curva de transición"
            textSize = 14f
            setPadding(0, 16.dp, 0, 4.dp)
            setTextColor(getColor(R.color.text_primary))
        }
        val curves      = arrayOf("Equal Power (natural)", "Lineal", "Entrada suave", "Ease out")
        val curveKeys   = arrayOf("EQUAL_POWER", "LINEAR", "EASE_IN", "EASE_OUT")
        val curveChecked = curveKeys.indexOf(curveKey).coerceAtLeast(0)
        var selectedCurve = curveChecked
        val radioGroup = RadioGroup(this)
        curves.forEachIndexed { i, label ->
            val rb = RadioButton(this).apply {
                text = label
                id = i
                isChecked = (i == curveChecked)
                setTextColor(getColor(R.color.text_primary))
            }
            radioGroup.addView(rb)
        }
        radioGroup.setOnCheckedChangeListener { _, id -> selectedCurve = id }

        container.addView(tvDuration)
        container.addView(seekBar)
        container.addView(tvCurveLabel)
        container.addView(radioGroup)

        MaterialAlertDialogBuilder(this)
            .setTitle("Opciones de crossfade")
            .setView(container)
            .setPositiveButton("Aplicar") { _, _ ->
                val newMs = ((seekBar.progress + 1) * 1000L)
                val newCurveKey = curveKeys[selectedCurve]
                prefs.edit()
                    .putLong("crossfade_duration_ms", newMs)
                    .putString("fade_curve", newCurveKey)
                    .apply()
                PlayerController.setCrossfadeDuration(newMs)
                val curve = runCatching {
                    PlayerController.FadeCurve.valueOf(newCurveKey)
                }.getOrDefault(PlayerController.FadeCurve.EQUAL_POWER)
                PlayerController.setFadeCurve(curve)
                refreshCrossfadeSubtitle()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    // ── Carpetas excluidas ─────────────────────────────────────────────────
    private fun setupExcludeFolders() {
        refreshExcludedCount()
        binding.rowExcludeFolders.setOnClickListener {
            showExcludeFoldersDialog()
        }
    }

    private fun getExcludedFolders(): MutableSet<String> {
        return getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .getStringSet("excluded_folders", emptySet())
            ?.toMutableSet() ?: mutableSetOf()
    }

    private fun saveExcludedFolders(folders: Set<String>) {
        getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .edit().putStringSet("excluded_folders", folders).apply()
    }

    private fun refreshExcludedCount() {
        val count = getExcludedFolders().size
        binding.tvExcludedCount.text = if (count == 0) {
            getString(R.string.settings_exclude_folders_none)
        } else {
            getString(R.string.settings_exclude_folders_count, count)
        }
    }

    private fun showExcludeFoldersDialog() {
        val folders = getExcludedFolders()
        val items   = folders.toTypedArray()
        val checked = BooleanArray(items.size) { false }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.settings_exclude_folders_title))

        if (items.isEmpty()) {
            builder.setMessage(getString(R.string.settings_exclude_folders_none))
        } else {
            builder.setMultiChoiceItems(items, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            builder.setNegativeButton(getString(R.string.cancel), null)
            builder.setNeutralButton(getString(R.string.delete)) { _, _ ->
                val updated = folders.filterIndexed { i, _ -> !checked[i] }.toSet()
                saveExcludedFolders(updated)
                refreshExcludedCount()
                Toast.makeText(this, getString(R.string.settings_exclude_folders_saved), Toast.LENGTH_SHORT).show()
            }
        }

        builder.setPositiveButton(getString(R.string.settings_exclude_folders_add)) { _, _ ->
            showAddFolderDialog()
        }

        builder.show()
    }

    private fun showAddFolderDialog() {
        val input = TextInputEditText(this).apply {
            hint = getString(R.string.settings_exclude_folders_hint)
            setPadding(48, 32, 48, 16)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.settings_exclude_folders_add))
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                val folder = input.text?.toString()?.trim() ?: ""
                if (folder.isNotEmpty()) {
                    val folders = getExcludedFolders().also { it.add(folder) }
                    saveExcludedFolders(folders)
                    refreshExcludedCount()
                    Toast.makeText(this, getString(R.string.settings_exclude_folders_saved), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    // ── Carpetas favoritas (incluidas manualmente) ─────────────────────────
    private fun setupFavoriteFolders() {
        refreshFavoriteFoldersCount()
        binding.rowFavoriteFolders?.setOnClickListener {
            showFavoriteFoldersDialog()
        }
    }

    private fun getFavoriteFolders(): MutableSet<String> =
        getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .getStringSet("favorite_folders", emptySet())
            ?.toMutableSet() ?: mutableSetOf()

    private fun saveFavoriteFolders(folders: Set<String>) {
        getSharedPreferences("aero_prefs", MODE_PRIVATE)
            .edit().putStringSet("favorite_folders", folders).apply()
    }

    private fun refreshFavoriteFoldersCount() {
        val count = getFavoriteFolders().size
        binding.tvFavoriteFoldersCount?.text = if (count == 0)
            "Sin carpetas favoritas — se muestran todas"
        else
            "$count carpeta${if (count != 1) "s" else ""} incluida${if (count != 1) "s" else ""}"
    }

    private fun showFavoriteFoldersDialog() {
        val folders = getFavoriteFolders()
        val items   = folders.toTypedArray()
        val checked = BooleanArray(items.size) { false }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle("Carpetas favoritas")
            .setMessage(if (items.isEmpty())
                "Si agregas carpetas favoritas, solo se mostrarán las canciones de esas rutas.\n\nÚtil para tarjetas SD o carpetas específicas."
            else null)

        if (items.isNotEmpty()) {
            builder.setMultiChoiceItems(items, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            builder.setNeutralButton("Eliminar seleccionadas") { _, _ ->
                val updated = folders.filterIndexed { i, _ -> !checked[i] }.toSet()
                saveFavoriteFolders(updated)
                refreshFavoriteFoldersCount()
                Toast.makeText(this, "Carpetas actualizadas", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setPositiveButton("Agregar carpeta") { _, _ ->
            showAddFavoriteFolderDialog()
        }
        builder.setNegativeButton(getString(R.string.cancel), null)
        builder.show()
    }

    private fun showAddFavoriteFolderDialog() {
        val input = com.google.android.material.textfield.TextInputEditText(this).apply {
            hint = "/storage/emulated/0/Music o /sdcard/Music"
            setPadding(48, 32, 48, 16)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Agregar carpeta favorita")
            .setMessage("Ingresa la ruta completa de la carpeta")
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                val folder = input.text?.toString()?.trim()?.trimEnd('/') ?: ""
                if (folder.isNotEmpty()) {
                    val folders = getFavoriteFolders().also { it.add(folder) }
                    saveFavoriteFolders(folders)
                    refreshFavoriteFoldersCount()
                    Toast.makeText(this, "Carpeta favorita agregada ✓", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun setupHistory() {
        binding.rowHistory?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.HistoryActivity::class.java))
        }
    }

    private fun setupStats() {
        binding.rowStats?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.StatsActivity::class.java))
        }
    }

    private fun setupBatchTagEditor() {
        binding.rowBatchTagEditor?.setOnClickListener {
            startActivity(android.content.Intent(this, com.aeroplayer.ui.BatchTagEditorActivity::class.java))
        }
    }

    private fun setupAccentColor() {
        // Mostrar color actual
        val currentKey = ThemeManager.getCurrentAccentKey(this)
        val current = ThemeManager.accentOptions.firstOrNull { it.key == currentKey }
            ?: ThemeManager.accentOptions[0]
        binding.tvAccentCurrent?.text = current.nameEs
        updateAccentPreview(current.color)

        binding.rowAccentColor?.setOnClickListener {
            val names  = ThemeManager.accentOptions.map { it.nameEs }.toTypedArray()
            val keys   = ThemeManager.accentOptions.map { it.key }
            val colors = ThemeManager.accentOptions.map { it.color }
            val checked = keys.indexOf(ThemeManager.getCurrentAccentKey(this)).coerceAtLeast(0)

            MaterialAlertDialogBuilder(this)
                .setTitle("Color de acento")
                .setSingleChoiceItems(names, checked) { dialog, which ->
                    ThemeManager.setAccentColor(this, keys[which])
                    binding.tvAccentCurrent?.text = names[which]
                    updateAccentPreview(colors[which])
                    dialog.dismiss()
                    // FIX color de acento: recrear la Activity para que todas las vistas
                    // (nav, botones, textos con @color/accent_blue en XML) adopten el nuevo color.
                    // Sin recreate() solo cambia el indicador activo del nav.
                    setResult(android.app.Activity.RESULT_OK,
                        android.content.Intent().putExtra("accent_changed", true))
                    recreate()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }

    private fun updateAccentPreview(color: Int) {
        binding.vAccentPreview?.let { v ->
            val bg = v.background?.mutate() ?: return
            DrawableCompat.setTint(bg, color)
            v.background = bg
        }
    }

    private fun setupCustomBackground() {
        refreshBackgroundState()
        binding.rowCustomBackground?.setOnClickListener {
            val hasBackground = ThemeManager.hasCustomBackground(this)
            val options = if (hasBackground) {
                arrayOf("Cambiar imagen de fondo", "Quitar fondo personalizado")
            } else {
                arrayOf("Elegir imagen de fondo")
            }
            MaterialAlertDialogBuilder(this)
                .setTitle("Fondo personalizado")
                .setItems(options) { _, which ->
                    when {
                        which == 0 -> backgroundPicker.launch("image/*")
                        hasBackground && which == 1 -> {
                            ThemeManager.clearCustomBackground(this)
                            refreshBackgroundState()
                            Toast.makeText(this, "Fondo eliminado", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .show()
        }
    }

    private fun refreshBackgroundState() {
        binding.tvBackgroundCurrent?.text = if (ThemeManager.hasCustomBackground(this)) {
            "Fondo personalizado activo ✓"
        } else {
            "Sin fondo personalizado"
        }
    }

    // ── Normalización de volumen (ReplayGain) ─────────────────────────────────
    private fun setupReplayGain() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        binding.switchReplayGain?.apply {
            isChecked = prefs.getBoolean("replaygain_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("replaygain_enabled", checked).apply()
                if (!checked) com.aeroplayer.utils.ReplayGainManager.resetGain()
                binding.rowReplayGainMode?.visibility = if (checked) View.VISIBLE else View.GONE
            }
        }
        binding.rowReplayGainMode?.visibility =
            if (prefs.getBoolean("replaygain_enabled", false)) View.VISIBLE else View.GONE
        binding.rowReplayGainMode?.setOnClickListener {
            val modes = arrayOf("Por canción (Track)", "Por álbum (Album)")
            val current = if (prefs.getString("replaygain_mode", "TRACK") == "ALBUM") 1 else 0
            MaterialAlertDialogBuilder(this)
                .setTitle("Modo de normalización")
                .setSingleChoiceItems(modes, current) { dialog, which ->
                    prefs.edit().putString("replaygain_mode",
                        if (which == 1) "ALBUM" else "TRACK").apply()
                    dialog.dismiss()
                }
                .show()
        }
    }

    // ── Explorador de carpetas ─────────────────────────────────────────────────
    private fun setupFolderBrowser() {
        binding.rowFolderBrowser?.setOnClickListener {
            startActivity(
                android.content.Intent(this,
                    com.aeroplayer.ui.library.FolderBrowserActivity::class.java)
            )
        }
    }

    // ── Hi-Fi / USB DAC ────────────────────────────────────────────────────────
    private fun setupHiFi() {
        binding.rowHiFi?.setOnClickListener { showHiFiDialog() }
        // Mostrar badge si hay DAC USB o chip detectado
        val hasUsbDac = com.aeroplayer.utils.HiFiAudioManager.hasUsbDac(this)
        val chip = com.aeroplayer.utils.HiFiAudioManager.detectHiFiChip()
        binding.tvHiFiStatus?.text = when {
            hasUsbDac -> "🔌 DAC USB detectado"
            chip != com.aeroplayer.utils.HiFiAudioManager.HiFiChip.GENERIC -> "🎵 ${chip.name.replace("_", " ")}"
            else -> "Sin hardware Hi-Fi dedicado"
        }
    }

    private fun showHiFiDialog() {
        val devices = com.aeroplayer.utils.HiFiAudioManager.getOutputDevices(this)
        val chip    = com.aeroplayer.utils.HiFiAudioManager.detectHiFiChip()
        val instructions = com.aeroplayer.utils.HiFiAudioManager.getActivationInstructions(this)

        val sb = StringBuilder()
        sb.appendLine("📱 Chip: ${chip.name.replace("_", " ")}")
        sb.appendLine()
        sb.appendLine("🔊 Dispositivos de salida:")
        devices.forEach { dev ->
            sb.appendLine("  • ${dev.name} — ${dev.typeLabel}" +
                if (dev.isHiRes) " ✨ Hi-Res" else "")
        }
        sb.appendLine()
        sb.appendLine("ℹ️ $instructions")

        MaterialAlertDialogBuilder(this)
            .setTitle("Hi-Fi / Audio de alta calidad")
            .setMessage(sb.toString())
            .setPositiveButton("Intentar activar") { _, _ ->
                val result = com.aeroplayer.utils.HiFiAudioManager.activateHiFiMode(this)
                val msg = when (result) {
                    com.aeroplayer.utils.HiFiAudioManager.HiFiActivationResult.ACTIVATED ->
                        "✓ Hi-Fi activado"
                    com.aeroplayer.utils.HiFiAudioManager.HiFiActivationResult.REQUIRES_SYSTEM_SETTING ->
                        "Actívalo desde los ajustes del sistema (ver instrucciones arriba)"
                    else -> "No aplicable para este dispositivo"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun setupAbout() {
        binding.tvVersion.text = "${getString(R.string.about_version)} ${com.aeroplayer.BuildConfig.VERSION_NAME}"
        setupCrashLogs()
    }

    private fun setupCrashLogs() {
        binding.btnCopyLogs.setOnClickListener {
            val logs = com.aeroplayer.utils.CrashLogger.readLogs(this)
            if (logs.isBlank()) {
                android.widget.Toast.makeText(this, "No hay crashes registrados ✓", android.widget.Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val clipboard = getSystemService(android.content.ClipboardManager::class.java)
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("AeroPlayer Crash Log", logs))
            android.widget.Toast.makeText(this, "Log copiado al portapapeles", android.widget.Toast.LENGTH_LONG).show()
        }

        binding.btnClearLogs.setOnClickListener {
            com.aeroplayer.utils.CrashLogger.clearLogs(this)
            android.widget.Toast.makeText(this, "Logs borrados", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != android.app.Activity.RESULT_OK) return
        when (requestCode) {
            REQUEST_BACKUP_EXPORT -> {
                lifecycleScope.launch {
                    val result = com.aeroplayer.utils.BackupManager.export(this@SettingsActivity, uri)
                    android.widget.Toast.makeText(this@SettingsActivity, result.message, android.widget.Toast.LENGTH_LONG).show()
                }
            }
            REQUEST_BACKUP_IMPORT -> {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                    .setTitle("Restaurar backup")
                    .setMessage("Esto importará tus playlists y configuración guardadas. ¿Continuar?")
                    .setPositiveButton("Importar") { _, _ ->
                        lifecycleScope.launch {
                            val result = com.aeroplayer.utils.BackupManager.import(this@SettingsActivity, uri)
                            android.widget.Toast.makeText(this@SettingsActivity, result.message, android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    companion object {
        private const val REQUEST_BACKUP_EXPORT = 7001
        private const val REQUEST_BACKUP_IMPORT = 7002
    }
}
