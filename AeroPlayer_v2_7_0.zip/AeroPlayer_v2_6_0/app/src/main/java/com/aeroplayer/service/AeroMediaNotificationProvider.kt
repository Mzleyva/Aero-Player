package com.aeroplayer.service

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession

/**
 * AeroMediaNotificationProvider — proveedor de notificaciones personalizado para Media3.
 *
 * PROBLEMA EN ANDROID 11:
 * DefaultMediaNotificationProvider pasa el bitmap de portada a tamaño completo
 * (600×600 = ~1.4 MB sin comprimir) directamente a la notificación vía Binder IPC.
 * Android 11 tiene un límite de ~1 MB por transacción IPC en SystemUI.
 * Resultado: TransactionTooLargeException en el proceso de SystemUI → crash del
 * sistema operativo completo (la barra de estado desaparece, etc.).
 *
 * SOLUCIÓN:
 * Escalar el bitmap a máximo 256×256 antes de pasarlo a la notificación.
 * 256×256 = ~256 KB sin comprimir, muy por debajo del límite IPC.
 * Esta es la práctica estándar de Spotify, YouTube Music y otros reproductores.
 *
 * NOTA: El bitmap original (sin escalar) se sigue usando en el PlayerActivity;
 * solo el que va a la notificación se reduce.
 */
@UnstableApi
class AeroMediaNotificationProvider(context: Context) :
    DefaultMediaNotificationProvider(context) {

    companion object {
        // Tamaño máximo seguro para bitmaps en notificaciones en Android 11.
        // 256px × 256px × 4 bytes/px = 262 KB — muy por debajo del límite de 1 MB.
        private const val MAX_NOTIF_BITMAP_PX = 256
    }

    override fun addNotificationActions(
        mediaSession: MediaSession,
        mediaButtons: com.google.common.collect.ImmutableList<androidx.media3.session.CommandButton>,
        builder: androidx.core.app.NotificationCompat.Builder,
        actionFactory: MediaNotification.ActionFactory
    ): IntArray {
        return super.addNotificationActions(mediaSession, mediaButtons, builder, actionFactory)
    }

    /**
     * Intercepta el bitmap de portada antes de que se añada a la notificación.
     * Si es mayor que MAX_NOTIF_BITMAP_PX en cualquier dimensión, lo escala.
     */
    override fun getMediaArtworkBitmap(
        context: Context,
        metadata: MediaMetadata,
        durationMs: Long
    ): Bitmap? {
        val original = super.getMediaArtworkBitmap(context, metadata, durationMs)
            ?: return null
        return scaleBitmapForNotification(original)
    }

    private fun scaleBitmapForNotification(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= MAX_NOTIF_BITMAP_PX && h <= MAX_NOTIF_BITMAP_PX) return bitmap

        // Escalar manteniendo aspect ratio
        val scale = MAX_NOTIF_BITMAP_PX.toFloat() / maxOf(w, h)
        val newW = (w * scale).toInt().coerceAtLeast(1)
        val newH = (h * scale).toInt().coerceAtLeast(1)

        return runCatching {
            Bitmap.createScaledBitmap(bitmap, newW, newH, true /* filter = bilinear */)
        }.getOrElse { bitmap } // si falla por OOM, usar el original (mejor que crashear)
    }
}
