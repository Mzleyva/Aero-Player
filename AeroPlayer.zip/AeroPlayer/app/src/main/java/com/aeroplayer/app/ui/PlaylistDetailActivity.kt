package com.aeroplayer.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.app.databinding.ActivityPlaylistDetailBinding
import com.aeroplayer.app.ui.adapters.SongAdapter
import com.aeroplayer.app.ui.viewmodel.PlayerViewModel
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch
import com.aeroplayer.app.R

class PlaylistDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistDetailBinding
    private val viewModel: PlayerViewModel by viewModels(
        factoryProducer = { (application as AeroApp).playerViewModelFactory }
    )
    private var playlistId: Long = -1

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            lifecycleScope.launch {
                viewModel.repository.updatePlaylistCover(playlistId, it.toString())
            }
            Glide.with(this).load(it).into(binding.ivPlaylistCover)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playlistId = intent.getLongExtra("playlist_id", -1)
        if (playlistId == -1L) { finish(); return }

        val adapter = SongAdapter(
            onSongClick = { song ->
                lifecycleScope.launch {
                    val songs = mutableListOf<com.aeroplayer.app.data.model.Song>()
                    viewModel.repository.getSongsInPlaylist(playlistId).collect {
                        songs.clear(); songs.addAll(it)
                    }
                    viewModel.playSong(song, songs)
                    startActivity(Intent(this@PlaylistDetailActivity, PlayerActivity::class.java))
                }
            }
        )

        binding.rvPlaylistSongs.apply {
            layoutManager = LinearLayoutManager(this@PlaylistDetailActivity)
            this.adapter = adapter
        }

        lifecycleScope.launch {
            viewModel.repository.getSongsInPlaylist(playlistId).collect {
                adapter.submitList(it)
                binding.tvSongCount.text = "${it.size} canciones"
            }
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnPlayAll.setOnClickListener {
            val songs = adapter.currentList
            if (songs.isNotEmpty()) {
                viewModel.playSong(songs.first(), songs)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
        }

        // Cambiar carátula
        binding.ivPlaylistCover.setOnClickListener {
            imagePickerLauncher.launch("image/*")
        }
    }
}

// ─── AeroApp ───────────────────────────────────────────────────────────────
package com.aeroplayer.app

import android.app.Application
import androidx.lifecycle.ViewModelProvider
import com.aeroplayer.app.ui.viewmodel.PlayerViewModel

class AeroApp : Application() {
    val playerViewModelFactory: ViewModelProvider.Factory by lazy {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                return PlayerViewModel(this@AeroApp) as T
            }
        }
    }
}
