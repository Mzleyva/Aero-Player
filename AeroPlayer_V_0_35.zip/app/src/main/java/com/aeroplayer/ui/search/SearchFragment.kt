package com.aeroplayer.ui.search

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentSearchBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private lateinit var songsAdapter: SearchSongsAdapter
    private lateinit var artistsAdapter: SearchGroupAdapter
    private lateinit var albumsAdapter: SearchGroupAdapter
    private lateinit var recentAdapter: RecentSearchesAdapter
    private lateinit var recentManager: RecentSearchesManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recentManager = RecentSearchesManager(requireContext())
        setupRecentSearches()
        setupSearchBar()
        setupAdapters()
        setupChips()
        observeResults()
    }

    // ── Búsquedas recientes ──────────────────────────────────────────────────
    private fun setupRecentSearches() {
        recentAdapter = RecentSearchesAdapter(
            onQueryClick = { query ->
                binding.etSearch.setText(query)
                binding.etSearch.setSelection(query.length)
                viewModel.search(query)
                hideRecentSearches()
            },
            onRemoveClick = { query ->
                lifecycleScope.launch { recentManager.removeSearch(query) }
            }
        )
        binding.rvRecentSearches.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = recentAdapter
        }

        lifecycleScope.launch {
            recentManager.recentSearches.collectLatest { list ->
                recentAdapter.submitList(list)
                // Solo actualizar visibilidad si el campo está vacío
                if (binding.etSearch.text.isNullOrEmpty()) {
                    binding.recentSearchesContainer.visibility =
                        if (list.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.emptyState.visibility =
                        if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }

        binding.btnClearAllRecent.setOnClickListener {
            lifecycleScope.launch { recentManager.clearAll() }
        }
    }

    private fun hideRecentSearches() {
        binding.recentSearchesContainer.visibility = View.GONE
        binding.emptyState.visibility = View.GONE
    }

    // ── Search bar ───────────────────────────────────────────────────────────
    private fun setupSearchBar() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                binding.btnClear.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE

                when {
                    query.length >= 2 -> {
                        viewModel.search(query)
                        binding.recentSearchesContainer.visibility = View.GONE
                        binding.emptyState.visibility = View.GONE
                        binding.noResults.visibility = View.GONE
                    }
                    query.isEmpty() -> {
                        // Vacío: mostrar recientes o estado vacío
                        showEmptyOrRecent()
                        clearResults()
                    }
                    else -> {
                        // FIX: 1 carácter — ocultar recientes, mostrar mensaje de espera
                        binding.recentSearchesContainer.visibility = View.GONE
                        binding.noResults.visibility = View.GONE
                        binding.sectionSongs.visibility = View.GONE
                        binding.sectionArtists.visibility = View.GONE
                        binding.sectionAlbums.visibility = View.GONE
                        binding.emptyState.visibility = View.VISIBLE
                    }
                }
            }
        })

        binding.etSearch.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val query = v.text.toString().trim()
                if (query.length >= 2) {
                    lifecycleScope.launch { recentManager.addSearch(query) }
                }
                hideKeyboard()
                true
            } else false
        }

        binding.btnClear.setOnClickListener {
            binding.etSearch.text?.clear()
            showEmptyOrRecent()
            clearResults()
            hideKeyboard()
        }
    }

    private fun showEmptyOrRecent() {
        val hasRecent = recentAdapter.currentList.isNotEmpty()
        binding.recentSearchesContainer.visibility = if (hasRecent) View.VISIBLE else View.GONE
        binding.emptyState.visibility              = if (hasRecent) View.GONE    else View.VISIBLE
        binding.sectionSongs.visibility    = View.GONE
        binding.sectionArtists.visibility  = View.GONE
        binding.sectionAlbums.visibility   = View.GONE
        binding.noResults.visibility       = View.GONE
    }

    private fun clearResults() {
        songsAdapter.setQuery("")
        songsAdapter.submitList(emptyList())
        artistsAdapter.submitList(emptyList())
        albumsAdapter.submitList(emptyList())
    }

    // ── Chips de filtro ──────────────────────────────────────────────────────
    private fun setupChips() {
        binding.chipAll.setOnClickListener     { filterResults(SearchFilter.ALL) }
        binding.chipSongs.setOnClickListener   { filterResults(SearchFilter.SONGS) }
        binding.chipArtists.setOnClickListener { filterResults(SearchFilter.ARTISTS) }
        binding.chipAlbums.setOnClickListener  { filterResults(SearchFilter.ALBUMS) }
    }

    private fun filterResults(filter: SearchFilter) {
        binding.sectionSongs.visibility   = if (filter == SearchFilter.ALL || filter == SearchFilter.SONGS)   View.VISIBLE else View.GONE
        binding.sectionArtists.visibility = if (filter == SearchFilter.ALL || filter == SearchFilter.ARTISTS) View.VISIBLE else View.GONE
        binding.sectionAlbums.visibility  = if (filter == SearchFilter.ALL || filter == SearchFilter.ALBUMS)  View.VISIBLE else View.GONE
        binding.chipAll.isSelected     = filter == SearchFilter.ALL
        binding.chipSongs.isSelected   = filter == SearchFilter.SONGS
        binding.chipArtists.isSelected = filter == SearchFilter.ARTISTS
        binding.chipAlbums.isSelected  = filter == SearchFilter.ALBUMS
    }

    // ── Adapters ─────────────────────────────────────────────────────────────
    private fun setupAdapters() {
        songsAdapter = SearchSongsAdapter(
            onSongClick = { song, songs ->
                PlayerController.playSongs(songs, songs.indexOf(song))
                viewModel.incrementPlayCount(song)
                val query = binding.etSearch.text?.toString()?.trim() ?: ""
                if (query.length >= 2) lifecycleScope.launch { recentManager.addSearch(query) }
                startActivity(
                    Intent(requireContext(), PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(
                        requireContext(), R.anim.slide_up, R.anim.fade_out
                    ).toBundle()
                )
            },
            onLikeClick  = { song -> viewModel.toggleLike(song) },
            onAddToQueue = { song -> PlayerController.addToQueue(song) }
        )
        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = songsAdapter
            isNestedScrollingEnabled = false
        }

        artistsAdapter = SearchGroupAdapter { groupName ->
            showGroupSongs(groupName, SearchFilter.ARTISTS)
        }
        binding.rvArtists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = artistsAdapter
            isNestedScrollingEnabled = false
        }

        albumsAdapter = SearchGroupAdapter { groupName ->
            showGroupSongs(groupName, SearchFilter.ALBUMS)
        }
        binding.rvAlbums.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = albumsAdapter
            isNestedScrollingEnabled = false
        }
    }

    // ── Observar resultados ──────────────────────────────────────────────────
    private fun observeResults() {
        viewModel.searchResults.observe(viewLifecycleOwner) { songs ->
            val query = binding.etSearch.text?.toString()?.trim() ?: ""
            if (query.length < 2) return@observe

            songsAdapter.setQuery(query)   // FIX: activar resaltado de texto
            songsAdapter.submitList(songs.take(30))
            binding.sectionSongs.visibility = if (songs.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvSongsCount.text = "${songs.size} canciones"

            val artists = songs.groupBy { it.artist }
                .map { (artist, artistSongs) ->
                    SearchGroup(
                        name     = artist,
                        subtitle = "${artistSongs.size} canciones",
                        coverUri = artistSongs.firstOrNull()?.albumArtUri?.toString(),
                        songs    = artistSongs
                    )
                }.sortedBy { it.name }
            artistsAdapter.submitList(artists.take(20))
            binding.sectionArtists.visibility = if (artists.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvArtistsCount.text = "${artists.size} artistas"

            val albums = songs.groupBy { it.album }
                .map { (album, albumSongs) ->
                    SearchGroup(
                        name     = album,
                        subtitle = "${albumSongs.firstOrNull()?.artist ?: ""} • ${albumSongs.size} canciones",
                        coverUri = albumSongs.firstOrNull()?.albumArtUri?.toString(),
                        songs    = albumSongs
                    )
                }.sortedBy { it.name }
            albumsAdapter.submitList(albums.take(20))
            binding.sectionAlbums.visibility = if (albums.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvAlbumsCount.text = "${albums.size} álbumes"

            binding.noResults.visibility    = if (!songs.isNotEmpty()) View.VISIBLE else View.GONE
            binding.tvNoResultsQuery.text   = "\"$query\""
        }
    }

    private fun showGroupSongs(groupName: String, type: SearchFilter) {
        val allSongs = viewModel.searchResults.value ?: return
        val filtered = when (type) {
            SearchFilter.ARTISTS -> allSongs.filter { it.artist == groupName }
            SearchFilter.ALBUMS  -> allSongs.filter { it.album  == groupName }
            else -> allSongs
        }
        if (filtered.isNotEmpty()) {
            filtered.firstOrNull()?.let { viewModel.incrementPlayCount(it) }
            PlayerController.playSongs(filtered, 0)
            startActivity(
                    Intent(requireContext(), PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(
                        requireContext(), R.anim.slide_up, R.anim.fade_out
                    ).toBundle()
                )
        }
    }

    private fun hideKeyboard() {
        val imm = ContextCompat.getSystemService(requireContext(), InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

enum class SearchFilter { ALL, SONGS, ARTISTS, ALBUMS }
