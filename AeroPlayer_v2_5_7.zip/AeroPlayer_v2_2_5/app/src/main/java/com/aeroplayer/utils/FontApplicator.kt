package com.aeroplayer.utils

import android.app.Activity
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * FontApplicator — aplica una fuente personalizada a TODOS los TextViews
 * de una Activity de forma recursiva después del inflado completo.
 *
 * Usa decorView.post{} para esperar al primer frame renderizado,
 * garantizando que todas las vistas ya existen cuando se aplica la fuente.
 */
object FontApplicator {

    fun apply(activity: Activity, typeface: Typeface) {
        // post() garantiza ejecución después del primer layout completo
        activity.window?.decorView?.post {
            applyToView(activity.window.decorView, typeface)
        }
    }

    private fun applyToView(view: View, typeface: Typeface) {
        when {
            view is TextView -> {
                // Preservar negrita/cursiva si ya estaba aplicada
                val style = view.typeface?.style ?: Typeface.NORMAL
                view.typeface = Typeface.create(typeface, style)
            }
            view is ViewGroup -> {
                for (i in 0 until view.childCount) {
                    applyToView(view.getChildAt(i), typeface)
                }
            }
        }
    }
}
