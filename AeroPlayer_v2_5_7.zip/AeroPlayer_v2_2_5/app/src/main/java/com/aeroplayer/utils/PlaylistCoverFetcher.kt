package com.aeroplayer.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

/**
 * PlaylistCoverFetcher — Sesión 6
 *
 * Busca automáticamente una portada para una playlist usando:
 *   1. iTunes Search API (gratuita, sin clave, ~100ms)
 *   2. MusicBrainz / Cover Art Archive como fallback
 *
 * El nombre de la playlist se usa como query de búsqueda.
 * Devuelve la URL de la imagen en alta resolución (600x600) o null si no encuentra.
 *
 * Uso:
 *   val url = PlaylistCoverFetcher.fetch("Banda Grupera")
 *   if (url != null) viewModel.updatePlaylistFull(id, name, url)
 */
object PlaylistCoverFetcher {

    /**
     * Busca una portada para [playlistName].
     * Ejecutar en IO thread (suspending).
     * @return URL de imagen o null
     */
    suspend fun fetch(playlistName: String): String? = withContext(Dispatchers.IO) {
        // Limpiar el nombre: quitar emojis, signos, normalizar espacios
        val query = playlistName
            .replace(Regex("[^\\p{L}\\p{N} ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(60)  // iTunes tiene límite práctico en la query

        if (query.isBlank()) return@withContext null

        // ── Intento 1: iTunes Search API ─────────────────────────────────────
        runCatching {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val json = URL("https://itunes.apple.com/search?term=$encoded&media=music&entity=album&limit=5&lang=es_es")
                .openConnection()
                .apply { connectTimeout = 5_000; readTimeout = 5_000 }
                .getInputStream()
                .bufferedReader()
                .readText()

            val results = JSONObject(json).optJSONArray("results") ?: return@runCatching null
            if (results.length() == 0) return@runCatching null

            // Tomar el primer resultado y escalar la imagen a 600x600
            val artUrl = results.getJSONObject(0)
                .optString("artworkUrl100", "")
                .ifBlank { return@runCatching null }

            // iTunes devuelve 100x100; reemplazar por 600x600
            artUrl.replace("100x100bb", "600x600bb")
        }.getOrNull()
            ?: fetchFromMusicBrainz(query)
    }

    /** Fallback: MusicBrainz + Cover Art Archive */
    private fun fetchFromMusicBrainz(query: String): String? = runCatching {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val json = URL("https://musicbrainz.org/ws/2/release/?query=$encoded&limit=3&fmt=json")
            .openConnection()
            .apply {
                connectTimeout = 5_000; readTimeout = 5_000
                setRequestProperty("User-Agent", "AeroPlayer/2.0 (android)")
            }
            .getInputStream()
            .bufferedReader()
            .readText()

        val releases = JSONObject(json).optJSONArray("releases") ?: return null
        if (releases.length() == 0) return null

        val mbid = releases.getJSONObject(0).optString("id", "")
            .ifBlank { return null }

        // Intentar obtener portada desde Cover Art Archive
        val coverJson = URL("https://coverartarchive.org/release/$mbid")
            .openConnection()
            .apply { connectTimeout = 5_000; readTimeout = 5_000 }
            .getInputStream()
            .bufferedReader()
            .readText()

        JSONObject(coverJson)
            .optJSONArray("images")
            ?.getJSONObject(0)
            ?.optJSONObject("thumbnails")
            ?.optString("large", "")
            ?.ifBlank { null }
    }.getOrNull()
}
