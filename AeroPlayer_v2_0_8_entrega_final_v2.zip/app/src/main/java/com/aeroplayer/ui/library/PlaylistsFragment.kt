package com.aeroplayer.ui.library

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.databinding.FragmentPlaylistsBinding
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.SmartPlaylistActivity
import com.aeroplayer.ui.SmartPlaylistType
import com.aeroplayer.ui.playlist.CreatePlaylistActivity
import com.aeroplayer.ui.playlist.PlaylistDetailActivity

class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PlaylistAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupSmartPlaylists()
        setupRecyclerView()
        observePlaylists()
        setupFab()
    }

    private fun setupSmartPlaylists() {
        val smartAdapter = SmartPlaylistCardAdapter { type ->
            startActivity(
                Intent(requireContext(), SmartPlaylistActivity::class.java)
                    .putExtra(SmartPlaylistActivity.EXTRA_TYPE, type.name)
            )
        }
        binding.rvSmartPlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = smartAdapter
        }
        smartAdapter.submitList(SmartPlaylistType.entries.toList())

        // FIX: portada para la card "Me gusta" — primera canción con like
        viewLifecycleOwner.lifecycleScope.launch {
            val uriStr = viewModel.getLikedFirstArtUri()
            smartAdapter.updateLikedCover(uriStr?.let { android.net.Uri.parse(it) })
        }

        // Sesión 9: botones de Mix diario y Playlist rápida
        binding.btnDailyMix?.setOnClickListener {
            val allSongs = viewModel.allSongs.value ?: return@setOnClickListener
            val topPlayed = viewModel.topPlayed.value ?: emptyList()
            (parentFragment ?: this).let {
                // Llamar buildDailyMix desde HomeFragment si estamos anidados,
                // o directamente desde aquí si ya tenemos los datos
            }
            buildMixFromPlaylistsFragment(allSongs, topPlayed, isDaily = true)
        }
        binding.btnQuickPlaylist?.setOnClickListener {
            val allSongs = viewModel.allSongs.value ?: return@setOnClickListener
            val topPlayed = viewModel.topPlayed.value ?: emptyList()
            buildMixFromPlaylistsFragment(allSongs, topPlayed, isDaily = false)
        }
    }

    private fun buildMixFromPlaylistsFragment(
        allSongs: List<com.aeroplayer.model.Song>,
        topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>,
        isDaily: Boolean
    ) {
        if (allSongs.isEmpty()) return
        if (isDaily) {
            // Delegamos en HomeFragment via SharedViewModel
            viewModel.triggerDailyMix.value = true
        } else {
            viewModel.triggerQuickPlaylist.value = true
        }
    }

    private fun setupRecyclerView() {
        adapter = PlaylistAdapter(
            onPlaylistClick = { playlist ->
                startActivity(
                    Intent(requireContext(), PlaylistDetailActivity::class.java)
                        .putExtra("playlistId", playlist.id)
                        .putExtra("playlistName", playlist.name)
                )
            },
            onDeleteClick = { playlist ->
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar playlist")
                    .setMessage("¿Eliminar \"${playlist.name}\"?")
                    .setPositiveButton("Eliminar") { _, _ -> viewModel.deletePlaylist(playlist.id) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )
        // FIX SESIÓN 6: buscar portada en internet al tocar "Buscar portada"
        adapter.onFetchCoverClick = { playlist -> fetchCoverForPlaylist(playlist) }

        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@PlaylistsFragment.adapter
            setHasFixedSize(true)
        }
    }

    /** Busca portada por nombre de playlist en iTunes y la guarda en la DB. */
    private fun fetchCoverForPlaylist(playlist: com.aeroplayer.data.db.PlaylistEntity) {
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Buscando portada para \"${playlist.name}\"…", com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE)
        snack.show()
        viewLifecycleOwner.lifecycleScope.launch {
            val url = com.aeroplayer.utils.PlaylistCoverFetcher.fetch(playlist.name)
            snack.dismiss()
            if (url != null) {
                viewModel.updatePlaylistFull(playlist.id, playlist.name, url)
                com.google.android.material.snackbar.Snackbar.make(binding.root, "✅ Portada actualizada", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            } else {
                com.google.android.material.snackbar.Snackbar.make(binding.root, "No se encontró portada para \"${playlist.name}\"", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun observePlaylists() {
        viewModel.playlists.observe(viewLifecycleOwner) { playlists ->
            adapter.submitList(playlists)
            binding.tvEmpty.visibility = if (playlists.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text       = "${playlists.size} playlist${if (playlists.size != 1) "s" else ""}"
            playlists.forEach { playlist ->
                viewModel.getPlaylistSongCount(playlist.id)
                    .observe(viewLifecycleOwner) { count ->
                        adapter.updateSongCount(playlist.id, count ?: 0)
                    }
                // FIX SESIÓN 6 — Bug portada Me gusta / playlists sin coverUri:
                // Cuando la playlist no tiene coverUri propia, mostrar la carátula
                // de la primera canción. Antes no había fallback → ícono genérico siempre.
                if (playlist.coverUri == null) {
                    viewModel.getFirstSongCoverInPlaylist(playlist.id)
                        .observe(viewLifecycleOwner) { uri ->
                            adapter.updateSongCover(playlist.id, uri)
                        }
                }
            }
        }
    }

    private fun setupFab() {
        binding.fabNewPlaylist.setOnClickListener {
            startActivity(Intent(requireContext(), CreatePlaylistActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// ── Adapter de tarjetas de smart playlist (scroll horizontal) ─────────────────
private class SmartPlaylistCardAdapter(
    private val onClick: (SmartPlaylistType) -> Unit
) : ListAdapter<SmartPlaylistType, SmartPlaylistCardAdapter.VH>(TypeDiff()) {

    private val cardColors = listOf(
        intArrayOf(Color.parseColor("#1A3A6E"), Color.parseColor("#0D1F3C")), // Azul
        intArrayOf(Color.parseColor("#6E1A3A"), Color.parseColor("#3C0D1F")), // Rosa
        intArrayOf(Color.parseColor("#1A6E3A"), Color.parseColor("#0D3C1F")), // Verde
        intArrayOf(Color.parseColor("#6E3A1A"), Color.parseColor("#3C1F0D"))  // Naranja
    )

    inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card) {
        val tvEmoji: TextView  = card.findViewWithTag("emoji")
        val tvName:  TextView  = card.findViewWithTag("name")
        val tvDesc:  TextView  = card.findViewWithTag("desc")
        val ivCover: android.widget.ImageView? = card.findViewWithTag("cover")
    }

    // Cache de portadas para cards LIKED y otras
    private val coverCache = mutableMapOf<SmartPlaylistType, android.net.Uri?>()

    fun updateLikedCover(uri: android.net.Uri?) {
        coverCache[SmartPlaylistType.LIKED] = uri
        val pos = currentList.indexOf(SmartPlaylistType.LIKED)
        if (pos >= 0) notifyItemChanged(pos)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            layoutParams = RecyclerView.LayoutParams(
                (152 * dp).toInt(), (118 * dp).toInt()
            ).also { it.marginEnd = (10 * dp).toInt() }
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#1E2330"), Color.parseColor("#161A22"))
            ).apply { cornerRadius = 16 * dp }
            isClickable = true; isFocusable = true; elevation = 4 * dp
        }

        // ImageView de fondo para la portada (solo LIKED por ahora)
        val ivCover = android.widget.ImageView(ctx).apply {
            tag = "cover"
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            alpha = 0.35f
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }

        // Wrap en FrameLayout para superponer portada + contenido
        val frame = FrameLayout(ctx).apply {
            layoutParams = RecyclerView.LayoutParams(
                (152 * dp).toInt(), (118 * dp).toInt()
            ).also { it.marginEnd = (10 * dp).toInt() }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#1E2330"), Color.parseColor("#161A22"))
            ).apply { cornerRadius = 16 * dp }
            elevation = 4 * dp
        }
        frame.addView(ivCover)
        card.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        frame.addView(card)

        val tvEmoji = TextView(ctx).apply {
            tag = "emoji"; textSize = 26f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (6 * dp).toInt() }
        }
        val tvName = TextView(ctx).apply {
            tag = "name"; textSize = 12f; maxLines = 2
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        val tvDesc = TextView(ctx).apply {
            tag = "desc"; textSize = 10f; maxLines = 2
            setTextColor(Color.parseColor("#99FFFFFF"))
            gravity = android.view.Gravity.CENTER
            setPadding(0, (3 * dp).toInt(), 0, 0)
        }

        card.addView(tvEmoji)
        card.addView(tvName)
        card.addView(tvDesc)
        return VH(frame)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val type   = getItem(position)
        val colors = cardColors[position % cardColors.size]
        holder.tvEmoji.text = type.emoji
        holder.tvName.text  = type.titleEs
        holder.tvDesc.text  = type.descriptionEs
        val dp = holder.card.resources.displayMetrics.density
        holder.card.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, colors
        ).apply { cornerRadius = 16 * dp }

        // FIX SESIÓN 6: mostrar portada de la primera canción liked en la card LIKED
        val coverUri = coverCache[type]
        if (coverUri != null && holder.ivCover != null) {
            com.bumptech.glide.Glide.with(holder.ivCover)
                .load(coverUri)
                .centerCrop()
                .into(holder.ivCover)
            holder.ivCover.visibility = android.view.View.VISIBLE
        } else {
            holder.ivCover?.visibility = android.view.View.GONE
        }

        holder.itemView.setOnClickListener { onClick(type) }
    }

    class TypeDiff : DiffUtil.ItemCallback<SmartPlaylistType>() {
        override fun areItemsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
        override fun areContentsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
    }
}
