package com.aeroplayer.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.app.R
import com.aeroplayer.app.databinding.ActivityMainBinding
import com.aeroplayer.app.ui.fragments.*
import com.aeroplayer.app.ui.viewmodel.PlayerViewModel
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    val viewModel: PlayerViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            scanMusic()
        } else {
            Toast.makeText(this, "Se necesitan permisos para leer música", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.connectService()
        setupBottomNavigation()
        checkPermissions()

        // Mini player al tocar
        binding.miniPlayer.root.setOnClickListener {
            startActivity(android.content.Intent(this, PlayerActivity::class.java))
        }

        // Observar canción actual para mini player
        lifecycleScope.launch {
            viewModel.currentSong.collect { song ->
                if (song != null) {
                    binding.miniPlayer.tvMiniTitle.text = song.title
                    binding.miniPlayer.tvMiniArtist.text = song.artist
                }
            }
        }

        lifecycleScope.launch {
            viewModel.isPlaying.collect { playing ->
                binding.miniPlayer.btnMiniPlayPause.setImageResource(
                    if (playing) R.drawable.ic_pause else R.drawable.ic_play
                )
            }
        }

        binding.miniPlayer.btnMiniPlayPause.setOnClickListener { viewModel.togglePlayPause() }
        binding.miniPlayer.btnMiniNext.setOnClickListener { viewModel.skipNext() }
    }

    private fun setupBottomNavigation() {
        // Cargar fragmento inicial
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, HomeFragment())
            .commit()

        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_library -> LibraryFragment()
                R.id.nav_search -> SearchFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }
    }

    private fun checkPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) scanMusic() else permissionLauncher.launch(permissions)
    }

    private fun scanMusic() {
        lifecycleScope.launch {
            viewModel.repository.scanDeviceMusic()
        }
    }
}
