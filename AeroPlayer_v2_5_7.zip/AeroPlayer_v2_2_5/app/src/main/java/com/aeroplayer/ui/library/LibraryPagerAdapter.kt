package com.aeroplayer.ui.library

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.aeroplayer.ui.video.VideoLibraryFragment

class LibraryPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    private val ctx: Context = fragment.requireContext()

    private fun isVideoEnabled(): Boolean =
        ctx.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
            .getBoolean("video_local_enabled", false)

    override fun getItemCount() = if (isVideoEnabled()) 7 else 6

    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> FilesFragment()
        1 -> AlbumsFragment()
        2 -> ArtistsFragment()
        3 -> GenresFragment()
        4 -> LikedFragment()
        5 -> PlaylistsFragment()
        6 -> VideoLibraryFragment()   // Sesión 8: solo visible si video_local_enabled=true
        else -> FilesFragment()
    }
}
