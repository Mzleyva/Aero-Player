package com.aeroplayer.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur

object BlurUtils {

    /**
     * Aplica blur gaussiano a un bitmap.
     * Escala la imagen antes de procesar para mejor rendimiento.
     * @param radius radio de blur (1–25), 18 da buen efecto de fondo
     */
    fun blur(context: Context, source: Bitmap, radius: Float = 18f): Bitmap {
        // Escalar a un tamaño pequeño para acelerar el blur y acentuar el efecto
        val scaleFactor = 6
        val scaledW = (source.width / scaleFactor).coerceAtLeast(1)
        val scaledH = (source.height / scaleFactor).coerceAtLeast(1)

        val scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+: usar RenderEffect (más moderno, se aplica en el layout)
                // Aquí usamos el fallback de RenderScript que funciona en todas las versiones
                blurWithRenderScript(context, scaled, radius)
            } else {
                blurWithRenderScript(context, scaled, radius)
            }
        } catch (e: Exception) {
            // Fallback: si RenderScript falla, devolver la imagen escalada (ya tiene efecto suave)
            scaled
        }
    }

    @Suppress("DEPRECATION")
    private fun blurWithRenderScript(context: Context, bitmap: Bitmap, radius: Float): Bitmap {
        val safeRadius = radius.coerceIn(1f, 25f)
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)

        val rs = RenderScript.create(context)
        val input  = Allocation.createFromBitmap(rs, bitmap)
        val outAlloc = Allocation.createFromBitmap(rs, output)
        val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))

        script.setRadius(safeRadius)
        script.setInput(input)
        script.forEach(outAlloc)
        outAlloc.copyTo(output)

        rs.destroy()
        return output
    }
}
