package com.aeroplayer.ui.library

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.data.db.PlaylistEntity
import com.aeroplayer.databinding.ItemPlaylistBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * FIX: La versión anterior usaba LiveData.observe(context as LifecycleOwner) dentro
 * de onBindViewHolder, causando memory leaks porque los observers nunca se cancelaban
 * al reciclar ViewHolders.
 *
 * Solución: el caller pasa el conteo ya resuelto como Int.
 * PlaylistsFragment observa el LiveData una sola vez y llama notifyItemChanged
 * cuando cambia el conteo, manteniendo el adapter desacoplado del lifecycle.
 */
class PlaylistAdapter(
    private val onPlaylistClick: (PlaylistEntity) -> Unit,
    private val onDeleteClick: (PlaylistEntity) -> Unit
) : ListAdapter<PlaylistEntity, PlaylistAdapter.VH>(PlaylistDiff()) {

    // Map de playlistId → conteo de canciones actualizado desde el Fragment
    private val songCounts = mutableMapOf<Long, Int>()

    /** Llamado desde PlaylistsFragment cuando llega un conteo nuevo. */
    fun updateSongCount(playlistId: Long, count: Int) {
        val old = songCounts[playlistId]
        songCounts[playlistId] = count
        if (old != count) {
            val pos = currentList.indexOfFirst { it.id == playlistId }
            if (pos >= 0) notifyItemChanged(pos, PAYLOAD_COUNT)
        }
    }

    inner class VH(val b: ItemPlaylistBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivPlaylistCover.clipToOutline   = true
        b.ivPlaylistCover.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val playlist = getItem(position)
        bindFull(holder, playlist)
    }

    // Partial bind: solo actualiza el conteo sin redibujar todo el item
    override fun onBindViewHolder(holder: VH, position: Int, payloads: List<Any>) {
        if (payloads.contains(PAYLOAD_COUNT)) {
            val playlist = getItem(position)
            holder.b.tvSongCount.text = formatCount(songCounts[playlist.id] ?: 0)
        } else if (payloads.contains(PAYLOAD_COVER)) {
            val playlist = getItem(position)
            val cover: Any? = playlist.coverUri ?: songCovers[playlist.id]
            Glide.with(holder.b.ivPlaylistCover)
                .load(cover)
                .placeholder(R.drawable.ic_playlist_placeholder)
                .error(R.drawable.ic_playlist_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(holder.b.ivPlaylistCover)
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    private fun bindFull(holder: VH, playlist: PlaylistEntity) = with(holder.b) {
        tvPlaylistName.text = playlist.name
        tvSongCount.text    = formatCount(songCounts[playlist.id] ?: 0)

        // FIX SESIÓN 6 — Portada con 3 niveles de fallback:
        // 1. coverUri guardada en la DB (puede ser URL de internet o URI local)
        // 2. Primera carátula de las canciones de la playlist (resuelto por el caller)
        // 3. Placeholder
        val coverSource: Any? = playlist.coverUri
            ?: songCovers[playlist.id]  // URI de la primera canción de la playlist

        Glide.with(ivPlaylistCover)
            .load(coverSource)
            .placeholder(R.drawable.ic_playlist_placeholder)
            .error(R.drawable.ic_playlist_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(ivPlaylistCover)

        ivMore.setOnClickListener {
            MaterialAlertDialogBuilder(root.context)
                .setTitle(playlist.name)
                .setItems(arrayOf("Editar nombre", "Buscar portada en internet", "Eliminar playlist")) { _, which ->
                    when (which) {
                        0 -> { /* editar nombre — manejado por el caller */ }
                        1 -> onFetchCoverClick?.invoke(playlist)
                        2 -> onDeleteClick(playlist)
                    }
                }
                .show()
        }

        root.setOnClickListener { onPlaylistClick(playlist) }
    }

    // Map de playlistId → URI de la primera canción (fallback de portada)
    private val songCovers = mutableMapOf<Long, android.net.Uri?>()

    /** Llamado desde PlaylistsFragment con la URI de la primera canción de la playlist. */
    fun updateSongCover(playlistId: Long, coverUri: android.net.Uri?) {
        val old = songCovers[playlistId]
        songCovers[playlistId] = coverUri
        // Solo refrescar si no hay coverUri propia y el cover de canción cambió
        if (old != coverUri) {
            val pos = currentList.indexOfFirst { it.id == playlistId && it.coverUri == null }
            if (pos >= 0) notifyItemChanged(pos, PAYLOAD_COVER)
        }
    }

    var onFetchCoverClick: ((PlaylistEntity) -> Unit)? = null

    private fun formatCount(count: Int) = when (count) {
        0    -> "Sin canciones"
        1    -> "1 canción"
        else -> "$count canciones"
    }

    companion object {
        private const val PAYLOAD_COUNT = "payload_count"
        private const val PAYLOAD_COVER = "payload_cover"
    }

    class PlaylistDiff : DiffUtil.ItemCallback<PlaylistEntity>() {
        override fun areItemsTheSame(a: PlaylistEntity, b: PlaylistEntity) = a.id == b.id
        override fun areContentsTheSame(a: PlaylistEntity, b: PlaylistEntity) = a == b
    }
}
