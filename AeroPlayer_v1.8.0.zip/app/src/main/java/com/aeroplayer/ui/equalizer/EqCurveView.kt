package com.aeroplayer.ui.equalizer

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

/**
 * Vista que dibuja la curva de respuesta del ecualizador en tiempo real.
 * Se actualiza cada vez que el usuario mueve una banda.
 */
class EqCurveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var levels: List<Int> = emptyList()   // milli-dB por banda

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = 0xFF5B9BD4.toInt()
        style  = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val zeroPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = 0x33FFFFFF
        style       = Paint.Style.STROKE
        strokeWidth = 1f
    }

    fun setLevels(levels: List<Int>) {
        this.levels = levels
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (levels.isEmpty()) return

        val w     = width.toFloat()
        val h     = height.toFloat()
        val midY  = h / 2f
        val range = 1500f   // ±1500 milli-dB típico

        // Línea central (0 dB)
        canvas.drawLine(0f, midY, w, midY, zeroPaint)

        // Construir path de la curva usando spline cúbico suavizado
        val path  = Path()
        val n     = levels.size

        fun xOf(i: Int) = if (n <= 1) w / 2f else i.toFloat() / (n - 1) * w
        fun yOf(level: Int) = midY - (level.toFloat() / range) * midY

        if (n == 1) {
            val y = yOf(levels[0])
            path.moveTo(0f, y); path.lineTo(w, y)
        } else {
            // Calcular puntos de control para curva suavizada (Catmull-Rom → Bezier)
            path.moveTo(xOf(0), yOf(levels[0]))
            for (i in 0 until n - 1) {
                val x0 = xOf((i - 1).coerceAtLeast(0))
                val y0 = yOf(levels[(i - 1).coerceAtLeast(0)])
                val x1 = xOf(i);     val y1 = yOf(levels[i])
                val x2 = xOf(i + 1); val y2 = yOf(levels[i + 1])
                val x3 = xOf((i + 2).coerceAtMost(n - 1))
                val y3 = yOf(levels[(i + 2).coerceAtMost(n - 1)])

                val cp1x = x1 + (x2 - x0) / 6f
                val cp1y = y1 + (y2 - y0) / 6f
                val cp2x = x2 - (x3 - x1) / 6f
                val cp2y = y2 - (y3 - y1) / 6f
                path.cubicTo(cp1x, cp1y, cp2x, cp2y, x2, y2)
            }
        }

        // Fill degradado debajo de la curva
        val fillPath = Path(path)
        fillPath.lineTo(w, midY)
        fillPath.lineTo(0f, midY)
        fillPath.close()
        fillPaint.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(0x335B9BD4, 0x005B9BD4),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)

        // Línea principal
        canvas.drawPath(path, linePaint)

        // Puntos en cada banda
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF5B9BD4.toInt()
            style = Paint.Style.FILL
        }
        levels.forEachIndexed { i, level ->
            canvas.drawCircle(xOf(i), yOf(level), 4f, dotPaint)
        }
    }
}
