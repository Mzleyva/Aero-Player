package com.aeroplayer.service

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aeroplayer.model.Song

/**
 * MultiQueueManager — v1.8.3
 *
 * Gestiona múltiples colas de reproducción nombradas simultáneas.
 * El concepto es similar a Musicolet: el usuario puede tener varias
 * colas activas y cambiar entre ellas sin perder el estado de ninguna.
 *
 * Integración:
 *  - PlayerController delega a MultiQueueManager para get/set de la cola activa.
 *  - La UI puede listar todas las colas con [allQueues] y cambiar con [switchTo].
 *  - Persiste las colas en SharedPreferences como JSON.
 */
object MultiQueueManager {

    data class NamedQueue(
        val id: String,
        val name: String,
        val songs: List<Song>,
        val currentIndex: Int = 0,
        val positionMs: Long = 0L
    )

    private val _queues = MutableLiveData<List<NamedQueue>>(emptyList())
    val allQueues: LiveData<List<NamedQueue>> = _queues

    private val _activeId = MutableLiveData<String?>(null)
    val activeQueueId: LiveData<String?> = _activeId

    private val _activeQueue = MutableLiveData<NamedQueue?>(null)
    val activeQueue: LiveData<NamedQueue?> = _activeQueue

    // ── Crear / obtener colas ─────────────────────────────────────────────────

    /** Crea una nueva cola y la establece como activa. */
    fun createQueue(name: String, songs: List<Song>, startIndex: Int = 0): NamedQueue {
        val id    = "q_${System.currentTimeMillis()}"
        val queue = NamedQueue(id = id, name = name, songs = songs, currentIndex = startIndex)
        val current = _queues.value.orEmpty().toMutableList()
        current.add(queue)
        _queues.postValue(current)
        setActive(id)
        return queue
    }

    /** Reemplaza la cola activa con nuevas canciones (el comportamiento anterior). */
    fun setActiveQueueSongs(songs: List<Song>, name: String? = null, startIndex: Int = 0) {
        val activeId = _activeId.value
        if (activeId != null) {
            updateQueue(activeId, songs = songs, currentIndex = startIndex, name = name)
        } else {
            createQueue(name ?: "Cola 1", songs, startIndex)
        }
    }

    /** Cambia la cola activa. Retorna la NamedQueue activada, o null si el id no existe. */
    fun switchTo(id: String): NamedQueue? {
        val q = _queues.value.orEmpty().find { it.id == id } ?: return null
        setActive(id)
        return q
    }

    /** Devuelve las canciones de la cola activa. */
    fun getActiveSongs(): List<Song> = _activeQueue.value?.songs ?: emptyList()

    /** Devuelve el índice actual de la cola activa. */
    fun getActiveIndex(): Int = _activeQueue.value?.currentIndex ?: 0

    /** Actualiza el progreso (índice + posición) de la cola activa. */
    fun saveProgress(index: Int, positionMs: Long) {
        val id = _activeId.value ?: return
        updateQueue(id, currentIndex = index, positionMs = positionMs)
    }

    /** Añade una canción al final de la cola activa. */
    fun addToActiveQueue(song: Song) {
        val id = _activeId.value ?: run {
            createQueue("Cola 1", listOf(song)); return
        }
        val q = _queues.value.orEmpty().find { it.id == id } ?: return
        updateQueue(id, songs = q.songs + song)
    }

    /** Elimina una canción de la cola activa por índice. */
    fun removeFromActiveQueue(index: Int) {
        val id = _activeId.value ?: return
        val q = _queues.value.orEmpty().find { it.id == id } ?: return
        val newSongs = q.songs.toMutableList().also { it.removeAt(index) }
        updateQueue(id, songs = newSongs)
    }

    /** Reordena la cola activa. */
    fun reorderActiveQueue(newOrder: List<Song>) {
        val id = _activeId.value ?: return
        updateQueue(id, songs = newOrder)
    }

    /** Elimina una cola por id. Si era la activa, activa la primera disponible. */
    fun deleteQueue(id: String) {
        val current = _queues.value.orEmpty().toMutableList()
        current.removeAll { it.id == id }
        _queues.postValue(current)
        if (_activeId.value == id) {
            val next = current.firstOrNull()
            if (next != null) setActive(next.id) else { _activeId.postValue(null); _activeQueue.postValue(null) }
        }
    }

    /** Renombra una cola. */
    fun renameQueue(id: String, newName: String) = updateQueue(id, name = newName)

    // ── Internos ──────────────────────────────────────────────────────────────

    private fun setActive(id: String) {
        _activeId.postValue(id)
        _activeQueue.postValue(_queues.value.orEmpty().find { it.id == id })
    }

    private fun updateQueue(
        id: String,
        name: String?      = null,
        songs: List<Song>? = null,
        currentIndex: Int? = null,
        positionMs: Long?  = null
    ) {
        val current = _queues.value.orEmpty().toMutableList()
        val idx = current.indexOfFirst { it.id == id }
        if (idx < 0) return
        val old = current[idx]
        current[idx] = old.copy(
            name         = name         ?: old.name,
            songs        = songs        ?: old.songs,
            currentIndex = currentIndex ?: old.currentIndex,
            positionMs   = positionMs   ?: old.positionMs
        )
        _queues.postValue(current)
        if (_activeId.value == id) _activeQueue.postValue(current[idx])
    }
}
