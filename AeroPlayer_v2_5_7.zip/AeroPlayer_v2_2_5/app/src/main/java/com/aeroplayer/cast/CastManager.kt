package com.aeroplayer.cast

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.CastState
import com.google.android.gms.cast.framework.CastStateListener
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.aeroplayer.model.Song

/**
 * Singleton que gestiona el estado de la sesión de Chromecast.
 * Se inicializa en MainActivity y se usa desde PlayerActivity.
 */
object CastManager {

    private val _isCasting = MutableLiveData(false)
    val isCasting: LiveData<Boolean> = _isCasting

    private val _isAvailable = MutableLiveData(false)
    val isAvailable: LiveData<Boolean> = _isAvailable

    private var castContext: CastContext? = null
    private var currentSession: CastSession? = null

    private val castStateListener = CastStateListener { state ->
        _isAvailable.postValue(state != CastState.NO_DEVICES_AVAILABLE)
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            currentSession = session
            _isCasting.postValue(true)
        }
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            currentSession = session
            _isCasting.postValue(true)
        }
        override fun onSessionEnded(session: CastSession, error: Int) {
            currentSession = null
            _isCasting.postValue(false)
        }
        override fun onSessionSuspended(session: CastSession, reason: Int) {
            _isCasting.postValue(false)
        }
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionStartFailed(session: CastSession, error: Int) {
            _isCasting.postValue(false)
        }
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
    }

    fun init(context: Context) {
        runCatching {
            castContext = CastContext.getSharedInstance(context)
            castContext?.addCastStateListener(castStateListener)
            castContext?.sessionManager?.addSessionManagerListener(
                sessionListener, CastSession::class.java
            )
        }
    }

    fun release() {
        castContext?.removeCastStateListener(castStateListener)
        castContext?.sessionManager?.removeSessionManagerListener(
            sessionListener, CastSession::class.java
        )
    }

    /**
     * Envía una canción al Chromecast conectado.
     *
     * Mejoras v2.3.0:
     * - Levanta un servidor HTTP local con NanoHTTPD para servir el archivo
     *   (Chromecast no puede acceder a content:// URIs locales directamente).
     * - Fallback graceful si el archivo no es accesible.
     * - Registra listener para sincronizar posición Cast ↔ ExoPlayer.
     */
    fun castSong(song: Song, context: Context? = null) {
        val session = currentSession ?: return
        val remoteClient = session.remoteMediaClient ?: return

        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MUSIC_TRACK).apply {
            putString(MediaMetadata.KEY_TITLE,        song.title)
            putString(MediaMetadata.KEY_ARTIST,       song.artist)
            putString(MediaMetadata.KEY_ALBUM_TITLE,  song.album)
            putString(MediaMetadata.KEY_TRACK_NUMBER, "${song.trackNumber}")
            song.albumArtUri?.let {
                addImage(com.google.android.gms.common.images.WebImage(
                    android.net.Uri.parse(it.toString())
                ))
            }
        }

        // Intentar servir el archivo localmente vía servidor HTTP embebido
        val contentUrl = tryGetLocalHttpUrl(song, context) ?: song.uri.toString()

        val mediaInfo = MediaInfo.Builder(contentUrl)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(getMimeType(song))
            .setMetadata(metadata)
            .setStreamDuration(song.duration)
            .build()

        val startPosition = com.aeroplayer.service.PlayerController.getCurrentPosition()

        remoteClient.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(mediaInfo)
                .setAutoplay(true)
                .setCurrentTime(startPosition)
                .build()
        ).addStatusListener { status ->
            if (!status.isSuccess) {
                android.util.Log.w("CastManager", "Cast load failed: ${status.statusCode}")
            }
        }

        // Sincronizar posición Cast → ExoPlayer al pausar/reanudar
        remoteClient.registerCallback(object : com.google.android.gms.cast.framework.media.RemoteMediaClient.Callback() {
            override fun onStatusUpdated() {
                val pos = remoteClient.approximateStreamPosition
                if (pos > 0 && !remoteClient.isPlaying) {
                    com.aeroplayer.service.PlayerController.seekTo(pos)
                }
            }
        })
    }

    /**
     * Intenta resolver la URI de la canción en una URL HTTP accesible por Chromecast.
     * Usa el servidor HTTP local si está disponible.
     */
    private fun tryGetLocalHttpUrl(song: Song, context: Context?): String? {
        // Si ya es una URL HTTP/HTTPS (radio, stream), usarla directamente
        val uriStr = song.uri.toString()
        if (uriStr.startsWith("http://") || uriStr.startsWith("https://")) return uriStr

        // Para archivos locales, exponer vía FileProvider o servidor local
        // (requiere permisos de red local en la misma WiFi)
        if (context != null) {
            try {
                val file = java.io.File(song.path)
                if (file.exists() && file.canRead()) {
                    // Obtener IP local
                    val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
                    val ipInt = wifiManager?.connectionInfo?.ipAddress ?: 0
                    if (ipInt != 0) {
                        val ip = android.text.format.Formatter.formatIpAddress(ipInt)
                        return "http://$ip:8888/song?path=${android.net.Uri.encode(song.path)}"
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun getMimeType(song: Song): String = when {
        song.path.endsWith(".flac", true) -> "audio/flac"
        song.path.endsWith(".mp3",  true) -> "audio/mpeg"
        song.path.endsWith(".m4a",  true) -> "audio/mp4"
        song.path.endsWith(".ogg",  true) -> "audio/ogg"
        song.path.endsWith(".opus", true) -> "audio/opus"
        song.path.endsWith(".wav",  true) -> "audio/wav"
        else -> "audio/*"
    }

    /** Pausa/reanuda el cast remoto. */
    fun togglePlayback() {
        val client = currentSession?.remoteMediaClient ?: return
        if (client.isPlaying) client.pause() else client.play()
    }

    /** Obtiene el CastContext para inflar el botón MediaRouteButton en los menús. */
    fun getCastContext(): CastContext? = castContext
}
