package com.aeroplayer.ui.search

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "search_prefs")

class RecentSearchesManager(private val context: Context) {

    private val KEY_RECENT = stringPreferencesKey("recent_searches")
    private val MAX_RECENT = 8

    val recentSearches: Flow<List<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[KEY_RECENT] ?: ""
        if (raw.isBlank()) emptyList()
        else raw.split("||").filter { it.isNotBlank() }
    }

    suspend fun addSearch(query: String) {
        if (query.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = (prefs[KEY_RECENT] ?: "")
                .split("||")
                .filter { it.isNotBlank() && it != query }
                .toMutableList()
            current.add(0, query)
            prefs[KEY_RECENT] = current.take(MAX_RECENT).joinToString("||")
        }
    }

    suspend fun removeSearch(query: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[KEY_RECENT] ?: "")
                .split("||")
                .filter { it.isNotBlank() && it != query }
            prefs[KEY_RECENT] = current.joinToString("||")
        }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.remove(KEY_RECENT) }
    }
}
