package com.aeroplayer.ui.visualizer

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.media3.common.util.UnstableApi
import com.aeroplayer.service.VisualizerAudioProcessor
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.*

/**
 * AudioVisualizerView — v2.5.0
 *
 * Modos: BARS (spectrum), WAVE (waveform), CIRCLE (radial pulsante).
 *
 * Fuente de datos: VisualizerAudioProcessor (intercepta PCM de ExoPlayer).
 * NO usa android.media.audiofx.Visualizer → NO necesita RECORD_AUDIO.
 */
@UnstableApi
class AudioVisualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { BARS, WAVE, CIRCLE }

    private var mode: Mode = Mode.BARS
    private var fftData:  FloatArray = FloatArray(0)
    private var waveData: FloatArray = FloatArray(0)
    private var scope: CoroutineScope? = null

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }
    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f
    }

    fun init(@Suppress("UNUSED_PARAMETER") unusedSessionId: Int = 0) {
        release()
        scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
        scope!!.launch {
            VisualizerAudioProcessor.fftFlow.collectLatest { fft ->
                fftData = fft; postInvalidateOnAnimation()
            }
        }
        scope!!.launch {
            VisualizerAudioProcessor.waveFlow.collectLatest { wave -> waveData = wave }
        }
    }

    fun release() { scope?.cancel(); scope = null; fftData = FloatArray(0); waveData = FloatArray(0) }
    fun setMode(m: Mode) { mode = m; invalidate() }
    fun getMode() = mode

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (fftData.isEmpty() && waveData.isEmpty()) { drawIdle(canvas); return }
        when (mode) {
            Mode.BARS   -> drawBars(canvas)
            Mode.WAVE   -> drawWave(canvas)
            Mode.CIRCLE -> drawCircle(canvas)
        }
    }

    private fun drawBars(canvas: Canvas) {
        if (fftData.isEmpty()) return
        val fft = fftData; val w = width.toFloat(); val h = height.toFloat()
        val nBars = minOf(fft.size, 64); val barW = w / nBars; val gap = barW * 0.15f
        barPaint.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(0xFF7EC8E3.toInt(), 0xFF5B9BD4.toInt(), 0xFFE879A2.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        glowPaint.shader = barPaint.shader
        for (i in 0 until nBars) {
            val mag = fft[i * fft.size / nBars]
            val barH = (mag * h * 0.85f).coerceAtLeast(3f)
            val x = i * barW + gap / 2f
            val rect = RectF(x, h - barH, x + barW - gap, h)
            canvas.drawRoundRect(rect, 4f, 4f, barPaint)
            if (mag > 0.6f) { glowPaint.alpha = ((mag - 0.6f) / 0.4f * 80).toInt(); canvas.drawRoundRect(rect, 4f, 4f, glowPaint) }
        }
    }

    private fun drawWave(canvas: Canvas) {
        if (waveData.isEmpty()) return
        val wave = waveData; val w = width.toFloat(); val h = height.toFloat(); val midY = h / 2f
        wavePaint.shader = LinearGradient(0f, 0f, w, 0f,
            intArrayOf(0xFF5B9BD4.toInt(), 0xFF7EC8E3.toInt(), 0xFFE879A2.toInt()),
            null, Shader.TileMode.CLAMP)
        val path = Path(); val step = wave.size.toFloat() / w
        fun waveY(i: Int) = midY - wave[(i * step).toInt().coerceIn(wave.indices)] * midY * 0.9f
        path.moveTo(0f, waveY(0))
        for (i in 1 until w.toInt()) {
            val cpx = (i - 0.5f); path.cubicTo(cpx, waveY(i-1), cpx, waveY(i), i.toFloat(), waveY(i))
        }
        canvas.drawPath(path, wavePaint)
        canvas.drawLine(0f, midY, w, midY, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x22FFFFFF; style = Paint.Style.STROKE; strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f) })
    }

    private fun drawCircle(canvas: Canvas) {
        if (fftData.isEmpty()) return
        val fft = fftData; val cx = width / 2f; val cy = height / 2f
        val baseR = minOf(cx, cy) * 0.45f; val energy = fft.take(32).average().toFloat()
        circlePaint.shader = SweepGradient(cx, cy,
            intArrayOf(0xFF5B9BD4.toInt(), 0xFF7EC8E3.toInt(), 0xFFE879A2.toInt(), 0xFF5B9BD4.toInt()), null)
        canvas.drawCircle(cx, cy, baseR + energy * 20f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x885B9BD4.toInt() })
        val nSpokes = minOf(fft.size, 128)
        for (i in 0 until nSpokes) {
            val angle = (i.toFloat() / nSpokes) * 2f * PI.toFloat()
            val mag = fft[i * fft.size / nSpokes]; val r2 = baseR + mag * baseR * 0.8f
            circlePaint.alpha = (100 + mag * 155).toInt().coerceIn(0, 255)
            canvas.drawLine((cx + baseR * cos(angle)).toFloat(), (cy + baseR * sin(angle)).toFloat(),
                (cx + r2 * cos(angle)).toFloat(), (cy + r2 * sin(angle)).toFloat(), circlePaint)
        }
        glowPaint.color = 0x335B9BD4.toInt()
        glowPaint.maskFilter = BlurMaskFilter(30f + energy * 30f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(cx, cy, baseR * 0.3f + energy * 15f, glowPaint)
    }

    private fun drawIdle(canvas: Canvas) {
        canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x33FFFFFF; style = Paint.Style.STROKE; strokeWidth = 2f
                pathEffect = DashPathEffect(floatArrayOf(8f, 8f), 0f) })
    }
}
