package com.aeroplayer.ui.player

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemLyricLineBinding

/**
 * Adapter para letras sincronizadas (karaoke).
 * FIX: usa ListAdapter + DiffUtil para evitar el parpadeo de notifyDataSetChanged().
 * Solo rebindea la línea que cambió de activa.
 */
class SyncedLyricsAdapter : ListAdapter<SyncedLyricsAdapter.LyricLine, SyncedLyricsAdapter.VH>(LyricDiff()) {

    data class LyricLine(val timeMs: Long, val text: String)

    private var activeIndex: Int = -1

    /**
     * Actualiza la línea activa según posición de reproducción.
     * Devuelve true si el índice cambió (para que el caller haga scroll).
     */
    fun updateActiveIndex(positionMs: Long): Boolean {
        if (currentList.isEmpty()) return false
        var newIndex = currentList.indexOfLast { it.timeMs <= positionMs }
        if (newIndex < 0) newIndex = 0
        if (newIndex == activeIndex) return false
        val old = activeIndex
        activeIndex = newIndex
        // FIX: solo notificar las 2 líneas que cambian — sin parpadeo global
        if (old >= 0 && old < currentList.size) notifyItemChanged(old,  PAYLOAD_ACTIVE)
        if (activeIndex < currentList.size)      notifyItemChanged(activeIndex, PAYLOAD_ACTIVE)
        return true
    }

    fun getActiveIndex() = activeIndex

    inner class VH(val b: ItemLyricLineBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLyricLineBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    // Bind completo
    override fun onBindViewHolder(holder: VH, position: Int) {
        applyState(holder, position == activeIndex, animate = false)
        holder.b.tvLine.text = getItem(position).text
    }

    // Bind parcial — solo cambia el estilo visual sin reescribir el texto
    override fun onBindViewHolder(holder: VH, position: Int, payloads: List<Any>) {
        if (payloads.contains(PAYLOAD_ACTIVE)) {
            applyState(holder, position == activeIndex, animate = position == activeIndex)
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    private fun applyState(holder: VH, isActive: Boolean, animate: Boolean) {
        val ctx = holder.b.tvLine.context
        if (isActive) {
            holder.b.tvLine.setTextColor(ctx.getColor(R.color.text_primary))
            holder.b.tvLine.textSize = 16f
            if (animate) {
                AnimatorSet().apply {
                    playTogether(
                        ObjectAnimator.ofFloat(holder.b.tvLine, "scaleX", 0.92f, 1.08f, 1f),
                        ObjectAnimator.ofFloat(holder.b.tvLine, "scaleY", 0.92f, 1.08f, 1f),
                        ObjectAnimator.ofFloat(holder.b.tvLine, "alpha",  0.5f,  1f)
                    )
                    duration = 350
                    interpolator = DecelerateInterpolator()
                    start()
                }
            } else {
                holder.b.tvLine.alpha  = 1f
                holder.b.tvLine.scaleX = 1f
                holder.b.tvLine.scaleY = 1f
            }
        } else {
            holder.b.tvLine.setTextColor(ctx.getColor(R.color.text_hint))
            holder.b.tvLine.textSize = 15f
            holder.b.tvLine.alpha    = 1f
            holder.b.tvLine.scaleX   = 1f
            holder.b.tvLine.scaleY   = 1f
        }
    }

    companion object {
        private const val PAYLOAD_ACTIVE = "active"
    }

    class LyricDiff : DiffUtil.ItemCallback<LyricLine>() {
        override fun areItemsTheSame(a: LyricLine, b: LyricLine)    = a.timeMs == b.timeMs
        override fun areContentsTheSame(a: LyricLine, b: LyricLine) = a == b
    }
}
