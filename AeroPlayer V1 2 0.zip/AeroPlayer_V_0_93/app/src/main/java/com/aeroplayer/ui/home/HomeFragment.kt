package com.aeroplayer.ui.home

import android.app.ActivityOptions
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentHomeBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide

class HomeFragment : Fragment() {

    companion object {
        // Caché de selección rápida: persiste mientras el proceso vive.
        // Se limpia al presionar Home 2 veces (ver setupDoubleHomeRefresh).
        private var cachedQuickPick: List<com.aeroplayer.model.Song>? = null

        /** Llamado desde MainActivity al detectar doble toque Home */
        fun clearQuickPickCache() {
            cachedQuickPick = null
        }
    }


    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private lateinit var quickPickAdapter: QuickPickPageAdapter
    private lateinit var mostPlayedAdapter: SongHorizontalAdapter
    private lateinit var shortcutsAdapter: ShortcutAdapter
    private lateinit var favPlaylistsAdapter: ShortcutAdapter

    // Chips activos: conjunto de tags de género/mood seleccionados
    private val activeFilters = mutableSetOf<String>()

    // Selector de imagen para el avatar del perfil.
    // BUGFIX: usa OpenDocument en lugar de GetContent para obtener
    // FLAG_GRANT_PERSISTABLE_URI_PERMISSION y que el URI sobreviva reinicios.
    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        // OpenDocument otorga permiso persistible — takePersistableUriPermission lo confirma.
        runCatching {
            requireContext().contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        requireContext().getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .edit().putString("user_avatar", uri.toString()).apply()
        loadAvatar(uri.toString())
    }

    private fun loadAvatar(uriString: String?) {
        if (uriString != null) {
            val uri = android.net.Uri.parse(uriString)
            // Verificar que el permiso persistente sigue activo.
            // En content:// URIs de OpenDocument esto puede perderse si se limpió caché
            // o el archivo fue movido. Si ya no es válido, limpiamos la preferencia.
            val hasPermission = try {
                requireContext().contentResolver.persistedUriPermissions.any { perm ->
                    perm.uri == uri && perm.isReadPermission
                }
            } catch (_: Exception) { false }

            val isFileUri = uri.scheme == "file"

            if (hasPermission || isFileUri) {
                Glide.with(this)
                    .load(uri)
                    .circleCrop()
                    .placeholder(com.aeroplayer.R.drawable.ic_person)
                    .error(com.aeroplayer.R.drawable.ic_person)
                    .into(binding.btnProfile)
            } else {
                // Permiso perdido — limpiar y mostrar ícono por defecto
                requireContext()
                    .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
                    .edit().remove("user_avatar").apply()
                binding.btnProfile.setImageResource(com.aeroplayer.R.drawable.ic_person)
                binding.btnProfile.setColorFilter(
                    androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.text_secondary)
                )
            }
        } else {
            binding.btnProfile.setImageResource(com.aeroplayer.R.drawable.ic_person)
            binding.btnProfile.setColorFilter(
                androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.text_secondary)
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupAdapters()
        setupButtons()
        setupChips()
        observeData()

        // Cargar avatar guardado
        val savedAvatar = requireContext()
            .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .getString("user_avatar", null)
        loadAvatar(savedAvatar)
    }

    // ── Adapters ─────────────────────────────────────────────────────────────
    private fun setupAdapters() {
        // Selección rápida — lista vertical estilo YT Music
        quickPickAdapter = QuickPickPageAdapter(
            onClick = { song, songs ->
                PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.quick_pick))
                viewModel.incrementPlayCount(song)
            },
            onAddToQueue = { song ->
                PlayerController.addToQueue(song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "\"${song.title}\" agregado a la cola",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            },
            onAddToPlaylist = { song -> showQuickPickAddToPlaylist(song) },
            onViewArtist    = { artistName -> showArtistSongs(artistName) }
        )
        // Carrusel con RecyclerView + PagerSnapHelper (snap entre páginas sin restricciones de ViewPager2)
        val snapHelper = androidx.recyclerview.widget.PagerSnapHelper()
        binding.vpQuickPick.apply {
            layoutManager = androidx.recyclerview.widget.LinearLayoutManager(
                context, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false
            )
            adapter = quickPickAdapter
            isNestedScrollingEnabled = false
        }
        snapHelper.attachToRecyclerView(binding.vpQuickPick)

        // Indicadores de página
        binding.vpQuickPick.addOnScrollListener(object : androidx.recyclerview.widget.RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: androidx.recyclerview.widget.RecyclerView, newState: Int) {
                if (newState == androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_IDLE) {
                    val lm = rv.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return
                    val pos = lm.findFirstCompletelyVisibleItemPosition()
                    if (pos >= 0) updatePageIndicators(pos)
                }
            }
        })

        // Más escuchadas
        mostPlayedAdapter = SongHorizontalAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.most_played))
            viewModel.incrementPlayCount(song)
        }
        binding.rvMostPlayed.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = mostPlayedAdapter
        }

        // Accesos directos
        shortcutsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvShortcuts.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = shortcutsAdapter
        }

        // Playlists favoritas
        favPlaylistsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvFavoritePlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = favPlaylistsAdapter
        }
    }

    private fun handleShortcutClick(shortcut: Shortcut) {
        when (shortcut.type) {
            ShortcutType.PLAYLIST -> startActivity(
                Intent(requireContext(),
                    com.aeroplayer.ui.playlist.PlaylistDetailActivity::class.java)
                    .putExtra("playlistId", shortcut.id)
                    .putExtra("playlistName", shortcut.name)
            )
            ShortcutType.LIKED -> findNavController().navigate(R.id.libraryFragment)
            ShortcutType.ALBUM -> {
                val allSongs = viewModel.allSongs.value ?: return
                val albumSongs = allSongs.filter { it.album == shortcut.name }
                if (albumSongs.isNotEmpty()) {
                    PlayerController.playSongs(albumSongs, 0, queueName = shortcut.name)
                }
            }
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private fun setupButtons() {
        binding.btnPlayAll.setOnClickListener {
            val songs = quickPickAdapter.getCurrentList()
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, queueName = getString(R.string.quick_pick))
            }
        }

        binding.btnProfile.setOnClickListener { showProfileMenu(it) }
    }

    // ── Chips de filtro ───────────────────────────────────────────────────────
    /**
     * Cada chip filtra canciones cuyo título, álbum o artista contiene
     * alguna de las palabras clave asociadas al mood/género.
     * Si ningún chip está activo se muestran todas las canciones.
     */
    private fun setupChips() {
        val chipMap = mapOf(
            binding.chipRelax       to listOf("relax", "chill", "sleep", "calm", "ambient", "lofi", "lo-fi"),
            binding.chipSad         to listOf("sad", "triste", "melanchol", "blues", "heartbreak", "llanto"),
            binding.chipCommute     to listOf("commute", "drive", "road", "trip", "viaje", "energy", "pump"),
            binding.chipPop         to listOf("pop", "hits", "top", "chart", "radio edit"),
            binding.chipElectronica to listOf("electronic", "electro", "edm", "techno", "house", "dance", "synth", "trance"),
            binding.chipBanda       to listOf("banda", "norteño", "corrido", "sierreño", "grupero", "nortena", "ranchera")
        )

        binding.chipPodcasts.visibility = android.view.View.GONE

        chipMap.forEach { (chip, keywords) ->
            chip.setOnCheckedChangeListener { _, isChecked ->
                val tag = keywords.first()
                if (isChecked) activeFilters.add(tag) else activeFilters.remove(tag)
                val targetScale = if (isChecked) 1.12f else 1f
                chip.animate()
                    .scaleX(targetScale).scaleY(targetScale)
                    .setDuration(120)
                    .setInterpolator(android.view.animation.OvershootInterpolator(3f))
                    .withEndAction {
                        chip.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    }
                    .start()
                applyChipFilter(keywords, isChecked)
            }
        }
    }

    private fun applyChipFilter(keywords: List<String>, isChecked: Boolean) {
        val allSongs = viewModel.allSongs.value ?: return

        val allActiveKeywords = mutableListOf<String>()
        if (binding.chipRelax.isChecked)
            allActiveKeywords += listOf("relax", "chill", "sleep", "calm", "ambient", "lofi", "lo-fi")
        if (binding.chipSad.isChecked)
            allActiveKeywords += listOf("sad", "triste", "melanchol", "blues", "heartbreak", "llanto")
        if (binding.chipCommute.isChecked)
            allActiveKeywords += listOf("commute", "drive", "road", "trip", "viaje", "energy", "pump")
        if (binding.chipPop.isChecked)
            allActiveKeywords += listOf("pop", "hits", "top", "chart", "radio edit")
        if (binding.chipElectronica.isChecked)
            allActiveKeywords += listOf("electronic", "electro", "edm", "techno", "house", "dance", "synth", "trance")
        if (binding.chipBanda.isChecked)
            allActiveKeywords += listOf("banda", "norteño", "corrido", "sierreño", "grupero", "nortena", "ranchera")

        if (allActiveKeywords.isEmpty()) {
            buildSmartQuickPick(allSongs, viewModel.topPlayed.value ?: emptyList())
            binding.tvQuickPickSubtitle.visibility = View.GONE
            return
        }

        val filtered = allSongs.filter { song ->
            val haystack = "${song.title} ${song.artist} ${song.album}".lowercase()
            allActiveKeywords.any { kw -> haystack.contains(kw) }
        }.shuffled()

        if (filtered.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            binding.btnPlayAll.visibility = View.GONE
            quickPickAdapter.submitList(emptyList())
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "Sin resultados para estos filtros"
        } else {
            binding.tvQuickPickEmpty.visibility = View.GONE
            binding.btnPlayAll.visibility = View.VISIBLE
            quickPickAdapter.submitList(filtered)
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "${filtered.size} canciones encontradas"
        }
    }

    // ── Observe ───────────────────────────────────────────────────────────────
    private fun observeData() {
        updateGreeting()

        // — Selección rápida: varía cada sesión con mezcla de estrategias —
        viewModel.topPlayed.observe(viewLifecycleOwner) { topPlayed ->
            val allSongs = viewModel.allSongs.value ?: return@observe
            buildSmartQuickPick(allSongs, topPlayed)

            // Sección "Más escuchadas": siempre basada en play count
            if (topPlayed.isNotEmpty()) {
                val topIds = topPlayed.map { it.songId }.toSet()
                val mostPlayed = allSongs
                    .filter { it.id in topIds }
                    .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
                    .take(20)
                mostPlayedAdapter.submitList(mostPlayed)
                binding.sectionMostPlayed.visibility =
                    if (mostPlayed.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            if (songs.isNotEmpty()) {
                // Sesión 3: usar caché si existe, construir solo si es la primera vez
                val cached = cachedQuickPick
                if (cached != null && cached.isNotEmpty()) {
                    quickPickAdapter.submitList(cached)
                    updatePageIndicators(0)
                    binding.vpQuickPick.visibility = android.view.View.VISIBLE
                    binding.tvQuickPickEmpty.visibility = android.view.View.GONE
                } else if (viewModel.topPlayed.value.isNullOrEmpty()) {
                    buildSmartQuickPick(songs, emptyList())
                }
            }
            // Accesos directos: reconstruir shortcuts cuando llegan las canciones,
            // ya que freshArtMap depende de allSongs para resolver las portadas.
            val playlists = viewModel.playlists.value
            when {
                playlists == null -> { /* esperar al observer de playlists */ }
                playlists.isEmpty() -> buildShortcutsFromAlbums(songs)
                else -> rebuildShortcutsAndFavorites() // re-resolución con URIs frescas
            }
        }

        // Accesos directos + playlists favoritas se reconstruyen juntos
        viewModel.playlists.observe(viewLifecycleOwner) { _ -> rebuildShortcutsAndFavorites() }
        viewModel.favoritePlaylistIds.observe(viewLifecycleOwner) { _ -> rebuildShortcutsAndFavorites() }
    }

    /**
     * Selección rápida inteligente: mezcla 3 estrategias en cada sesión
     * para que siempre se sienta distinta:
     *   A) Las N más reproducidas
     *   B) Canciones del mismo artista/álbum que las más reproducidas
     *   C) Relleno aleatorio del resto de la biblioteca
     */
    // ── Indicadores de página para el carrusel de selección rápida ───────────
    private fun updatePageIndicators(activePage: Int) {
        val container = binding.quickPickIndicators
        container.removeAllViews()
        val pageCount = quickPickAdapter.itemCount
        if (pageCount <= 1) { container.visibility = android.view.View.GONE; return }
        container.visibility = android.view.View.VISIBLE
        val density = resources.displayMetrics.density
        val dotSize  = (6 * density).toInt()
        val dotMargin = (4 * density).toInt()
        for (i in 0 until pageCount) {
            val dot = android.view.View(requireContext()).apply {
                val params = android.widget.LinearLayout.LayoutParams(dotSize, dotSize).also {
                    it.marginStart = dotMargin; it.marginEnd = dotMargin
                }
                layoutParams = params
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(
                        if (i == activePage)
                            androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.accent_blue)
                        else
                            androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.surface_card)
                    )
                }
            }
            container.addView(dot)
        }
    }

    
    private fun buildSmartQuickPick(allSongs: List<Song>, topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>) {
        if (allSongs.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            binding.btnPlayAll.visibility = View.GONE
            return
        }

        // FIX BUG QuickPick: si ya existe un caché de esta sesión, NO reconstruir.
        // buildSmartQuickPick se dispara cada vez que topPlayed cambia, incluyendo
        // cuando el usuario toca una canción (incrementPlayCount → loadTopPlayed).
        // Sin esta guard, la lista se baraja de nuevo con cada toque.
        val existing = cachedQuickPick
        if (existing != null && existing.isNotEmpty()) {
            quickPickAdapter.submitList(existing)
            return
        }

        val result = mutableListOf<Song>()

        if (topPlayed.isNotEmpty()) {
            val topIds = topPlayed.map { it.songId }.toSet()
            val topSongs = allSongs
                .filter { it.id in topIds }
                .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }

            // A) Las 5 más reproducidas
            val seed = topSongs.take(5)
            result.addAll(seed)

            // B) Canciones del mismo artista o álbum (no duplicar)
            val seedArtists = seed.map { it.artist }.toSet()
            val seedAlbums  = seed.map { it.album }.toSet()
            val related = allSongs
                .filter { it.id !in topIds &&
                           (it.artist in seedArtists || it.album in seedAlbums) }
                .shuffled()
                .take(8)
            result.addAll(related)

            // C) Relleno aleatorio con canciones que no aparecen arriba
            val usedIds = result.map { it.id }.toSet()
            val filler = allSongs
                .filter { it.id !in usedIds }
                .shuffled()
                .take((15 - result.size).coerceAtLeast(0))
            result.addAll(filler)

            // Mezclar — máx 20, el scroll horizontal da acceso a todas
            val shuffled = result.shuffled().take(20)
            cachedQuickPick = shuffled
            quickPickAdapter.submitList(shuffled)
            updatePageIndicators(0)

            // Subtítulo oculto
            binding.tvQuickPickSubtitle.visibility = View.GONE
        } else {
            // Sin historial: aleatorio puro
            val shuffled = allSongs.shuffled().take(20)
            cachedQuickPick = shuffled
            quickPickAdapter.submitList(shuffled)
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.visibility = View.GONE
        }

        binding.tvQuickPickEmpty.visibility = View.GONE
        binding.btnPlayAll.visibility = View.VISIBLE
    }

    /**
     * Accesos directos: playlists del usuario (sin favoritas, máx 6).
     * Si no hay playlists, muestra los álbumes más escuchados.
     */
    private fun rebuildShortcutsAndFavorites() {
        val playlists = viewModel.playlists.value ?: return
        val favIds    = viewModel.favoritePlaylistIds.value ?: emptySet()

        // Mapa songId → albumArtUri fresca del MediaStore actual.
        // Evita usar la URI almacenada en playlist_songs que puede quedar stale
        // si el MediaStore rescaneó y cambió los albumIds.
        val freshArtMap: Map<Long, String?> =
            viewModel.allSongs.value?.associate { it.id to it.albumArtUri?.toString() }
                ?: emptyMap()

        viewLifecycleOwner.lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            // Resolver portada: prioridad → coverUri manual → primera canción con URI fresca → URI almacenada
            suspend fun playlistCover(p: com.aeroplayer.data.db.PlaylistEntity): String? {
                if (p.coverUri != null) return p.coverUri
                // Buscar el primer songId de la playlist y cruzarlo con freshArtMap
                val firstSongId = viewModel.getPlaylistFirstSongId(p.id)
                if (firstSongId != null) {
                    val freshUri = freshArtMap[firstSongId]
                    if (freshUri != null) return freshUri
                }
                // Fallback: URI guardada en la tabla (puede ser stale pero mejor que nada)
                return viewModel.getPlaylistFirstArtUri(p.id)
            }

            val favPlaylists = playlists
                .filter { it.id in favIds }
                .map { p -> com.aeroplayer.ui.home.Shortcut(p.id, p.name, playlistCover(p), ShortcutType.PLAYLIST) }

            val nonFavPlaylists = playlists
                .filter { it.id !in favIds }
                .take(6)
                .map { p -> com.aeroplayer.ui.home.Shortcut(p.id, p.name, playlistCover(p), ShortcutType.PLAYLIST) }
                .toMutableList()

            // "Me gusta" va primero, con portada fresca de la primera canción que gusta
            val likedFirstSongId = viewModel.getLikedFirstSongId()
            val likedCover = if (likedFirstSongId != null) {
                freshArtMap[likedFirstSongId] ?: viewModel.getLikedFirstArtUri()
            } else {
                viewModel.getLikedFirstArtUri()
            }
            nonFavPlaylists.add(0, com.aeroplayer.ui.home.Shortcut(-1L, "Me gusta", likedCover, ShortcutType.LIKED))

            withContext(kotlinx.coroutines.Dispatchers.Main) {
                if (!isAdded) return@withContext

                favPlaylistsAdapter.submitList(favPlaylists)
                binding.sectionFavoritePlaylists.visibility =
                    if (favPlaylists.isNotEmpty()) View.VISIBLE else View.GONE

                if (nonFavPlaylists.isNotEmpty()) {
                    shortcutsAdapter.submitList(nonFavPlaylists)
                    binding.rvShortcuts.visibility = View.VISIBLE
                } else {
                    buildShortcutsFromAlbums(viewModel.allSongs.value ?: emptyList())
                }
            }
        }
    }

    private fun buildShortcutsFromAlbums(songs: List<Song>) {
        if (!viewModel.playlists.value.isNullOrEmpty()) return
        val topAlbums = songs
            .groupBy { it.album }
            .entries
            .sortedByDescending { it.value.size }
            .take(6)
            .map { (album, albumSongs) ->
                Shortcut(
                    id       = album.hashCode().toLong(),
                    name     = album,
                    coverUri = albumSongs.firstOrNull()?.albumArtUri?.toString(),
                    type     = ShortcutType.ALBUM
                )
            }
        if (topAlbums.isNotEmpty()) shortcutsAdapter.submitList(topAlbums)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun updateGreeting() {
        val name = viewModel.getProfileName()
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val timeGreet = when {
            hour < 12 -> "Buenos días"
            hour < 18 -> "Buenas tardes"
            else      -> "Buenas noches"
        }
        // Si el usuario no configuró su nombre, mostrar solo el saludo de tiempo
        val greetText = if (name.isBlank()) timeGreet else "$timeGreet, $name"

        // FIX BUG#4: solo usamos tvAppName para el saludo animado.
        val appNameView = binding.tvAppName

        // Mostrar primero el nombre de la app
        appNameView.alpha = 1f
        appNameView.text  = getString(R.string.app_name)

        // Después de 1.8s, animar transición al saludo personalizado
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!isAdded) return@postDelayed
            appNameView.animate()
                .alpha(0f)
                .setDuration(400)
                .withEndAction {
                    if (!isAdded) return@withEndAction
                    appNameView.text = greetText
                    appNameView.animate()
                        .alpha(1f)
                        .setDuration(400)
                        .start()
                }.start()
        }, 1800)

        // Fetch del clima en background
        fetchWeather()
    }

    /**
     * Convierte la condición meteorológica de wttr.in a un emoji representativo.
     * Mejora la legibilidad sin depender de imágenes externas.
     */
    private fun weatherEmoji(condition: String): String {
        val c = condition.lowercase()
        return when {
            c.contains("sol") || c.contains("despejad") || c.contains("clear") || c.contains("sunny") -> "☀️"
            c.contains("parcial") || c.contains("partly") || c.contains("patchy") -> "⛅"
            c.contains("nublad") || c.contains("overcast") || c.contains("cloudy") -> "☁️"
            c.contains("lluvia") || c.contains("rain") || c.contains("drizzle") || c.contains("llovizna") -> "🌧️"
            c.contains("tormenta") || c.contains("thunder") || c.contains("storm") -> "⛈️"
            c.contains("nieve") || c.contains("snow") || c.contains("sleet") -> "❄️"
            c.contains("niebla") || c.contains("fog") || c.contains("mist") || c.contains("bruma") -> "🌫️"
            c.contains("viento") || c.contains("wind") -> "💨"
            c.contains("noche") || c.contains("night") -> "🌙"
            else -> "🌡️"
        }
    }

    private fun fetchWeather() {
        viewLifecycleOwner.lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val client = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                // wttr.in JSON v2 — más fiable para idioma que el formato texto
                val req = okhttp3.Request.Builder()
                    .url("https://wttr.in/?format=j1&lang=es")
                    .header("User-Agent", "AeroPlayer/1.0")
                    .header("Accept-Language", "es-ES,es;q=0.9")
                    .build()

                val body = client.newCall(req).execute().body?.string()?.trim()
                    ?: return@runCatching

                // Parsear JSON básico para extraer condición y temperatura
                val json = org.json.JSONObject(body)
                val current = json.getJSONArray("current_condition").getJSONObject(0)
                val tempC   = current.getString("temp_C")

                // La descripción en español viene en langDesc
                val langArray = current.optJSONArray("lang_es")
                val condEs = if (langArray != null && langArray.length() > 0) {
                    langArray.getJSONObject(0).optString("value", "")
                } else {
                    // Fallback: traducción manual de weatherDesc en inglés
                    val descEn = current.optJSONArray("weatherDesc")
                        ?.optJSONObject(0)?.optString("value", "") ?: ""
                    translateWeatherCondition(descEn)
                }

                if (condEs.isNotBlank()) {
                    val emoji = weatherEmoji(condEs)
                    val text  = "$emoji $condEs $tempC°C"
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        if (!isAdded) return@withContext
                        binding.tvWeather?.let { tv ->
                            tv.text = text
                            tv.alpha = 0f
                            tv.visibility = android.view.View.VISIBLE
                            tv.animate().alpha(1f).setDuration(400).start()
                        }
                    }
                }
            }
        }
    }

    /** Traduce condiciones meteorológicas comunes del inglés al español. */
    private fun translateWeatherCondition(en: String): String {
        val e = en.lowercase()
        return when {
            e.contains("sunny") || e.contains("clear")          -> "Despejado"
            e.contains("partly cloudy")                          -> "Parcialmente nublado"
            e.contains("cloudy") || e.contains("overcast")       -> "Nublado"
            e.contains("mist") || e.contains("fog")              -> "Niebla"
            e.contains("drizzle")                                -> "Llovizna"
            e.contains("heavy rain") || e.contains("torrential") -> "Lluvia intensa"
            e.contains("rain") || e.contains("shower")           -> "Lluvia"
            e.contains("snow") || e.contains("sleet")            -> "Nieve"
            e.contains("blizzard")                               -> "Tormenta de nieve"
            e.contains("thunder") || e.contains("storm")         -> "Tormenta"
            e.contains("wind") || e.contains("blowing")          -> "Viento"
            e.contains("haze")                                   -> "Bruma"
            e.contains("freezing")                               -> "Heladas"
            else                                                 -> en
        }
    }

    private fun showProfileMenu(anchor: View) {
        val popup = androidx.appcompat.widget.PopupMenu(requireContext(), anchor, android.view.Gravity.END)
        popup.menu.apply {
            add(0, 1, 0, getString(R.string.menu_settings)).setIcon(R.drawable.ic_settings)
            add(0, 2, 1, getString(R.string.menu_profile)).setIcon(R.drawable.ic_person)
            add(0, 3, 2, getString(R.string.menu_exclude_folders)).setIcon(R.drawable.ic_library)
            add(0, 5, 3, "Radio en línea").setIcon(R.drawable.ic_radio)
            add(0, 4, 4, getString(R.string.menu_about)).setIcon(R.drawable.ic_info)
        }
        popup.setForceShowIcon(true)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { startActivity(Intent(requireContext(), com.aeroplayer.ui.settings.SettingsActivity::class.java)); true }
                2 -> { avatarPicker.launch(arrayOf("image/*")); true }
                3 -> { showExcludeFoldersDialog(); true }
                5 -> { startActivity(Intent(requireContext(), com.aeroplayer.ui.OnlineRadioActivity::class.java)); true }
                4 -> { showAboutDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun showProfileDialog() {
        val current = viewModel.getProfileName()
        val input = android.widget.EditText(requireContext()).apply {
            setText(current)
            hint = getString(R.string.profile_name_hint)
            setPadding(64, 24, 64, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSelection(text.length)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.edit_profile_title))
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setProfileName(input.text.toString().trim())
                updateGreeting()
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, getString(R.string.profile_saved),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showExcludeFoldersDialog() {
        val songs = viewModel.allSongs.value ?: emptyList()
        val folders = songs.map { java.io.File(it.path).parent ?: "/" }
            .distinct().sorted().toTypedArray()
        if (folders.isEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "No se encontraron carpetas de música",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show(); return
        }
        val excluded = viewModel.getExcludedFolders().toMutableSet()
        val checked = BooleanArray(folders.size) { folders[it] in excluded }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_exclude_folders))
            .setMultiChoiceItems(folders, checked) { _, which, isChecked ->
                if (isChecked) excluded.add(folders[which]) else excluded.remove(folders[which])
            }
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setExcludedFolders(excluded)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Carpetas actualizadas",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showAboutDialog() {
        val version = try {
            requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName
        } catch (e: Exception) { "1.2.0" }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_about))
            .setIcon(R.drawable.ic_info)
            .setMessage("Aero Player v$version\n\n${getString(R.string.about_description)}")
            .setPositiveButton(getString(R.string.done), null).show()
    }

    // ── Quick Pick helpers ────────────────────────────────────────────────────
    private fun showQuickPickAddToPlaylist(song: Song) {
        val playlists = viewModel.playlists.value ?: emptyList()
        if (playlists.isEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, getString(R.string.create_playlist_first),
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.add_to_playlist))
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Agregado a ${playlists[idx].name}",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun showArtistSongs(artistName: String) {
        val allSongs = viewModel.allSongs.value ?: return
        val artistSongs = allSongs.filter { it.artist == artistName }
        if (artistSongs.isEmpty()) return
        // Reproducir todas las canciones del artista y abrir el player
        PlayerController.playSongs(artistSongs, 0, queueName = artistName)
    }

    override fun onResume() {
        super.onResume()
        // Recargar avatar cada vez que el fragment vuelve a primer plano
        val savedAvatar = requireContext()
            .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .getString("user_avatar", null)
        loadAvatar(savedAvatar)

        // BUGFIX: actualizar el saludo al volver al home por si el usuario
        // cambió su nombre de perfil mientras estaba en otra pantalla.
        updateGreeting()

        // Si el caché fue limpiado (doble Home), reconstruir la selección rápida
        if (cachedQuickPick == null && quickPickAdapter.itemCount == 0) {
            val allSongs = viewModel.allSongs.value ?: return
            if (allSongs.isNotEmpty()) {
                buildSmartQuickPick(allSongs, viewModel.topPlayed.value ?: emptyList())
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
