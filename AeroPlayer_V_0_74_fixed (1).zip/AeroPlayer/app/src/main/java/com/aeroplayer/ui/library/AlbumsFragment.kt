package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemAlbumBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

data class Album(
    val name: String,
    val artist: String,
    val coverUri: android.net.Uri?,
    val songs: List<Song>
)

class AlbumsFragment : Fragment() {

    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // FrameLayout raíz para superponer el estado vacío
        val frame = FrameLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(context.getColor(R.color.background_dark))
        }

        // RecyclerView de álbumes
        val rv = RecyclerView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            layoutManager = GridLayoutManager(context, 2)
            setPadding(8, 8, 8, 80)
            clipToPadding = false
        }

        // Estado vacío
        val tvEmpty = TextView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            text = "No hay álbumes en tu biblioteca"
            setTextColor(context.getColor(R.color.text_secondary))
            textSize = 14f
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        frame.addView(rv)
        frame.addView(tvEmpty)

        val adapter = AlbumGridAdapter { album ->
            showAlbumOptions(album)
        }
        rv.adapter = adapter

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            val albums = songs
                .groupBy { it.album }
                .map { (album, songList) ->
                    Album(
                        name     = album,
                        artist   = songList.first().artist,
                        coverUri = songList.first().albumArtUri,
                        songs    = songList.sortedBy { it.trackNumber }
                    )
                }
                .sortedBy { it.name.lowercase() }
            adapter.submitList(albums)
            // FIX: mostrar estado vacío si no hay álbumes
            tvEmpty.visibility = if (albums.isEmpty()) View.VISIBLE else View.GONE
            rv.visibility      = if (albums.isEmpty()) View.GONE   else View.VISIBLE
        }

        return frame
    }

    private fun showAlbumOptions(album: Album) {
        val options = arrayOf(
            "▶  Reproducir todo",
            "🔀  Reproducir en aleatorio",
            "➕  Agregar a la cola"
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("${album.name}\n${album.songs.size} canciones")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // Reproducir en orden desde la primera canción
                        val first = album.songs.firstOrNull() ?: return@setItems
                        viewModel.incrementPlayCount(first)
                        PlayerController.playSongs(
                            album.songs.sortedBy { it.trackNumber },
                            startIndex = 0,
                            queueName  = album.name
                        )
                    }
                    1 -> {
                        // Mezclar y reproducir
                        val shuffled = album.songs.shuffled()
                        val first = shuffled.firstOrNull() ?: return@setItems
                        viewModel.incrementPlayCount(first)
                        PlayerController.playSongs(
                            shuffled,
                            startIndex = 0,
                            queueName  = album.name
                        )
                    }
                    2 -> {
                        // Agregar todas las canciones del álbum a la cola
                        album.songs.sortedBy { it.trackNumber }.forEach { song ->
                            PlayerController.addToQueue(song)
                        }
                        com.google.android.material.snackbar.Snackbar.make(
                            requireView(),
                            "${album.songs.size} canciones agregadas a la cola",
                            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                        ).show()
                    }
                }
            }
            .show()
    }
}

class AlbumGridAdapter(
    private val onClick: (Album) -> Unit
) : ListAdapter<Album, AlbumGridAdapter.VH>(AlbumDiff()) {

    inner class VH(val b: ItemAlbumBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val album = getItem(position)
        holder.b.tvName.text   = album.name
        holder.b.tvArtist.text = album.artist
        holder.b.tvCount.text  = "${album.songs.size} canciones"
        Glide.with(holder.b.ivCover)
            .load(album.coverUri)
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.b.ivCover)
        holder.b.root.setOnClickListener { onClick(album) }
    }

    class AlbumDiff : DiffUtil.ItemCallback<Album>() {
        override fun areItemsTheSame(a: Album, b: Album)    = a.name == b.name
        override fun areContentsTheSame(a: Album, b: Album) = a == b
    }
}
