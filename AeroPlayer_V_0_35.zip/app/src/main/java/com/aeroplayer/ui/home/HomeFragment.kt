package com.aeroplayer.ui.home

import android.app.ActivityOptions
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentHomeBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private lateinit var quickPickAdapter: SongHorizontalAdapter
    private lateinit var mostPlayedAdapter: SongHorizontalAdapter
    private lateinit var shortcutsAdapter: ShortcutAdapter
    private lateinit var favPlaylistsAdapter: ShortcutAdapter

    // Chips activos: conjunto de tags de género/mood seleccionados
    private val activeFilters = mutableSetOf<String>()

    // Selector de imagen para el avatar del perfil
    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        // Persistir permiso para que el URI sobreviva reinicios
        runCatching {
            requireContext().contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        requireContext().getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .edit().putString("user_avatar", uri.toString()).apply()
        loadAvatar(uri.toString())
    }

    private fun loadAvatar(uriString: String?) {
        if (uriString != null) {
            Glide.with(this)
                .load(Uri.parse(uriString))
                .circleCrop()
                .placeholder(com.aeroplayer.R.drawable.ic_person)
                .error(com.aeroplayer.R.drawable.ic_person)
                .into(binding.btnProfile)
        } else {
            binding.btnProfile.setImageResource(com.aeroplayer.R.drawable.ic_person)
            binding.btnProfile.setColorFilter(
                androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.text_secondary)
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAdapters()
        setupButtons()
        setupChips()
        observeData()

        // Cargar avatar guardado
        val savedAvatar = requireContext()
            .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .getString("user_avatar", null)
        loadAvatar(savedAvatar)
    }

    // ── Adapters ─────────────────────────────────────────────────────────────
    private fun setupAdapters() {
        // Selección rápida
        quickPickAdapter = SongHorizontalAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.quick_pick))
            viewModel.incrementPlayCount(song)
            startActivity(
                Intent(requireContext(), PlayerActivity::class.java),
                ActivityOptions.makeCustomAnimation(
                    requireContext(), R.anim.slide_up, R.anim.fade_out
                ).toBundle()
            )
        }
        binding.rvQuickPick.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = quickPickAdapter
        }

        // Más escuchadas
        mostPlayedAdapter = SongHorizontalAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.most_played))
            viewModel.incrementPlayCount(song)
            startActivity(
                Intent(requireContext(), PlayerActivity::class.java),
                ActivityOptions.makeCustomAnimation(
                    requireContext(), R.anim.slide_up, R.anim.fade_out
                ).toBundle()
            )
        }
        binding.rvMostPlayed.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = mostPlayedAdapter
        }

        // Accesos directos
        shortcutsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvShortcuts.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = shortcutsAdapter
        }

        // Playlists favoritas
        favPlaylistsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvFavoritePlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = favPlaylistsAdapter
        }
    }

    private fun handleShortcutClick(shortcut: Shortcut) {
        when (shortcut.type) {
            ShortcutType.PLAYLIST -> startActivity(
                Intent(requireContext(),
                    com.aeroplayer.ui.playlist.PlaylistDetailActivity::class.java)
                    .putExtra("playlistId", shortcut.id)
                    .putExtra("playlistName", shortcut.name)
            )
            ShortcutType.LIKED -> findNavController().navigate(R.id.libraryFragment)
            ShortcutType.ALBUM -> {
                val allSongs = viewModel.allSongs.value ?: return
                val albumSongs = allSongs.filter { it.album == shortcut.name }
                if (albumSongs.isNotEmpty()) {
                    PlayerController.playSongs(albumSongs, 0, queueName = shortcut.name)
                    startActivity(
                        Intent(requireContext(), PlayerActivity::class.java),
                        ActivityOptions.makeCustomAnimation(
                            requireContext(), R.anim.slide_up, R.anim.fade_out
                        ).toBundle()
                    )
                }
            }
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private fun setupButtons() {
        binding.btnPlayAll.setOnClickListener {
            val songs = quickPickAdapter.currentList
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, queueName = getString(R.string.quick_pick))
                startActivity(
                    Intent(requireContext(), PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(
                        requireContext(), R.anim.slide_up, R.anim.fade_out
                    ).toBundle()
                )
            }
        }

        binding.btnSearch.setOnClickListener {
            findNavController().navigate(R.id.searchFragment)
        }

        binding.btnThemeToggle.setOnClickListener {
            (requireActivity() as? com.aeroplayer.ui.MainActivity)?.toggleTheme()
            binding.btnThemeToggle.animate()
                .rotation(binding.btnThemeToggle.rotation + 180f)
                .setDuration(300).start()
        }

        binding.btnProfile.setOnClickListener { showProfileMenu(it) }
    }

    // ── Chips de filtro ───────────────────────────────────────────────────────
    /**
     * Cada chip filtra canciones cuyo título, álbum o artista contiene
     * alguna de las palabras clave asociadas al mood/género.
     * Si ningún chip está activo se muestran todas las canciones.
     */
    private fun setupChips() {
        val chipMap = mapOf(
            binding.chipRelax       to listOf("relax", "chill", "sleep", "calm", "ambient", "lofi", "lo-fi"),
            binding.chipSad         to listOf("sad", "triste", "melanchol", "blues", "heartbreak", "llanto"),
            binding.chipCommute     to listOf("commute", "drive", "road", "trip", "viaje", "energy", "pump"),
            binding.chipPop         to listOf("pop", "hits", "top", "chart", "radio edit"),
            binding.chipElectronica to listOf("electronic", "electro", "edm", "techno", "house", "dance", "synth", "trance"),
            binding.chipBanda       to listOf("banda", "norteño", "corrido", "sierreño", "grupero", "nortena", "ranchera")
        )

        binding.chipPodcasts.visibility = android.view.View.GONE

        chipMap.forEach { (chip, keywords) ->
            chip.setOnCheckedChangeListener { _, isChecked ->
                val tag = keywords.first()
                if (isChecked) activeFilters.add(tag) else activeFilters.remove(tag)
                val targetScale = if (isChecked) 1.12f else 1f
                chip.animate()
                    .scaleX(targetScale).scaleY(targetScale)
                    .setDuration(120)
                    .setInterpolator(android.view.animation.OvershootInterpolator(3f))
                    .withEndAction {
                        chip.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    }
                    .start()
                applyChipFilter(keywords, isChecked)
            }
        }
    }

    private fun applyChipFilter(keywords: List<String>, isChecked: Boolean) {
        val allSongs = viewModel.allSongs.value ?: return

        val allActiveKeywords = mutableListOf<String>()
        if (binding.chipRelax.isChecked)
            allActiveKeywords += listOf("relax", "chill", "sleep", "calm", "ambient", "lofi", "lo-fi")
        if (binding.chipSad.isChecked)
            allActiveKeywords += listOf("sad", "triste", "melanchol", "blues", "heartbreak", "llanto")
        if (binding.chipCommute.isChecked)
            allActiveKeywords += listOf("commute", "drive", "road", "trip", "viaje", "energy", "pump")
        if (binding.chipPop.isChecked)
            allActiveKeywords += listOf("pop", "hits", "top", "chart", "radio edit")
        if (binding.chipElectronica.isChecked)
            allActiveKeywords += listOf("electronic", "electro", "edm", "techno", "house", "dance", "synth", "trance")
        if (binding.chipBanda.isChecked)
            allActiveKeywords += listOf("banda", "norteño", "corrido", "sierreño", "grupero", "nortena", "ranchera")

        if (allActiveKeywords.isEmpty()) {
            buildSmartQuickPick(allSongs, viewModel.topPlayed.value ?: emptyList())
            binding.tvQuickPickSubtitle.text = "Basado en tus más escuchadas"
            return
        }

        val filtered = allSongs.filter { song ->
            val haystack = "${song.title} ${song.artist} ${song.album}".lowercase()
            allActiveKeywords.any { kw -> haystack.contains(kw) }
        }.shuffled()

        if (filtered.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            binding.btnPlayAll.visibility = View.GONE
            quickPickAdapter.submitList(emptyList())
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "Sin resultados para estos filtros"
        } else {
            binding.tvQuickPickEmpty.visibility = View.GONE
            binding.btnPlayAll.visibility = View.VISIBLE
            quickPickAdapter.submitList(filtered)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "${filtered.size} canciones encontradas"
        }
    }

    // ── Observe ───────────────────────────────────────────────────────────────
    private fun observeData() {
        updateGreeting()

        // — Selección rápida: varía cada sesión con mezcla de estrategias —
        viewModel.topPlayed.observe(viewLifecycleOwner) { topPlayed ->
            val allSongs = viewModel.allSongs.value ?: return@observe
            buildSmartQuickPick(allSongs, topPlayed)

            // Sección "Más escuchadas": siempre basada en play count
            if (topPlayed.isNotEmpty()) {
                val topIds = topPlayed.map { it.songId }.toSet()
                val mostPlayed = allSongs
                    .filter { it.id in topIds }
                    .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
                    .take(20)
                mostPlayedAdapter.submitList(mostPlayed)
                binding.sectionMostPlayed.visibility =
                    if (mostPlayed.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            if (songs.isNotEmpty() && viewModel.topPlayed.value.isNullOrEmpty()) {
                buildSmartQuickPick(songs, emptyList())
            }
            buildShortcutsFromAlbums(songs)
        }

        // Accesos directos + playlists favoritas se reconstruyen juntos
        viewModel.playlists.observe(viewLifecycleOwner) { _ -> rebuildShortcutsAndFavorites() }
        viewModel.favoritePlaylistIds.observe(viewLifecycleOwner) { _ -> rebuildShortcutsAndFavorites() }
    }

    /**
     * Selección rápida inteligente: mezcla 3 estrategias en cada sesión
     * para que siempre se sienta distinta:
     *   A) Las N más reproducidas
     *   B) Canciones del mismo artista/álbum que las más reproducidas
     *   C) Relleno aleatorio del resto de la biblioteca
     */
    private fun buildSmartQuickPick(allSongs: List<Song>, topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>) {
        if (allSongs.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            binding.btnPlayAll.visibility = View.GONE
            return
        }

        val result = mutableListOf<Song>()

        if (topPlayed.isNotEmpty()) {
            val topIds = topPlayed.map { it.songId }.toSet()
            val topSongs = allSongs
                .filter { it.id in topIds }
                .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }

            // A) Las 5 más reproducidas
            val seed = topSongs.take(5)
            result.addAll(seed)

            // B) Canciones del mismo artista o álbum (no duplicar)
            val seedArtists = seed.map { it.artist }.toSet()
            val seedAlbums  = seed.map { it.album }.toSet()
            val related = allSongs
                .filter { it.id !in topIds &&
                           (it.artist in seedArtists || it.album in seedAlbums) }
                .shuffled()
                .take(8)
            result.addAll(related)

            // C) Relleno aleatorio con canciones que no aparecen arriba
            val usedIds = result.map { it.id }.toSet()
            val filler = allSongs
                .filter { it.id !in usedIds }
                .shuffled()
                .take((15 - result.size).coerceAtLeast(0))
            result.addAll(filler)

            // Mezclar para que no siempre empiece con las mismas
            val shuffled = result.shuffled().take(20)
            quickPickAdapter.submitList(shuffled)

            // Subtítulo dinámico
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = when {
                related.isNotEmpty() -> "Basado en tus más escuchadas y artistas similares"
                else                 -> "Basado en tus más escuchadas"
            }
        } else {
            // Sin historial: aleatorio puro
            val shuffled = allSongs.shuffled().take(20)
            quickPickAdapter.submitList(shuffled)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "Descubre tu biblioteca"
        }

        binding.tvQuickPickEmpty.visibility = View.GONE
        binding.btnPlayAll.visibility = View.VISIBLE
    }

    /**
     * Accesos directos: playlists del usuario (sin favoritas, máx 6).
     * Si no hay playlists, muestra los álbumes más escuchados.
     */
    private fun rebuildShortcutsAndFavorites() {
        val playlists = viewModel.playlists.value ?: return
        val favIds    = viewModel.favoritePlaylistIds.value ?: emptySet()

        // — Sección favoritas —
        val favPlaylists = playlists
            .filter { it.id in favIds }
            .map { p -> Shortcut(p.id, p.name, p.coverUri, ShortcutType.PLAYLIST) }
        favPlaylistsAdapter.submitList(favPlaylists)
        binding.sectionFavoritePlaylists.visibility =
            if (favPlaylists.isNotEmpty()) View.VISIBLE else View.GONE

        // — Accesos directos: playlists NO favoritas (máx 6) —
        val nonFavPlaylists = playlists
            .filter { it.id !in favIds }
            .take(6)
            .map { p -> Shortcut(p.id, p.name, p.coverUri, ShortcutType.PLAYLIST) }
            .toMutableList()

        // Agregar "Me gusta" si hay espacio
        if (nonFavPlaylists.size < 6) {
            nonFavPlaylists.add(0, Shortcut(-1L, "Me gusta", null, ShortcutType.LIKED))
        }

        if (nonFavPlaylists.isNotEmpty()) {
            shortcutsAdapter.submitList(nonFavPlaylists)
        } else {
            // Si no hay playlists, mostrar álbumes
            buildShortcutsFromAlbums(viewModel.allSongs.value ?: emptyList())
        }
    }

    private fun buildShortcutsFromAlbums(songs: List<Song>) {
        if (!viewModel.playlists.value.isNullOrEmpty()) return
        val topAlbums = songs
            .groupBy { it.album }
            .entries
            .sortedByDescending { it.value.size }
            .take(6)
            .map { (album, albumSongs) ->
                Shortcut(
                    id       = album.hashCode().toLong(),
                    name     = album,
                    coverUri = albumSongs.firstOrNull()?.albumArtUri?.toString(),
                    type     = ShortcutType.ALBUM
                )
            }
        if (topAlbums.isNotEmpty()) shortcutsAdapter.submitList(topAlbums)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun updateGreeting() {
        val name = viewModel.getProfileName()
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val timeGreet = when {
            hour < 12 -> "Buenos días"
            hour < 18 -> "Buenas tardes"
            else      -> "Buenas noches"
        }
        binding.tvGreeting.text = "$timeGreet, $name"
    }

    private fun showProfileMenu(anchor: View) {
        val popup = androidx.appcompat.widget.PopupMenu(requireContext(), anchor)
        popup.menu.apply {
            add(0, 1, 0, getString(R.string.menu_settings)).setIcon(R.drawable.ic_settings)
            add(0, 2, 1, getString(R.string.menu_profile)).setIcon(R.drawable.ic_person)
            add(0, 3, 2, getString(R.string.menu_exclude_folders)).setIcon(R.drawable.ic_library)
            add(0, 4, 3, getString(R.string.menu_about)).setIcon(R.drawable.ic_music_placeholder)
        }
        popup.setForceShowIcon(true)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { startActivity(Intent(requireContext(), com.aeroplayer.ui.settings.SettingsActivity::class.java)); true }
                2 -> { avatarPicker.launch("image/*"); true }
                3 -> { showExcludeFoldersDialog(); true }
                4 -> { showAboutDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    private fun showProfileDialog() {
        val current = viewModel.getProfileName()
        val input = android.widget.EditText(requireContext()).apply {
            setText(current)
            hint = getString(R.string.profile_name_hint)
            setPadding(64, 24, 64, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSelection(text.length)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.edit_profile_title))
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setProfileName(input.text.toString().trim())
                updateGreeting()
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, getString(R.string.profile_saved),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showExcludeFoldersDialog() {
        val songs = viewModel.allSongs.value ?: emptyList()
        val folders = songs.map { java.io.File(it.path).parent ?: "/" }
            .distinct().sorted().toTypedArray()
        if (folders.isEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "No se encontraron carpetas de música",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show(); return
        }
        val excluded = viewModel.getExcludedFolders().toMutableSet()
        val checked = BooleanArray(folders.size) { folders[it] in excluded }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_exclude_folders))
            .setMultiChoiceItems(folders, checked) { _, which, isChecked ->
                if (isChecked) excluded.add(folders[which]) else excluded.remove(folders[which])
            }
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setExcludedFolders(excluded)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Carpetas actualizadas",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showAboutDialog() {
        val version = try {
            requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName
        } catch (e: Exception) { "0.16" }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_about))
            .setMessage("Aero Player v$version\n\n${getString(R.string.about_description)}\n\nDesarrollado con ❤ inspirado en la estética Frutiger Aero.")
            .setPositiveButton(getString(R.string.done), null).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
