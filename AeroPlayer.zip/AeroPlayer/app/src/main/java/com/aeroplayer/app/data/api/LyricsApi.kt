package com.aeroplayer.app.data.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

// ─── API letras (lyrics.ovh - gratuita, sin key) ───────────────────────────
interface LyricsApi {
    @GET("v1/{artist}/{title}")
    suspend fun getLyrics(
        @Path("artist") artist: String,
        @Path("title") title: String
    ): LyricsApiResponse
}

data class LyricsApiResponse(
    val lyrics: String?,
    val error: String?
)

object LyricsClient {
    val api: LyricsApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.lyrics.ovh/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LyricsApi::class.java)
    }
}
