package com.aeroplayer.ui.equalizer

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatSeekBar

/**
 * SeekBar vertical real (no rotation hack).
 * Dibuja y responde a toques en orientación vertical.
 * El progreso aumenta hacia arriba (max = arriba, 0 = abajo).
 */
class VerticalSeekBar @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatSeekBar(context, attrs) {

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(h, w, oldh, oldw)
    }

    @Synchronized
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(heightMeasureSpec, widthMeasureSpec)
        setMeasuredDimension(measuredHeight, measuredWidth)
    }

    @Synchronized
    override fun onDraw(canvas: Canvas) {
        canvas.rotate(-90f)
        canvas.translate(-height.toFloat(), 0f)
        super.onDraw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (event.action) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_MOVE,
            MotionEvent.ACTION_UP -> {
                // Invertir: toque arriba = max, toque abajo = 0
                val newProgress = max - (max * event.y / height).toInt()
                progress = newProgress.coerceIn(0, max)
                onSizeChanged(width, height, 0, 0)
                // Propagar a listeners
                val listener = seekListener
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> listener?.onStartTrackingTouch(this)
                    MotionEvent.ACTION_UP   -> listener?.onStopTrackingTouch(this)
                }
                listener?.onProgressChanged(this, progress, true)
            }
        }
        return true
    }

    // Almacenar listener en campo en lugar de setTag() para evitar
    // "The key must be an application-specific resource id" en Android 9+
    private var seekListener: OnSeekBarChangeListener? = null

    override fun setOnSeekBarChangeListener(l: OnSeekBarChangeListener?) {
        super.setOnSeekBarChangeListener(l)
        seekListener = l
    }
}
