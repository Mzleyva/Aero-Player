package com.aeroplayer.utils

import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.animation.DecelerateInterpolator

/**
 * Colección de animaciones vivas para botones del reproductor.
 * Cada función aplica una micro-animación semántica al View receptor.
 */
object ButtonAnimations {

    /**
     * Pulso de presión: escala down → up con rebote.
     * Usar en TODOS los botones interactivos al ser tocados.
     */
    fun View.animatePulse(scaleDown: Float = 0.82f, duration: Long = 120L) {
        animate().cancel()
        animate()
            .scaleX(scaleDown)
            .scaleY(scaleDown)
            .setDuration(duration)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration((duration * 1.4).toLong())
                    .setInterpolator(OvershootInterpolator(2.5f))
                    .start()
            }
            .start()
    }

    /**
     * Play/Pause: escala pop + leve rotación al cambiar estado.
     */
    fun View.animatePlayPause(isPlaying: Boolean) {
        animate().cancel()
        val rotation = if (isPlaying) 8f else -8f
        animate()
            .scaleX(0.78f)
            .scaleY(0.78f)
            .rotation(rotation)
            .setDuration(90L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .rotation(0f)
                    .setDuration(200L)
                    .setInterpolator(OvershootInterpolator(3f))
                    .start()
            }
            .start()
    }

    /**
     * Skip: deslizamiento lateral + rebote.
     * forward=true → siguiente, forward=false → anterior.
     */
    fun View.animateSkip(forward: Boolean) {
        animate().cancel()
        val dir = if (forward) 18f else -18f
        animate()
            .translationX(dir)
            .scaleX(0.85f)
            .scaleY(0.85f)
            .setDuration(100L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                animate()
                    .translationX(0f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(200L)
                    .setInterpolator(OvershootInterpolator(2f))
                    .start()
            }
            .start()
    }

    /**
     * Shuffle activado: giro completo + pop de color.
     * Shuffle desactivado: giro inverso sutil.
     */
    fun View.animateShuffle(enabled: Boolean) {
        animate().cancel()
        if (enabled) {
            // Giro de 360° con escala pop
            animate()
                .rotation(360f)
                .scaleX(1.25f)
                .scaleY(1.25f)
                .setDuration(350L)
                .setInterpolator(OvershootInterpolator(1.5f))
                .withEndAction {
                    rotation = 0f
                    animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(150L)
                        .start()
                }
                .start()
        } else {
            animate()
                .rotation(-45f)
                .alpha(0.5f)
                .setDuration(180L)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction {
                    animate()
                        .rotation(0f)
                        .alpha(0.4f)
                        .setDuration(120L)
                        .start()
                }
                .start()
        }
    }

    /**
     * Repeat: pop de escala al cambiar modo.
     * intensity: 0=off, 1=all, 2=one
     */
    fun View.animateRepeatChange(intensity: Int) {
        animate().cancel()
        val targetScale = when (intensity) {
            2 -> 1.35f  // repeat one: más grande
            1 -> 1.2f   // repeat all
            else -> 0.9f // off
        }
        animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .setDuration(130L)
            .setInterpolator(OvershootInterpolator(2f))
            .withEndAction {
                animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(150L)
                    .setInterpolator(OvershootInterpolator(1.5f))
                    .start()
            }
            .start()
    }

    /**
     * Like: corazón que late (scale up fuerte → down suave → rebote).
     */
    fun View.animateLike(liked: Boolean) {
        animate().cancel()
        if (liked) {
            animate()
                .scaleX(1.6f)
                .scaleY(1.6f)
                .setDuration(120L)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction {
                    animate()
                        .scaleX(0.9f)
                        .scaleY(0.9f)
                        .setDuration(100L)
                        .withEndAction {
                            animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(150L)
                                .setInterpolator(OvershootInterpolator(2f))
                                .start()
                        }.start()
                }.start()
        } else {
            animate()
                .scaleX(0.8f)
                .scaleY(0.8f)
                .setDuration(100L)
                .withEndAction {
                    animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(150L)
                        .setInterpolator(OvershootInterpolator(1.5f))
                        .start()
                }.start()
        }
    }
}
