package com.aeroplayer.ui.search

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemSearchGroupBinding
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

// ── Model ────────────────────────────────────────────────────────────────────
data class SearchGroup(
    val name: String,
    val subtitle: String,
    val coverUri: String?,
    val songs: List<Song>
)

// ── Adapter ──────────────────────────────────────────────────────────────────
class SearchGroupAdapter(
    private val onGroupClick: (String) -> Unit
) : ListAdapter<SearchGroup, SearchGroupAdapter.VH>(GroupDiff()) {

    inner class VH(val b: ItemSearchGroupBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemSearchGroupBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group = getItem(position)
        with(holder.b) {
            tvName.text = group.name
            tvSubtitle.text = group.subtitle

            Glide.with(ivCover)
                .load(group.coverUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivCover)

            root.setOnClickListener { onGroupClick(group.name) }
        }
    }

    class GroupDiff : DiffUtil.ItemCallback<SearchGroup>() {
        override fun areItemsTheSame(a: SearchGroup, b: SearchGroup) = a.name == b.name
        override fun areContentsTheSame(a: SearchGroup, b: SearchGroup) = a == b
    }
}
