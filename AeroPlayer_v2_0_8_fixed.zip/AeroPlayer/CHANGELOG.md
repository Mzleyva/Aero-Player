
## v1.8.5 — Negro puro real + Headers transparentes

### 🖤 Fondo negro al inicio
- **`SplashActivity`**: default cambiado de `"auto"` → `"dark"` — la app ya no
  arranca en azul marino si el sistema está en modo claro. Primera vez que se
  instala siempre empieza en negro.
- **`values-night/colors.xml`**: `background_dark` = `#000000`, `surface_dark` = `#0D0D0D`,
  `surface_card` = `#141414`, `surface_nav` = `#080808`.

### 🔳 Headers transparentes (Artistas / Álbumes / Géneros / Playlists)
- **`activity_artist_detail.xml`**: `headerContainer` cambiado de
  `@color/surface_dark` → `@android:color/transparent`. La foto del artista
  ya no flota sobre un rectángulo azul marino — se ve directo sobre el fondo.
- **`activity_album_detail.xml`**: mismo fix en el header de portada.
- **`activity_genre_detail.xml`**: mismo fix.
- **`activity_playlist_detail.xml`**: mismo fix.

### 🔲 Barra de navegación negra
- **`bg_unified_bar.xml`**: `#CC1A1D2E` → `#CC000000` (negro 80% opaco).
- **`bg_bottom_nav.xml`**: mismo cambio. La píldora de nav/mini-player ya no
  es azul marino translúcido — es negro translúcido.
- Borde `#22FFFFFF` (más sutil que el anterior `#33FFFFFF`).

### 📦 Fragments transparentes
- **`AlbumsFragment`**, **`ArtistsFragment`**: `setBackgroundColor(background_dark)`
  → `TRANSPARENT` — los fragments no tapan el fondo personalizado de `MainActivity`
  con su propio fondo opaco.


## v1.8.4 — Artistas + Géneros + Negro puro

### 🖼️ Artistas — fotos permanentes
- **`ArtistImageProvider`**: cambiado de `cacheDir` → `filesDir/artist_photos`.
  `cacheDir` es borrado por el sistema cuando hay poco espacio libre; `filesDir`
  persiste mientras la app esté instalada. Las fotos ya no desaparecen solas.
- Límite de 300 fotos con evicción LRU por fecha de modificación.
- Nuevo método `getCachedFile(artistName)` que devuelve el `File` guardado para
  cargarlo directamente con Glide sin decodificar en memoria primero.
- **`ArtistsFragment`**: carga en 3 pasos: (1) foto permanente de filesDir
  (instantáneo), (2) carátula del álbum local mientras descarga, (3) foto real
  del artista en background → reemplaza la carátula con crossfade.
- Animación de entrada staggered: slide desde la izquierda + fade, 20ms por ítem.

### 🎨 Artistas — diseño mejorado
- **`item_artist.xml`**: foto más grande (68dp con anillo de acento sutil detrás),
  tipografía inter_bold para el nombre, chevron más pequeño.
- **`bg_avatar_ring.xml`**: oval de color accent_blue al 35% de opacidad detrás
  de la foto circular → diferencia visualmente artistas con y sin foto real.

### 🎼 Géneros — fix de visualización rota
- **`item_genre.xml`**: corregido bug donde `ImageView` tenía `height=0dp` +
  `layout_weight=1` dentro de un `LinearLayout` vertical sin altura fija —
  la imagen nunca se dibujaba. Ahora altura fija de 110dp con `FrameLayout`.
- **`gradient_genre_overlay.xml`**: degradado sutil oscuro sobre la portada.
- **`GenresFragment`**: paleta de 12 colores asignados por hash del nombre
  de género — cada género tiene siempre el mismo color. Cuando no hay portada
  se muestra ese color como placeholder en lugar del icono genérico.
- Ordenación: géneros reales alfabéticos primero, "Sin género" siempre al final.
- Limpieza de espacios en blanco en el nombre de género antes del agrupado.

### 🖤 Fondo negro puro
- **`values-night/colors.xml`**: `background_dark` cambiado de `#0D0F14`
  (azul marino oscuro) a `#000000` (negro puro). Superficies ajustadas:
  `surface_dark` → `#0D0D0D`, `surface_card` → `#141414`, `surface_nav` → `#080808`.
- `android:navigationBarColor` actualizado a `@color/background_dark` en el tema
  principal para que la barra de navegación también sea negra.

### ℹ️ Nota sobre el fondo de pantalla
- El fondo de imagen que aparece en la app es un fondo **personalizado configurado
  por el usuario** en Ajustes → Fondo personalizado. Se puede quitar desde ese
  mismo menú con "Quitar fondo personalizado". No es un color del tema.


## v1.8.3 — Android Auto + Multi-Cola + Visualizador + CUE Sheet

### 🚗 Android Auto (nuevo)
- **`AeroAutoService`**: MediaBrowserServiceCompat completo que expone la biblioteca a Android Auto.
  - Árbol de navegación: Cola actual / Más escuchadas / Me gusta / Álbumes / Artistas.
  - `onPlayFromSearch`: búsqueda por voz desde el coche.
  - `onPlayFromMediaId`: reproducción directa al tocar cualquier item en la pantalla del coche.
  - Sincronización en tiempo real de PlaybackStateCompat y MediaMetadataCompat con PlayerController.
  - `automotive_app_desc.xml` declarado en Manifest → Play Store puede marcar la app como
    compatible con Android Auto.
- **`MusicRepository`**: añadidos `getMostPlayed`, `getLikedSongs`, `getAllAlbums`, `getAllArtists`,
  `getSongsForAlbum`, `getSongsByArtist`, `getSongById`, `searchSongs` para servir el árbol de AA.
- **`PlayerController`**: alias `loadQueue`, `play`, `skipToNext/Previous`, `seekToIndex`,
  `currentPositionMs` para interfaz compatible con MediaSessionCompat.

### 🎵 Multi-Cola (nuevo)
- **`MultiQueueManager`**: gestiona N colas nombradas simultáneas.
  - `createQueue`, `switchTo`, `deleteQueue`, `renameQueue`, `duplicateQueue`.
  - Guarda el progreso (índice + posición) de cada cola al cambiar de una a otra.
  - `addToActiveQueue`, `removeFromActiveQueue`, `reorderActiveQueue`.
- **`MultiQueueActivity`**: UI con tabs de colas, lista drag-to-reorder con swipe-to-remove,
  chip de cola activa, long press para opciones (renombrar/duplicar/eliminar).
- **`PlayerController.playSongs()`**: ahora notifica a MultiQueueManager automáticamente.
- **`QueueSongsAdapter`**: adapter genérico reutilizable para vistas de cola.

### 🎨 Visualizador (nuevo)
- **`AudioVisualizerView`**: vista Canvas con tres modos:
  - `BARS`: 64 barras de frecuencia con gradiente azul→rosa y glow blur en picos.
  - `WAVE`: forma de onda spline suavizada, bicolor, con línea central 0.
  - `CIRCLE`: círculo pulsante con 128 radios de frecuencia y glow central dinámico.
  - Suavizado exponencial (EMA) para evitar parpadeo abrupto entre capturas.
- **`VisualizerActivity`**: pantalla fullscreen landscape con selector de modo (chips),
  album art difuminado como fondo, título/artista en esquina superior.
  Inicializa/libera el Visualizer en onResume/onPause para no consumir batería.

### 📀 CUE Sheet (nuevo)
- **`CueSheetParser`**: parser binario completo del formato CUE.
  - Soporta standalone `.cue` y CUE embebido como Vorbis Comment (FLAC).
  - Multi-FILE (álbumes donde cada pista está en un archivo separado).
  - Campos REM DATE, REM GENRE, PERFORMER, TITLE de álbum y pista.
  - `toSongs()` convierte pistas CUE en objetos Song con `cueStartMs`/`cueEndMs`.
- **`CueSheetBrowserActivity`**: lista las pistas del .cue con número, título, artista y
  tiempo de inicio. "▶ Todo" carga el álbum completo; tap individual inicia desde esa pista.
- **`FolderBrowserActivity`**: detecta archivos `.cue` y los abre con CueSheetBrowserActivity
  en lugar de intentar reproducirlos directamente.
- **`PlayerController`**: al cambiar de canción, hace `seekTo(cueStartMs)` si la pista es CUE.
- **`Song`**: añadidos campos `cueStartMs: Long` y `cueEndMs: Long` (default 0 / Long.MAX_VALUE).

### 🔌 EQ por dispositivo — fix real
- **`AudioDeviceEqRouter`**: BroadcastReceiver que faltaba en v1.8.2.
  - Escucha `ACTION_HEADSET_PLUG` y `BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED`.
  - Al conectar auriculares → aplica perfil "Auriculares"; Bluetooth → "Bluetooth";
    USB DAC → "Hi-Fi DAC"; desconexión → "Bocinas" o el primario.
  - Detecta el dispositivo actual en `register()` y aplica el perfil inmediatamente.
  - Si no hay sesión de audio activa, guarda `eq_pending_profile` para aplicarlo cuando
    el usuario abra EqualizerActivity (via `applyPendingProfileIfAny`).
  - Registrado en `MusicService.onCreate()`, liberado en `onDestroy()`.
  - Setting `auto_eq_switch_enabled` para que el usuario pueda desactivarlo.


## v1.8.2 — Correcciones y mejoras visuales

### 🔧 Fix: Editor de etiquetas (permisos)
- **`BatchTagEditorActivity`**: implementación completa de permisos de escritura MediaStore.
  - Android 10+ (API 29+): usa `MediaStore.createWriteRequest` para solicitar permiso
    de escritura masiva. El sistema muestra un diálogo nativo antes de guardar.
  - `RecoverableSecurityException` como fallback adicional para casos donde el sistema
    lanza la excepción en lugar del diálogo de permisos.
  - `MANAGE_MEDIA` añadido al Manifest para Android 11+ (permite editar sin confirmación
    por archivo una vez que el permiso está concedido).
  - Informe de resultado mejorado: "✓ N actualizadas · M sin permiso".

### 🎚️ Fix: Ecualizador — número de columnas
- **`EqualizerActivity`**: el `bandContainer` ahora vive dentro de un `HorizontalScrollView`.
  - Con ≤10 bandas: se distribuyen uniformemente en el ancho de pantalla.
  - Con 15 o 20 bandas: cada columna tiene un mínimo de 44dp garantizado y se puede
    hacer scroll horizontal para ver todas. Antes se comprimían hasta ser invisibles.
  - Los sliders cambian de color dinámicamente al mover (azul positivo, rosa negativo).
  - Etiqueta dB sobre cada banda actualizada en tiempo real con color semántico.
  - Separadores visuales entre secciones (perfil, bandas, efectos, presets).
  - Curva EQ más alta (120dp) para mejor legibilidad.

### 🎨 Mejoras visuales: EqCurveView
- **`EqCurveView`**: rediseño completo de la vista de curva.
  - Gradiente bicolor: zona positiva azul, zona negativa rosa/magenta.
  - Líneas de grid a ±5dB y ±10dB con etiquetas en eje Y.
  - Animación suave (180ms, DecelerateInterpolator) al cambiar entre presets.
  - Puntos de banda con anillo de highlight cuando la ganancia supera ±3dB.
  - Gradiente horizontal en la línea principal (azul → celeste → rosa).

### 🔊 Fix: ReplayGain — lectura real de tags
- **`ReplayGainManager`**: implementación de lectura binaria de tags RG.
  - Antes: `readReplayGainTag()` siempre retornaba null. MediaMetadataRetriever
    no expone REPLAYGAIN_TRACK_GAIN y el código lo reconocía sin resolverlo.
  - Ahora: lectura directa en binario de los primeros 128KB del archivo:
    - **ID3v2** (MP3): busca frames TXXX con clave REPLAYGAIN_TRACK/ALBUM_GAIN.
      Soporta ID3v2.3 y ID3v2.4 con syncsafe integers.
    - **Vorbis Comment** (FLAC/OGG): parsea el bloque VORBIS_COMMENT de FLAC
      y fallback a búsqueda de string para OGG.
    - **APEv2** (APE, WavPack): busca el footer APETAGEX y parsea los items.
  - La estimación por bitrate se mantiene como fallback.
  - Sin dependencias externas (sin jaudiotagger).

# AeroPlayer — Changelog

## v1.3.4 — YouTube Music + correcciones de rendimiento

### Nueva función
- **YouTube Music** (opcional): búsqueda de pistas, carga de playlists por URL/ID y
  reproducción directa vía NewPipeExtractor + ExoPlayer.
- La pestaña YT Music se activa/desactiva desde **Ajustes → YouTube Music** (switch).
  Cuando está desactivada no aparece en la barra de navegación.

### Correcciones de rendimiento
- OkHttp con **HTTP/2 multiplexado** — reduce latencia de búsqueda ~2 s → ~600 ms.
- **Connection pool ampliado** (10 conexiones, 5 min keepalive) para reutilizar
  conexiones TLS entre búsqueda y resolución de stream.
- **Cache de stream URLs** con TTL de 5 h — evita re-resolver la misma pista.
- `chooseBestAudioStream()` ahora filtra por MIME antes de iterar — O(n) → O(1) promedio.
- `NewPipe.init()` con **doble-checked locking** — ya no se puede llamar dos veces desde
  coroutines concurrentes causando `IllegalStateException` silenciosa.

### Correcciones de bugs
- **videoId extraído con regex robusta** (`\bv=([^&]+)`) — antes fallaba con URLs del
  tipo `?feature=share&v=xxx` o `youtu.be/xxx`.
- **Charset correcto en OkHttpDownloader** — respetaba siempre UTF-8 sin importar lo que
  declarara el `Content-Type`, causando que NewPipe parseara HTML corrupto.
- **Streams con `content == null` filtrados** antes de elegir el mejor stream — evitaba
  NPE al reproducir manifiestos DASH incompletos.
- **`resolvePlaylistQueue()`** ya no reinicia la cola con cada canción resuelta; las
  canciones después de la primera se añaden con `addToQueue()` sin interrumpir.
- **`clearSearch()` resetea `lastQuery`** — antes impedía relanzar la misma búsqueda
  después de borrar el campo.



### Bug corregido
- **MIGRATION_4_5 faltante** (`AppDatabase.kt`): La cadena de migraciones de Room
  referenciaba `MIGRATION_4_5` en `addMigrations()` pero el objeto nunca estaba
  definido, causando `Unresolved reference: MIGRATION_4_5` en tiempo de compilación.
  Se agregó una migración no-op (vacía) para cerrar el gap entre versiones 4 y 5
  de la base de datos sin destruir datos existentes.


## v0.83 — Pitch Control · LRC mejorado · Carpetas favoritas

### ⚡ Pitch Control (control de tono)
- **`PlayerController`**: nuevo `pitchSemitones: LiveData<Int>` (-12..+12) y `pitchLock: LiveData<Boolean>`.
  - `setPitchSemitones(n)` — desplaza el tono en semitonos usando `PlaybackParameters(speed, pitch)`.
  - `togglePitchLock()` — activa/desactiva pitch correction. Con lock activo, el pitch siempre es 1.0 sin importar la velocidad (se acabó el efecto "chipmunk" al acelerar).
  - Persistido en `aero_prefs` con claves `playback_pitch_semitones` y `playback_pitch_lock`.
- **`PlayerActivity`**: el botón de velocidad ahora abre un menú "Velocidad y tono" con dos opciones:
  - *Velocidad* → selector existente.
  - *Tono (pitch)* → nuevo `showPitchDialog()` con lista de -12 a +12 semitonos y botón para activar/desactivar pitch lock.

### 🎵 LRC local mejorado (offline lyrics)
- **`LyricsFileManager`**: búsqueda multi-ruta para `.lrc`:
  - Caché en memoria (`ConcurrentHashMap`) — evita I/O repetido al volver a la misma canción.
  - Busca `<nombre>.lrc`, `<nombre>.LRC`, `<nombre_lowercase>.lrc` en la carpeta del audio.
  - Fallback con búsqueda case-insensitive en el directorio (funciona en tarjetas SD con FAT32/exFAT).
  - `clearCache()` expuesto para invalidar si el usuario mueve archivos.

### 📁 Carpetas favoritas
- **`MainViewModel`**: nuevas funciones `getFavoriteFolders()`, `setFavoriteFolders()`, `addFavoriteFolder()`, `removeFavoriteFolder()`.
  - Si el conjunto está vacío → se muestran todas las canciones (comportamiento anterior).
  - Si hay carpetas favoritas → solo se muestran canciones cuya ruta empieza por alguna de ellas.
  - El filtro se combina con excluidas y canciones ocultas en `loadSongs()`.
- **`SettingsActivity`**: nueva fila "Carpetas favoritas" (`rowFavoriteFolders`) con diálogo para agregar/eliminar rutas.
- **`activity_settings.xml`**: nueva fila debajo de "Carpetas excluidas" con ícono `ic_bookmark_outline` y `tvFavoriteFoldersCount`.



## v0.81 — Corrección de bugs

### Bugs corregidos
- **BUG1 — NPE en `PlayerController.connect()`** (`PlayerController.kt`): Se reemplazó
  `controller!!.playbackParameters.withSpeed(savedSpeed)` por una llamada segura con
  `controller?.let { ctrl -> ... }`. Si el `MediaController` fallaba al conectarse,
  la app crasheaba con `NullPointerException`.
- **BUG2 — Duplicados silenciosos en playlists** (`MusicRepository.kt`): `addSongToPlaylist()`
  ahora verifica `if (existing.any { it.songId == song.id }) return` antes de insertar.
  El `PrimaryKey(autoGenerate=true)` de Room no prevenía duplicados, lo que permitía
  agregar la misma canción múltiples veces sin advertencia.
- **BUG3 — Variable shadow en `scanMediaStoreAndCache()`** (`MusicRepository.kt`): Se
  eliminó la re-query interna `val likedIds = likedDao.getAllLikedSync()...` que ignoraba
  el parámetro recibido y hacía una consulta redundante a la BD, potencialmente
  devolviendo datos inconsistentes en escenarios concurrentes.
- **BUG4 — `searchRunnable!!` innecesario** (`PlaylistDetailActivity.kt`): Reemplazado
  `searchHandler.postDelayed(searchRunnable!!, 150)` por
  `searchRunnable?.let { searchHandler.postDelayed(it, 150) }` para evitar NPE futuro.
- **BUG5 — `ivCustomBackground!!` en MainActivity** (`MainActivity.kt`): Reemplazado
  por `binding.ivCustomBackground?.let { into(it) }`. En layouts sin esta vista
  (landscape, tablets) la aserción non-null causaría crash al cargar fondo personalizado.
- **BUG6 — Memory retention en `PlayerController.disconnect()`** (`PlayerController.kt`):
  Se limpian `appContext = null` y `prefs = null` al desconectar para que el GC pueda
  liberar el contexto de la aplicación cuando el ViewModel se destruye.

## v0.20.0 — Bugs, Paging 3, GIF Canvas, UI polish

### Correcciones de bugs
- **animateBackground**: el degradado del player ahora anima desde el color real
  de la carátula anterior en lugar de siempre partir desde `surface_dark`.
  Se agregó `currentDominantColor` como campo de clase para rastrear el valor previo.
- **AlbumArtPagerAdapter**: reemplazado `notifyDataSetChanged()` por tres llamadas
  `notifyItemChanged(CENTER_PAGE ± 1)` al cambiar de canción. Elimina la invalidación
  masiva de 2001 páginas en cada transición.
- **crossfadeRunnable**: movido el guard `val ctrl = controller ?: return` al tope
  del Runnable. Cuando el controller es null el loop se detiene en lugar de
  reprogramarse cada 50 ms indefinidamente (background, sin música).
- **SettingsActivity back**: `overridePendingTransition(0,0)` reemplazado por
  `(R.anim.fade_in, R.anim.slide_out_right)`, consistente con el resto del app.

### Paging 3 — bibliotecas grandes
- **SongPagingSource**: nuevo `PagingSource` que sirve páginas de 60 canciones
  desde la lista en memoria. La lista se carga una vez desde MediaStore y se
  repagina en cada cambio de sort o refresh sin recargar el disco.
- **SongListAdapter**: migrado de `ListAdapter` a `PagingDataAdapter`.
- **FilesFragment**: reescrito para colectar `Flow<PagingData<Song>>` via
  `collectLatest`. Sort y MediaStore refresh invalidan la fuente automáticamente.
- **MainViewModel**: expone `songsPagingData: Flow<PagingData<Song>>` usando
  `flatMapLatest` sobre `_sortedSongs` + `cachedIn(viewModelScope)`.
- **build.gradle**: agregado `room-paging:2.6.1` y `paging-runtime-ktx:3.3.2`.

### GIF Canvas por canción
- **SongCanvasEntity / SongCanvasDao**: nueva tabla Room `song_canvas` con migración
  `MIGRATION_1_2` (DB versión 1 → 2). Sin destructive fallback.
- **AppDatabase**: versión 2, expone `songCanvasDao()`.
- **MusicRepository**: métodos `setCanvas`, `deleteCanvas`, `getCanvas`,
  `getCanvasLive` sobre `SongCanvasDao`.
- **MainViewModel**: `setCanvas`, `deleteCanvas`, `getCanvasLive` expuestos.
- **item_album_art_pager.xml**: FrameLayout con `ivGifCanvas` (GONE por defecto)
  + `ivPagerAlbumArt` encima.
- **AlbumArtPagerAdapter**: nuevo campo `canvasProvider: () -> Uri?`. Si hay
  canvas activo carga el GIF con `Glide.asGif()` y oculta el album art;
  si no hay canvas, limpia `ivGifCanvas` explícitamente para evitar reciclado.
- **PlayerActivity**: campo `activeCanvasUri`, launcher `gifPicker`
  (ActivityResultContracts.GetContent + `takePersistableUriPermission`),
  `observeCanvas(songId)` que refresca la página central y actualiza el tint del
  botón, `showCanvasMenu()` con opciones Cambiar / Quitar.
- **activity_player.xml**: `btnCanvas` agregado al panel lateral con ícono
  `ic_gif_canvas` vectorial.

### Mejoras de UI
- **Marquee en título**: `tvSongTitle.isSelected = true` al cambiar de canción,
  activando el scroll automático en títulos largos.
- **Indicador de posición**: `tvPlaylistContext` muestra el nombre de la cola
  (Playlist, álbum, artista, "Me gusta", etc.) y `tvArtistTop` muestra
  `#N · pos/total` igual a las capturas de referencia. `PlayerController.playSongs`
  acepta nuevo parámetro opcional `queueName` que todos los lanzadores pasan.
- **Spring animation en chips**: al activar/desactivar un chip de filtro en Home
  se ejecuta una animación overshoot (scale 1→1.12→1, 200 ms total).
- **Búsqueda dentro de playlist**: `btnSearch` ya existía en el layout pero no
  estaba conectado. Ahora muestra un `EditText` colapsable con debounce 150 ms,
  botón de cerrar, y contador `"filtradas / total"`.

### Calidad de código
- `PlayerController.queueName: LiveData<String?>` nuevo campo para propagar el
  nombre de la cola a cualquier observer sin tocar los Intents.
- `LikedFragment`: migrado a `PagingData.from(songs)` + `snapshot()` para ser
  compatible con el nuevo `PagingDataAdapter`.
