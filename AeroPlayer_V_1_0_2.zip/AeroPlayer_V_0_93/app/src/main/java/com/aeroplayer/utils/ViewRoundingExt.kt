package com.aeroplayer.utils

import android.graphics.Outline
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView

/**
 * Extensiones para redondear vistas correctamente en Android 5+.
 *
 * El problema: `android:clipToOutline="true"` en XML no hace nada por sí solo.
 * Para que funcione se necesita:
 *   1. view.clipToOutline = true
 *   2. view.outlineProvider = ViewOutlineProvider.BACKGROUND  ← esto falta siempre
 *
 * BACKGROUND le dice a Android que use la forma del background drawable
 * (que ya tiene corners definidos) como máscara de recorte.
 */

/** Redondea la vista usando el outline del background drawable. */
fun View.roundCorners() {
    clipToOutline   = true
    outlineProvider = ViewOutlineProvider.BACKGROUND
    if (background == null) {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 12f)
            }
        }
    }
}

/** Redondea con un radio fijo en dp. */
fun View.roundCorners(radiusDp: Float) {
    val radiusPx = radiusDp * resources.displayMetrics.density
    clipToOutline   = true
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
}

/** Recorte circular (avatares). */
fun View.makeCircle() {
    clipToOutline   = true
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }
}

/**
 * Recorre todo el árbol de vistas y aplica clipToOutline + BACKGROUND
 * a cualquier ImageView que ya tenga un background con esquinas redondeadas
 * (bg_album_art, bg_album_art_small, bg_album_art_large, bg_card, etc.).
 *
 * Llamar una sola vez en onCreate/onViewCreated después de setContentView/inflate.
 * Esto cubre todos los adapters, fragments y activities sin tocar cada uno.
 */
fun ViewGroup.applyAlbumArtRounding() {
    for (i in 0 until childCount) {
        val child = getChildAt(i)
        if (child is ImageView && child.background != null) {
            child.clipToOutline   = true
            child.outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        if (child is ViewGroup) child.applyAlbumArtRounding()
    }
}

