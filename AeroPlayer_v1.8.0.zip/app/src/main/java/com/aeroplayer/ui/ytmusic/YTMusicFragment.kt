package com.aeroplayer.ui.ytmusic

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentYtMusicBinding
import com.aeroplayer.model.YTResult
import com.aeroplayer.model.YTSong
import com.aeroplayer.service.PlayerController
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

/**
 * YTMusicFragment  —  v1.3.4
 *
 * Pantalla de YouTube Music dentro de AeroPlayer.
 * Solo se muestra si el usuario activó "YouTube Music" en Ajustes.
 *
 * CORRECCIONES:
 *  - Bug: extensión viewModelScope ambigua reemplazada por lifecycleScope.
 *  - Bug: progressStream era hijo de un container oculto — ahora se muestra
 *    directamente como FrameLayout overlay.
 *  - Bug: resolvePlaylistQueue no reiniciaba la cola si ya había una activa.
 *    Fix: solo llama playSongs() con la primera canción resuelta y luego
 *    extiende la cola con addMediaItem sin interrumpir la reproducción.
 */
class YTMusicFragment : Fragment() {

    private var _binding: FragmentYtMusicBinding? = null
    private val binding get() = _binding!!

    private val viewModel: YTMusicViewModel by viewModels()

    private lateinit var searchAdapter: YTSearchResultsAdapter
    private lateinit var playlistAdapter: YTPlaylistSongsAdapter

    // Evita iniciar reproducción de playlist varias veces al rotar pantalla
    private var playlistQueueStarted = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentYtMusicBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)

        setupSearch()
        setupPlaylistInput()
        setupAdapters()
        observeViewModel()
    }

    // ── Search ────────────────────────────────────────────────────────────────

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                when {
                    query.length >= 2 -> {
                        viewModel.search(query)
                        searchAdapter.setQuery(query)
                    }
                    query.isEmpty() -> {
                        viewModel.clearSearch()
                        binding.sectionSearchResults.isVisible = false
                        binding.tvNoResults.isVisible = false
                        binding.tvSearchCount.text = ""
                    }
                }
            }
        })

        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { hideKeyboard(); true } else false
        }
    }

    // ── Playlist input ────────────────────────────────────────────────────────

    private fun setupPlaylistInput() {
        binding.btnLoadPlaylist.setOnClickListener {
            val url = binding.etPlaylistUrl.text?.toString()?.trim() ?: ""
            if (url.isBlank()) {
                binding.etPlaylistUrl.error = "Introduce una URL o ID de playlist"
                return@setOnClickListener
            }
            hideKeyboard()
            playlistQueueStarted = false
            viewModel.loadPlaylist(url)
        }

        binding.btnPlayAll.setOnClickListener {
            val songs = viewModel.currentPlaylist.value?.songs ?: return@setOnClickListener
            if (songs.isEmpty()) return@setOnClickListener
            playlistQueueStarted = false
            showSnackbar("Cargando ${songs.size} canciones…")
            viewModel.resolvePlaylistQueue(songs)
        }

        binding.btnShuffleAll.setOnClickListener {
            val songs = viewModel.currentPlaylist.value?.songs ?: return@setOnClickListener
            if (songs.isEmpty()) return@setOnClickListener
            playlistQueueStarted = false
            showSnackbar("Cargando ${songs.size} canciones…")
            viewModel.resolvePlaylistQueue(songs.shuffled())
        }
    }

    // ── Adapters ──────────────────────────────────────────────────────────────

    private fun setupAdapters() {
        searchAdapter = YTSearchResultsAdapter(
            onSongClick  = { song -> viewModel.resolveAndPlay(song) },
            onAddToQueue = { song -> resolveAndAddToQueue(song) }
        )
        binding.rvSearchResults.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = searchAdapter
            isNestedScrollingEnabled = false
        }

        playlistAdapter = YTPlaylistSongsAdapter(
            onSongClick  = { song, idx ->
                val songs = viewModel.currentPlaylist.value?.songs ?: return@YTPlaylistSongsAdapter
                // Reproducir desde la canción pulsada y resolver el resto en background
                viewModel.resolveAndPlay(song)
                if (songs.size > 1) {
                    playlistQueueStarted = false
                    viewModel.resolvePlaylistQueue(songs.drop(idx + 1))
                }
            },
            onAddToQueue = { song -> resolveAndAddToQueue(song) }
        )
        binding.rvPlaylistSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = playlistAdapter
            isNestedScrollingEnabled = false
        }
    }

    // ── ViewModel observers ───────────────────────────────────────────────────

    private fun observeViewModel() {
        // Búsqueda
        viewModel.searchResults.observe(viewLifecycleOwner) { songs ->
            searchAdapter.submitList(songs)
            binding.sectionSearchResults.isVisible = songs.isNotEmpty()
            binding.tvSearchCount.text = if (songs.isNotEmpty()) "${songs.size} resultados" else ""
            binding.tvNoResults.isVisible = songs.isEmpty()
                    && (binding.etSearch.text?.length ?: 0) >= 2
                    && viewModel.isSearching.value == false
        }
        viewModel.isSearching.observe(viewLifecycleOwner) { loading ->
            binding.progressSearch.isVisible = loading
            if (loading) binding.tvNoResults.isVisible = false
        }
        viewModel.searchError.observe(viewLifecycleOwner) { err ->
            err?.let { showSnackbar("Error al buscar: $it") }
        }

        // Playlist
        viewModel.currentPlaylist.observe(viewLifecycleOwner) { playlist ->
            playlist ?: return@observe
            binding.sectionPlaylist.isVisible = true
            binding.tvPlaylistName.text  = playlist.name
            binding.tvPlaylistCount.text = "${playlist.songCount} canciones"
            playlistAdapter.submitList(playlist.songs)
            binding.btnPlayAll.isVisible    = playlist.songs.isNotEmpty()
            binding.btnShuffleAll.isVisible = playlist.songs.isNotEmpty()
        }
        viewModel.isLoadingPlaylist.observe(viewLifecycleOwner) { loading ->
            binding.progressPlaylist.isVisible = loading
        }
        viewModel.playlistError.observe(viewLifecycleOwner) { err ->
            err?.let { showSnackbar("Error en playlist: $it") }
        }

        // Stream individual (canción seleccionada)
        viewModel.streamState.observe(viewLifecycleOwner) { state ->
            binding.progressStream.isVisible = state is YTMusicViewModel.StreamState.Loading
            when (state) {
                is YTMusicViewModel.StreamState.Ready -> {
                    PlayerController.playSongs(listOf(state.song), 0, "YouTube Music")
                    viewModel.clearStreamState()
                }
                is YTMusicViewModel.StreamState.Error -> {
                    showSnackbar("No se pudo reproducir: ${state.msg}")
                    viewModel.clearStreamState()
                }
                else -> Unit
            }
        }

        // Cola de playlist (resolución en background)
        viewModel.resolvedQueue.observe(viewLifecycleOwner) { songs ->
            if (songs.isEmpty()) return@observe
            if (!playlistQueueStarted) {
                // Primera canción resuelta → iniciar reproducción
                PlayerController.playSongs(songs, 0, "YT Music Playlist")
                playlistQueueStarted = true
            }
            // Las siguientes canciones se añaden via PlayerController en el ViewModel
        }
        viewModel.queueResolutionProgress.observe(viewLifecycleOwner) { (done, total) ->
            binding.tvQueueProgress.isVisible = total > 0 && done < total
            if (total > 0) binding.tvQueueProgress.text = "Cargando cola: $done / $total"
        }
    }

    // ── Queue helper ──────────────────────────────────────────────────────────

    private fun resolveAndAddToQueue(song: YTSong) {
        lifecycleScope.launch {
            val extractor = com.aeroplayer.data.repository.YTMusicExtractor.getInstance(requireContext())
            when (val r = extractor.resolveToSong(song)) {
                is YTResult.Success -> {
                    PlayerController.addToQueue(r.data)
                    showSnackbar("\"${song.title}\" añadida a la cola")
                }
                is YTResult.Error -> showSnackbar("Error al añadir a cola: ${r.message}")
                else -> Unit
            }
        }
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun showSnackbar(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = ContextCompat.getSystemService(requireContext(), InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(binding.etSearch.windowToken, 0)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
