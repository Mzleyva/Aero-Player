package com.aeroplayer.ui.ytmusic

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemYtSongBinding
import com.aeroplayer.model.YTSong
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Adapter para las canciones de una playlist de YouTube Music.
 * Muestra número de pista, thumbnail, título, artista y duración.
 */
class YTPlaylistSongsAdapter(
    private val onSongClick: (YTSong, Int) -> Unit,   // (song, indexInPlaylist)
    private val onAddToQueue: (YTSong) -> Unit
) : ListAdapter<YTSong, YTPlaylistSongsAdapter.VH>(YTSongDiff()) {

    inner class VH(val b: ItemYtSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemYtSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        b.ivThumbnail.clipToOutline   = true
        b.ivThumbnail.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text    = song.title
            tvArtist.text   = song.artist
            tvDuration.text = formatDuration(song.durationMs)
            badgeYtMusic.text = "${position + 1}"   // número de pista

            Glide.with(ivThumbnail)
                .load(song.thumbnailUrl)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivThumbnail)

            ivMore.setOnClickListener {
                com.google.android.material.dialog.MaterialAlertDialogBuilder(root.context)
                    .setTitle(song.title)
                    .setItems(arrayOf("Agregar a cola")) { _, which ->
                        if (which == 0) onAddToQueue(song)
                    }.show()
            }

            root.setOnClickListener { onSongClick(song, position) }
        }
    }

    private fun formatDuration(ms: Long): String {
        if (ms <= 0L) return ""
        val totalSec = ms / 1000
        return "%d:%02d".format(totalSec / 60, totalSec % 60)
    }

    class YTSongDiff : DiffUtil.ItemCallback<YTSong>() {
        override fun areItemsTheSame(a: YTSong, b: YTSong) = a.id == b.id
        override fun areContentsTheSame(a: YTSong, b: YTSong) = a == b
    }
}
