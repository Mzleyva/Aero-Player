package com.aeroplayer.utils

import android.content.Context
import android.net.Uri
import com.aeroplayer.data.db.AppDatabase
import com.aeroplayer.data.db.PlaylistEntity
import com.aeroplayer.data.db.PlaylistSongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * BackupManager — exporta e importa el estado completo de AeroPlayer.
 *
 * Formato: JSON comprimido con:
 * - Playlists + sus canciones (por ruta de archivo)
 * - Configuración (SharedPreferences "aero_prefs")
 * - Historial de reproducción (últimas 500 entradas)
 * - Canciones con "me gusta"
 *
 * Uso:
 *   BackupManager.export(context, uri) → escribe en el URI elegido por el usuario
 *   BackupManager.import(context, uri) → restaura desde el URI
 */
object BackupManager {

    data class BackupResult(val success: Boolean, val message: String)

    // ── Export ────────────────────────────────────────────────────────────────

    suspend fun export(context: Context, destUri: Uri): BackupResult =
        withContext(Dispatchers.IO) {
            try {
                val db    = AppDatabase.getInstance(context)
                val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
                val root  = JSONObject()

                // Metadata
                root.put("version", 1)
                root.put("app", "AeroPlayer")
                root.put("created_at", System.currentTimeMillis())
                root.put("created_at_readable",
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))

                // ── Playlists ────────────────────────────────────────────────
                val playlistsArr = JSONArray()
                val playlists    = db.playlistDao().getAllPlaylistsSync()
                playlists.forEach { pl ->
                    val plObj  = JSONObject()
                    plObj.put("id",         pl.id)
                    plObj.put("name",       pl.name)
                    plObj.put("coverUri",   pl.coverUri ?: "")
                    plObj.put("createdAt",  pl.createdAt)

                    val songsArr = JSONArray()
                    val songs    = db.playlistDao().getSongsForPlaylistSync(pl.id)
                    songs.forEach { s ->
                        val sObj = JSONObject()
                        sObj.put("songId",   s.songId)
                        sObj.put("path",     s.path)
                        sObj.put("title",    s.title)
                        sObj.put("artist",   s.artist)
                        sObj.put("position", s.position)
                        songsArr.put(sObj)
                    }
                    plObj.put("songs", songsArr)
                    playlistsArr.put(plObj)
                }
                root.put("playlists", playlistsArr)

                // ── Liked songs ──────────────────────────────────────────────
                val likedArr = JSONArray()
                db.likedDao().getAllLikedSync().forEach { liked ->
                    likedArr.put(JSONObject().apply {
                        put("songId",    liked.songId)
                        put("path",      liked.path)
                        put("title",     liked.title)
                        put("artist",    liked.artist)
                        put("likedAt",   liked.likedAt)
                    })
                }
                root.put("liked_songs", likedArr)

                // ── Listening history (last 200) ─────────────────────────────
                val historyArr = JSONArray()
                db.historyDao().getRecentHistorySync(200).forEach { h ->
                    historyArr.put(JSONObject().apply {
                        put("songId",    h.songId)
                        put("title",     h.title)
                        put("artist",    h.artist)
                        put("album",     h.album)
                        put("path",      h.path)
                        put("playedAt",  h.playedAt)
                    })
                }
                root.put("history", historyArr)

                // ── Settings (aero_prefs) ────────────────────────────────────
                val settingsObj = JSONObject()
                prefs.all.forEach { (k, v) ->
                    when (v) {
                        is Boolean -> settingsObj.put(k, v)
                        is Int     -> settingsObj.put(k, v)
                        is Long    -> settingsObj.put(k, v)
                        is Float   -> settingsObj.put(k, v)
                        is String  -> settingsObj.put(k, v)
                        is Set<*>  -> settingsObj.put(k, JSONArray(v.toList()))
                    }
                }
                root.put("settings", settingsObj)

                // Write to file
                context.contentResolver.openOutputStream(destUri)?.use { out ->
                    OutputStreamWriter(out, Charsets.UTF_8).use { w ->
                        w.write(root.toString(2))
                    }
                } ?: return@withContext BackupResult(false, "No se pudo abrir el archivo de destino")

                BackupResult(true, "Backup exportado correctamente")
            } catch (e: Exception) {
                BackupResult(false, "Error al exportar: ${e.message}")
            }
        }

    // ── Import ────────────────────────────────────────────────────────────────

    suspend fun import(context: Context, srcUri: Uri): BackupResult =
        withContext(Dispatchers.IO) {
            try {
                val json = context.contentResolver.openInputStream(srcUri)?.use { ins ->
                    BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).readText()
                } ?: return@withContext BackupResult(false, "No se pudo leer el archivo")

                val root = JSONObject(json)
                val version = root.optInt("version", 0)
                if (version < 1) return@withContext BackupResult(false, "Formato de backup no reconocido")

                val db    = AppDatabase.getInstance(context)
                val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)

                // ── Restore playlists ────────────────────────────────────────
                val playlistsArr = root.optJSONArray("playlists")
                if (playlistsArr != null) {
                    for (i in 0 until playlistsArr.length()) {
                        val plObj = playlistsArr.getJSONObject(i)
                        val name  = plObj.getString("name")
                        val cover = plObj.optString("coverUri", "").ifBlank { null }
                        val newId = db.playlistDao().insertPlaylist(
                            PlaylistEntity(name = name, coverUri = cover)
                        )
                        val songsArr = plObj.optJSONArray("songs") ?: continue
                        for (j in 0 until songsArr.length()) {
                            val sObj = songsArr.getJSONObject(j)
                            db.playlistDao().insertSongToPlaylist(
                                PlaylistSongEntity(
                                    playlistId = newId,
                                    songId     = sObj.getLong("songId"),
                                    path       = sObj.optString("path", ""),
                                    title      = sObj.optString("title", ""),
                                    artist     = sObj.optString("artist", ""),
                                    position   = sObj.optInt("position", j)
                                )
                            )
                        }
                    }
                }

                // ── Restore settings ─────────────────────────────────────────
                val settingsObj = root.optJSONObject("settings")
                if (settingsObj != null) {
                    val editor = prefs.edit()
                    // Only restore non-sensitive settings (skip session keys etc.)
                    val skip = setOf("lastfm_session_key", "lastfm_password")
                    settingsObj.keys().forEach { key ->
                        if (key in skip) return@forEach
                        when (val v = settingsObj.get(key)) {
                            is Boolean -> editor.putBoolean(key, v)
                            is Int     -> editor.putInt(key, v)
                            is Long    -> editor.putLong(key, v)
                            is Double  -> editor.putFloat(key, v.toFloat())
                            is String  -> editor.putString(key, v)
                        }
                    }
                    editor.apply()
                }

                val playlistCount = root.optJSONArray("playlists")?.length() ?: 0
                BackupResult(true, "Backup restaurado: $playlistCount playlists importadas")
            } catch (e: Exception) {
                BackupResult(false, "Error al importar: ${e.message}")
            }
        }
}
