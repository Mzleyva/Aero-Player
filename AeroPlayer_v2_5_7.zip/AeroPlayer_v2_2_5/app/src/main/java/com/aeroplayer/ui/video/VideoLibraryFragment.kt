package com.aeroplayer.ui.video

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.data.repository.VideoRepository
import com.aeroplayer.model.LocalVideo
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

/**
 * VideoLibraryFragment — Sesión 8
 * Lista los videos locales. Al tocar uno muestra un diálogo
 * para elegir modo: Audio o Video.
 */
class VideoLibraryFragment : Fragment() {

    private lateinit var recycler: androidx.recyclerview.widget.RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var progressBar: android.widget.ProgressBar

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                               savedInstanceState: Bundle?): View {
        return LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

            progressBar = ProgressBar(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = 48.dp }
            }
            addView(progressBar)

            tvEmpty = TextView(requireContext()).apply {
                text = "No se encontraron videos locales"
                textSize = 15f; gravity = Gravity.CENTER
                setTextColor(0x88FFFFFF.toInt())
                visibility = View.GONE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.topMargin = 32.dp }
            }
            addView(tvEmpty)

            recycler = androidx.recyclerview.widget.RecyclerView(requireContext()).apply {
                layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
            }
            addView(recycler)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadVideos()
    }

    private fun loadVideos() {
        viewLifecycleOwner.lifecycleScope.launch {
            progressBar.visibility = View.VISIBLE
            val videos = VideoRepository(requireContext()).getLocalVideos()
            progressBar.visibility = View.GONE
            if (videos.isEmpty()) {
                tvEmpty.visibility = View.VISIBLE
            } else {
                recycler.adapter = VideoAdapter(videos) { video -> showModeDialog(video) }
            }
        }
    }

    private fun showModeDialog(video: LocalVideo) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(video.title)
            .setItems(arrayOf("🎵 Solo audio (con portada)", "🎬 Ver video")) { _, which ->
                val mode = if (which == 0) LocalVideo.PlayMode.AUDIO_ONLY else LocalVideo.PlayMode.VIDEO
                val intent = Intent(requireContext(), VideoPlayerActivity::class.java).apply {
                    putExtra("video_id",       video.id)
                    putExtra("video_uri",      video.uri.toString())
                    putExtra("video_title",    video.title)
                    putExtra("video_duration", video.duration)
                    putExtra("video_thumb",    video.thumbnailUri?.toString())
                    putExtra("play_mode",      mode.name)
                }
                startActivity(intent)
            }
            .show()
    }

    private inner class VideoAdapter(
        private val items: List<LocalVideo>,
        private val onClick: (LocalVideo) -> Unit
    ) : androidx.recyclerview.widget.RecyclerView.Adapter<VideoAdapter.VH>() {

        inner class VH(view: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(view) {
            val thumb:    ImageView = view.findViewWithTag("thumb")
            val tvTitle:  TextView  = view.findViewWithTag("title")
            val tvMeta:   TextView  = view.findViewWithTag("meta")
        }

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(16.dp, 10.dp, 16.dp, 10.dp)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val thumb = ImageView(parent.context).apply {
                tag = "thumb"; scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = LinearLayout.LayoutParams(80.dp, 52.dp)
                    .also { it.marginEnd = 12.dp }
                setBackgroundColor(0xFF1E1E1E.toInt())
            }
            val textCol = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tvTitle = TextView(parent.context).apply {
                tag = "title"; textSize = 14f
                setTextColor(0xFFFFFFFF.toInt()); maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val tvMeta = TextView(parent.context).apply {
                tag = "meta"; textSize = 11f
                setTextColor(0x88FFFFFF.toInt())
            }
            textCol.addView(tvTitle); textCol.addView(tvMeta)
            row.addView(thumb); row.addView(textCol)
            return VH(row)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val v = items[position]
            holder.tvTitle.text = v.title
            val dur = formatMs(v.duration)
            val res = if (v.width > 0) "${v.width}×${v.height}" else ""
            holder.tvMeta.text = listOf(dur, res).filter { it.isNotBlank() }.joinToString("  ·  ")
            Glide.with(holder.thumb)
                .load(v.thumbnailUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .error(R.drawable.ic_music_placeholder)
                .centerCrop()
                .into(holder.thumb)
            holder.itemView.setOnClickListener { onClick(v) }
        }

        private fun formatMs(ms: Long): String {
            val s = ms / 1000
            return if (s >= 3600) "%d:%02d:%02d".format(s/3600, (s%3600)/60, s%60)
            else "%d:%02d".format(s/60, s%60)
        }
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
