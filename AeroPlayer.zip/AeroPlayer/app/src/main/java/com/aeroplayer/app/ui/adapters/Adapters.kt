package com.aeroplayer.app.ui.adapters

import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.app.data.model.Playlist
import com.aeroplayer.app.data.model.Song
import com.aeroplayer.app.databinding.ItemSongBinding
import com.aeroplayer.app.databinding.ItemPlaylistBinding
import com.bumptech.glide.Glide
import com.aeroplayer.app.R

// ─── Adapter de Canciones ──────────────────────────────────────────────────
class SongAdapter(
    private val onSongClick: (Song) -> Unit,
    private val onMoreClick: ((Song) -> Unit)? = null
) : ListAdapter<Song, SongAdapter.SongViewHolder>(SongDiff) {

    inner class SongViewHolder(val binding: ItemSongBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(song: Song) {
            binding.tvSongTitle.text = song.title
            binding.tvSongArtist.text = song.artist
            binding.tvSongDuration.text = formatDuration(song.duration)
            binding.ivLiked.visibility = if (song.isLiked) View.VISIBLE else View.GONE

            Glide.with(binding.root)
                .load(song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .into(binding.ivSongArt)

            binding.root.setOnClickListener { onSongClick(song) }
            binding.btnMore.setOnClickListener { onMoreClick?.invoke(song) }
        }

        private fun formatDuration(ms: Long): String {
            val s = ms / 1000
            return "%d:%02d".format(s / 60, s % 60)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val binding = ItemSongBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SongViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}

// ─── Adapter de Playlists ──────────────────────────────────────────────────
class PlaylistAdapter(
    private val onPlaylistClick: (Playlist) -> Unit
) : ListAdapter<Playlist, PlaylistAdapter.PlaylistViewHolder>(PlaylistDiff) {

    inner class PlaylistViewHolder(val binding: ItemPlaylistBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(playlist: Playlist) {
            binding.tvPlaylistName.text = playlist.name

            Glide.with(binding.root)
                .load(playlist.coverUri)
                .placeholder(R.drawable.ic_playlist_placeholder)
                .into(binding.ivPlaylistCover)

            binding.root.setOnClickListener { onPlaylistClick(playlist) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaylistViewHolder {
        val binding = ItemPlaylistBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PlaylistViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PlaylistViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object PlaylistDiff : DiffUtil.ItemCallback<Playlist>() {
        override fun areItemsTheSame(a: Playlist, b: Playlist) = a.id == b.id
        override fun areContentsTheSame(a: Playlist, b: Playlist) = a == b
    }
}
