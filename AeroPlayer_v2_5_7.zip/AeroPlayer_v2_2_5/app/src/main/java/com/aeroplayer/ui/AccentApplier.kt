package com.aeroplayer.ui

import android.content.Context
import android.content.res.ColorStateList
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.aeroplayer.utils.applyAlbumArtRounding

/**
 * Aplica el color de acento guardado en ThemeManager a todas las vistas
 * que en el XML tienen @color/accent_blue hardcodeado.
 *
 * Uso: llama AccentApplier.apply(context, rootView) en el onCreate/onViewCreated
 * de cada Activity/Fragment, DESPUÉS de inflar el layout.
 */
object AccentApplier {

    /**
     * Recorre toda la jerarquía de vistas y aplica el color de acento
     * a TextViews con texto de color azul, ProgressBars, TabLayouts, FABs y Switches.
     * Acepta cualquier View como raíz — si es ViewGroup recursa en sus hijos.
     */
    fun apply(context: Context, root: android.view.View) {
        val color = if (AeroThemeManager.isAeroActive(context)) {
            AeroThemeManager.getAccentColor(context)
        } else {
            ThemeManager.getAccentColor(context)
        }
        val csl   = ColorStateList.valueOf(color)
        applyRecursive(root, color, csl)
        // FIX redondeo global: aplicar clipToOutline+outlineProvider a todos los ImageViews
        // con background. Se llama aquí porque AccentApplier.apply ya se invoca en todas
        // las Activities y Fragments, evitando tener que tocarlo en cada archivo.
        if (root is ViewGroup) root.applyAlbumArtRounding()
    }

    private fun applyRecursive(view: android.view.View, color: Int, csl: ColorStateList) {
        when (view) {
            is TabLayout -> {
                view.setSelectedTabIndicatorColor(color)
                view.setTabTextColors(
                    view.tabTextColors?.defaultColor ?: 0x88FFFFFF.toInt(),
                    color
                )
            }
            is android.widget.SeekBar -> {
                // FIX: SeekBar extiende ProgressBar y SÍ tiene thumbTintList
                view.progressTintList = csl
                view.thumbTintList    = csl
            }
            is ProgressBar -> {
                // ProgressBar base NO tiene thumbTintList — solo progressTintList
                view.progressTintList = csl
            }
            is FloatingActionButton -> {
                view.backgroundTintList = csl
            }
            is com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton -> {
                view.backgroundTintList = csl
            }
            is com.google.android.material.button.MaterialButton -> {
                // Solo re-tintamos MaterialButtons cuyo ripple/stroke sea el azul por defecto
                val bg = view.backgroundTintList?.defaultColor
                if (bg != null && isDefaultAccentBlue(bg)) {
                    view.backgroundTintList = csl
                    view.rippleColor = ColorStateList.valueOf(
                        android.graphics.Color.argb(0x33,
                            android.graphics.Color.red(color),
                            android.graphics.Color.green(color),
                            android.graphics.Color.blue(color))
                    )
                }
            }
            is com.google.android.material.switchmaterial.SwitchMaterial -> {
                // El thumb y el track deben reflejar el estado del switch:
                //   checked = ON  → color de acento del tema
                //   unchecked = OFF → gris neutro (#808080 para thumb, 40% alpha para track)
                val grayThumb = android.graphics.Color.parseColor("#808080")
                val grayTrack = android.graphics.Color.argb(0x66, 0x60, 0x60, 0x60)
                val accentTrack = android.graphics.Color.argb(
                    0x66,
                    android.graphics.Color.red(color),
                    android.graphics.Color.green(color),
                    android.graphics.Color.blue(color)
                )

                val thumbStates = arrayOf(
                    intArrayOf(android.R.attr.state_checked),
                    intArrayOf(-android.R.attr.state_checked)
                )
                val trackStates = arrayOf(
                    intArrayOf(android.R.attr.state_checked),
                    intArrayOf(-android.R.attr.state_checked)
                )

                view.thumbTintList = android.content.res.ColorStateList(
                    thumbStates, intArrayOf(color, grayThumb)
                )
                view.trackTintList = android.content.res.ColorStateList(
                    trackStates, intArrayOf(accentTrack, grayTrack)
                )
            }
            is Switch -> {
                val grayThumb = android.graphics.Color.parseColor("#808080")
                val grayTrack = android.graphics.Color.argb(0x66, 0x60, 0x60, 0x60)
                val accentTrack = android.graphics.Color.argb(
                    0x66,
                    android.graphics.Color.red(color),
                    android.graphics.Color.green(color),
                    android.graphics.Color.blue(color)
                )
                val states = arrayOf(
                    intArrayOf(android.R.attr.state_checked),
                    intArrayOf(-android.R.attr.state_checked)
                )
                view.thumbTintList = android.content.res.ColorStateList(
                    states, intArrayOf(color, grayThumb)
                )
                view.trackTintList = android.content.res.ColorStateList(
                    states, intArrayOf(accentTrack, grayTrack)
                )
            }
            is com.google.android.material.bottomnavigation.BottomNavigationView -> {
                // Tintear el indicador activo de la barra de navegación inferior
                view.itemActiveIndicatorColor = csl
            }
            is TextView -> {
                // Solo re-tintamos TextViews cuyo color actual sea el azul por defecto (#4A9EFF)
                val currentColor = view.currentTextColor
                if (isDefaultAccentBlue(currentColor)) {
                    view.setTextColor(color)
                }
            }
            is ImageView -> {
                // Tintamos ImageViews que tienen tint azul explícito
                val tintList = view.imageTintList
                if (tintList != null && isDefaultAccentBlue(tintList.defaultColor)) {
                    view.imageTintList = csl
                }
            }
        }

        // Recursar en ViewGroups
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                applyRecursive(view.getChildAt(i), color, csl)
            }
        }
    }

    /**
     * Compara con tolerancia si el color es el azul por defecto #4A9EFF
     * o variantes con distintos valores de alpha.
     */
    private fun isDefaultAccentBlue(color: Int): Boolean {
        // Ignorar alpha, comparar solo RGB
        val r = android.graphics.Color.red(color)
        val g = android.graphics.Color.green(color)
        val b = android.graphics.Color.blue(color)
        // #4A9EFF = R:74 G:158 B:255
        return r in 60..90 && g in 140..175 && b == 255
    }
}
