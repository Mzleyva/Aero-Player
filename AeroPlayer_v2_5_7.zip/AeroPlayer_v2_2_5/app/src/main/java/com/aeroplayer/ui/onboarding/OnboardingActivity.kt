package com.aeroplayer.ui.onboarding

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityOnboardingBinding
import com.aeroplayer.ui.MainActivity
import com.bumptech.glide.Glide

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private var selectedAvatarUri: Uri? = null

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        selectedAvatarUri = uri
        Glide.with(this).load(uri).circleCrop().into(binding.ivAvatar)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Selector de foto
        binding.avatarContainer.setOnClickListener {
            imagePicker.launch("image/*")
        }

        // IME Done → continuar
        binding.etName.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { saveAndContinue(); true }
            else false
        }

        // Botón continuar
        binding.btnContinue.setOnClickListener { saveAndContinue() }

        // Omitir → saltar directamente
        binding.btnSkip.setOnClickListener { goToMain() }
    }

    private fun saveAndContinue() {
        val name = binding.etName.text?.toString()?.trim() ?: ""
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE).edit()
        prefs.putBoolean("onboarding_done", true)
        if (name.isNotEmpty())           prefs.putString("user_name", name)
        if (selectedAvatarUri != null)   prefs.putString("user_avatar", selectedAvatarUri.toString())
        prefs.apply()

        // Animar botón antes de salir
        binding.btnContinue.animate()
            .scaleX(0.95f).scaleY(0.95f).setDuration(100)
            .withEndAction {
                binding.btnContinue.animate().scaleX(1f).scaleY(1f).setDuration(100)
                    .withEndAction { goToMain() }.start()
            }.start()
    }

    private fun goToMain() {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE).edit()
        prefs.putBoolean("onboarding_done", true).apply()
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        finish()
    }
}
