package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentFilesBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class SortOrder {
    TITLE, ARTIST, ALBUM, DURATION,
    DATE_ADDED,        // más reciente primero (usa lastModified del archivo)
    YEAR,              // año de lanzamiento
    RECENTLY_EDITED,   // modificado recientemente
    FORMAT,            // agrupado por formato (FLAC, MP3, etc.)
    PLAY_COUNT,        // más reproducidas primero
    CUSTOM             // orden personalizado por el usuario (drag & drop)
}

class FilesFragment : Fragment() {

    private var _binding: FragmentFilesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: SongListAdapter

    // FIX SESSION 2: restaurar el sort elegido por el usuario entre sesiones.
    // Antes siempre arrancaba en DATE_ADDED y si el usuario había elegido otro sort
    // en la sesión anterior lo perdía al cerrar la app.
    private var currentSort: SortOrder = SortOrder.DATE_ADDED

    private fun prefs() = requireContext()
        .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)

    private fun loadSavedSort(): SortOrder {
        val name = prefs().getString("files_sort_order", SortOrder.DATE_ADDED.name)
        return runCatching { SortOrder.valueOf(name ?: "") }.getOrDefault(SortOrder.DATE_ADDED)
    }

    private fun loadCustomOrder(): List<Long> {
        val raw = prefs().getString("custom_song_order", "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split(",").mapNotNull { it.trim().toLongOrNull() }
    }

    private fun saveCustomOrder(ids: List<Long>) {
        prefs().edit().putString("custom_song_order", ids.joinToString(",")).apply()
    }

    private fun showCustomOrderScreen() {
        val songs = viewModel.allSongs.value?.toMutableList() ?: return
        val saved = loadCustomOrder()
        val workList = if (saved.isNotEmpty()) {
            val idx = saved.withIndex().associate { (i, id) -> id to i }
            songs.sortedBy { idx[it.id] ?: Int.MAX_VALUE }.toMutableList()
        } else songs
        val ctx = requireContext()
        val rv = androidx.recyclerview.widget.RecyclerView(ctx).apply {
            layoutManager = androidx.recyclerview.widget.LinearLayoutManager(ctx)
            setPadding(0, 8, 0, 8)
        }
        val adapter = object : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
            inner class VH(val tv: android.widget.TextView) : androidx.recyclerview.widget.RecyclerView.ViewHolder(tv)
            override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int): VH {
                val tv = android.widget.TextView(ctx).apply {
                    textSize = 14f; setPadding(56, 24, 56, 24)
                    setTextColor(ctx.getColor(R.color.text_primary))
                }
                return VH(tv)
            }
            override fun onBindViewHolder(h: androidx.recyclerview.widget.RecyclerView.ViewHolder, pos: Int) {
                (h as VH).tv.text = "≡  ${workList[pos].title}"
            }
            override fun getItemCount() = workList.size
        }
        rv.adapter = adapter
        androidx.recyclerview.widget.ItemTouchHelper(
            object : androidx.recyclerview.widget.ItemTouchHelper.SimpleCallback(
                androidx.recyclerview.widget.ItemTouchHelper.UP or
                androidx.recyclerview.widget.ItemTouchHelper.DOWN, 0) {
                override fun onMove(rv2: androidx.recyclerview.widget.RecyclerView,
                    from: androidx.recyclerview.widget.RecyclerView.ViewHolder,
                    to: androidx.recyclerview.widget.RecyclerView.ViewHolder): Boolean {
                    val f = from.bindingAdapterPosition; val t = to.bindingAdapterPosition
                    if (f < 0 || t < 0) return false
                    val moved = workList.removeAt(f); workList.add(t, moved)
                    adapter.notifyItemMoved(f, t); return true
                }
                override fun onSwiped(vh: androidx.recyclerview.widget.RecyclerView.ViewHolder, d: Int) {}
            }).attachToRecyclerView(rv)
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("Orden personalizado")
            .setView(rv)
            .setPositiveButton("Guardar") { _, _ ->
                saveCustomOrder(workList.map { it.id })
                applySortToViewModel()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun saveSortOrder(order: SortOrder) {
        prefs().edit().putString("files_sort_order", order.name).apply()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFilesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        currentSort = loadSavedSort() // restaurar sort de la sesión anterior
        setupRecyclerView()
        setupAlphabetSidebar()
        setupSortButton()
        setupShuffleButton()
        observePagingData()
        observeLiked()
        observeLoadState()
    }

    private fun launchPlayerWithTransition(
        songView: android.view.View?,
        song: com.aeroplayer.model.Song,
        songs: List<com.aeroplayer.model.Song>,
        index: Int
    ) {
        PlayerController.playSongs(songs, index)
        val act = requireActivity()
        if (songView != null && android.os.Build.VERSION.SDK_INT >= 21) {
            val intent = android.content.Intent(act,
                com.aeroplayer.ui.player.PlayerActivity::class.java)
            val albumArtView = songView.findViewById<android.view.View>(R.id.ivAlbumArt)
            if (albumArtView != null) {
                val options = androidx.core.app.ActivityOptionsCompat.makeSceneTransitionAnimation(
                    act, albumArtView, "player_album_art"
                )
                act.startActivity(intent, options.toBundle())
            } else {
                act.startActivity(intent)
            }
        } else {
            act.startActivity(android.content.Intent(act,
                com.aeroplayer.ui.player.PlayerActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = SongListAdapter(
            viewLifecycleOwner.lifecycleScope,
            onSongClick     = { song, _ ->
                val songs = sortedSongs()
                PlayerController.playSongs(
                    songs, songs.indexOf(song).coerceAtLeast(0),
                    queueName = getString(R.string.tab_files)
                )
                viewModel.incrementPlayCount(song)
            },
            onLikeClick     = { song -> viewModel.toggleLike(song) },
            onAddToPlaylist = { song -> showAddToPlaylistDialog(song) },
            onAddToQueue    = { song -> PlayerController.addToQueue(song) }
        )
        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter       = this@FilesFragment.adapter
            setHasFixedSize(true)
        }
    }

    /** Construye y activa la barra alfabética lateral para scroll rápido. */
    private fun setupAlphabetSidebar() {
        val sidebar = binding.alphabetSidebar ?: return
        val bubble  = binding.tvAlphabetBubble ?: return
        val rv      = binding.rvSongs
        sidebar.removeAllViews()

        val letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".toList()
        val dp = resources.displayMetrics.density

        letters.forEach { letter ->
            val tv = android.widget.TextView(requireContext()).apply {
                text      = letter.toString()
                textSize  = 9f
                setTextColor(requireContext().getColor(R.color.text_secondary))
                gravity   = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    0, 1f
                )
            }
            sidebar.addView(tv)
        }

        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        var hideRunnable: Runnable? = null

        sidebar.setOnTouchListener { _, event ->
            val y = event.y
            val idx = ((y / sidebar.height) * letters.size).toInt().coerceIn(0, letters.lastIndex)
            val letter = letters[idx]

            bubble.text       = letter.toString()
            bubble.visibility = android.view.View.VISIBLE

            // Encontrar el primer item que empieza con esa letra
            val songs = sortedSongs()
            val targetIdx = songs.indexOfFirst { song ->
                val first = song.title.trimStart().uppercase().firstOrNull()
                if (letter == '#') first?.isDigit() == true
                else first == letter.uppercaseChar()
            }
            if (targetIdx >= 0) {
                (rv.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager)
                    ?.scrollToPositionWithOffset(targetIdx, 0)
            }

            // Ocultar burbuja tras 1s sin movimiento
            hideRunnable?.let { handler.removeCallbacks(it) }
            if (event.action == android.view.MotionEvent.ACTION_UP ||
                event.action == android.view.MotionEvent.ACTION_CANCEL) {
                val h = Runnable { bubble.visibility = android.view.View.GONE }
                hideRunnable = h
                handler.postDelayed(h, 400)
            }
            true
        }
    }

    private fun setupSortButton() {
        binding.btnSort.setOnClickListener {
            val labels = listOf(
                "Por título"              to SortOrder.TITLE,
                "Por artista"             to SortOrder.ARTIST,
                "Por álbum"               to SortOrder.ALBUM,
                "Por duración"            to SortOrder.DURATION,
                "Agregado recientemente"  to SortOrder.DATE_ADDED,
                "Por año"                 to SortOrder.YEAR,
                "Editado recientemente"   to SortOrder.RECENTLY_EDITED,
                "Por formato"             to SortOrder.FORMAT,
                "Más reproducidas"         to SortOrder.PLAY_COUNT,
                "Personalizado"            to SortOrder.CUSTOM
            )
            val options = labels.map { (label, order) ->
                "$label${if (currentSort == order) " ✓" else ""}"
            }.toTypedArray()

            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Ordenar por")
                .setItems(options) { _, idx ->
                    currentSort = labels[idx].second
                    saveSortOrder(currentSort)
                    if (currentSort == SortOrder.CUSTOM) {
                        showCustomOrderScreen()
                    } else {
                        applySortToViewModel()
                    }
                }
                .show()
        }
    }

    /** Botón de reproducción aleatoria de todos los archivos. */
    private fun setupShuffleButton() {
        binding.btnShuffleAll?.setOnClickListener {
            val all = viewModel.allSongs.value ?: return@setOnClickListener
            if (all.isEmpty()) return@setOnClickListener
            val shuffled = all.shuffled()
            PlayerController.playSongs(shuffled, 0, queueName = "Aleatorio")
            Snackbar.make(binding.root,
                "▶ ${shuffled.size} canciones en aleatorio", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun sortedSongs(): List<Song> {
        val all = viewModel.allSongs.value ?: return emptyList()
        return applySortOrder(all, currentSort)
    }

    private fun applySortOrder(all: List<Song>, order: SortOrder): List<Song> = when (order) {
        SortOrder.TITLE           -> all.sortedBy { it.title.lowercase() }
        SortOrder.ARTIST          -> all.sortedBy { it.artist.lowercase() }
        SortOrder.ALBUM           -> all.sortedBy { it.album.lowercase() }
        SortOrder.DURATION        -> all.sortedByDescending { it.duration }
        SortOrder.DATE_ADDED      -> all.sortedByDescending {
            // FIX RENDIMIENTO: usar Song.dateAdded (de MediaStore) en lugar de
            // File.lastModified() que hace una llamada syscat por cada canción,
            // bloqueando el hilo IO cientos de veces en bibliotecas grandes.
            // dateAdded es 0 solo si MediaStore no lo tiene; en ese caso fallback al path.
            if (it.dateAdded > 0L) it.dateAdded
            else java.io.File(it.path).lastModified() / 1000L
        }
        SortOrder.YEAR            -> all.sortedByDescending { it.year }
        SortOrder.RECENTLY_EDITED -> all.sortedByDescending {
            // FIX RENDIMIENTO: idem con dateModified
            if (it.dateModified > 0L) it.dateModified
            else java.io.File(it.path).lastModified() / 1000L
        }
        SortOrder.FORMAT          -> all.sortedWith(
            compareBy({ it.formatLabel }, { it.title.lowercase() })
        )
        SortOrder.PLAY_COUNT      -> all.sortedByDescending { it.playCount }
        SortOrder.CUSTOM          -> {
            val saved = loadCustomOrder()
            if (saved.isEmpty()) all
            else {
                val indexed = saved.withIndex().associate { (i, id) -> id to i }
                all.sortedBy { indexed[it.id] ?: Int.MAX_VALUE }
            }
        }
    }

    private fun observePagingData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.songsPagingData.collectLatest { pagingData ->
                adapter.submitData(pagingData)
            }
        }
        // FIX LENTITUD: usar debounce para el re-sort.
        // allSongs se emite cada vez que incrementPlayCount dispara loadSongs (aunque la
        // lista no cambie). Sin debounce, cada toque a "reproducir" fuerza un re-sort
        // completo con File.lastModified() por cada canción.
        val sortHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var sortRunnable: Runnable? = null
        viewModel.allSongs.observe(viewLifecycleOwner) { _ ->
            sortRunnable?.let { sortHandler.removeCallbacks(it) }
            val r = Runnable { applySortToViewModel() }
            sortRunnable = r
            sortHandler.postDelayed(r, 200)
        }
    }

    private fun applySortToViewModel() {
        val all = viewModel.allSongs.value ?: return
        val label = when (currentSort) {
            SortOrder.TITLE           -> "título"
            SortOrder.ARTIST          -> "artista"
            SortOrder.ALBUM           -> "álbum"
            SortOrder.DURATION        -> "duración"
            SortOrder.DATE_ADDED      -> "agregado recientemente"
            SortOrder.YEAR            -> "año"
            SortOrder.RECENTLY_EDITED -> "editado recientemente"
            SortOrder.FORMAT          -> "formato"
            SortOrder.PLAY_COUNT      -> "más reproducidas"
            SortOrder.CUSTOM          -> "personalizado"
        }
        // PERF: applySortOrder ya no llama File.lastModified() — usa Song.dateAdded y
        // Song.dateModified de MediaStore. El sort es O(n·log n) sobre campos en memoria,
        // así que se puede ejecutar directamente en el main thread sin bloquear.
        val sorted = applySortOrder(all, currentSort)
        viewModel.submitSortedSongs(sorted)
        binding.tvCount.text = "${sorted.size} canciones · $label"
    }

    private fun observeLoadState() {
        viewLifecycleOwner.lifecycleScope.launch {
            adapter.loadStateFlow.collectLatest { states ->
                val refresh = states.refresh
                binding.tvEmpty.visibility =
                    if (refresh is LoadState.NotLoading && adapter.itemCount == 0)
                        View.VISIBLE else View.GONE
            }
        }
    }

    private fun observeLiked() {
        viewModel.likedSongs.observe(viewLifecycleOwner) { liked ->
            adapter.updateLikedIds(liked.map { it.songId }.toSet())
        }
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = viewModel.playlists.value ?: return
        if (playlists.isEmpty()) {
            Snackbar.make(binding.root, "Crea una playlist primero",
                Snackbar.LENGTH_SHORT).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Agregar a playlist")
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                Snackbar.make(binding.root, "Agregado a ${playlists[idx].name}",
                    Snackbar.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
