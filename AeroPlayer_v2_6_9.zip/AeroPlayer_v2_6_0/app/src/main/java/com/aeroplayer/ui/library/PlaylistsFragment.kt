package com.aeroplayer.ui.library

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.databinding.FragmentPlaylistsBinding
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.SmartPlaylistActivity
import com.aeroplayer.ui.SmartPlaylistType
import com.aeroplayer.ui.playlist.CreatePlaylistActivity
import com.aeroplayer.ui.playlist.PlaylistDetailActivity

class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PlaylistAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupSmartPlaylists()
        setupRecyclerView()
        observePlaylists()
        setupFab()
    }

    private fun setupSmartPlaylists() {
        val smartAdapter = SmartPlaylistCardAdapter { type ->
            startActivity(
                Intent(requireContext(), SmartPlaylistActivity::class.java)
                    .putExtra(SmartPlaylistActivity.EXTRA_TYPE, type.name)
            )
        }
        binding.rvSmartPlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = smartAdapter
        }
        smartAdapter.submitList(SmartPlaylistType.entries.toList())

        // FIX PORTADA ME GUSTA: usar URI fresca de allSongs en lugar de la almacenada
        // en liked_songs.albumArtUri (puede ser stale tras re-escaneo de MediaStore).
        viewLifecycleOwner.lifecycleScope.launch {
            val songId = viewModel.getLikedFirstSongId()
            val freshUri = songId?.let { id ->
                viewModel.allSongs.value?.firstOrNull { it.id == id }?.albumArtUri
                    ?: run {
                        // Fallback a DB si allSongs aún no cargó
                        viewModel.getLikedFirstArtUri()?.let { android.net.Uri.parse(it) }
                    }
            }
            smartAdapter.updateLikedCover(freshUri)
        }

        // Sesión 9: Mix diario y Playlist rápida — se ejecutan directamente aquí
        binding.btnDailyMix?.setOnClickListener {
            val allSongs  = viewModel.allSongs.value
            val topPlayed = viewModel.topPlayed.value ?: emptyList()
            if (allSongs.isNullOrEmpty()) {
                com.google.android.material.snackbar.Snackbar
                    .make(binding.root, "Cargando biblioteca…", 1500).show()
                return@setOnClickListener
            }
            buildAndPlayDailyMix(allSongs, topPlayed)
            com.google.android.material.snackbar.Snackbar
                .make(binding.root, "🎲 Reproduciendo Mix del día", 1800).show()
        }
        binding.btnQuickPlaylist?.setOnClickListener {
            val allSongs  = viewModel.allSongs.value
            val topPlayed = viewModel.topPlayed.value ?: emptyList()
            if (allSongs.isNullOrEmpty()) {
                com.google.android.material.snackbar.Snackbar
                    .make(binding.root, "Cargando biblioteca…", 1500).show()
                return@setOnClickListener
            }
            buildAndPlayQuickPlaylist(allSongs, topPlayed)
            com.google.android.material.snackbar.Snackbar
                .make(binding.root, "⚡ Playlist rápida lista", 1800).show()
        }
    }

    // ── Mix diario ─────────────────────────────────────────────────────────────
    private fun buildAndPlayDailyMix(
        allSongs: List<com.aeroplayer.model.Song>,
        topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>
    ) {
        val prefs = requireContext().getSharedPreferences("home_prefs",
            android.content.Context.MODE_PRIVATE)
        val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US)
            .format(java.util.Date())

        if (prefs.getString("daily_mix_day", "") == today) {
            val ids = prefs.getString("daily_mix_ids", "")
                ?.split(",")?.mapNotNull { it.toLongOrNull() } ?: emptyList()
            val songs = ids.mapNotNull { id -> allSongs.firstOrNull { it.id == id } }
            if (songs.isNotEmpty()) {
                com.aeroplayer.service.PlayerController.playSongs(songs, 0, "🎲 Mix del día")
                return
            }
        }
        val topIds    = topPlayed.map { it.songId }.toSet()
        val topSongs  = allSongs.filter { it.id in topIds }
            .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
        val seedArts  = topSongs.take(5).map { it.artist }.toSet()
        val top       = topSongs.take(10).shuffled()
        val related   = allSongs.filter { it.id !in topIds && it.artist in seedArts }.shuffled().take(8)
        val discover  = allSongs.filter { it.id !in topIds && it.artist !in seedArts }.shuffled().take(7)
        val mix       = (top + related + discover).shuffled().take(25)

        prefs.edit()
            .putString("daily_mix_day", today)
            .putString("daily_mix_ids", mix.joinToString(",") { it.id.toString() })
            .apply()
        com.aeroplayer.service.PlayerController.playSongs(mix, 0, "🎲 Mix del día")
    }

    // ── Playlist rápida ────────────────────────────────────────────────────────
    private fun buildAndPlayQuickPlaylist(
        allSongs: List<com.aeroplayer.model.Song>,
        topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>
    ) {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val currentSong = com.aeroplayer.service.PlayerController.currentSong.value
        val topIds = topPlayed.map { it.songId }.toSet()

        val moodKw = when {
            hour in 6..9   -> listOf("acoustic","chill","lofi","morning","tranquil")
            hour in 10..17 -> listOf("energy","pop","rock","workout","motivation")
            hour in 18..21 -> listOf("jazz","blues","indie","evening","mellow")
            else            -> listOf("ambient","sleep","calm","relax","night")
        }
        val sameArtist = currentSong?.let { cur ->
            allSongs.filter { it.artist.equals(cur.artist, ignoreCase = true)
                              && it.id != cur.id }.take(5)
        } ?: emptyList()
        val liked   = allSongs.filter { it.isLiked }.shuffled().take(8)
        val byMood  = allSongs.filter { s ->
            val hay = "${s.title} ${s.genre} ${s.artist}".lowercase()
            moodKw.any { hay.contains(it) }
        }.shuffled().take(7)
        val top     = allSongs.filter { it.id in topIds }
            .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
            .take(5)

        val combined = (sameArtist + liked + byMood + top)
            .distinctBy { it.id }.shuffled().take(20)
            .let { if (it.isEmpty()) allSongs.shuffled().take(20) else it }
        com.aeroplayer.service.PlayerController.playSongs(combined, 0, "⚡ Playlist rápida")
    }

    private fun setupRecyclerView() {
        adapter = PlaylistAdapter(
            onPlaylistClick = { playlist ->
                startActivity(
                    Intent(requireContext(), PlaylistDetailActivity::class.java)
                        .putExtra("playlistId", playlist.id)
                        .putExtra("playlistName", playlist.name)
                )
            },
            onDeleteClick = { playlist ->
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar playlist")
                    .setMessage("¿Eliminar \"${playlist.name}\"?")
                    .setPositiveButton("Eliminar") { _, _ -> viewModel.deletePlaylist(playlist.id) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )
        // FIX SESIÓN 6: buscar portada en internet al tocar "Buscar portada"
        adapter.onFetchCoverClick = { playlist -> fetchCoverForPlaylist(playlist) }

        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@PlaylistsFragment.adapter
            setHasFixedSize(true)
        }
    }

    /** Busca portada por nombre de playlist en iTunes y la guarda en la DB. */
    private fun fetchCoverForPlaylist(playlist: com.aeroplayer.data.db.PlaylistEntity) {
        val snack = com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Buscando portada para \"${playlist.name}\"…", com.google.android.material.snackbar.Snackbar.LENGTH_INDEFINITE)
        snack.show()
        viewLifecycleOwner.lifecycleScope.launch {
            val url = com.aeroplayer.utils.PlaylistCoverFetcher.fetch(playlist.name)
            snack.dismiss()
            if (url != null) {
                viewModel.updatePlaylistFull(playlist.id, playlist.name, url)
                com.google.android.material.snackbar.Snackbar.make(binding.root, "✅ Portada actualizada", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            } else {
                com.google.android.material.snackbar.Snackbar.make(binding.root, "No se encontró portada para \"${playlist.name}\"", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun observePlaylists() {
        viewModel.playlists.observe(viewLifecycleOwner) { playlists ->
            adapter.submitList(playlists)
            binding.tvEmpty.visibility = if (playlists.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text       = "${playlists.size} playlist${if (playlists.size != 1) "s" else ""}"
            playlists.forEach { playlist ->
                viewModel.getPlaylistSongCount(playlist.id)
                    .observe(viewLifecycleOwner) { count ->
                        adapter.updateSongCount(playlist.id, count ?: 0)
                    }
                // FIX PORTADAS PLAYLISTS: usar URI fresca de allSongs en lugar de la
                // almacenada en la DB (playlist_songs.albumArtUri). Las URIs de la DB
                // apuntan a content://media/external/audio/albumart/{albumId} que cambia
                // cuando MediaStore re-escanea — Glide falla al cargarlas silenciosamente.
                // SOLUCIÓN: obtener el songId de la primera canción y buscar su albumArtUri
                // en allSongs (siempre fresca del escaneo actual de MediaStore).
                if (playlist.coverUri == null) {
                    viewLifecycleOwner.lifecycleScope.launch {
                        val songId = viewModel.getPlaylistFirstSongId(playlist.id)
                        val freshUri = songId?.let { id ->
                            viewModel.allSongs.value?.firstOrNull { it.id == id }?.albumArtUri
                                ?: run {
                                    // Si allSongs no tiene el song (todavía cargando),
                                    // usar el URI de la DB como último recurso
                                    viewModel.getPlaylistFirstArtUri(playlist.id)
                                        ?.let { android.net.Uri.parse(it) }
                                }
                        }
                        adapter.updateSongCover(playlist.id, freshUri)
                    }
                }
            }
        }
    }

    private fun setupFab() {
        binding.fabNewPlaylist.setOnClickListener {
            startActivity(Intent(requireContext(), CreatePlaylistActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// ── Adapter de tarjetas de smart playlist (scroll horizontal) ─────────────────
private class SmartPlaylistCardAdapter(
    private val onClick: (SmartPlaylistType) -> Unit
) : ListAdapter<SmartPlaylistType, SmartPlaylistCardAdapter.VH>(TypeDiff()) {

    private val cardColors = listOf(
        intArrayOf(Color.parseColor("#1A3A6E"), Color.parseColor("#0D1F3C")),
        intArrayOf(Color.parseColor("#6E1A3A"), Color.parseColor("#3C0D1F")),
        intArrayOf(Color.parseColor("#1A6E3A"), Color.parseColor("#0D3C1F")),
        intArrayOf(Color.parseColor("#6E3A1A"), Color.parseColor("#3C1F0D"))
    )

    private val coverCache = mutableMapOf<SmartPlaylistType, android.net.Uri?>()

    fun updateLikedCover(uri: android.net.Uri?) {
        coverCache[SmartPlaylistType.LIKED] = uri
        val pos = currentList.indexOf(SmartPlaylistType.LIKED)
        if (pos >= 0) notifyItemChanged(pos)
    }

    inner class VH(root: FrameLayout) : RecyclerView.ViewHolder(root) {
        val frame:   FrameLayout                 = root
        val ivCover: android.widget.ImageView    = root.getChildAt(0) as android.widget.ImageView
        val inner:   LinearLayout                = root.getChildAt(1) as LinearLayout
        val tvEmoji: TextView                    = inner.getChildAt(0) as TextView
        val tvName:  TextView                    = inner.getChildAt(1) as TextView
        val tvDesc:  TextView                    = inner.getChildAt(2) as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density

        // Root: FrameLayout con clip y elevación
        val frame = FrameLayout(ctx).apply {
            layoutParams = RecyclerView.LayoutParams(
                (156 * dp).toInt(), (120 * dp).toInt()
            ).also { it.marginEnd = (10 * dp).toInt() }
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#1E2330"), Color.parseColor("#161A22"))
            ).apply { cornerRadius = 16 * dp }
            elevation = 4 * dp
            isClickable = true; isFocusable = true
        }

        // Capa 1: imagen de portada semitransparente
        val ivCover = android.widget.ImageView(ctx).apply {
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            alpha = 0.4f
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT)
        }

        // Capa 2: contenido (emoji + nombre + desc) centrado
        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = android.view.Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT)
            setPadding((10 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt(), (10 * dp).toInt())
        }
        val tvEmoji = TextView(ctx).apply {
            textSize = 28f; gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val tvName = TextView(ctx).apply {
            textSize = 13f; maxLines = 2; gravity = android.view.Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = (4 * dp).toInt() }
        }
        val tvDesc = TextView(ctx).apply {
            textSize = 10f; maxLines = 2; gravity = android.view.Gravity.CENTER
            setTextColor(Color.parseColor("#AAFFFFFF"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = (2 * dp).toInt() }
        }
        inner.addView(tvEmoji); inner.addView(tvName); inner.addView(tvDesc)
        frame.addView(ivCover); frame.addView(inner)

        return VH(frame)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val type   = getItem(position)
        val colors = cardColors[position % cardColors.size]
        holder.tvEmoji.text = type.emoji
        holder.tvName.text  = type.titleEs
        holder.tvDesc.text  = type.descriptionEs

        val dp = holder.frame.resources.displayMetrics.density
        holder.frame.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, colors
        ).apply { cornerRadius = 16 * dp }

        // Portada de la primera canción liked en la card LIKED
        val coverUri = coverCache[type]
        if (coverUri != null) {
            com.bumptech.glide.Glide.with(holder.ivCover)
                .load(coverUri)
                .centerCrop()
                .into(holder.ivCover)
            holder.ivCover.visibility = android.view.View.VISIBLE
        } else {
            holder.ivCover.visibility = android.view.View.GONE
        }

        // Click en toda la card (incluye la imagen de fondo)
        holder.frame.setOnClickListener { onClick(type) }
    }

    class TypeDiff : DiffUtil.ItemCallback<SmartPlaylistType>() {
        override fun areItemsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
        override fun areContentsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
    }
}
