package com.aeroplayer.model

import android.net.Uri

/**
 * Sesión 8: modelo de video local.
 * Un archivo de video puede reproducirse en dos modos:
 *  - AUDIO_ONLY: solo el audio, usando la portada del video como albumArt
 *  - VIDEO: el video completo en pantalla
 */
data class LocalVideo(
    val id:           Long,
    val title:        String,
    val duration:     Long,       // ms
    val path:         String,
    val uri:          Uri,
    val thumbnailUri: Uri?,       // frame del video extraído por MediaStore
    val size:         Long = 0L,
    val width:        Int  = 0,
    val height:       Int  = 0,
    val mimeType:     String = "",
    val dateAdded:    Long = 0L
) {
    enum class PlayMode { AUDIO_ONLY, VIDEO }

    /** Convierte el video a Song para reproducirlo como audio (modo AUDIO_ONLY). */
    fun toSong(): Song = Song(
        id          = id,
        title       = title,
        artist      = "",
        album       = "",
        duration    = duration,
        path        = path,
        uri         = uri,
        albumArtUri = thumbnailUri,
        mimeType    = mimeType,
        size        = size,
        dateAdded   = dateAdded
    )
}
