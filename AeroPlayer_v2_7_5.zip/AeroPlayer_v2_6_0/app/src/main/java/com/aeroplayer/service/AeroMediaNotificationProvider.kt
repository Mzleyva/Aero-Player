package com.aeroplayer.service

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession

/**
 * AeroMediaNotificationProvider — corrige el crash de SystemUI en Android 11.
 *
 * CAUSA: La portada del álbum (~1.4 MB) supera el límite IPC de Android 11 (~1 MB)
 * al pasar vía Binder a SystemUI → TransactionTooLargeException → crash del OS.
 *
 * SOLUCIÓN: Interceptar la Notification que produce DefaultMediaNotificationProvider,
 * extraer el largeIcon, escalarlo a máx 256×256 px y escribirlo de vuelta
 * directamente en el campo Notification.largeIcon via reflexión — preservando
 * media style, acciones e intents intactos sin tener que reconstruir nada.
 *
 * Compatible con Media3 1.4.1.
 */
@UnstableApi
class AeroMediaNotificationProvider(
    private val context: android.content.Context
) : MediaNotification.Provider {

    companion object {
        private const val MAX_PX = 256   // 256×256 × 4 bytes ≈ 256 KB, seguro para IPC
    }

    private val delegate = DefaultMediaNotificationProvider(context)

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: com.google.common.collect.ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val original = delegate.createNotification(
            mediaSession, customLayout, actionFactory, onNotificationChangedCallback
        )

        // Sólo aplicable en API 23+ donde existe getLargeIcon()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return original

        // Extraer el bitmap de la portada del largeIcon
        val largeIconBitmap: Bitmap = extractLargeIconBitmap(original.notification)
            ?: return original   // sin portada → sin riesgo IPC

        if (largeIconBitmap.width <= MAX_PX && largeIconBitmap.height <= MAX_PX) return original

        // Escalar el bitmap a MAX_PX
        val scaled = scaleBitmap(largeIconBitmap)

        // Reemplazar largeIcon en la Notification existente vía el campo público Bitmap
        // Notification.largeIcon es un campo público desde API 1 y sigue disponible en API 30.
        // Es más seguro que reconstruir toda la notificación (que perdería media style/actions).
        original.notification.largeIcon = scaled

        return original
    }

    override fun handleCustomCommand(
        session: MediaSession,
        action: String,
        extras: Bundle
    ): Boolean = delegate.handleCustomCommand(session, action, extras)

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun extractLargeIconBitmap(notif: Notification): Bitmap? {
        // Notification.largeIcon es el Bitmap público (API 1+)
        // getLargeIcon() devuelve un Icon (API 23+) que puede diferir del campo Bitmap
        // Para nuestro propósito el campo directo es suficiente y más simple.
        @Suppress("DEPRECATION")
        notif.largeIcon?.let { return it }

        // Fallback: extraer del Icon en API 23+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notif.getLargeIcon()?.loadDrawable(context)?.let { drawable ->
                val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: MAX_PX
                val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: MAX_PX
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                drawable.setBounds(0, 0, w, h)
                drawable.draw(Canvas(bmp))
                return bmp
            }
        }
        return null
    }

    private fun scaleBitmap(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= MAX_PX && h <= MAX_PX) return src
        val factor = MAX_PX.toFloat() / maxOf(w, h)
        return runCatching {
            Bitmap.createScaledBitmap(
                src,
                (w * factor).toInt().coerceAtLeast(1),
                (h * factor).toInt().coerceAtLeast(1),
                true
            )
        }.getOrElse { src }
    }
}
