package com.aeroplayer.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import java.util.concurrent.Executors

/**
 * AeroMediaNotificationProvider — corrige el crash de SystemUI en Android 11.
 *
 * CAUSA: Media3 pasa el bitmap de portada (~1.4 MB) a SystemUI via Binder IPC.
 * Android 11 limita las transacciones IPC a ~1 MB → TransactionTooLargeException
 * en el proceso de SystemUI → crash del sistema operativo completo.
 *
 * SOLUCIÓN: BitmapLoader personalizado que escala cualquier bitmap a máx 256×256
 * antes de entregarlo a la notificación (256 KB, seguro para IPC en todos los Android).
 */
@UnstableApi
object AeroMediaNotificationProvider {
    fun create(context: Context): DefaultMediaNotificationProvider =
        DefaultMediaNotificationProvider.Builder(context)
            .setBitmapLoader(ScalingBitmapLoader(context.applicationContext))
            .build()
}

@UnstableApi
private class ScalingBitmapLoader(private val context: Context) : BitmapLoader {

    private val executor = Executors.newSingleThreadExecutor()

    companion object {
        // 256×256 × 4 bytes/px ≈ 256 KB — muy por debajo del límite IPC de Android 11
        private const val MAX_PX = 256
    }

    override fun supportsMimeType(mimeType: String) = true

    /** Llamado cuando la portada está en MediaMetadata.artworkData (bytes). */
    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> {
        val future = SettableFuture.create<Bitmap>()
        executor.execute {
            runCatching {
                val raw = BitmapFactory.decodeByteArray(data, 0, data.size)
                future.set(if (raw != null) scale(raw) else null)
            }.onFailure { future.setException(it) }
        }
        return future
    }

    /** Llamado cuando la portada está en MediaMetadata.artworkUri (content:// o https://). */
    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        val future = SettableFuture.create<Bitmap>()
        executor.execute {
            runCatching {
                val raw: Bitmap? = when (uri.scheme) {
                    "content" -> {
                        // content:// → MediaStore album art → abrir con ContentResolver
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            BitmapFactory.decodeStream(stream)
                        }
                    }
                    "file" -> {
                        BitmapFactory.decodeFile(uri.path)
                    }
                    "http", "https" -> {
                        java.net.URL(uri.toString()).openStream().use { stream ->
                            BitmapFactory.decodeStream(stream)
                        }
                    }
                    else -> null
                }
                future.set(if (raw != null) scale(raw) else null)
            }.onFailure { future.setException(it) }
        }
        return future
    }

    private fun scale(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= MAX_PX && h <= MAX_PX) return bitmap
        val factor = MAX_PX.toFloat() / maxOf(w, h)
        return runCatching {
            Bitmap.createScaledBitmap(
                bitmap,
                (w * factor).toInt().coerceAtLeast(1),
                (h * factor).toInt().coerceAtLeast(1),
                true  // bilinear filter
            )
        }.getOrElse { bitmap }
    }
}
