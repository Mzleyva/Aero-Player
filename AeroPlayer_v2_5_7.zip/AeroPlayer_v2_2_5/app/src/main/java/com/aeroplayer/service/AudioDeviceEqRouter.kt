package com.aeroplayer.service

import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import com.aeroplayer.ui.equalizer.EqualizerActivity

/**
 * AudioDeviceEqRouter — v1.8.3
 *
 * Detecta cambios de dispositivo de audio (auriculares, Bluetooth, bocinas)
 * y cambia automáticamente al perfil de EQ guardado para ese dispositivo.
 *
 * FIX de la v1.8.2: el EqualizerActivity tenía la lógica de perfiles pero
 * NO había ningún BroadcastReceiver que detectara la conexión/desconexión.
 * Este objeto cierra ese gap.
 *
 * Uso:
 *   AudioDeviceEqRouter.register(context)   // en MusicService.onCreate()
 *   AudioDeviceEqRouter.unregister(context) // en MusicService.onDestroy()
 */
object AudioDeviceEqRouter {

    private const val TAG = "AudioDeviceEqRouter"
    private const val PREFS = "eq_custom_presets"
    private const val KEY_AUTO_EQ = "auto_eq_switch_enabled"

    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                AudioManager.ACTION_HEADSET_PLUG -> {
                    val state = intent.getIntExtra("state", -1)
                    val microphone = intent.getIntExtra("microphone", 0)
                    if (state == 1) {
                        // Auriculares conectados (con o sin micrófono)
                        Log.d(TAG, "Auriculares conectados (mic=$microphone)")
                        applyProfileForDevice(ctx, DeviceType.HEADPHONES)
                    } else if (state == 0) {
                        // Desconectados → volver a bocinas
                        Log.d(TAG, "Auriculares desconectados")
                        applyProfileForDevice(ctx, DeviceType.SPEAKERS)
                    }
                }
                android.bluetooth.BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(
                        android.bluetooth.BluetoothProfile.EXTRA_STATE, -1)
                    when (state) {
                        BluetoothProfile.STATE_CONNECTED    -> {
                            Log.d(TAG, "Bluetooth audio conectado")
                            applyProfileForDevice(ctx, DeviceType.BLUETOOTH)
                        }
                        BluetoothProfile.STATE_DISCONNECTED -> {
                            Log.d(TAG, "Bluetooth audio desconectado")
                            // Si hay auriculares físicos conectados, volver a HEADPHONES
                            val type = currentWiredDevice(ctx)
                            applyProfileForDevice(ctx, type)
                        }
                    }
                }
            }
        }
    }

    enum class DeviceType(val profileName: String) {
        SPEAKERS("Bocinas"),
        HEADPHONES("Auriculares"),
        BLUETOOTH("Bluetooth"),
        HIFI_DAC("Hi-Fi DAC"),
        GENERAL("General")
    }

    fun register(ctx: Context) {
        if (registered) return
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_AUTO_EQ, true)) return  // usuario desactivó auto-switch

        val filter = IntentFilter().apply {
            addAction(AudioManager.ACTION_HEADSET_PLUG)
            addAction(android.bluetooth.BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
        }
        ctx.registerReceiver(receiver, filter)
        registered = true
        Log.d(TAG, "AudioDeviceEqRouter registrado")

        // Aplicar perfil inmediatamente según el estado actual
        applyProfileForDevice(ctx, currentWiredDevice(ctx))
    }

    fun unregister(ctx: Context) {
        if (!registered) return
        runCatching { ctx.unregisterReceiver(receiver) }
        registered = false
    }

    /** Detecta qué dispositivo de audio hay conectado AHORA mismo. */
    fun currentWiredDevice(ctx: Context): DeviceType {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val hasHeadphones = devices.any {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            val hasBluetooth = devices.any {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
            }
            val hasUsb = devices.any {
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                it.type == AudioDeviceInfo.TYPE_USB_ACCESSORY
            }
            return when {
                hasUsb        -> DeviceType.HIFI_DAC
                hasHeadphones -> DeviceType.HEADPHONES
                hasBluetooth  -> DeviceType.BLUETOOTH
                else          -> DeviceType.SPEAKERS
            }
        } else {
            // Fallback Android < 6
            @Suppress("DEPRECATION")
            return if (am.isWiredHeadsetOn) DeviceType.HEADPHONES
                   else if (am.isBluetoothA2dpOn) DeviceType.BLUETOOTH
                   else DeviceType.SPEAKERS
        }
    }

    private fun applyProfileForDevice(ctx: Context, device: DeviceType) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_AUTO_EQ, true)) return

        val profileName = device.profileName
        val savedLevels = prefs.getString("eq_band_levels_$profileName", null)

        if (savedLevels == null) {
            Log.d(TAG, "Sin perfil guardado para '$profileName', aplicando General")
            val general = prefs.getString("eq_band_levels_General", null)
            if (general != null) applyLevelsString(ctx, general, "General")
            return
        }
        applyLevelsString(ctx, savedLevels, profileName)
    }

    /**
     * Aplica los niveles de EQ al ecualizador activo.
     * Como el Equalizer de android.media.audiofx no es thread-safe y puede
     * estar siendo usado por EqualizerActivity, lo aplicamos con try/catch.
     */
    private fun applyLevelsString(ctx: Context, levelsStr: String, profileName: String) {
        val levels = levelsStr.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (levels.isEmpty()) return

        val sessionId = MusicService.audioSessionId
        if (sessionId == 0) {
            Log.d(TAG, "No hay sesión de audio activa, guardando perfil '$profileName' para aplicar después")
            // Guardar como "pending profile" — se aplicará cuando el EQ abra
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("eq_pending_profile", profileName).apply()
            return
        }

        runCatching {
            val eq = android.media.audiofx.Equalizer(0, sessionId)
            val nBands = eq.numberOfBands.toInt()
            levels.forEachIndexed { i, level ->
                val hwBand = ((i.toFloat() / levels.size.coerceAtLeast(1)) * nBands)
                    .toInt().coerceIn(0, nBands - 1).toShort()
                eq.setBandLevel(hwBand, level.toShort())
            }
            eq.enabled = true
            eq.release()
            Log.d(TAG, "Perfil '$profileName' aplicado: ${levels.size} bandas")
        }.onFailure {
            Log.w(TAG, "Error aplicando perfil EQ: ${it.message}")
        }

        // Actualizar la preferencia de perfil activo para que EqualizerActivity
        // lo muestre correctamente cuando el usuario lo abra
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("eq_profile", profileName)
            .remove("eq_pending_profile")
            .apply()
    }

    /** Comprueba si hay un perfil pendiente y lo aplica (llamar desde EqualizerActivity.onResume). */
    fun applyPendingProfileIfAny(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pending = prefs.getString("eq_pending_profile", null) ?: return
        val levels = prefs.getString("eq_band_levels_$pending", null) ?: return
        applyLevelsString(ctx, levels, pending)
    }

    /** Devuelve el perfil que debería estar activo según el hardware conectado. */
    fun getSuggestedProfileName(ctx: Context): String = currentWiredDevice(ctx).profileName

    /** Habilitar/deshabilitar el switch automático desde Settings. */
    fun setAutoSwitchEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_EQ, enabled).apply()
        if (enabled) register(ctx) else unregister(ctx)
    }

    fun isAutoSwitchEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_EQ, true)
}
