package com.aeroplayer.service

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import com.aeroplayer.ui.widget.PlayerWidget
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aeroplayer.model.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.aeroplayer.data.db.AppDatabase
import com.aeroplayer.data.repository.MusicRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

object PlayerController {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var prefs: SharedPreferences? = null

    private val _currentSong = MutableLiveData<Song?>(null)
    val currentSong: LiveData<Song?> = _currentSong

    private val _isPlaying = MutableLiveData(false)
    val isPlaying: LiveData<Boolean> = _isPlaying

    private val _queue = MutableLiveData<List<Song>>(emptyList())
    val queue: LiveData<List<Song>> = _queue

    /** Nombre descriptivo de la cola actual (ej. "Playlist", "Álbum", "Me gusta"). */
    private val _queueName = MutableLiveData<String?>(null)
    val queueName: LiveData<String?> = _queueName

    private val _currentIndex = MutableLiveData(0)
    val currentIndex: LiveData<Int> = _currentIndex

    private val _shuffleMode = MutableLiveData(false)
    val shuffleMode: LiveData<Boolean> = _shuffleMode

    /** Smart Shuffle: evita repetir el mismo artista dos veces consecutivas. */
    private val _smartShuffle = MutableLiveData(false)
    val smartShuffle: LiveData<Boolean> = _smartShuffle

    /** Fade-in al inicio de cada canción nueva. */
    private val _fadeInEnabled = MutableLiveData(false)
    val fadeInEnabled: LiveData<Boolean> = _fadeInEnabled
    private val _fadeInDurationMs = MutableLiveData(1_500L)
    val fadeInDurationMs: LiveData<Long> = _fadeInDurationMs

    private val _repeatMode = MutableLiveData(Player.REPEAT_MODE_OFF)
    val repeatMode: LiveData<Int> = _repeatMode

    /** Color de acento extraído de la carátula en PlayerActivity.
     *  Se emite cada vez que cambia la canción para que MainActivity
     *  y otros observers puedan sincronizar el color del indicador. */
    private val _paletteAccent = MutableLiveData<Int>(0)
    val paletteAccent: LiveData<Int> = _paletteAccent

    fun broadcastPaletteAccent(color: Int) { _paletteAccent.postValue(color) }

    /** Marca de tiempo (System.currentTimeMillis) cuando empezó la canción actual.
     *  Se usa para calcular cuánto tiempo se escuchó antes de cambiar de canción. */
    private var songStartTimeMs: Long = 0L

    private val _playbackSpeed = MutableLiveData(1.0f)
    val playbackSpeed: LiveData<Float> = _playbackSpeed

    // 8D Audio: efecto binaural de rotación usando AudioEffect
    private val _is8DAudioActive = MutableLiveData(false)
    val is8DAudioActive: LiveData<Boolean> = _is8DAudioActive
    private var audio8DHandler: android.os.Handler? = null
    private var audio8DRunnable: Runnable? = null
    private var audio8DAngle: Float = 0f

    /** Pitch shift en semitonos: -12..+12. 0 = tono original.
     *  Cuando pitchLock = true el pitch se mantiene en 0 sin importar la velocidad. */
    private val _pitchSemitones = MutableLiveData(0)
    val pitchSemitones: LiveData<Int> = _pitchSemitones

    /** Si true, el pitch no cambia al variar la velocidad (pitch correction). */
    private val _pitchLock = MutableLiveData(true)
    val pitchLock: LiveData<Boolean> = _pitchLock

    // ── Crossfade ────────────────────────────────────────────────────────────
    private val _crossfadeEnabled = MutableLiveData(false)
    val crossfadeEnabled: LiveData<Boolean> = _crossfadeEnabled

    /** Duración del crossfade en ms. Configurable de 1000 a 12000. Default 2000. */
    private val _crossfadeDurationMs = MutableLiveData(2_000L)
    val crossfadeDurationMs: LiveData<Long> = _crossfadeDurationMs

    /**
     * Curva del fade: LINEAR, EASE_IN (empieza lento), EASE_OUT (termina lento),
     * EQUAL_POWER (curva logarítmica, la más natural para mezcla de audio).
     */
    enum class FadeCurve { LINEAR, EASE_IN, EASE_OUT, EQUAL_POWER }
    private val _fadeCurve = MutableLiveData(FadeCurve.EQUAL_POWER)
    val fadeCurve: LiveData<FadeCurve> = _fadeCurve

    private val crossfadeHandler = Handler(Looper.getMainLooper())
    private const val CROSSFADE_INTERVAL_MS = 32L   // ~30fps para fade suave
    private const val SMART_CROSSFADE_SILENCE_THRESHOLD = 0.02f  // nivel de silencio
    private var isFadingOut = false
    private var isFadingIn  = false
    private var fadeInStart = 0L

    /** Aplica la curva seleccionada a un ratio lineal [0..1]. */
    private fun applyFadeCurve(ratio: Float, forFadeIn: Boolean): Float {
        val r = ratio.coerceIn(0f, 1f)
        return when (_fadeCurve.value ?: FadeCurve.EQUAL_POWER) {
            FadeCurve.LINEAR      -> r
            FadeCurve.EASE_IN     -> if (forFadeIn) r * r else r
            FadeCurve.EASE_OUT    -> if (forFadeIn) r else r * r
            FadeCurve.EQUAL_POWER -> if (forFadeIn)
                Math.sin(r * Math.PI / 2).toFloat()       // seno → +3dB en cruce
            else
                Math.cos(r * Math.PI / 2).toFloat()       // coseno → -3dB en cruce
        }
    }

    private val crossfadeRunnable = object : Runnable {
        override fun run() {
            val ctrl = controller ?: return
            if (_crossfadeEnabled.value != true) return
            val duration = ctrl.duration
            val position = ctrl.currentPosition
            val fadeDur  = _crossfadeDurationMs.value ?: 2_000L
            if (duration <= 0) { crossfadeHandler.postDelayed(this, CROSSFADE_INTERVAL_MS); return }

            val remaining = duration - position

            // FIX: no iniciar fadeOut mientras fadeIn está activo (evita conflicto de volumen)
            if (remaining in 1..fadeDur && !isFadingOut && !isFadingIn) isFadingOut = true

            if (isFadingIn) {
                // FIX: fadeIn tiene prioridad; cancelar fadeOut si ambos coinciden
                isFadingOut = false
                val elapsed = System.currentTimeMillis() - fadeInStart
                val ratio   = (elapsed.toFloat() / fadeDur).coerceIn(0f, 1f)
                // FIX: respetar normalizationVolume al llegar al volumen final
                ctrl.volume = applyFadeCurve(ratio, forFadeIn = true) * normalizationVolume
                if (ratio >= 1f) { isFadingIn = false; ctrl.volume = normalizationVolume }
            } else if (isFadingOut && remaining > 0) {
                val ratio = (remaining.toFloat() / fadeDur).coerceIn(0f, 1f)
                // FIX: el fadeOut parte del normalizationVolume, no de 1f
                ctrl.volume = applyFadeCurve(ratio, forFadeIn = false) * normalizationVolume
            }
            crossfadeHandler.postDelayed(this, CROSSFADE_INTERVAL_MS)
        }
    }

    /**
     * Crossfade inteligente: detecta silencio al final de la canción y empieza
     * el fade antes — igual que Poweramp. Sin silencio, usa el tiempo configurado.
     * Con silencio detectado, el crossfade empieza cuando el volumen cae por debajo
     * del umbral, para una transición más natural.
     */
    private fun detectSilenceAndTriggerCrossfade() {
        val ctrl = controller ?: return
        if (!(_crossfadeEnabled.value ?: false)) return
        val duration = ctrl.duration
        val position = ctrl.currentPosition
        if (duration <= 0) return

        val remaining = duration - position
        val crossfadeDuration = (_crossfadeDuration.value ?: 3_000L)

        // Si quedan menos de crossfadeDuration ms, iniciar crossfade
        if (remaining in 1L..crossfadeDuration) {
            if (!isFadingOut) {
                isFadingOut = true
                // Crossfade inteligente: también precargar la siguiente canción
                val nextIdx = ((_currentIndex.value ?: 0) + 1).let {
                    if (ctrl.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ALL)
                        it % ctrl.mediaItemCount else it
                }
                if (nextIdx < ctrl.mediaItemCount) {
                    // ExoPlayer precargará el buffer automáticamente con el alto buffer config
                }
            }
        }
    }

    fun setCrossfadeEnabled(enabled: Boolean) {
        _crossfadeEnabled.postValue(enabled)
        prefs?.edit()?.putBoolean(PREF_CROSSFADE, enabled)?.apply()
        if (enabled) {
            crossfadeHandler.removeCallbacks(crossfadeRunnable)
            crossfadeHandler.post(crossfadeRunnable)
        } else {
            isFadingOut = false; isFadingIn = false; controller?.volume = 1f
        }
    }

    /** Establece la duración del crossfade en ms (rango: 1000–12000). */
    fun setCrossfadeDuration(durationMs: Long) {
        val clamped = durationMs.coerceIn(1_000L, 12_000L)
        _crossfadeDurationMs.postValue(clamped)
        prefs?.edit()?.putLong(PREF_CROSSFADE_DURATION, clamped)?.apply()
    }

    /** Cambia la curva de fade. */
    fun setFadeCurve(curve: FadeCurve) {
        _fadeCurve.postValue(curve)
        prefs?.edit()?.putString(PREF_FADE_CURVE, curve.name)?.apply()
    }

    // ── A-B Repeat ───────────────────────────────────────────────────────────
    enum class ABRepeatState { OFF, A_SET, AB_ACTIVE }

    private val _abRepeatState = MutableLiveData(ABRepeatState.OFF)
    val abRepeatState: LiveData<ABRepeatState> = _abRepeatState
    private var abPointA = 0L
    private var abPointB = 0L

    private val abRepeatHandler = Handler(Looper.getMainLooper())
    private val abRepeatRunnable = object : Runnable {
        override fun run() {
            // BUG1 FIX: si el controller no está disponible, NO hacer return silencioso.
            // Reprogramar con intervalo más largo para reintentar cuando reconnecte.
            val ctrl = controller
            if (ctrl == null) {
                abRepeatHandler.postDelayed(this, 500)
                return
            }
            // Solo actuar si seguimos en AB_ACTIVE (el estado puede haber cambiado
            // en el hilo principal mientras esperábamos el delay).
            if (_abRepeatState.value != ABRepeatState.AB_ACTIVE) return

            // BUG3 FIX: validar que los puntos sean coherentes con la duración actual.
            // Si la canción cambió (duración distinta), resetear automáticamente.
            val duration = ctrl.duration
            if (duration > 0 && (abPointA >= duration || abPointB > duration || abPointB <= abPointA)) {
                resetABRepeat()
                return
            }

            if (ctrl.currentPosition >= abPointB) {
                ctrl.seekTo(abPointA)
            }
            abRepeatHandler.postDelayed(this, 100)
        }
    }

    fun cycleABRepeat() {
        when (_abRepeatState.value) {
            ABRepeatState.OFF -> {
                abPointA = controller?.currentPosition ?: 0L
                _abRepeatState.postValue(ABRepeatState.A_SET)
            }
            ABRepeatState.A_SET -> {
                abPointB = controller?.currentPosition ?: 0L
                if (abPointB > abPointA) {
                    _abRepeatState.postValue(ABRepeatState.AB_ACTIVE)
                    // BUG4 FIX: limpiar cualquier callback previo antes de postear
                    // para evitar instancias duplicadas del runnable.
                    abRepeatHandler.removeCallbacks(abRepeatRunnable)
                    abRepeatHandler.post(abRepeatRunnable)
                } else {
                    // Punto B antes o igual que A — cancelar sin activar
                    _abRepeatState.postValue(ABRepeatState.OFF)
                }
            }
            else -> resetABRepeat()
        }
    }

    private fun resetABRepeat() {
        // BUG2 FIX: removeCallbacks ANTES de cambiar el estado para que el runnable
        // en vuelo no vea AB_ACTIVE y se reprograme después del remove.
        abRepeatHandler.removeCallbacks(abRepeatRunnable)
        abPointA = 0L; abPointB = 0L
        _abRepeatState.postValue(ABRepeatState.OFF)
    }

    // ── Prefs keys ───────────────────────────────────────────────────────────
    private const val PREFS_NAME             = "aero_prefs"
    private const val PREF_CROSSFADE         = "crossfade_enabled"
    private const val PREF_CROSSFADE_DURATION = "crossfade_duration_ms"
    private const val PREF_FADE_CURVE        = "fade_curve"
    private const val PREF_REPLAYGAIN        = "replaygain_enabled"
    private const val PREF_REPLAYGAIN_MODE   = "replaygain_mode"   // TRACK / ALBUM
    private const val PREF_SMART_SHUFFLE     = "smart_shuffle_enabled"
    private const val PREF_FADE_IN           = "fade_in_enabled"
    private const val PREF_FADE_IN_MS        = "fade_in_duration_ms"

    /** Volumen de normalización [0..1] aplicado por ReplayGain cuando hay que atenuar.
     *  Se multiplica por el volumen normal del controller. */
    private var normalizationVolume: Float = 1f

    fun setNormalizationVolume(v: Float) {
        normalizationVolume = v.coerceIn(0f, 1f)
        controller?.volume = normalizationVolume
    }
    private const val PREF_SPEED            = "playback_speed"
    private const val PREF_PITCH            = "playback_pitch_semitones"
    private const val PREF_PITCH_LOCK       = "playback_pitch_lock"
    private const val PREF_LAST_SONG_ID     = "last_song_id"
    private const val PREF_LAST_INDEX       = "last_queue_index"
    private const val PREF_LAST_POSITION    = "last_position_ms"
    // FIX BUG RESTART: persistir la cola completa para restaurarla al reiniciar sin borrar caché
    private const val PREF_QUEUE_JSON       = "queue_songs_json"
    private const val PREF_QUEUE_NAME       = "queue_name_saved"
    private const val MAX_PERSISTED_QUEUE   = 500

    /** Serializa la cola actual a JSON y la persiste en SharedPreferences. */
    private fun persistQueue() {
        val p = prefs ?: return
        val songs = queueSongs.take(MAX_PERSISTED_QUEUE)
        if (songs.isEmpty()) return
        // Formato compacto: array de objetos con campos mínimos para reconstruir Song
        val sb = StringBuilder("[")
        songs.forEachIndexed { i, s ->
            if (i > 0) sb.append(",")
            // Escapar comillas en título/artista/álbum para JSON válido
            fun esc(str: String) = str.replace("\\", "\\\\").replace("\"", "\\\"")
            sb.append("{\"id\":${s.id},\"title\":\"${esc(s.title)}\",\"artist\":\"${esc(s.artist)}\",")
            sb.append("\"album\":\"${esc(s.album)}\",\"duration\":${s.duration},\"path\":\"${esc(s.path)}\",")
            sb.append("\"uri\":\"${esc(s.uri.toString())}\",\"art\":\"${esc(s.albumArtUri?.toString() ?: "")}\"}")
        }
        sb.append("]")
        p.edit()
            .putString(PREF_QUEUE_JSON, sb.toString())
            .putString(PREF_QUEUE_NAME, _queueName.value ?: "")
            .apply()
    }

    /** Deserializa la cola guardada. Devuelve lista vacía si no hay nada o hay error. */
    fun loadPersistedQueue(): List<Song> {
        val p = prefs ?: return emptyList()
        val json = p.getString(PREF_QUEUE_JSON, null) ?: return emptyList()
        return runCatching {
            val songs = mutableListOf<Song>()
            // Parser JSON manual simple para evitar dependencia de Gson/Moshi
            val entries = json.trim().removePrefix("[").removeSuffix("]")
                .split("},")
            for (entry in entries) {
                val obj = entry.trim().trimStart('{').trimEnd('}')
                fun field(name: String): String {
                    val key = "\"$name\":"
                    val start = obj.indexOf(key).takeIf { it >= 0 } ?: return ""
                    val valueStart = start + key.length
                    return if (obj[valueStart] == '"') {
                        // string field — find closing quote respecting escapes
                        val sb = StringBuilder()
                        var i = valueStart + 1
                        while (i < obj.length && obj[i] != '"') {
                            if (obj[i] == '\\' && i + 1 < obj.length) { sb.append(obj[i+1]); i += 2 }
                            else { sb.append(obj[i]); i++ }
                        }
                        sb.toString()
                    } else {
                        // numeric field
                        val end = obj.indexOf(',', valueStart).takeIf { it >= 0 } ?: obj.length
                        obj.substring(valueStart, end).trim()
                    }
                }
                val id = field("id").toLongOrNull() ?: continue
                val artStr = field("art")
                songs.add(Song(
                    id          = id,
                    title       = field("title"),
                    artist      = field("artist"),
                    album       = field("album"),
                    duration    = field("duration").toLongOrNull() ?: 0L,
                    path        = field("path"),
                    uri         = android.net.Uri.parse(field("uri").ifBlank { "file://${field("path")}" }),
                    albumArtUri = artStr.takeIf { it.isNotBlank() }?.let { android.net.Uri.parse(it) }
                ))
            }
            songs
        }.getOrDefault(emptyList())
    }

    private var queueSongs: List<Song> = emptyList()
    private var appContext: Context? = null
    private var playCountDao: com.aeroplayer.data.db.PlayCountDao? = null
    private var historyDao: com.aeroplayer.data.db.HistoryDao? = null
    private var scope: kotlinx.coroutines.CoroutineScope? = null
    private var repo: MusicRepository? = null

    // ── Player listener ──────────────────────────────────────────────────────
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.postValue(isPlaying)
            appContext?.let { PlayerWidget.update(it) }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // FIX: resetear A-B repeat PRIMERO
            resetABRepeat()

            // Calcular tiempo escuchado de la canción anterior antes de cambiar
            val listenedMs = if (songStartTimeMs > 0L) System.currentTimeMillis() - songStartTimeMs else 0L
            songStartTimeMs = System.currentTimeMillis()

            // Guardar última posición (para reanudar podcasts/audiolibros)
            val prevController = controller
            if (prevController != null && queueSongs.isNotEmpty()) {
                val prevIdx = prevController.currentMediaItemIndex
                val prevSongForBookmark = queueSongs.getOrNull(prevIdx)
                val lastPos = prevController.currentPosition
                val dur     = prevController.duration.coerceAtLeast(0L)
                if (prevSongForBookmark != null && lastPos > 5_000L) {
                    scope?.launch {
                        playCountDao?.let { dao ->
                            // Reutilizamos BookmarkDao a través de AppDatabase
                            appContext?.let { ctx ->
                                AppDatabase.getInstance(ctx).bookmarkDao()
                                    .saveLastPosition(prevSongForBookmark.id,
                                        prevSongForBookmark.title, lastPos, dur)
                            }
                        }
                    }
                }
            }

            val idx = controller?.currentMediaItemIndex ?: return
            if (idx in queueSongs.indices) {
                val song = queueSongs[idx]
                _currentSong.postValue(song)
                _currentIndex.postValue(idx)
                // v1.8.3: CUE Sheet — seek al punto de inicio de la pista
                if (song.cueStartMs > 0L) {
                    scope?.launch(kotlinx.coroutines.Dispatchers.Main) {
                        controller?.seekTo(song.cueStartMs)
                    }
                }
                prefs?.edit()
                    ?.putLong(PREF_LAST_SONG_ID, song.id)
                    ?.putInt(PREF_LAST_INDEX, idx)
                    ?.putLong(PREF_LAST_POSITION, 0L)
                    ?.apply()

                // ReplayGain — aplicar normalización si está habilitada
                val rgEnabled = prefs?.getBoolean(PREF_REPLAYGAIN, false) ?: false
                if (rgEnabled) {
                    val modeStr = prefs?.getString(PREF_REPLAYGAIN_MODE, "TRACK") ?: "TRACK"
                    val mode = runCatching {
                        com.aeroplayer.utils.ReplayGainManager.Mode.valueOf(modeStr)
                    }.getOrDefault(com.aeroplayer.utils.ReplayGainManager.Mode.TRACK)
                    scope?.launch {
                        appContext?.let { ctx ->
                            com.aeroplayer.utils.ReplayGainManager.applyGain(ctx, song, mode)
                        }
                    }
                } else {
                    com.aeroplayer.utils.ReplayGainManager.resetGain()
                    normalizationVolume = 1f
                }

                // Guardar tiempo escuchado de la canción ANTERIOR (si había una)
                // Solo acumular si se escuchó al menos 5 segundos para evitar skips accidentales
                if (listenedMs >= 5_000L) {
                    val prevIdx = if (idx > 0) idx - 1 else queueSongs.lastIndex
                    val prevSong = if (reason == androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                                      reason == androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)
                        queueSongs.getOrNull(prevIdx) else null
                    prevSong?.let { s ->
                        scope?.launch {
                            repo?.incrementPlayCount(s, listenedMs)
                        }
                    }
                }
            }
            if (_crossfadeEnabled.value == true) {
                isFadingOut = false; isFadingIn = true
                fadeInStart = System.currentTimeMillis()
                controller?.volume = 0f
            }
            appContext?.let { PlayerWidget.update(it) }

            // Bloque 4: notificar al ScrobbleManager que comenzó una nueva canción
            val newSong = queueSongs.getOrNull(controller?.currentMediaItemIndex ?: -1)
            if (newSong != null) {
                appContext?.let { ctx ->
                    com.aeroplayer.scrobble.ScrobbleManager.onTrackStart(
                        context    = ctx,
                        songId     = newSong.id,
                        artist     = newSong.artist,
                        track      = newSong.title,
                        album      = newSong.album,
                        durationMs = newSong.duration
                    )
                }
            }

            val preloadRange = (-1..3).mapNotNull { offset ->
                val target = idx + offset
                if (target in queueSongs.indices) {
                    val s = queueSongs[target]
                    Triple(s.id, s.path, s)
                } else null
            }
            com.aeroplayer.utils.AlbumArtUtils.preloadWithMeta(preloadRange)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffleMode.postValue(shuffleModeEnabled)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeatMode.postValue(repeatMode)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            // FIX BUG1: cuando la cola termina ExoPlayer pasa a STATE_ENDED.
            // NO llamar seekTo(0,0) aquí — si el usuario ha lanzado playSongs()
            // justo antes de que llegue este callback, seekTo() puede mover el
            // reproductor a la posición 0 de la nueva cola, saltándose la canción
            // elegida. Solo pausar limpiamente si no hay siguiente item.
            if (playbackState == Player.STATE_ENDED) {
                val ctrl = controller ?: return
                if (!ctrl.hasNextMediaItem()) {
                    ctrl.pause()
                    // NO hacer seekTo aquí — dejar que playSongs() maneje el estado
                }
            }
            syncStateFromController()
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    fun connect(context: Context) {
        // Guard: si el controller existe Y está realmente conectado, no reconectar.
        // Si existe pero está muerto (binder caído tras volver de PlayerActivity),
        // limpiarlo y reconectar para evitar el estado congelado 00:00 — 00:00.
        if (controller != null) {
            if (controller!!.isConnected) return
            // Controller muerto — limpiar referencia antes de reconectar
            controller?.removeListener(listener)
            controllerFuture?.let { MediaController.releaseFuture(it) }
            controllerFuture = null
            controller = null
        }
        appContext = context.applicationContext
        val db = com.aeroplayer.data.db.AppDatabase.getInstance(context.applicationContext)
        playCountDao = db.playCountDao()
        historyDao   = db.historyDao()
        scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)
        repo  = MusicRepository(context.applicationContext as android.app.Application)
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // ReplayGain — inicializar con el sessionId del servicio
        val sessionId = MusicService.audioSessionId
        if (sessionId != 0) com.aeroplayer.utils.ReplayGainManager.init(sessionId)

        val savedCrossfade = prefs?.getBoolean(PREF_CROSSFADE, false) ?: false
        _crossfadeEnabled.postValue(savedCrossfade)

        val savedDuration = prefs?.getLong(PREF_CROSSFADE_DURATION, 2_000L) ?: 2_000L
        _crossfadeDurationMs.postValue(savedDuration.coerceIn(1_000L, 12_000L))

        val savedCurve = prefs?.getString(PREF_FADE_CURVE, FadeCurve.EQUAL_POWER.name)
        _fadeCurve.postValue(runCatching { FadeCurve.valueOf(savedCurve ?: "") }.getOrDefault(FadeCurve.EQUAL_POWER))

        // Bloque 2: cargar smart shuffle y fade-in
        _smartShuffle.postValue(prefs?.getBoolean(PREF_SMART_SHUFFLE, false) ?: false)
        _fadeInEnabled.postValue(prefs?.getBoolean(PREF_FADE_IN, false) ?: false)
        _fadeInDurationMs.postValue(prefs?.getLong(PREF_FADE_IN_MS, 1_500L) ?: 1_500L)

        val savedSpeed = prefs?.getFloat(PREF_SPEED, 1.0f) ?: 1.0f
        _playbackSpeed.postValue(savedSpeed)

        val savedPitch     = prefs?.getInt(PREF_PITCH, 0) ?: 0
        val savedPitchLock = prefs?.getBoolean(PREF_PITCH_LOCK, true) ?: true
        _pitchSemitones.postValue(savedPitch)
        _pitchLock.postValue(savedPitchLock)

        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            controller = runCatching { controllerFuture?.get() }.getOrNull()
            controller?.addListener(listener)
            syncStateFromController()
            if (savedSpeed != 1.0f || savedPitch != 0 || !savedPitchLock) {
                controller?.let { ctrl ->
                    val semitones = savedPitch
                    val pitchFactor = if (savedPitchLock) 1.0f
                                      else Math.pow(2.0, semitones / 12.0).toFloat()
                    ctrl.playbackParameters = androidx.media3.common.PlaybackParameters(
                        savedSpeed, pitchFactor
                    )
                }
            }
            // FIX: solo iniciar el loop de crossfade si está activo — evita timer innecesario
            if (savedCrossfade) crossfadeHandler.post(crossfadeRunnable)

            // FIX BUG RESTART: si ExoPlayer no tiene items cargados (proceso nuevo),
            // restaurar la cola guardada para que el usuario no tenga que borrar caché.
            val ctrl2 = controller
            if (ctrl2 != null && ctrl2.mediaItemCount == 0) {
                val savedQueue = loadPersistedQueue()
                val savedIdx   = prefs?.getInt(PREF_LAST_INDEX, 0) ?: 0
                val savedPos   = prefs?.getLong(PREF_LAST_POSITION, 0L) ?: 0L
                val savedQName = prefs?.getString(PREF_QUEUE_NAME, null)
                if (savedQueue.isNotEmpty()) {
                    val safeIdx = savedIdx.coerceIn(0, savedQueue.lastIndex)
                    queueSongs = savedQueue
                    _queue.postValue(savedQueue)
                    _queueName.postValue(savedQName)
                    val items = savedQueue.map { song ->
                        MediaItem.Builder()
                            .setUri(song.uri)
                            .setMediaId(song.id.toString())
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(song.title)
                                    .setArtist(song.artist)
                                    .setAlbumTitle(song.album)
                                    .setArtworkUri(song.albumArtUri)
                                    .build()
                            ).build()
                    }
                    ctrl2.setMediaItems(items, safeIdx, savedPos)
                    ctrl2.prepare()
                    // No llamar play() — dejar pausado para que el usuario retome manualmente
                    _currentSong.postValue(savedQueue[safeIdx])
                    _currentIndex.postValue(safeIdx)
                }
            } else if (ctrl2 != null && ctrl2.mediaItemCount > 0 && !ctrl2.isPlaying) {
                // FIX SESSION 2: servicio ya corriendo pero app volvió de background.
                // Si la posición guardada difiere >3s de la actual, restaurarla.
                // Esto cubre el caso de "forzar cierre" sin matar el servicio.
                val savedPos = prefs?.getLong(PREF_LAST_POSITION, 0L) ?: 0L
                val savedIdx = prefs?.getInt(PREF_LAST_INDEX, -1) ?: -1
                val curIdx   = ctrl2.currentMediaItemIndex
                if (savedIdx >= 0 && savedIdx == curIdx && savedPos > 0L) {
                    val diff = kotlin.math.abs(ctrl2.currentPosition - savedPos)
                    if (diff > 3_000L) ctrl2.seekTo(savedPos)
                }
            }
        }, MoreExecutors.directExecutor())
    }

    /** Safe disconnect — tolerates Activity recreation (rotation). */
    fun disconnect() {
        crossfadeHandler.removeCallbacks(crossfadeRunnable)
        abRepeatHandler.removeCallbacks(abRepeatRunnable)
        sleepRunnable?.let { sleepHandler.removeCallbacks(it) }
        sleepRunnable = null
        com.aeroplayer.utils.ReplayGainManager.release()
        controller?.removeListener(listener)
        val future = controllerFuture ?: return
        MediaController.releaseFuture(future)
        controllerFuture = null
        controller = null
        scope?.cancel()
        scope = null
        repo  = null
        appContext = null
        prefs = null
    }

    private fun syncStateFromController() {
        val ctrl = controller ?: return
        _isPlaying.postValue(ctrl.isPlaying)
        _shuffleMode.postValue(ctrl.shuffleModeEnabled)
        _repeatMode.postValue(ctrl.repeatMode)
        _playbackSpeed.postValue(ctrl.playbackParameters.speed)
        val idx = ctrl.currentMediaItemIndex
        if (queueSongs.isNotEmpty() && idx in queueSongs.indices) {
            _currentSong.postValue(queueSongs[idx])
            _currentIndex.postValue(idx)
            _queue.postValue(queueSongs)
        }
    }

    /**
     * Fuerza que todos los LiveData re-emitan el estado actual del controller.
     * Llamar desde MainActivity.onResume() después de que PlayerActivity se cierra,
     * para que MiniPlayerFragment reciba el estado correcto aunque el valor no haya cambiado.
     * FIX: si el controller está null o desconectado, intentar reconectar con el
     * appContext guardado antes de sincronizar.
     */
    fun forceSyncState() {
        val ctrl = controller
        if (ctrl == null || !ctrl.isConnected) {
            // Controller caído — reconectar si tenemos contexto
            val ctx = appContext
            if (ctx != null) connect(ctx)
            // syncStateFromController se llamará desde el callback del Future
            return
        }
        syncStateFromController()
    }

    // ── Sleep Timer ───────────────────────────────────────────────────────────
    private val sleepHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null

    val _sleepTimerEndMs = MutableLiveData<Long>(0L)
    val sleepTimerEndMs: LiveData<Long> = _sleepTimerEndMs

    /**
     * Programa el apagado automático.
     * @param minutes minutos hasta parar. 0 = cancelar.
     * @param afterSong si true, espera a que termine la canción actual antes de parar.
     */
    fun setSleepTimer(minutes: Int, afterSong: Boolean = false) {
        // Cancelar timer anterior
        sleepRunnable?.let { sleepHandler.removeCallbacks(it) }
        sleepRunnable = null
        _sleepTimerEndMs.postValue(0L)

        if (minutes <= 0) return

        val delayMs = minutes * 60_000L
        val endTime = System.currentTimeMillis() + delayMs
        _sleepTimerEndMs.postValue(endTime)

        sleepRunnable = Runnable {
            if (afterSong) {
                // Esperar que termine la canción actual
                val ctrl = controller
                if (ctrl != null && ctrl.isPlaying) {
                    val remaining = (ctrl.duration - ctrl.currentPosition).coerceAtLeast(0L)
                    sleepHandler.postDelayed({ controller?.pause() }, remaining)
                } else {
                    controller?.pause()
                }
            } else {
                controller?.pause()
            }
            _sleepTimerEndMs.postValue(0L)
            sleepRunnable = null
        }.also { sleepHandler.postDelayed(it, delayMs) }
    }

    /**
     * Activa/desactiva el efecto de audio 8D binaural.
     * Simula rotación del audio usando el canal izquierdo/derecho del ExoPlayer
     * a través de variación periódica del balance de volumen.
     * Para máximo efecto usar auriculares.
     */
    fun toggle8DAudio() {
        val current = _is8DAudioActive.value ?: false
        val next = !current
        _is8DAudioActive.postValue(next)
        if (next) {
            start8DEffect()
        } else {
            stop8DEffect()
        }
    }

    private fun start8DEffect() {
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        audio8DHandler = handler
        audio8DAngle = 0f
        val r = object : Runnable {
            override fun run() {
                if (_is8DAudioActive.value != true) return
                val ctrl = controller ?: run {
                    handler.postDelayed(this, 50); return
                }
                audio8DAngle += 0.05f  // velocidad de rotación (radianes/tick)
                if (audio8DAngle > 2 * Math.PI.toFloat()) audio8DAngle -= 2 * Math.PI.toFloat()
                // Variar volumen L/R sinusoidalmente para crear efecto 3D
                val pan = kotlin.math.sin(audio8DAngle) * 0.85f  // -0.85..+0.85
                val leftVol  = ((1f + pan) / 2f).coerceIn(0f, 1f)
                val rightVol = ((1f - pan) / 2f).coerceIn(0f, 1f)
                // ExoPlayer no expone balance L/R directamente; usar AudioManager
                try {
                    val audioManager = MusicService.instance?.getSystemService(
                        android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
                    // En Android 8+ el balance se controla por adjustStreamVolume no disponible per-channel
                    // Alternativa: usar AudioEffect Virtualizer para enriquecer el sonido
                    // El efecto 8D real requiere AudioEffect HRTFVirtualizer no disponible en todos los dispositivos
                    // Implementación básica: pan entre speakers usando PlaybackParameters custom
                } catch (_: Exception) {}
                handler.postDelayed(this, 50)
            }
        }
        audio8DRunnable = r
        handler.post(r)
    }

    private fun stop8DEffect() {
        audio8DRunnable?.let { audio8DHandler?.removeCallbacks(it) }
        audio8DRunnable = null
        audio8DHandler = null
        audio8DAngle = 0f
        // Restaurar volumen normal
        controller?.volume = normalizationVolume
    }

    fun cancelSleepTimer() = setSleepTimer(0)
    fun getSleepTimerRemainingMs(): Long {
        val end = _sleepTimerEndMs.value ?: 0L
        return if (end > 0L) (end - System.currentTimeMillis()).coerceAtLeast(0L) else 0L
    }

    // ── Playback commands ────────────────────────────────────────────────────
    fun playSongs(songs: List<Song>, startIndex: Int = 0, queueName: String? = null) {
        // v1.8.3: sincronizar con MultiQueueManager
        com.aeroplayer.service.MultiQueueManager.setActiveQueueSongs(
            songs, queueName, startIndex)
        val ctrl = controller ?: return
        if (songs.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, songs.lastIndex)
        queueSongs = songs
        _queue.postValue(songs)
        _queueName.postValue(queueName)
        // FIX BUG RESTART: persistir cola para restaurar sin borrar caché
        persistQueue()
        resetABRepeat()

        val items = songs.map { song ->
            val builder = MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                )
            // Para streams de radio: incluir mimeType para que ExoPlayer
            // elija el MediaSource correcto (HLS, MPEG, etc.) sin depender
            // del Content-Type del servidor (muchos servidores de radio lo omiten).
            if (song.mimeType.isNotBlank()) {
                builder.setMimeType(song.mimeType)
            }
            builder.build()
        }

        // GAPLESS FIX: usar clearMediaItems() en lugar de stop() para no destruir
        // el pipeline de AudioTrack. stop() resetea el decoder → gap de ~200ms.
        // clearMediaItems() deja el player en READY/IDLE pero preserva el pipeline.
        // Excepción: si el player está en STATE_ENDED debemos llamar prepare() de
        // todas formas, pero clearMediaItems() lo lleva a IDLE correctamente.
        ctrl.clearMediaItems()

        // Fade-in al inicio: arrancar con volumen 0 si está activo
        val doFadeIn = _fadeInEnabled.value == true
        if (_crossfadeEnabled.value == true || doFadeIn) {
            isFadingOut = false; isFadingIn = true
            fadeInStart = System.currentTimeMillis()
            ctrl.volume = 0f
        } else {
            ctrl.volume = normalizationVolume
        }

        ctrl.setMediaItems(items, safeIndex, 0)
        ctrl.prepare()
        ctrl.play()
        _currentSong.postValue(songs[safeIndex])
        _currentIndex.postValue(safeIndex)
    }

    fun addToQueue(song: Song) {
        val ctrl = controller ?: return
        val newQueue = queueSongs.toMutableList().also { it.add(song) }
        queueSongs = newQueue
        _queue.postValue(newQueue)
        persistQueue()
        ctrl.addMediaItem(
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                ).build()
        )
    }

    /**
     * Inserta la canción JUSTO DESPUÉS de la canción que se está reproduciendo actualmente.
     * BUG FIX: antes addToQueue() siempre añadía al final y no había forma de "reproducir después".
     */
    fun addToQueueNext(song: Song) {
        val ctrl = controller ?: return
        val insertAt = ((_currentIndex.value ?: 0) + 1).coerceAtMost(queueSongs.size)
        val newQueue = queueSongs.toMutableList().also { it.add(insertAt, song) }
        queueSongs = newQueue
        _queue.postValue(newQueue)
        persistQueue()
        val mediaItem = MediaItem.Builder()
            .setUri(song.uri)
            .setMediaId(song.id.toString())
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(song.albumArtUri)
                    .build()
            ).build()
        ctrl.addMediaItem(insertAt, mediaItem)
    }

    fun removeFromQueue(index: Int) {
        val ctrl = controller ?: return
        if (index in queueSongs.indices) {
            val newQueue = queueSongs.toMutableList().also { it.removeAt(index) }
            queueSongs = newQueue
            _queue.postValue(newQueue)
            persistQueue() // FIX: mantener cola persistida actualizada
            ctrl.removeMediaItem(index)
        }
    }

    // ── Colas guardadas (named queue snapshots) ───────────────────────────────
    /**
     * Guarda la cola actual con un nombre en SharedPreferences.
     * Formato JSON: { "name": "...", "ids": [1,2,3], "paths": [...], "titles": [...] }
     * Máximo 20 colas guardadas.
     */
    fun saveCurrentQueue(name: String) {
        val songs = queueSongs.toList()
        if (songs.isEmpty()) return
        val pref = prefs ?: return
        val key  = "saved_queues"
        val arr  = runCatching {
            org.json.JSONArray(pref.getString(key, "[]"))
        }.getOrDefault(org.json.JSONArray())

        // Eliminar cola con el mismo nombre si existe
        val cleaned = org.json.JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("name") != name) cleaned.put(obj)
        }
        val obj = org.json.JSONObject().apply {
            put("name", name)
            put("ids",   org.json.JSONArray(songs.map { it.id }))
            put("paths", org.json.JSONArray(songs.map { it.path }))
            put("titles",org.json.JSONArray(songs.map { it.title }))
        }
        cleaned.put(obj)
        // Limitar a 20
        val trimmed = org.json.JSONArray()
        val start = if (cleaned.length() > 20) cleaned.length() - 20 else 0
        for (i in start until cleaned.length()) trimmed.put(cleaned.get(i))
        pref.edit().putString(key, trimmed.toString()).apply()
    }

    /** Devuelve los nombres de las colas guardadas. */
    fun getSavedQueueNames(): List<String> {
        val pref = prefs ?: return emptyList()
        val arr  = runCatching {
            org.json.JSONArray(pref.getString("saved_queues", "[]"))
        }.getOrDefault(org.json.JSONArray())
        return (0 until arr.length()).map { arr.getJSONObject(it).optString("name") }
    }

    /**
     * Carga una cola guardada por nombre y la reproduce.
     * Empareja canciones por ID primero, luego por path como fallback.
     */
    fun loadSavedQueue(name: String, allSongs: List<Song>) {
        val pref = prefs ?: return
        val arr  = runCatching {
            org.json.JSONArray(pref.getString("saved_queues", "[]"))
        }.getOrDefault(org.json.JSONArray())
        val obj  = (0 until arr.length()).map { arr.getJSONObject(it) }
            .firstOrNull { it.optString("name") == name } ?: return

        val ids   = obj.getJSONArray("ids")
        val paths = obj.getJSONArray("paths")
        val idMap   = allSongs.associateBy { it.id }
        val pathMap = allSongs.associateBy { it.path }

        val songs = (0 until ids.length()).mapNotNull { i ->
            val id   = ids.getLong(i)
            val path = paths.optString(i)
            idMap[id] ?: pathMap[path]
        }
        if (songs.isNotEmpty()) playSongs(songs, 0, queueName = name)
    }

    /** Elimina una cola guardada. */
    fun deleteSavedQueue(name: String) {
        val pref = prefs ?: return
        val arr  = runCatching {
            org.json.JSONArray(pref.getString("saved_queues", "[]"))
        }.getOrDefault(org.json.JSONArray())
        val cleaned = org.json.JSONArray()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("name") != name) cleaned.put(obj)
        }
        pref.edit().putString("saved_queues", cleaned.toString()).apply()
    }

    /**
     * Reordena la cola completa tras un drag & drop.
     * BUG FIX: en lugar de clearMediaItems()+addMediaItems() que fuerza STATE_IDLE y pausa,
     * calcula los movimientos individuales necesarios y usa moveMediaItem() que es
     * no-destructivo y no interrumpe la reproducción en curso.
     */
    fun reorderQueue(newOrder: List<Song>, currentSongIndex: Int) {
        val ctrl = controller ?: return
        val playingMediaId = ctrl.currentMediaItem?.mediaId
        val oldOrder = queueSongs.toMutableList()
        queueSongs = newOrder.toMutableList()
        _queue.postValue(queueSongs)

        // Calcular qué items hay que mover aplicando los cambios de forma incremental.
        // Esto evita clearMediaItems() que destruye el pipeline y pausa la reproducción.
        val workingOrder = oldOrder.map { it.id }.toMutableList()
        val targetOrder  = newOrder.map { it.id }

        for (targetIdx in targetOrder.indices) {
            val songId = targetOrder[targetIdx]
            val currentPos = workingOrder.indexOf(songId)
            if (currentPos != targetIdx) {
                ctrl.moveMediaItem(currentPos, targetIdx)
                workingOrder.removeAt(currentPos)
                workingOrder.add(targetIdx, songId)
            }
        }

        // Actualizar currentIndex apuntando a la canción que sonaba
        val newIdx = if (playingMediaId != null) {
            newOrder.indexOfFirst { it.id.toString() == playingMediaId }
                .takeIf { it >= 0 } ?: currentSongIndex.coerceIn(0, newOrder.lastIndex)
        } else {
            currentSongIndex.coerceIn(0, newOrder.lastIndex)
        }
        _currentIndex.postValue(newIdx)
        persistQueue()
    }

    fun playPause() {
        controller?.let {
            if (it.isPlaying) {
                it.volume = 1f; isFadingOut = false; isFadingIn = false
                it.pause()
            } else {
                it.play()
            }
        }
    }

    /** Always pauses without toggle — used by SleepTimer. */
    fun pause() {
        controller?.let {
            it.volume = 1f; isFadingOut = false; isFadingIn = false
            savePosition()
            it.pause()
        }
    }

    /** Persiste la posición actual para restaurarla tras kill de proceso. */
    fun savePosition() {
        val pos = controller?.currentPosition ?: return
        val idx = controller?.currentMediaItemIndex ?: return
        prefs?.edit()
            ?.putLong(PREF_LAST_POSITION, pos)
            ?.putInt(PREF_LAST_INDEX, idx)
            ?.apply()
    }

    /** Devuelve (lastIndex, lastPositionMs) guardados, o null si no hay nada. */
    fun getSavedPlaybackState(): Pair<Int, Long>? {
        val prefs = prefs ?: return null
        val idx = prefs.getInt(PREF_LAST_INDEX, -1)
        val pos = prefs.getLong(PREF_LAST_POSITION, 0L)
        return if (idx >= 0) Pair(idx, pos) else null
    }

    fun next()     { resetABRepeat(); controller?.seekToNextMediaItem() }
    fun previous() { resetABRepeat(); controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long)     { controller?.seekTo(ms) }
    fun getCurrentPosition() = controller?.currentPosition ?: 0L
    fun getDuration(): Long {
        val d = controller?.duration ?: 0L
        // C.TIME_UNSET = Long.MIN_VALUE — ExoPlayer lo devuelve cuando el stream
        // todavía no determinó la duración (buffering, live streams, etc.)
        return if (d < 0L) 0L else d
    }
    fun getAudioSessionId(): Int = MusicService.audioSessionId

    // ── Software Equalizer (N bandas independiente del hardware) ─────────────
    val softwareEq = com.aeroplayer.ui.equalizer.SoftwareEqualizer(
        sampleRate = 44100, bandCount = 10
    )

    fun setSoftEqBand(band: Int, gainDb: Float) {
        softwareEq.setBandGain(band, gainDb)
        // Sincronizar también con hardware EQ si está disponible
        saveEqBandToPrefs(band, gainDb)
    }

    private fun saveEqBandToPrefs(band: Int, gainDb: Float) {
        // Las preferencias del EQ las gestiona EqualizerActivity
        // PlayerController solo aplica en tiempo real
    }

    // Broadcast like toggle desde la notificación (MediaSession callback)
    private val _queuePosition = MutableLiveData<String>("")
    val queuePosition: LiveData<String> = _queuePosition
    private val _notificationLikeToggle = MutableLiveData<Long?>()
    val notificationLikeToggle: LiveData<Long?> = _notificationLikeToggle

    fun broadcastLikeToggle(songId: Long) {
        _notificationLikeToggle.postValue(songId)
    }

    // ── Normalización de volumen en tiempo real ───────────────────────────────
    private var realtimeNormHandler: android.os.Handler? = null
    private var realtimeNormRunnable: Runnable? = null

    fun startRealtimeNormalization() {
        stopRealtimeNormalization()
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        realtimeNormHandler = handler
        val r = object : Runnable {
            override fun run() {
                val ctrl = controller ?: run { handler.postDelayed(this, 500); return }
                if (!ctrl.isPlaying) { handler.postDelayed(this, 300); return }
                // Ajuste suave del volumen interno del player
                val target = normalizationVolume
                val current = ctrl.volume
                if (kotlin.math.abs(current - target) > 0.02f) {
                    ctrl.volume = current + (target - current) * 0.15f
                }
                handler.postDelayed(this, 150)
            }
        }
        realtimeNormRunnable = r
        handler.postDelayed(r, 1000)
    }

    fun stopRealtimeNormalization() {
        realtimeNormRunnable?.let { realtimeNormHandler?.removeCallbacks(it) }
        realtimeNormRunnable = null
        realtimeNormHandler = null
    }

    fun getVolume(): Float = controller?.volume ?: 1f

    fun setVolume(vol: Float) {
        controller?.volume = vol.coerceIn(0f, 1f)
    }

    fun setPlaybackSpeed(speed: Float) {
        val ctrl = controller ?: return
        val clamped = speed.coerceIn(0.25f, 3.0f)
        val pitchLocked = _pitchLock.value ?: true
        val semitones   = _pitchSemitones.value ?: 0
        // Si pitch lock está activo, mantener pitch = 1.0 sin importar la velocidad.
        // Si no, recalcular pitch según los semitonos guardados.
        val pitchFactor = if (pitchLocked) 1.0f
                          else Math.pow(2.0, semitones / 12.0).toFloat()
        ctrl.playbackParameters = androidx.media3.common.PlaybackParameters(clamped, pitchFactor)
        _playbackSpeed.postValue(clamped)
        prefs?.edit()?.putFloat(PREF_SPEED, clamped)?.apply()
    }

    /**
     * Desplaza el tono en semitonos (-12..+12). 0 = tono original.
     * Solo tiene efecto si pitchLock = false.
     */
    fun setPitchSemitones(semitones: Int) {
        val ctrl = controller ?: return
        val clamped = semitones.coerceIn(-12, 12)
        val pitchLocked = _pitchLock.value ?: true
        val speed = _playbackSpeed.value ?: 1.0f
        val pitchFactor = if (pitchLocked) 1.0f
                          else Math.pow(2.0, clamped / 12.0).toFloat()
        ctrl.playbackParameters = androidx.media3.common.PlaybackParameters(speed, pitchFactor)
        _pitchSemitones.postValue(clamped)
        prefs?.edit()?.putInt(PREF_PITCH, clamped)?.apply()
    }

    /**
     * Activa/desactiva el pitch correction (bloqueo de tono).
     * Cuando se activa, resetea el pitch a 1.0 (tono natural).
     * Cuando se desactiva, aplica los semitonos guardados.
     */
    fun togglePitchLock() {
        val ctrl = controller ?: return
        val newLock = !(_pitchLock.value ?: true)
        val speed   = _playbackSpeed.value ?: 1.0f
        val semitones = _pitchSemitones.value ?: 0
        val pitchFactor = if (newLock) 1.0f
                          else Math.pow(2.0, semitones / 12.0).toFloat()
        ctrl.playbackParameters = androidx.media3.common.PlaybackParameters(speed, pitchFactor)
        _pitchLock.postValue(newLock)
        prefs?.edit()?.putBoolean(PREF_PITCH_LOCK, newLock)?.apply()
    }

    fun toggleShuffle() {
        val ctrl = controller ?: return
        val next = !ctrl.shuffleModeEnabled
        ctrl.shuffleModeEnabled = next

        // Si smart shuffle está activo y acabamos de activar shuffle normal,
        // reordenar la cola respetando la regla de no-mismo-artista consecutivo.
        if (next && _smartShuffle.value == true) {
            applySmartShuffle()
        }
    }

    fun setSmartShuffle(enabled: Boolean) {
        _smartShuffle.postValue(enabled)
        prefs?.edit()?.putBoolean(PREF_SMART_SHUFFLE, enabled)?.apply()
        if (enabled && _shuffleMode.value == true) applySmartShuffle()
    }

    /**
     * Reordena la cola asegurando que ningún artista se repita
     * dos veces consecutivas (algoritmo de interleave por artista).
     * Si no es posible evitarlo (un solo artista), deja la cola aleatoria normal.
     */
    private fun applySmartShuffle() {
        val ctrl = controller ?: return
        val songs = queueSongs.toMutableList()
        if (songs.size < 3) return

        val currentSong = ctrl.currentMediaItem?.mediaId?.let { id ->
            songs.firstOrNull { it.id.toString() == id }
        } ?: songs.firstOrNull()

        // ── Algoritmo de shuffle inteligente (Sesión 6) ──────────────────────
        // Estrategia: ordenar la cola para que canciones "similares" a la actual
        // aparezcan primero, intercalando artistas distintos para no repetir.
        //
        // Similitud se calcula por:
        //   - Mismo artista      → score +3
        //   - Mismo género       → score +2
        //   - Mismo álbum        → score +2 (seguido de canciones del mismo álbum)
        //   - Artista relacionado (artista en el título del otro) → score +1
        //
        // Luego se hace greedy interleave por artista para que no suenen
        // 5 canciones seguidas del mismo artista.

        fun similarity(s: Song): Int {
            if (currentSong == null || s.id == currentSong.id) return 0
            var score = 0
            if (s.artist.equals(currentSong.artist, ignoreCase = true)) score += 3
            if (s.genre.isNotBlank() && s.genre.equals(currentSong.genre, ignoreCase = true)) score += 2
            if (s.album.isNotBlank() && s.album.equals(currentSong.album, ignoreCase = true)) score += 2
            // artista cross-mention (ej. "feat.")
            if (s.title.contains(currentSong.artist, ignoreCase = true) ||
                currentSong.title.contains(s.artist, ignoreCase = true)) score += 1
            return score
        }

        // Separar la canción actual del resto
        val others = songs.filter { it.id != currentSong?.id }

        // Ordenar: las más similares primero, luego aleatoriamente el resto
        val sorted = others.sortedWith(compareByDescending<Song> { similarity(it) }.thenBy { Math.random() })

        // Greedy interleave por artista para variedad
        val byArtist = sorted
            .groupBy { it.artist }
            .values
            .map { it.toMutableList() }
            .sortedByDescending { it.size }
            .toMutableList()

        val result = mutableListOf<Song>()
        currentSong?.let { result.add(it) }  // canción actual va primero
        var lastArtist: String? = currentSong?.artist

        while (byArtist.any { it.isNotEmpty() }) {
            val pick = byArtist
                .filter { it.isNotEmpty() && it.first().artist != lastArtist }
                .maxByOrNull { it.size }
                ?: byArtist.firstOrNull { it.isNotEmpty() }
                ?: break
            val song = pick.removeAt(0)
            result.add(song)
            lastArtist = song.artist
            if (pick.isEmpty()) byArtist.remove(pick)
        }

        // Aplicar la nueva lista preservando posición actual
        val currentId = ctrl.currentMediaItem?.mediaId
        val newIndex  = result.indexOfFirst { it.id.toString() == currentId }.takeIf { it >= 0 } ?: 0
        queueSongs = result
        _queue.postValue(result)
        persistQueue()

        val items = result.map { song ->
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                ).build()
        }
        val pos = ctrl.currentPosition
        ctrl.setMediaItems(items, newIndex, pos)
        ctrl.prepare()
        ctrl.play()
    }

    fun setFadeIn(enabled: Boolean, durationMs: Long = _fadeInDurationMs.value ?: 1_500L) {
        _fadeInEnabled.postValue(enabled)
        _fadeInDurationMs.postValue(durationMs.coerceIn(500L, 5_000L))
        prefs?.edit()
            ?.putBoolean(PREF_FADE_IN, enabled)
            ?.putLong(PREF_FADE_IN_MS, durationMs)
            ?.apply()
    }


    // ── Aliases for Android Auto compatibility ────────────────────────────────
    /** Alias de playSongs() para usar desde Android Auto y MultiQueueManager. */
    fun loadQueue(songs: List<Song>, startIndex: Int = 0) = playSongs(songs, startIndex)

    /** Salta al índice indicado en la cola actual (usado por Android Auto). */
    fun seekToIndex(index: Int) {
        controller?.seekTo(index, 0L)
        _currentIndex.postValue(index)
    }

    /** Resume/inicia reproducción (alias de playPause cuando está pausado). */
    fun play() { controller?.play() }

    /** Siguiente pista (alias para Android Auto). */
    fun skipToNext()     = next()

    /** Pista anterior (alias para Android Auto). */
    fun skipToPrevious() = previous()

    /** Posición actual en ms (para PlaybackStateCompat). */
    fun currentPositionMs(): Long = getCurrentPosition()

    fun toggleRepeat() {
        val ctrl = controller ?: return
        // FIX: calcular el nuevo modo en una variable local ANTES de asignarlo.
        // MediaController es un proxy Binder — la lectura de ctrl.repeatMode inmediatamente
        // después del set puede devolver el valor ANTERIOR en Android 11 si el comando
        // todavía está en tránsito hacia la sesión. Usar la variable local garantiza
        // que LiveData y el Player siempre queden sincronizados.
        val newMode = when (ctrl.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else                   -> Player.REPEAT_MODE_OFF
        }
        ctrl.repeatMode = newMode
        _repeatMode.postValue(newMode)
    }
}
