package com.aeroplayer.ui.library

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class LibraryPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    override fun getItemCount() = 6

    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> FilesFragment()
        1 -> AlbumsFragment()
        2 -> ArtistsFragment()
        3 -> GenresFragment()
        4 -> LikedFragment()
        5 -> PlaylistsFragment()
        else -> FilesFragment()
    }
}
