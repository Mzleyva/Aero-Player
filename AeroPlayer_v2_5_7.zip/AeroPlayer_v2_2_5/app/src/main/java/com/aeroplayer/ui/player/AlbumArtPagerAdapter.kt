package com.aeroplayer.ui.player

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.view.LayoutInflater
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemAlbumArtPagerBinding
import com.aeroplayer.utils.AlbumArtUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Adapter para el ViewPager2 de album art en el player.
 * Sesión 8: soporte para video canvas (TextureView) + fallback a negro si batería baja.
 */
class AlbumArtPagerAdapter : RecyclerView.Adapter<AlbumArtPagerAdapter.AlbumArtViewHolder>() {

    companion object {
        const val TOTAL_PAGES = 2001
        const val CENTER_PAGE = 1000
        private const val LOW_BATTERY_THRESHOLD = 15  // %
    }

    var uriProvider:    ((offset: Int) -> Uri?)               = { null }
    var pathProvider:   ((offset: Int) -> Pair<Long, String>?) = { null }
    /** Provee (gifUri, videoUri) del canvas para la posición central. */
    var canvasProvider: (() -> Pair<Uri?, Uri?>)               = { null to null }

    // MediaPlayer reutilizable para el video canvas de la página central
    private var videoPlayer: MediaPlayer? = null
    private var lastVideoUri: Uri? = null

    inner class AlbumArtViewHolder(val b: ItemAlbumArtPagerBinding) :
        RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumArtViewHolder {
        val holder = AlbumArtViewHolder(
            ItemAlbumArtPagerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
        holder.b.ivPagerAlbumArt.clipToOutline   = true
        holder.b.ivPagerAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        holder.b.ivGifCanvas.clipToOutline       = true
        holder.b.ivGifCanvas.outlineProvider     = android.view.ViewOutlineProvider.BACKGROUND
        return holder
    }

    override fun getItemCount() = TOTAL_PAGES

    override fun onViewRecycled(holder: AlbumArtViewHolder) {
        super.onViewRecycled(holder)
        val context = holder.b.root.context
        val isDestroyed = when (context) {
            is androidx.fragment.app.FragmentActivity -> context.isDestroyed || context.isFinishing
            is android.app.Activity                  -> context.isDestroyed || context.isFinishing
            else -> false
        }
        if (isDestroyed) return
        Glide.with(holder.b.ivGifCanvas).clear(holder.b.ivGifCanvas)
        holder.b.ivGifCanvas.visibility = View.GONE
        holder.b.tvVideoCanvas.visibility = View.GONE
        Glide.with(holder.b.ivPagerAlbumArt).clear(holder.b.ivPagerAlbumArt)
    }

    override fun onBindViewHolder(holder: AlbumArtViewHolder, position: Int) {
        val offset = position - CENTER_PAGE
        val artUri = uriProvider(offset)
        val (gifUri, videoUri) = if (offset == 0) canvasProvider() else null to null

        // ── Detección de batería baja (Sesión 8) ─────────────────────────────
        // Si la batería está < 15% se reemplaza el video/gif por fondo negro.
        // El usuario puede desactivar este comportamiento en Ajustes.
        val ctx = holder.b.root.context
        val isLowBattery = isBatteryLow(ctx)
        val disableLowBattery = ctx.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
            .getBoolean("canvas_ignore_low_battery", false)
        val useFallbackBlack = isLowBattery && !disableLowBattery

        // Prioridad: videoUri > gifUri > sin canvas. Si batería baja → fondo negro.
        val hasVideo  = videoUri != null && !useFallbackBlack
        val hasGif    = gifUri != null && !hasVideo && !useFallbackBlack
        val hasCanvas = hasVideo || hasGif || useFallbackBlack && (videoUri != null || gifUri != null)

        with(holder.b) {
            ivPagerAlbumArt.alpha = if (hasCanvas) 0f else 1f

            // ── Album art ────────────────────────────────────────────────────
            val songInfo = pathProvider(offset)
            val cached   = if (songInfo != null) AlbumArtUtils.getCached(songInfo.first) else null
            if (cached != null) {
                Glide.with(ivPagerAlbumArt).load(cached)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .transition(DrawableTransitionOptions.withCrossFade(150))
                    .centerCrop().into(ivPagerAlbumArt)
            } else {
                Glide.with(ivPagerAlbumArt).load(artUri)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .error(R.drawable.ic_music_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .transition(DrawableTransitionOptions.withCrossFade(150))
                    .centerCrop().into(ivPagerAlbumArt)
            }

            // ── Fondo negro por batería baja ──────────────────────────────────
            if (useFallbackBlack && (videoUri != null || gifUri != null)) {
                tvVideoCanvas.visibility = View.GONE
                ivGifCanvas.visibility   = View.GONE
                root.setBackgroundColor(android.graphics.Color.BLACK)
                return
            }
            root.setBackgroundColor(android.graphics.Color.TRANSPARENT)

            // ── Video Canvas ─────────────────────────────────────────────────
            if (hasVideo && videoUri != null) {
                ivGifCanvas.visibility   = View.GONE
                tvVideoCanvas.visibility = View.VISIBLE

                if (videoUri != lastVideoUri) {
                    lastVideoUri = videoUri
                    startVideoCanvas(tvVideoCanvas, videoUri, ctx)
                }
            } else {
                // Detener video si cambiamos a gif/nada
                if (!hasVideo) stopVideoCanvas()
                tvVideoCanvas.visibility = View.GONE
            }

            // ── GIF Canvas ────────────────────────────────────────────────────
            if (hasGif && gifUri != null) {
                ivGifCanvas.visibility = View.VISIBLE
                Glide.with(ivGifCanvas).asGif().load(gifUri)
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
                    .override(720, 720)
                    .centerCrop()
                    .error(R.drawable.ic_music_placeholder)
                    .into(ivGifCanvas)
            } else {
                Glide.with(ivGifCanvas).clear(ivGifCanvas)
                ivGifCanvas.visibility = View.GONE
            }
        }
    }

    /** Inicia (o reinicia) la reproducción del video canvas en el TextureView. */
    private fun startVideoCanvas(tv: TextureView, uri: Uri, ctx: Context) {
        stopVideoCanvas()
        val mp = MediaPlayer()
        videoPlayer = mp

        fun setupPlayer(surface: Surface) {
            runCatching {
                mp.setDataSource(ctx, uri)
                mp.setSurface(surface)
                mp.isLooping = true
                mp.setVolume(0f, 0f)  // sin sonido — es solo fondo visual
                mp.setOnPreparedListener { it.start() }
                mp.prepareAsync()
            }
        }

        if (tv.isAvailable) {
            setupPlayer(Surface(tv.surfaceTexture))
        } else {
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    setupPlayer(Surface(st))
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { stopVideoCanvas(); return true }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }
    }

    private fun stopVideoCanvas() {
        runCatching { videoPlayer?.stop(); videoPlayer?.release() }
        videoPlayer = null
    }

    /** Liberar el MediaPlayer al destruir el adapter (llamar desde PlayerActivity.onDestroy). */
    fun release() { stopVideoCanvas() }

    /** true si el nivel de batería está por debajo del umbral. */
    private fun isBatteryLow(ctx: Context): Boolean {
        val intent = ctx.registerReceiver(null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0) return false
        return (level * 100 / scale) < LOW_BATTERY_THRESHOLD
    }
}

