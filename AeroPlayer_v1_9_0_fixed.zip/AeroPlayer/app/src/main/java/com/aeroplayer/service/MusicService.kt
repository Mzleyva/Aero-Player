package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.R
import com.aeroplayer.service.AudioDeviceEqRouter

/**
 * Servicio de reproducción basado en MediaSessionService (Media3).
 *
 * v0.83 mejoras de audio:
 *  - Gapless playback real: setPreloadConfiguration + REPEAT_MODE_OFF con
 *    preloadNextMediaItem habilitado. ExoPlayer precarga el siguiente item
 *    en buffer antes de que termine el actual → transición sin silencio.
 *  - Hi-Res / Lossless: DefaultRenderersFactory con extensiones habilitadas
 *    (FLAC, ALAC, WAV 24/32bit, OPUS). TrackSelector con parámetros de audio
 *    sin restricción de bitrate para permitir formatos >16bit/>44.1kHz.
 *  - AUDIO_CONTENT_TYPE_MUSIC con USAGE_MEDIA y AudioFocus AUTO — Media3 gestiona
 *    el foco automáticamente (pausa en llamadas, baja volumen en notificaciones).
 *  - setWakeMode PARTIAL_WAKE_LOCK: mantiene reproducción con pantalla apagada
 *    sin consumir batería extra (Media3 libera el wake lock al pausar).
 */
@OptIn(UnstableApi::class)
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
    }

    override fun onCreate() {
        super.onCreate()

        // ── Audio attributes — Hi-Res compatible ─────────────────────────────
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            // ALLOW_CAPTURE_BY_NONE: evita que el sistema re-samplee el audio
            // para capturas de pantalla/accesibilidad — preserva calidad original.
            .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_NONE)
            .build()

        // ── TrackSelector sin restricción de bitrate ──────────────────────────
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxAudioBitrate(Int.MAX_VALUE)
                    .setMaxAudioChannelCount(8)
                    .setPreferredAudioMimeTypes(
                        "audio/flac",
                        "audio/alac",
                        "audio/wav",
                        "audio/x-wav",
                        "audio/vnd.wave",
                        "audio/ogg",
                        "audio/opus",
                        "audio/mpeg",
                        "audio/aac"
                    )
                    .build()
            )
        }

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink {
                return androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(VisualizerAudioProcessor.instance))
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .build()
            }
        }.apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also { exo ->
                exo.repeatMode = Player.REPEAT_MODE_OFF
            }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()

        AudioDeviceEqRouter.register(this)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        AudioDeviceEqRouter.unregister(this)
        audioSessionId = 0
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}

