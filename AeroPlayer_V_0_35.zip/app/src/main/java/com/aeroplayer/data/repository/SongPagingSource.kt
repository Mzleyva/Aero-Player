package com.aeroplayer.data.repository

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.aeroplayer.model.Song

/**
 * PagingSource que sirve páginas de [Song] desde la lista completa ya cargada
 * en memoria desde MediaStore.
 *
 * Por qué no consultar MediaStore directamente en cada página:
 * MediaStore no expone un offset/limit nativo estable — la lista completa cambia
 * de tamaño entre páginas si el usuario agrega/elimina archivos. La estrategia
 * más segura es cargar la lista una sola vez y paginar sobre ella en memoria,
 * lo que también permite ordenación arbitraria sin SQL extra.
 *
 * Para bibliotecas >5 000 canciones esto reduce el uso de RAM al cargar solo
 * [PAGE_SIZE] ítems en el RecyclerView a la vez, en lugar de la lista entera.
 *
 * @param songs Lista completa pre-cargada y ordenada desde [MusicRepository].
 */
class SongPagingSource(private val songs: List<Song>) : PagingSource<Int, Song>() {

    override fun getRefreshKey(state: PagingState<Int, Song>): Int? {
        // Mantener la posición de scroll actual al refrescar
        return state.anchorPosition?.let { anchor ->
            val page = state.closestPageToPosition(anchor)
            page?.prevKey?.plus(PAGE_SIZE) ?: page?.nextKey?.minus(PAGE_SIZE)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, Song> {
        return try {
            val startIndex = params.key ?: 0
            val endIndex   = minOf(startIndex + params.loadSize, songs.size)
            val page       = songs.subList(startIndex, endIndex)

            LoadResult.Page(
                data     = page,
                prevKey  = if (startIndex == 0) null else startIndex - params.loadSize,
                nextKey  = if (endIndex >= songs.size) null else endIndex
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    companion object {
        const val PAGE_SIZE = 60
    }
}
