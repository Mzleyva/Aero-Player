package com.aeroplayer.ui.search

import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemSearchSongBinding
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class SearchSongsAdapter(
    private val onSongClick: (Song, List<Song>) -> Unit,
    private val onLikeClick: (Song) -> Unit,
    private val onAddToQueue: (Song) -> Unit
) : ListAdapter<Song, SearchSongsAdapter.VH>(SongDiff()) {

    private var currentQuery: String = ""

    inner class VH(val b: ItemSearchSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemSearchSongBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            // Highlight matching text
            tvTitle.text = highlightQuery(song.title, currentQuery, root.context)
            tvArtist.text = highlightQuery(song.artist, currentQuery, root.context)
            tvAlbum.text = song.album

            Glide.with(ivAlbumArt)
                .load(song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivAlbumArt)

            ivLike.setImageResource(
                if (song.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            ivLike.setColorFilter(
                ContextCompat.getColor(
                    root.context,
                    if (song.isLiked) R.color.accent_pink else R.color.text_secondary
                )
            )
            ivLike.setOnClickListener { onLikeClick(song) }

            ivMore.setOnClickListener {
                MaterialAlertDialogBuilder(root.context)
                    .setTitle(song.title)
                    .setItems(arrayOf("Agregar a cola", if (song.isLiked) "Quitar de Me gusta" else "Me gusta")) { _, which ->
                        when (which) {
                            0 -> onAddToQueue(song)
                            1 -> onLikeClick(song)
                        }
                    }.show()
            }

            root.setOnClickListener { onSongClick(song, currentList) }
        }
    }

    fun setQuery(query: String) {
        currentQuery = query
        notifyDataSetChanged()
    }

    private fun highlightQuery(text: String, query: String, context: android.content.Context): SpannableString {
        val spannable = SpannableString(text)
        if (query.isBlank()) return spannable
        val lower = text.lowercase()
        val lowerQuery = query.lowercase()
        var start = lower.indexOf(lowerQuery)
        while (start >= 0) {
            spannable.setSpan(
                ForegroundColorSpan(ContextCompat.getColor(context, R.color.accent_blue)),
                start, start + query.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            start = lower.indexOf(lowerQuery, start + 1)
        }
        return spannable
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
