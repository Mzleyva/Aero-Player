package com.aeroplayer.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.aeroplayer.utils.AlbumArtUtils
import android.widget.LinearLayout
import android.view.View

/**
 * Adapter para el carrusel de selección rápida estilo YT Music.
 * Agrupa las canciones en páginas de PAGE_SIZE=4 ítems cada una.
 * Cada página es una columna vertical con 4 filas compactas.
 * El ViewPager2 se desliza horizontalmente entre páginas.
 */
class QuickPickPageAdapter(
    private val onClick:         (Song, List<Song>) -> Unit,
    private val onAddToQueue:    (Song) -> Unit,
    private val onAddToPlaylist: (Song) -> Unit,
    private val onViewArtist:    (String) -> Unit
) : RecyclerView.Adapter<QuickPickPageAdapter.PageVH>() {

    companion object {
        const val PAGE_SIZE = 4
    }

    private var songs: List<Song> = emptyList()

    fun submitList(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }

    fun getCurrentList(): List<Song> = songs

    /** Número de páginas = ceil(songs.size / PAGE_SIZE) */
    override fun getItemCount(): Int =
        if (songs.isEmpty()) 0 else (songs.size + PAGE_SIZE - 1) / PAGE_SIZE

    inner class PageVH(val container: LinearLayout) : RecyclerView.ViewHolder(container)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        val container = LinearLayout(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
        }
        return PageVH(container)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        holder.container.removeAllViews()
        val startIdx = position * PAGE_SIZE
        val endIdx   = minOf(startIdx + PAGE_SIZE, songs.size)

        for (i in startIdx until endIdx) {
            val song = songs[i]
            val rowView = LayoutInflater.from(holder.container.context)
                .inflate(R.layout.item_quick_pick_row, holder.container, false)

            // Portada
            val ivCover = rowView.findViewById<android.widget.ImageView>(R.id.ivCover)
            Glide.with(ivCover)
                .load(AlbumArtUtils.getCached(song.id) ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivCover)

            // Si no está en cache, precargar en background via AlbumArtUtils.preload().
            // No intentamos actualizar el ImageView aquí — el RecyclerView se encargará
            // de mostrar la imagen la próxima vez que este item sea visible.
            if (AlbumArtUtils.getCached(song.id) == null) {
                AlbumArtUtils.preload(listOf(Pair(song.id, song.path)))
            }

            // Texto
            rowView.findViewById<android.widget.TextView>(R.id.tvTitle).text  = song.title
            rowView.findViewById<android.widget.TextView>(R.id.tvArtist).text = song.artist

            // Click en la fila — reproducir
            rowView.setOnClickListener { onClick(song, songs) }

            // Botón 3 puntos
            rowView.findViewById<android.widget.ImageButton>(R.id.btnMore)
                .setOnClickListener { v -> showMenu(v, song) }

            holder.container.addView(rowView)
        }
    }

    private fun showMenu(anchor: View, song: Song) {
        val popup = androidx.appcompat.widget.PopupMenu(anchor.context, anchor)
        popup.menu.apply {
            add(0, 0, 0, "🎤  Ver artista")
            add(0, 1, 1, "➕  Agregar a cola")
            add(0, 2, 2, "📋  Agregar a playlist")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                0 -> { onViewArtist(song.artist); true }
                1 -> { onAddToQueue(song); true }
                2 -> { onAddToPlaylist(song); true }
                else -> false
            }
        }
        popup.show()
    }
}
