package com.aeroplayer.ui

import android.graphics.*
import android.graphics.drawable.Drawable

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║              AERO GLASS DRAWABLE                                        ║
 * ║                                                                          ║
 * ║  Drawable custom que replica el efecto "Aero Glass" de Windows Vista:   ║
 * ║                                                                          ║
 * ║  ┌─────────────────────────────────────────────────┐                    ║
 * ║  │▓▓▓▓▓▓▓▓ SPECULAR HIGHLIGHT (blanco 50%) ▓▓▓▓▓▓▓│  ← mitad superior ║
 * ║  │                                                 │                    ║
 * ║  │         Glass body (color semi-transp.)         │  ← cuerpo         ║
 * ║  │                                                 │                    ║
 * ║  └─────────────────────────────────────────────────┘                    ║
 * ║   └── borde brillante (1dp blanco 30%) ───────────┘                    ║
 * ║                                                                          ║
 * ║  USO como background de cards / bottom bar / botones:                   ║
 * ║    view.background = AeroGlassDrawable(accentColor)                     ║
 * ║                                                                          ║
 * ║  USO como background del mini player:                                    ║
 * ║    miniPlayerRoot.background = AeroGlassDrawable(                       ║
 * ║        accentColor, cornerRadius = 0f, alpha = 0.92f                    ║
 * ║    )                                                                     ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
class AeroGlassDrawable(
    private val accentColor: Int,
    private val cornerRadius: Float = 12f,
    private val glassAlpha: Float = 0.82f,  // opacidad del vidrio (0..1)
    private val showSpecular: Boolean = true // mostrar el highlight blanco superior
) : Drawable() {

    // ── Paints ────────────────────────────────────────────────────────────────

    /** Cuerpo principal del vidrio: color de acento con alpha reducida */
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    /** Specular highlight: degradado blanco en la mitad superior */
    private val specularPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    /** Borde perimetral brillante: 1dp blanco translúcido */
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = Color.argb(90, 255, 255, 255)
    }

    /** Sombra exterior suave */
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        // La sombra se dibuja como un rectángulo desplazado debajo
    }

    // ── Paths ─────────────────────────────────────────────────────────────────
    private val bodyPath    = Path()
    private val specularPath = Path()

    // ── Shaders (se crean en setBounds) ──────────────────────────────────────
    private var bodyShader: Shader? = null
    private var specularShader: Shader? = null

    // ── setBounds: aquí se crean todos los shaders según el tamaño real ───────
    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val b = bounds.toRectF()
        val r = cornerRadius

        // ── Cuerpo glass ────────────────────────────────────────────────────
        // Degradado vertical: acento oscuro arriba → acento más claro abajo
        // Simula el reflejo de luz que tenía el Aero glass en Vista
        val bodyTop    = blendWithWhite(accentColor, 0.15f, glassAlpha)
        val bodyBottom = blendWithWhite(accentColor, 0.30f, glassAlpha * 0.85f)
        bodyShader = LinearGradient(
            b.left, b.top, b.left, b.bottom,
            intArrayOf(bodyTop, bodyBottom),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        bodyPaint.shader = bodyShader

        // Path del cuerpo
        bodyPath.reset()
        bodyPath.addRoundRect(b, r, r, Path.Direction.CW)

        // ── Specular highlight ───────────────────────────────────────────────
        if (showSpecular) {
            // El highlight ocupa la mitad superior del componente
            val specularBottom = b.top + b.height() * 0.50f
            // Degradado: blanco 55% arriba → blanco 0% al 50%
            specularShader = LinearGradient(
                b.left, b.top, b.left, specularBottom,
                intArrayOf(
                    Color.argb(140, 255, 255, 255),
                    Color.argb(0,   255, 255, 255)
                ),
                floatArrayOf(0f, 1f),
                Shader.TileMode.CLAMP
            )
            specularPaint.shader = specularShader

            // El clip del specular: solo la mitad superior del RoundRect
            specularPath.reset()
            // Top half rect
            val specRect = RectF(b.left, b.top, b.right, specularBottom + r)
            specularPath.addRoundRect(specRect, r, r, Path.Direction.CW)
        }
    }

    // ── draw ─────────────────────────────────────────────────────────────────
    override fun draw(canvas: Canvas) {
        val b = bounds.toRectF()

        // 1. Cuerpo glass
        canvas.drawPath(bodyPath, bodyPaint)

        // 2. Specular highlight (mitad superior)
        if (showSpecular && specularShader != null) {
            canvas.save()
            canvas.clipPath(bodyPath)   // recortar al RoundRect del cuerpo
            canvas.drawPath(specularPath, specularPaint)
            canvas.restore()
        }

        // 3. Borde perimetral brillante
        val inset = borderPaint.strokeWidth / 2f
        val borderRect = RectF(
            b.left + inset, b.top + inset,
            b.right - inset, b.bottom - inset
        )
        canvas.drawRoundRect(borderRect, cornerRadius, cornerRadius, borderPaint)
    }

    // ── Alpha y ColorFilter (requeridos por Drawable) ─────────────────────────
    override fun setAlpha(alpha: Int) {
        bodyPaint.alpha = alpha
        specularPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        bodyPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    // ── Helper: mezcla un color con blanco y ajusta su alpha ─────────────────
    private fun blendWithWhite(color: Int, whiteFactor: Float, alpha: Float): Int {
        val r = lerp(Color.red(color),   255, whiteFactor)
        val g = lerp(Color.green(color), 255, whiteFactor)
        val b = lerp(Color.blue(color),  255, whiteFactor)
        val a = (alpha * 255).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int =
        (a + (b - a) * t).toInt().coerceIn(0, 255)
}


/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║              AERO BUTTON DRAWABLE                                       ║
 * ║                                                                          ║
 * ║  Drawable stateful para botones estilo Vista Aero:                      ║
 * ║    • Estado normal: glass azul con specular                              ║
 * ║    • Estado pressed: glass más oscuro y saturado                         ║
 * ║    • Estado disabled: glass gris desaturado                              ║
 * ║                                                                          ║
 * ║  USO:                                                                    ║
 * ║    button.background = AeroButtonDrawable(accentColor)                  ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
class AeroButtonDrawable(
    private val accentColor: Int,
    private val cornerRadius: Float = 6f
) : Drawable() {

    private var isPressed  = false
    private var isEnabled  = true

    private val normalDrawable   = AeroGlassDrawable(accentColor, cornerRadius, 0.88f)
    private val pressedDrawable  = AeroGlassDrawable(darkenColor(accentColor, 0.75f), cornerRadius, 0.95f, showSpecular = false)
    private val disabledDrawable = AeroGlassDrawable(Color.parseColor("#80909090"), cornerRadius, 0.60f, showSpecular = false)

    override fun isStateful() = true

    override fun onStateChange(state: IntArray): Boolean {
        val newPressed = android.R.attr.state_pressed in state
        val newEnabled = android.R.attr.state_enabled in state
        if (newPressed != isPressed || newEnabled != isEnabled) {
            isPressed = newPressed
            isEnabled = newEnabled
            invalidateSelf()
            return true
        }
        return false
    }

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        normalDrawable.bounds   = bounds
        pressedDrawable.bounds  = bounds
        disabledDrawable.bounds = bounds
    }

    override fun draw(canvas: Canvas) {
        when {
            !isEnabled -> disabledDrawable.draw(canvas)
            isPressed  -> pressedDrawable.draw(canvas)
            else       -> normalDrawable.draw(canvas)
        }
    }

    override fun setAlpha(alpha: Int) {
        normalDrawable.alpha   = alpha
        pressedDrawable.alpha  = alpha
        disabledDrawable.alpha = alpha
    }

    override fun setColorFilter(cf: ColorFilter?) {
        normalDrawable.colorFilter   = cf
        pressedDrawable.colorFilter  = cf
        disabledDrawable.colorFilter = cf
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT

    private fun darkenColor(color: Int, factor: Float): Int {
        val a = Color.alpha(color)
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private operator fun IntArray.contains(attr: Int) = any { it == attr }
}
