package com.aeroplayer.ui.player

import android.content.Intent
import android.app.ActivityOptions
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentMiniPlayerBinding
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class MiniPlayerFragment : Fragment() {

    private var _binding: FragmentMiniPlayerBinding? = null
    private val binding get() = _binding!!

    private val handler = Handler(Looper.getMainLooper())

    private val progressRunnable = object : Runnable {
        override fun run() {
            val b = _binding ?: return
            val pos = PlayerController.getCurrentPosition()
            val dur = PlayerController.getDuration()

            // FIX: dur puede ser -1 (C.TIME_UNSET) cuando ExoPlayer todavía está
            // en STATE_BUFFERING justo después de volver del PlayerActivity.
            // En ese caso no actualizar la barra y reintentar en 250ms (más frecuente
            // que el tick normal de 500ms) para salir del estado "00:00___00:00" rápido.
            when {
                dur > 0 -> {
                    b.progressBar.progress = ((pos * 100) / dur).toInt()
                    handler.postDelayed(this, 500)
                }
                dur == 0L -> {
                    b.progressBar.progress = 0
                    handler.postDelayed(this, 500)
                }
                else -> {
                    // dur negativo = aún buffering, reintentar pronto
                    handler.postDelayed(this, 250)
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMiniPlayerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), view as android.view.ViewGroup)

        // FIX redondeo: outlineProvider en código
        binding.ivAlbumArt.clipToOutline  = true
        binding.ivAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND

        setupControls()
        observePlayer()
    }

    private fun View.hapticTap() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun setupControls() {
        binding.btnPrev.isClickable      = true
        binding.btnPrev.isFocusable      = true
        binding.btnPlayPause.isClickable = true
        binding.btnPlayPause.isFocusable = true
        binding.btnNext.isClickable      = true
        binding.btnNext.isFocusable      = true

        binding.btnPrev.setOnClickListener {
            it.hapticTap()
            PlayerController.previous()
        }
        binding.btnPlayPause.setOnClickListener {
            it.hapticTap()
            PlayerController.playPause()
        }
        binding.btnNext.setOnClickListener {
            it.hapticTap()
            PlayerController.next()
        }

        // ── Swipe horizontal para saltar canción ──────────────────────────────
        val swipeThreshold     = (80 * resources.displayMetrics.density)   // px mínimos para activar
        val velocityThreshold  = (200 * resources.displayMetrics.density)  // px/s mínimos
        val velocityTracker    = android.view.VelocityTracker.obtain()
        var swipeStartX        = 0f
        var swipeStartY        = 0f
        var isSwipe            = false

        binding.root.setOnTouchListener { v, event ->
            velocityTracker.addMovement(event)

            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    swipeStartX = event.x
                    swipeStartY = event.y
                    isSwipe = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - swipeStartX
                    val dy = event.y - swipeStartY
                    if (!isSwipe && Math.abs(dx) > Math.abs(dy) * 1.5f && Math.abs(dx) > 20f) {
                        isSwipe = true
                    }
                    if (isSwipe) {
                        binding.infoLayout.translationX = dx * 0.3f
                        binding.ivAlbumArt.alpha = 1f - (Math.abs(dx) / 400f).coerceIn(0f, 0.4f)
                    }
                }
                android.view.MotionEvent.ACTION_UP -> {
                    velocityTracker.computeCurrentVelocity(1000)
                    val vx = velocityTracker.xVelocity
                    val dx = event.x - swipeStartX

                    binding.infoLayout.animate().translationX(0f).setDuration(200).start()
                    binding.ivAlbumArt.animate().alpha(1f).setDuration(200).start()

                    if (isSwipe && (Math.abs(dx) > swipeThreshold || Math.abs(vx) > velocityThreshold)) {
                        if (dx < 0) { v.hapticTap(); PlayerController.next() }
                        else        { v.hapticTap(); PlayerController.previous() }
                    } else if (!isSwipe) {
                        // Tap: verificar si fue sobre un botón de control
                        val controlViews = listOf(binding.btnPrev, binding.btnPlayPause, binding.btnNext)
                        val hitControl = controlViews.any { btn ->
                            val loc = IntArray(2); btn.getLocationInWindow(loc)
                            val ex = event.rawX; val ey = event.rawY
                            ex >= loc[0] && ex <= loc[0] + btn.width &&
                            ey >= loc[1] && ey <= loc[1] + btn.height
                        }
                        if (!hitControl) v.performClick()
                        else {
                            // Dispatch manual del click al botón correcto
                            controlViews.forEach { btn ->
                                val loc = IntArray(2); btn.getLocationInWindow(loc)
                                val ex = event.rawX; val ey = event.rawY
                                if (ex >= loc[0] && ex <= loc[0] + btn.width &&
                                    ey >= loc[1] && ey <= loc[1] + btn.height) {
                                    btn.performClick()
                                }
                            }
                        }
                    }
                    isSwipe = false
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    binding.infoLayout.animate().translationX(0f).setDuration(200).start()
                    binding.ivAlbumArt.animate().alpha(1f).setDuration(200).start()
                    isSwipe = false
                }
            }
            true // siempre consumir para recibir todos los eventos del gesto
        }

        binding.root.setOnClickListener {
            val options = android.app.ActivityOptions.makeCustomAnimation(
                requireContext(),
                R.anim.slide_up,
                R.anim.fade_out
            )
            startActivity(
                android.content.Intent(requireContext(),
                    com.aeroplayer.ui.player.PlayerActivity::class.java),
                options.toBundle()
            )
        }
    }

    private fun observePlayer() {
        PlayerController.currentSong.observe(viewLifecycleOwner) { song ->
            val b = _binding ?: return@observe
            if (song == null) {
                b.root.visibility = View.GONE
                return@observe
            }
            b.root.visibility = View.VISIBLE
            b.tvTitle.text  = song.title
            b.tvArtist.text = song.artist

            val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
            Glide.with(b.ivAlbumArt)
                .load(cached ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(b.ivAlbumArt)
        }

        PlayerController.isPlaying.observe(viewLifecycleOwner) { playing ->
            _binding?.btnPlayPause?.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    override fun onResume() {
        super.onResume()

        // FIX: al volver del PlayerActivity, los LiveData pueden NO re-emitir
        // si su valor no cambió (misma canción, mismo estado de play).
        // Forzar sincronización manual de todos los controles.
        syncStateNow()

        // Reiniciar el loop de progreso con un pequeño delay para darle tiempo
        // al MediaController a reconectarse si el binder estaba reconstruyéndose.
        // Sin el delay, getDuration() puede devolver -1 y mostrar 00:00 — 00:00.
        handler.removeCallbacks(progressRunnable)
        handler.postDelayed({ handler.post(progressRunnable) }, 350)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(progressRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(progressRunnable)
        _binding = null
    }

    /**
     * Sincroniza manualmente título, artista, carátula y botón play/pause
     * con el estado actual del PlayerController.
     * Necesario cuando los LiveData no re-emiten (valor sin cambios) al volver
     * del PlayerActivity.
     */
    private fun syncStateNow() {
        val b = _binding ?: return

        val song = PlayerController.currentSong.value
        if (song == null) {
            b.root.visibility = View.GONE
            return
        }
        b.root.visibility = View.VISIBLE
        b.tvTitle.text  = song.title
        b.tvArtist.text = song.artist

        b.btnPlayPause.setImageResource(
            if (PlayerController.isPlaying.value == true) R.drawable.ic_pause
            else R.drawable.ic_play
        )

        // Forzar actualización inmediata de la barra de progreso
        val pos = PlayerController.getCurrentPosition()
        val dur = PlayerController.getDuration()
        if (dur > 0) {
            b.progressBar.progress = ((pos * 100) / dur).toInt()
        }

        // Recargar carátula por si cambió mientras estábamos en PlayerActivity
        val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
        Glide.with(b.ivAlbumArt)
            .load(cached ?: song.albumArtUri)
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(b.ivAlbumArt)
    }
}
