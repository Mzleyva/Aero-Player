package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemAlbumBinding
import com.aeroplayer.model.Song
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.utils.AlbumArtUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class Album(
    val name: String,
    val artist: String,
    val coverUri: android.net.Uri?,
    val songs: List<Song>
)

class AlbumsFragment : Fragment() {

    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // FrameLayout raíz para superponer el estado vacío
        val frame = FrameLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(context.getColor(R.color.background_dark))
        }

        // RecyclerView de álbumes
        val rv = RecyclerView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            layoutManager = GridLayoutManager(context, 2)
            setPadding(8, 8, 8, 80)
            clipToPadding = false
        }

        // Estado vacío
        val tvEmpty = TextView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            text = "No hay álbumes en tu biblioteca"
            setTextColor(context.getColor(R.color.text_secondary))
            textSize = 14f
            gravity = Gravity.CENTER
            visibility = View.GONE
        }

        frame.addView(rv)
        frame.addView(tvEmpty)

        val adapter = AlbumGridAdapter { album ->
            val intent = android.content.Intent(
                requireContext(), AlbumDetailActivity::class.java
            ).apply {
                putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME,  album.name)
                putExtra(AlbumDetailActivity.EXTRA_ARTIST_NAME, album.artist)
            }
            startActivity(
                intent,
                android.app.ActivityOptions.makeCustomAnimation(
                    requireContext(),
                    com.aeroplayer.R.anim.slide_in_right,
                    com.aeroplayer.R.anim.slide_out_left
                ).toBundle()
            )
        }
        rv.adapter = adapter

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            val albums = songs
                .groupBy { it.album }
                .map { (album, songList) ->
                    Album(
                        name     = album,
                        artist   = songList.first().artist,
                        coverUri = songList.first().albumArtUri,
                        songs    = songList.sortedBy { it.trackNumber }
                    )
                }
                .sortedBy { it.name.lowercase() }
            adapter.submitList(albums)
            // FIX: mostrar estado vacío si no hay álbumes
            tvEmpty.visibility = if (albums.isEmpty()) View.VISIBLE else View.GONE
            rv.visibility      = if (albums.isEmpty()) View.GONE   else View.VISIBLE
        }

        return frame
    }

}

class AlbumGridAdapter(
    private val onClick: (Album) -> Unit
) : ListAdapter<Album, AlbumGridAdapter.VH>(AlbumDiff()) {

    inner class VH(val b: ItemAlbumBinding) : RecyclerView.ViewHolder(b.root) {
        var artJob: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onViewRecycled(holder: VH) {
        super.onViewRecycled(holder)
        holder.artJob?.cancel()
        holder.artJob = null
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val album = getItem(position)
        holder.b.tvName.text   = album.name
        holder.b.tvArtist.text = album.artist
        holder.b.tvCount.text  = "${album.songs.size} canciones"

        // Representante del álbum: primera canción con datos completos
        val repSong = album.songs.firstOrNull()

        // 1. Intentar cache en memoria (O(1), sin bloquear)
        val cached = if (repSong != null) AlbumArtUtils.getCached(repSong.id) else null
        if (cached != null) {
            holder.artJob?.cancel()
            Glide.with(holder.b.ivCover)
                .load(cached)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(holder.b.ivCover)
        } else {
            // Mostrar placeholder mientras carga
            Glide.with(holder.b.ivCover)
                .load(R.drawable.ic_music_placeholder)
                .into(holder.b.ivCover)

            holder.artJob?.cancel()
            holder.artJob = (holder.b.ivCover.context as? LifecycleOwner)
                ?.lifecycleScope
                ?.launch {
                    // 2. Intentar extraer desde archivo + online (async IO)
                    val bmp = if (repSong != null) {
                        AlbumArtUtils.loadArt(repSong.id, repSong.path, repSong.artist, repSong.album)
                    } else null

                    if (bmp != null) {
                        Glide.with(holder.b.ivCover)
                            .load(bmp)
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .centerCrop()
                            .into(holder.b.ivCover)
                    } else {
                        // 3. Último recurso: URI de MediaStore (puede fallar en Android 10+)
                        Glide.with(holder.b.ivCover)
                            .load(album.coverUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .error(R.drawable.ic_music_placeholder)
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .centerCrop()
                            .into(holder.b.ivCover)
                    }
                }
        }

        holder.b.root.setOnClickListener { onClick(album) }
    }

    class AlbumDiff : DiffUtil.ItemCallback<Album>() {
        override fun areItemsTheSame(a: Album, b: Album)    = a.name == b.name
        override fun areContentsTheSame(a: Album, b: Album) = a == b
    }
}
