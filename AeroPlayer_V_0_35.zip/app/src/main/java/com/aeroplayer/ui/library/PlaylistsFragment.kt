package com.aeroplayer.ui.library

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.databinding.FragmentPlaylistsBinding
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.playlist.CreatePlaylistActivity
import com.aeroplayer.ui.playlist.PlaylistDetailActivity

class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PlaylistAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observePlaylists()
        setupFab()
    }

    private fun setupRecyclerView() {
        // FIX: adapter ya no recibe LiveData — recibe solo callbacks
        adapter = PlaylistAdapter(
            onPlaylistClick = { playlist ->
                startActivity(
                    Intent(requireContext(), PlaylistDetailActivity::class.java)
                        .putExtra("playlistId", playlist.id)
                        .putExtra("playlistName", playlist.name)
                )
            },
            onDeleteClick = { playlist ->
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar playlist")
                    .setMessage("¿Eliminar \"${playlist.name}\"?")
                    .setPositiveButton("Eliminar") { _, _ ->
                        viewModel.deletePlaylist(playlist.id)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )
        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@PlaylistsFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun observePlaylists() {
        viewModel.playlists.observe(viewLifecycleOwner) { playlists ->
            adapter.submitList(playlists)
            binding.tvEmpty.visibility  = if (playlists.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text        = "${playlists.size} playlists"

            // FIX: observar el conteo de cada playlist desde el Fragment
            // (donde el lifecycle está controlado) y notificar al adapter vía método seguro
            playlists.forEach { playlist ->
                viewModel.getPlaylistSongCount(playlist.id)
                    .observe(viewLifecycleOwner) { count ->
                        adapter.updateSongCount(playlist.id, count ?: 0)
                    }
            }
        }
    }

    private fun setupFab() {
        binding.fabNewPlaylist.setOnClickListener {
            startActivity(Intent(requireContext(), CreatePlaylistActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
