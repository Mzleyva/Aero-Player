package com.aeroplayer.ui.library

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingDataAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemSongListBinding
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.aeroplayer.utils.FormatUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Adapter de la lista principal de canciones.
 * Migrado de ListAdapter → PagingDataAdapter para soportar Paging 3.
 *
 * La firma de los callbacks es idéntica a la versión anterior para no
 * romper FilesFragment. La única diferencia visible es que [getItem]
 * puede devolver null (página aún no cargada) — se maneja con early-return.
 */
class SongListAdapter(
    // FIX: recibir el scope del Fragment/Activity en lugar de usar findViewTreeLifecycleOwner()
    // que retorna null en Android 11 cuando el RecyclerView está dentro de un Fragment,
    // causando que las carátulas nunca se carguen.
    private val lifecycleScope: CoroutineScope,
    private val onSongClick: (Song, () -> List<Song>) -> Unit,
    private val onLikeClick: (Song) -> Unit,
    private val onAddToPlaylist: (Song) -> Unit,
    private val onAddToQueue: (Song) -> Unit,
    private val onPlayNext: ((Song) -> Unit)? = null,
    private val onCastSong: ((Song) -> Unit)? = null
) : PagingDataAdapter<Song, SongListAdapter.VH>(SongDiff()) {

    // Set local de IDs likeados para actualización optimista instantánea.
    // Se actualiza desde el Fragment vía updateLikedIds() sin esperar loadSongs().
    private val likedIds = mutableSetOf<Long>()

    fun updateLikedIds(ids: Set<Long>) {
        likedIds.clear()
        likedIds.addAll(ids)
        // Refrescar visualmente sin recargar datos
        notifyItemRangeChanged(0, itemCount, PAYLOAD_LIKE)
    }

    inner class VH(val b: ItemSongListBinding) : RecyclerView.ViewHolder(b.root) {
        // FIX: guardar el job de carga de carátula para cancelarlo cuando el
        // ViewHolder se recicla — sin esto, una carga lenta puede aplicar
        // la imagen de la canción anterior a un item que ya muestra otra canción.
        var artJob: kotlinx.coroutines.Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemSongListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        // FIX redondeo: outlineProvider en código — XML clipToOutline solo no aplica recorte
        binding.ivAlbumArt.clipToOutline  = true
        binding.ivAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(binding)
    }

    override fun onViewRecycled(holder: VH) {
        super.onViewRecycled(holder)
        holder.artJob?.cancel()
        holder.artJob = null
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position) ?: return   // placeholder de Paging — aún no cargado
        with(holder.b) {
            tvTitle.text    = song.title
            tvArtist.text   = song.artist
            tvDuration.text = FormatUtils.formatDuration(song.duration)

            // Play count
            if (song.playCount > 0) {
                tvPlayCount?.visibility = android.view.View.VISIBLE
                tvPlayCount?.text = "▶ ${song.playCount}"
            } else {
                tvPlayCount?.visibility = android.view.View.GONE
            }

            // Badge de formato para TODOS los tipos (FLAC, MP3, Opus, AAC, etc.)
            val fmt = song.formatLabel
            if (fmt.isNotBlank() && fmt != "Audio") {
                tvFormatBadge?.visibility = android.view.View.VISIBLE
                tvFormatBadge?.text = fmt
            } else {
                tvFormatBadge?.visibility = android.view.View.GONE
            }

            // Cargar carátula: primero desde cache, luego async desde archivo
            val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
            if (cached != null) {
                holder.artJob?.cancel()
                Glide.with(ivAlbumArt).load(cached)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .centerCrop().into(ivAlbumArt)
            } else {
                Glide.with(ivAlbumArt).load(R.drawable.ic_music_placeholder).into(ivAlbumArt)
                holder.artJob?.cancel()
                holder.artJob = lifecycleScope.launch {
                    val bmp = com.aeroplayer.utils.AlbumArtUtils.loadArt(song.id, song.path)
                    if (bmp != null) {
                        Glide.with(ivAlbumArt).load(bmp)
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .centerCrop().into(ivAlbumArt)
                    } else {
                        Glide.with(ivAlbumArt).load(song.albumArtUri)
                            .placeholder(R.drawable.ic_music_placeholder)
                            .error(R.drawable.ic_music_placeholder)
                            .centerCrop().into(ivAlbumArt)
                    }
                }
            }

            bindLikeState(this, song.id in likedIds, animate = false)

            ivLike.setOnClickListener {
                val nowLiked = song.id !in likedIds
                if (nowLiked) likedIds.add(song.id) else likedIds.remove(song.id)
                bindLikeState(this, nowLiked, animate = true)
                onLikeClick(song)
            }

            ivMore.setOnClickListener { showSongMenu(it, song) }
            // La lista completa paginada no está disponible como List directa;
            // FilesFragment la provee a través del lambda snapshot.
            root.setOnClickListener { onSongClick(song) { snapshot().items.filterNotNull().let { snap ->
                // FIX: snapshot() only returns loaded pages (e.g. 22 visible items).
                // The lambda caller (FilesFragment) overrides this with the full sorted list.
                snap
            } } }
        }
    }

    // Bind parcial — solo actualiza el icono de like
    override fun onBindViewHolder(holder: VH, position: Int, payloads: List<Any>) {
        if (payloads.contains(PAYLOAD_LIKE)) {
            val song = getItem(position) ?: return
            bindLikeState(holder.b, song.id in likedIds, animate = false)
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    // ── Like state + animación bounce ────────────────────────────────────────
    private fun bindLikeState(b: ItemSongListBinding, liked: Boolean, animate: Boolean) {
        b.ivLike.setImageResource(
            if (liked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
        b.ivLike.setColorFilter(
            b.root.context.getColor(
                if (liked) R.color.accent_pink else R.color.text_secondary
            )
        )
        if (animate && liked) animateLikeBounce(b.ivLike)
    }

    private fun animateLikeBounce(view: View) {
        val scaleX = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.4f, 1f)
        val scaleY = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.4f, 1f)
        AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            duration = 300
            interpolator = OvershootInterpolator(3f)
            start()
        }
    }

    // ── Menú contextual ──────────────────────────────────────────────────────
    private fun showSongMenu(anchor: View, song: Song) {
        val isLiked = song.id in likedIds
        val castAvailable = com.aeroplayer.cast.CastManager.isAvailable.value == true

        val items = buildList {
            add(anchor.context.getString(R.string.add_to_queue))
            add(anchor.context.getString(R.string.play_next))
            add(anchor.context.getString(R.string.add_to_playlist_menu))
            add(if (isLiked) anchor.context.getString(R.string.unlike)
                else         anchor.context.getString(R.string.like))
            add(anchor.context.getString(R.string.view_artist))
            add(anchor.context.getString(R.string.go_to_album))
            add("⬇️  Descargar con YTDLnis")
            if (castAvailable) add("📺  ${anchor.context.getString(R.string.cast_to_device)}")
        }.toTypedArray()

        MaterialAlertDialogBuilder(anchor.context)
            .setTitle(song.title)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> onAddToQueue(song)
                    1 -> onPlayNext?.invoke(song) ?: onAddToQueue(song)
                    2 -> onAddToPlaylist(song)
                    3 -> {
                        val nowLiked = !isLiked
                        if (nowLiked) likedIds.add(song.id) else likedIds.remove(song.id)
                        val pos = snapshot().items.indexOfFirst { it?.id == song.id }
                        if (pos >= 0) notifyItemChanged(pos, PAYLOAD_LIKE)
                        onLikeClick(song)
                    }
                    4 -> {
                        // Ver artista
                        val intent = android.content.Intent(anchor.context,
                            com.aeroplayer.ui.library.ArtistDetailActivity::class.java).apply {
                            putExtra("artist_name", song.artist)
                        }
                        anchor.context.startActivity(intent)
                    }
                    5 -> {
                        // Ir al álbum
                        val intent = android.content.Intent(anchor.context,
                            com.aeroplayer.ui.library.AlbumDetailActivity::class.java).apply {
                            putExtra("album_name", song.album)
                            putExtra("artist_name", song.artist)
                        }
                        anchor.context.startActivity(intent)
                    }
                    6 -> {
                        // Descargar con YTDLnis
                        openYTDLnisFromLibrary(anchor.context, song)
                    }
                    7 -> {
                        // Cast (solo si castAvailable)
                        if (castAvailable) {
                            onCastSong?.invoke(song) ?: run {
                                com.aeroplayer.cast.CastManager.castSong(song)
                            }
                        }
                    }
                }
            }
            .show()
    }

    private fun openYTDLnisFromLibrary(ctx: android.content.Context, song: Song) {
        val query = "${song.artist} - ${song.title}"
        val input = android.widget.EditText(ctx).apply {
            hint = "https://youtube.com/..."
            setPadding(64, 32, 64, 16)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText("https://www.youtube.com/results?search_query=${android.net.Uri.encode(query)}")
            selectAll()
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("⬇️ Descargar con YTDLnis")
            .setMessage("Pega el link de YouTube, SoundCloud, etc.:")
            .setView(input)
            .setPositiveButton("Enviar a YTDLnis") { _, _ ->
                val url = input.text.toString().trim().ifBlank { return@setPositiveButton }
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_TEXT, url)
                    setPackage("com.deniscerri.ytdl")
                }
                try {
                    ctx.startActivity(intent)
                } catch (_: android.content.ActivityNotFoundException) {
                    // YTDLnis no instalado
                    val storeUri = android.net.Uri.parse(
                        "https://play.google.com/store/apps/details?id=com.deniscerri.ytdl")
                    ctx.startActivity(android.content.Intent(
                        android.content.Intent.ACTION_VIEW, storeUri))
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    companion object {
        const val PAYLOAD_LIKE = "payload_like"
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song)    = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
