package com.aeroplayer.service

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession

/**
 * AeroMediaNotificationProvider — corrige el crash de SystemUI en Android 11.
 *
 * CAUSA: La portada del álbum (~1.4 MB sin comprimir) supera el límite IPC de
 * Android 11 (~1 MB) al pasar vía Binder a SystemUI →
 * TransactionTooLargeException en SystemUI → crash del sistema operativo.
 *
 * SOLUCIÓN: Delegar al DefaultMediaNotificationProvider, extraer el largeIcon
 * de la Notification resultante, escalarlo a máx 256×256 px y reconstruir la
 * notificación usando Notification.Builder(context, original) que clona
 * todos los campos (media style, acciones, intents) cambiando solo el largeIcon.
 *
 * Compatible con Media3 1.4.1 (no requiere setBitmapLoader).
 */
@UnstableApi
class AeroMediaNotificationProvider(
    private val context: android.content.Context
) : MediaNotification.Provider {

    companion object {
        // 256×256 × 4 bytes/px ≈ 256 KB — seguro para IPC en Android 11
        private const val MAX_PX = 256
    }

    private val delegate = DefaultMediaNotificationProvider(context)

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: com.google.common.collect.ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val original = delegate.createNotification(
            mediaSession, customLayout, actionFactory, onNotificationChangedCallback
        )

        // Solo API 23+ puede leer getLargeIcon(); en versiones anteriores no hay problema.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return original

        val largeIconBitmap: Bitmap = extractLargeIconBitmap(original.notification)
            ?: return original  // sin portada → sin problema IPC

        // Si ya es pequeño no hace falta escalar
        if (largeIconBitmap.width <= MAX_PX && largeIconBitmap.height <= MAX_PX) return original

        // Escalar y clonar la notificación con el icon reducido
        val scaled = scaleBitmap(largeIconBitmap)
        val rebuilt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // API 26+: Notification.Builder(context, notification) clona todo
            Notification.Builder(context, original.notification)
                .setLargeIcon(scaled)
                .build()
        } else {
            // API 23–25: reconstruir manualmente los campos esenciales
            @Suppress("DEPRECATION")
            Notification.Builder(context)
                .setSmallIcon(original.notification.smallIcon)
                .setLargeIcon(scaled)
                .setContentTitle(
                    original.notification.extras
                        .getCharSequence(Notification.EXTRA_TITLE)
                )
                .setContentText(
                    original.notification.extras
                        .getCharSequence(Notification.EXTRA_TEXT)
                )
                .setContentIntent(original.notification.contentIntent)
                .setDeleteIntent(original.notification.deleteIntent)
                .setOngoing(
                    original.notification.flags and Notification.FLAG_ONGOING_EVENT != 0
                )
                .build()
        }

        return MediaNotification(original.notificationId, rebuilt)
    }

    override fun handleCustomCommand(
        session: MediaSession,
        action: String,
        extras: Bundle
    ): Boolean = delegate.handleCustomCommand(session, action, extras)

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun extractLargeIconBitmap(notif: Notification): Bitmap? {
        val icon: Icon = notif.getLargeIcon() ?: return null
        return iconToBitmap(icon)
    }

    private fun iconToBitmap(icon: Icon): Bitmap? = runCatching {
        val drawable = icon.loadDrawable(context) ?: return null
        val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: MAX_PX
        val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: MAX_PX
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, w, h)
        drawable.draw(canvas)
        bmp
    }.getOrNull()

    private fun scaleBitmap(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= MAX_PX && h <= MAX_PX) return src
        val factor = MAX_PX.toFloat() / maxOf(w, h)
        return runCatching {
            Bitmap.createScaledBitmap(
                src,
                (w * factor).toInt().coerceAtLeast(1),
                (h * factor).toInt().coerceAtLeast(1),
                true
            )
        }.getOrElse { src }
    }
}
