package com.aeroplayer.ui

import android.app.Application
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.aeroplayer.R
import com.aeroplayer.data.db.PlayCountEntity
import com.aeroplayer.data.repository.LyricsResult
import com.aeroplayer.data.repository.MusicRepository
import com.aeroplayer.data.repository.SongPagingSource
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MusicRepository(app)

    private val _allSongs = MutableLiveData<List<Song>>()
    val allSongs: LiveData<List<Song>> = _allSongs

    private val _topPlayed = MutableLiveData<List<PlayCountEntity>>()
    val topPlayed: LiveData<List<PlayCountEntity>> = _topPlayed

    private val _searchResults = MutableLiveData<List<Song>>()
    val searchResults: LiveData<List<Song>> = _searchResults

    private val _lyrics = MutableLiveData<String?>()
    val lyrics: LiveData<String?> = _lyrics

    private val _syncedLyrics = MutableLiveData<String?>()
    val syncedLyrics: LiveData<String?> = _syncedLyrics

    /** Non-null when a lyrics fetch failed due to a network error. */
    private val _lyricsError = MutableLiveData<String?>()
    val lyricsError: LiveData<String?> = _lyricsError

    /** True while songs are being loaded from MediaStore. */
    private val _isLoadingSongs = MutableLiveData(false)
    val isLoadingSongs: LiveData<Boolean> = _isLoadingSongs

    val likedSongs    = repo.getLikedSongsLive()
    val likedCount    = repo.getLikedCountLive()
    val playlists     = repo.getAllPlaylistsLive()
    val playlistCount = repo.getPlaylistCountLive()

    // ── Playlists favoritas (persisten en SharedPreferences) ─────────────────
    private val _favoritePlaylistIds = MutableLiveData<Set<Long>>(loadFavoritePlaylistIds())
    val favoritePlaylistIds: LiveData<Set<Long>> = _favoritePlaylistIds

    private fun prefs() = getApplication<Application>()
        .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)

    private fun loadFavoritePlaylistIds(): Set<Long> =
        prefs().getStringSet("favorite_playlist_ids", emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()

    private fun saveFavoritePlaylistIds(ids: Set<Long>) {
        prefs().edit()
            .putStringSet("favorite_playlist_ids", ids.map { it.toString() }.toSet())
            .apply()
    }

    fun toggleFavoritePlaylist(playlistId: Long) {
        val current = _favoritePlaylistIds.value?.toMutableSet() ?: mutableSetOf()
        if (playlistId in current) current.remove(playlistId)
        else current.add(playlistId)
        saveFavoritePlaylistIds(current)
        _favoritePlaylistIds.value = current
    }

    // ── Paging 3 ─────────────────────────────────────────────────────────────
    /**
     * Estado del sort actual de FilesFragment.
     * Cuando cambia, [songsPagingData] emite una nueva página desde el inicio.
     */
    private val _sortedSongs = MutableStateFlow<List<Song>>(emptyList())

    /**
     * Flow de PagingData<Song> para FilesFragment.
     * Cada vez que [_sortedSongs] cambia (nuevo sort o nuevo MediaStore scan)
     * se crea un PagingSource fresco y el Pager emite desde la página 0.
     *
     * [cachedIn] mantiene las páginas en el ViewModel — sobrevive rotaciones
     * sin recargar MediaStore.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    val songsPagingData: Flow<PagingData<Song>> = _sortedSongs
        .flatMapLatest { songs ->
            Pager(
                config = PagingConfig(
                    pageSize           = SongPagingSource.PAGE_SIZE,
                    prefetchDistance   = SongPagingSource.PAGE_SIZE / 2,
                    enablePlaceholders = false
                ),
                pagingSourceFactory  = { repo.getPagingSource(songs) }
            ).flow
        }
        .cachedIn(viewModelScope)

    /** Llamado desde FilesFragment cuando el usuario cambia el sort. */
    fun submitSortedSongs(sorted: List<Song>) {
        _sortedSongs.value = sorted
    }

    // ── MediaStore ContentObserver ────────────────────────────────────────────
    private val mediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            // MediaStore cambió — forzar re-escaneo e invalidar caché
            viewModelScope.launch { loadSongs(forceRefresh = true) }
        }
    }

    init {
        loadSongs()
        loadTopPlayed()
        getApplication<Application>().contentResolver.registerContentObserver(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            true,
            mediaObserver
        )
    }

    fun loadSongs(forceRefresh: Boolean = false) = viewModelScope.launch {
        _isLoadingSongs.value = true
        val songs = repo.getAllSongs(forceRefresh)
        val hidden = getHiddenSongIds()
        _allSongs.value = songs.filter { it.id !in hidden }
        // Alimentar el pager con el sort por defecto (título)
        _sortedSongs.value = _allSongs.value?.sortedBy { it.title.lowercase() }
        _isLoadingSongs.value = false
    }

    // ── Canciones ocultas ─────────────────────────────────────────────────────
    fun getHiddenSongIds(): Set<Long> =
        prefs().getStringSet("hidden_song_ids", emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()

    fun hideSong(songId: Long) {
        val current = getHiddenSongIds().toMutableSet()
        current.add(songId)
        prefs().edit().putStringSet("hidden_song_ids", current.map { it.toString() }.toSet()).apply()
        viewModelScope.launch { loadSongs() }
    }

    fun unhideSong(songId: Long) {
        val current = getHiddenSongIds().toMutableSet()
        current.remove(songId)
        prefs().edit().putStringSet("hidden_song_ids", current.map { it.toString() }.toSet()).apply()
        viewModelScope.launch { loadSongs() }
    }

    fun loadTopPlayed() = viewModelScope.launch {
        _topPlayed.value = repo.getTopPlayedSongs(20)
    }

    private var searchJob: Job? = null

    fun search(query: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(200L) // debounce 200ms
            val songs = _allSongs.value ?: repo.getAllSongs()
            val q = query.lowercase()
            _searchResults.value = songs.filter {
                it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q)
            }
        }
    }

    fun toggleLike(song: Song) = viewModelScope.launch {
        repo.toggleLike(song)
    }

    fun incrementPlayCount(song: Song) = viewModelScope.launch {
        repo.incrementPlayCount(song)
        loadTopPlayed()
    }

    fun createPlaylist(name: String, coverUri: String? = null) = viewModelScope.launch {
        repo.createPlaylist(name, coverUri)
    }

    fun updatePlaylistFull(id: Long, name: String, coverUri: String? = null) = viewModelScope.launch {
        repo.updatePlaylist(id, name, coverUri)
    }

    fun deletePlaylist(id: Long) = viewModelScope.launch {
        val favs = _favoritePlaylistIds.value?.toMutableSet() ?: mutableSetOf()
        if (id in favs) {
            favs.remove(id)
            saveFavoritePlaylistIds(favs)
            _favoritePlaylistIds.value = favs
        }
        repo.deletePlaylist(id)
    }

    fun addSongToPlaylist(playlistId: Long, song: Song) = viewModelScope.launch {
        repo.addSongToPlaylist(playlistId, song)
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch {
        repo.removeSongFromPlaylist(playlistId, songId)
    }

    fun reorderPlaylistSongs(playlistId: Long, songs: List<Song>) = viewModelScope.launch {
        repo.reorderPlaylistSongs(playlistId, songs)
    }

    fun fetchLyrics(artist: String, title: String, songPath: String = "") = viewModelScope.launch {
        _lyrics.value       = null
        _syncedLyrics.value = null
        _lyricsError.value  = null
        when (val result = repo.getLyricsResponse(artist, title, songPath)) {
            is LyricsResult.Success -> {
                val resp = result.response
                _syncedLyrics.value = resp.syncedLyrics?.takeIf { it.isNotBlank() }
                _lyrics.value = resp.plainLyrics?.takeIf { it.isNotBlank() }
                    ?: resp.syncedLyrics
                        ?.lines()
                        ?.joinToString("\n") { line ->
                            line.replace(Regex("^\\[\\d+:\\d+\\.\\d+]\\s*"), "")
                        }
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
            }
            is LyricsResult.NotFound -> {
                _lyrics.value = null
            }
            is LyricsResult.Error -> {
                _lyricsError.value = result.throwable.message ?: getApplication<Application>().getString(R.string.error_network)
            }
        }
    }

    fun getPlaylistSongs(playlistId: Long)     = repo.getPlaylistSongsLive(playlistId)
    fun getPlaylistSongCount(playlistId: Long) = repo.getPlaylistSongCount(playlistId)

    // ── Historial ─────────────────────────────────────────────────────────────
    val listeningHistory = repo.getHistoryLive(200)

    fun clearHistory() = viewModelScope.launch { repo.clearHistory() }

    // ── Smart Playlists ───────────────────────────────────────────────────────
    /** Construye la lista de canciones para una smart playlist dada. */
    suspend fun getSmartPlaylistSongs(type: SmartPlaylistType): List<Song> =
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            val allSongs = _allSongs.value ?: emptyList()
            val songMap = allSongs.associateBy { it.id }

            when (type) {
                SmartPlaylistType.RECENTLY_PLAYED -> {
                    repo.getRecentUniqueSongs(50).mapNotNull { entry ->
                        songMap[entry.songId] ?: Song(
                            id = entry.songId, title = entry.title,
                            artist = entry.artist, album = entry.album,
                            duration = entry.duration, path = entry.path,
                            albumArtUri = entry.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entry.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.MOST_PLAYED -> {
                    repo.getTopPlayedSongs(50).mapNotNull { entity ->
                        songMap[entity.songId] ?: Song(
                            id = entity.songId, title = entity.title,
                            artist = entity.artist, album = entity.title,
                            duration = 0, path = entity.path,
                            albumArtUri = entity.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entity.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.HISTORY -> {
                    repo.getHistorySync(100).mapNotNull { entry ->
                        songMap[entry.songId] ?: Song(
                            id = entry.songId, title = entry.title,
                            artist = entry.artist, album = entry.album,
                            duration = entry.duration, path = entry.path,
                            albumArtUri = entry.albumArtUri?.let { android.net.Uri.parse(it) },
                            uri = android.net.Uri.parse("file://${entry.path}"),
                            trackNumber = 0, year = 0, size = 0
                        )
                    }
                }
                SmartPlaylistType.LIKED -> {
                    allSongs.filter { song ->
                        likedSongs.value?.any { it.songId == song.id } == true
                    }
                }
            }
        }

    // ── Excluded folders ──────────────────────────────────────────────────────
    fun getExcludedFolders(): Set<String> =
        prefs().getStringSet("excluded_folders", emptySet()) ?: emptySet()

    fun setExcludedFolders(folders: Set<String>) {
        prefs().edit().putStringSet("excluded_folders", folders).apply()
        viewModelScope.launch { loadSongs() }
    }

    // ── Profile name (persisted) ──────────────────────────────────────────────
    fun getProfileName(): String =
        prefs().getString("profile_name", "Aero Player User") ?: "Aero Player User"

    fun setProfileName(name: String) {
        prefs().edit()
            .putString("profile_name", name.trim().ifBlank { "Aero Player User" })
            .apply()
    }

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /** Asigna el GIF Canvas de la canción con [songId]. */
    fun setCanvas(songId: Long, gifUri: String) = viewModelScope.launch {
        repo.setCanvas(songId, gifUri)
    }

    /** Elimina el GIF Canvas de la canción con [songId]. */
    fun deleteCanvas(songId: Long) = viewModelScope.launch {
        repo.deleteCanvas(songId)
    }

    /**
     * LiveData reactivo del canvas para [songId].
     * El player lo observa — cuando el usuario asigna o elimina un canvas
     * el GIF aparece o desaparece inmediatamente sin necesidad de reiniciar.
     */
    fun getCanvasLive(songId: Long) = repo.getCanvasLive(songId)

    override fun onCleared() {
        super.onCleared()
        getApplication<Application>().contentResolver.unregisterContentObserver(mediaObserver)
        PlayerController.disconnect()
    }
}
