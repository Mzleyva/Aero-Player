package com.aeroplayer.ui.player

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemQueueSongBinding
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class QueueAdapter(
    private val onItemClick: (Song, Int) -> Unit,
    private val onRemoveClick: (Int) -> Unit
) : ListAdapter<Song, QueueAdapter.VH>(SongDiff()) {

    private var currentIndex: Int = 0

    inner class VH(val b: ItemQueueSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemQueueSongBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text = song.title
            tvArtist.text = song.artist

            // Highlight currently playing
            val isPlaying = position == currentIndex
            root.alpha = if (isPlaying) 1f else 0.7f
            tvTitle.setTextColor(
                root.context.getColor(
                    if (isPlaying) R.color.accent_blue else R.color.text_primary
                )
            )
            ivNowPlaying.visibility = if (isPlaying) android.view.View.VISIBLE else android.view.View.GONE

            Glide.with(ivAlbumArt)
                .load(
                    com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
                        ?: song.albumArtUri
                )
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivAlbumArt)

            ivRemove.setOnClickListener { onRemoveClick(position) }
            root.setOnClickListener { onItemClick(song, position) }
        }
    }

    fun setCurrentIndex(index: Int) {
        val old = currentIndex
        currentIndex = index
        notifyItemChanged(old)
        notifyItemChanged(index)
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
