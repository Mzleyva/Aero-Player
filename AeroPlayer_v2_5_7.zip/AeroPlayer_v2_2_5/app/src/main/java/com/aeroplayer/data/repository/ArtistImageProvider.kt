package com.aeroplayer.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Busca imágenes de artistas en múltiples fuentes:
 *  1. Deezer API  — rápida, buena cobertura
 *  2. MusicBrainz CAA — open data
 *  3. iTunes     — fallback adicional
 *
 * Las imágenes se cachean en disco.
 */
object ArtistImageProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("User-Agent", "AeroPlayer/1.0 (Android)")
                    .build()
            )
        }
        .build()

    private var cacheDir: File? = null

    fun init(context: Context) {
        // FIX v1.8.4: usar filesDir (datos permanentes de la app) en lugar de cacheDir.
        // cacheDir es borrado por el sistema cuando hay poco espacio — las fotos
        // de artistas desaparecían tras unos días. filesDir persiste mientras
        // la app esté instalada y el usuario no limpie datos manualmente.
        cacheDir = File(context.filesDir, "artist_photos").also { it.mkdirs() }
    }

    private fun cacheKey(artist: String) =
        artist.replace(Regex("[^a-zA-Z0-9]"), "_").take(80)

    private fun readCache(key: String): Bitmap? {
        val dir = cacheDir ?: return null
        val file = File(dir, "$key.jpg")
        if (!file.exists()) return null
        // Actualizar lastModified para LRU
        runCatching { file.setLastModified(System.currentTimeMillis()) }
        return runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
    }

    /** Devuelve la ruta en filesDir para una imagen de artista (para cargarla con Glide). */
    fun getCachedFile(artistName: String): File? {
        val dir = cacheDir ?: return null
        val file = File(dir, "${cacheKey(artistName)}.jpg")
        return if (file.exists()) file else null
    }

    /** Número de fotos guardadas actualmente. */
    fun cachedCount(): Int = cacheDir?.listFiles()?.size ?: 0

    /** Borra todas las fotos guardadas. */
    fun clearAll() { cacheDir?.listFiles()?.forEach { it.delete() } }

    private fun writeCache(key: String, bitmap: Bitmap) {
        runCatching {
            val dir = cacheDir ?: return
            File(dir, "$key.jpg").outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            // Limitar a 300 fotos máximo — evictar las más antiguas si se supera
            val files = dir.listFiles()?.sortedBy { it.lastModified() } ?: return
            if (files.size > 300) {
                files.take(files.size - 300).forEach { it.delete() }
            }
        }
    }

    suspend fun fetchArtistImage(artistName: String): Bitmap? =
        withContext(Dispatchers.IO) {
            if (artistName.isBlank()) return@withContext null
            val key = cacheKey(artistName)

            // 1. Caché de disco
            readCache(key)?.let { return@withContext it }

            // 2. Deezer — proveedor principal (tiene fotos de artistas)
            fetchFromDeezer(artistName)?.let {
                writeCache(key, it)
                return@withContext it
            }

            // 3. MusicBrainz + Cover Art Archive
            (fetchFromMusicBrainz(artistName) ?: fetchFromDiscogs(artistName))?.let {
                writeCache(key, it)
                return@withContext it
            }

            // 4. iTunes por nombre de artista
            fetchFromItunes(artistName)?.let {
                writeCache(key, it)
                return@withContext it
            }

            null
        }

    private fun fetchFromDeezer(artist: String): Bitmap? = runCatching {
        val q = java.net.URLEncoder.encode(artist, "UTF-8")
        val url = "https://api.deezer.com/search/artist?q=$q&limit=1"
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val body = resp.body?.string() ?: return null

        // Extraer picture_xl del primer resultado
        val match = Regex("\"picture_xl\":\"([^\"]+)\"").find(body)
        val imgUrl = match?.groupValues?.get(1)?.replace("\\/", "/") ?: return null

        // Ignorar imágenes por defecto de Deezer (no tienen foto real)
        if (imgUrl.contains("default")) return null

        downloadBitmap(imgUrl)
    }.getOrNull()

    /** Fallback: Discogs API (sin API key para búsqueda básica) */
    private fun fetchFromDiscogs(artist: String): Bitmap? = runCatching {
        val url = "https://api.discogs.com/database/search?q=${java.net.URLEncoder.encode(artist, "UTF-8")}&type=artist&per_page=1"
        val req = okhttp3.Request.Builder()
            .url(url)
            .header("User-Agent", "AeroPlayer/2.3 +https://aeroplayer.app")
            .build()
        val body = OkHttpClient.Builder()
            .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .build()
            .newCall(req).execute().use { it.body?.string() } ?: return null
        val json = org.json.JSONObject(body)
        val results = json.optJSONArray("results") ?: return null
        if (results.length() == 0) return null
        val coverImage = results.getJSONObject(0).optString("cover_image") ?: return null
        if (coverImage.isBlank() || coverImage.contains("spacer")) return null
        val imgReq = okhttp3.Request.Builder().url(coverImage).build()
        val bytes = OkHttpClient().newCall(imgReq).execute().use { it.body?.bytes() } ?: return null
        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()

    private fun fetchFromMusicBrainz(artist: String): Bitmap? = runCatching {
        val q = java.net.URLEncoder.encode("artist:\"$artist\"", "UTF-8")
        val url = "https://musicbrainz.org/ws/2/artist/?query=$q&limit=1&fmt=json"
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val body = resp.body?.string() ?: return null

        val mbid = Regex("\"id\":\"([a-f0-9\\-]{36})\"").find(body)
            ?.groupValues?.get(1) ?: return null

        // Cover Art Archive no tiene imágenes de artistas directamente,
        // buscar release del artista y usar su portada como representación
        val relUrl = "https://musicbrainz.org/ws/2/release/?artist=$mbid&limit=1&fmt=json"
        val relResp = client.newCall(Request.Builder().url(relUrl).build()).execute()
        val relBody = relResp.body?.string() ?: return null

        val relMbid = Regex("\"id\":\"([a-f0-9\\-]{36})\"").find(relBody)
            ?.groupValues?.get(1) ?: return null

        downloadBitmap("https://coverartarchive.org/release/$relMbid/front-250")
    }.getOrNull()

    private fun fetchFromItunes(artist: String): Bitmap? = runCatching {
        val q = java.net.URLEncoder.encode(artist, "UTF-8")
        val url = "https://itunes.apple.com/search?term=$q&media=music&entity=musicArtist&limit=1"
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val body = resp.body?.string() ?: return null

        // iTunes no devuelve fotos de artistas directamente, buscar álbum del artista
        val albumUrl = "https://itunes.apple.com/search?term=$q&media=music&entity=album&limit=1"
        val albumResp = client.newCall(Request.Builder().url(albumUrl).build()).execute()
        val albumBody = albumResp.body?.string() ?: return null

        val match = Regex("\"artworkUrl100\":\"([^\"]+)\"").find(albumBody)
        val artUrl = match?.groupValues?.get(1) ?: return null
        downloadBitmap(artUrl.replace("100x100", "500x500"))
    }.getOrNull()

    private fun downloadBitmap(url: String): Bitmap? = runCatching {
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val bytes = resp.body?.bytes() ?: return null
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()

    fun clearCache(artistName: String) {
        runCatching { File(cacheDir, "${cacheKey(artistName)}.jpg").delete() }
    }
}
