package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityAlbumDetailBinding
import com.aeroplayer.databinding.ItemPlaylistSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.AccentApplier
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.utils.AlbumArtUtils
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AlbumDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ALBUM_NAME  = "album_name"
        const val EXTRA_ARTIST_NAME = "artist_name"
    }

    private lateinit var binding: ActivityAlbumDetailBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityAlbumDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AccentApplier.apply(this, binding.root)

        val albumName  = intent.getStringExtra(EXTRA_ALBUM_NAME)  ?: run { finish(); return }
        val artistName = intent.getStringExtra(EXTRA_ARTIST_NAME) ?: ""

        binding.btnBack.setOnClickListener { finish() }

        viewModel.allSongs.observe(this) { allSongs ->
            val songs = allSongs
                .filter { it.album == albumName && (artistName.isEmpty() || it.artist == artistName) }
                .sortedWith(compareBy({ it.discNumber }, { it.trackNumber }))

            binding.tvAlbumName.text   = albumName
            binding.tvAlbumArtist.text = songs.firstOrNull()?.artist ?: artistName

            // Info: "12 canciones · 2019 · 45:32"
            val year = songs.firstOrNull { it.year > 0 }?.year
            val totalMs = songs.sumOf { it.duration }
            val totalMin = totalMs / 60000
            val infoStr = buildString {
                append("${songs.size} canción${if (songs.size != 1) "es" else ""}")
                if (year != null && year > 0) append(" · $year")
                if (totalMin > 0) append(" · ${totalMin} min")
            }
            binding.tvAlbumInfo.text = infoStr

            loadCover(songs)
            setupSongs(songs)
            setupButtons(songs, albumName)
        }
    }

    private fun loadCover(songs: List<Song>) {
        val repSong = songs.firstOrNull() ?: return

        val cached = AlbumArtUtils.getCached(repSong.id)
        if (cached != null) {
            Glide.with(binding.ivAlbumCover).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade()).into(binding.ivAlbumCover)
            applyPalette(cached)
        } else {
            Glide.with(binding.ivAlbumCover).load(repSong.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .centerCrop()
                .into(binding.ivAlbumCover)

            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    AlbumArtUtils.loadArt(repSong.id, repSong.path, repSong.artist, repSong.album)
                }
                if (bmp != null) {
                    Glide.with(binding.ivAlbumCover).load(bmp).centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade()).into(binding.ivAlbumCover)
                    applyPalette(bmp)
                }
            }
        }
    }

    private fun applyPalette(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val fallback = ContextCompat.getColor(this, R.color.surface_dark)
            val dominant = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(fallback)
            ) ?: fallback
            binding.headerContainer.setBackgroundColor(dominant)
        }
    }

    private fun setupSongs(songs: List<Song>) {
        // Si el álbum tiene más de un número de disco, insertar separadores "Disco N"
        val discs = songs.map { it.discNumber }.filter { it > 0 }.distinct().sorted()
        val isMultiDisc = discs.size > 1

        val adapter = AlbumSongAdapter(
            isMultiDisc = isMultiDisc,
            onClick = { song ->
                viewModel.incrementPlayCount(song)
                PlayerController.playSongs(
                    songs, songs.indexOf(song),
                    queueName = binding.tvAlbumName.text.toString()
                )
                startActivity(
                    Intent(this, PlayerActivity::class.java),
                    ActivityOptions.makeCustomAnimation(this, R.anim.fade_in, R.anim.fade_out).toBundle()
                )
            }
        )
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter
        binding.rvSongs.isNestedScrollingEnabled = false

        if (isMultiDisc) {
            // Construir lista intercalando DiscHeader items
            val items = mutableListOf<AlbumListItem>()
            discs.forEach { disc ->
                items.add(AlbumListItem.DiscHeader("Disco $disc"))
                songs.filter { it.discNumber == disc }.forEach { items.add(AlbumListItem.SongItem(it)) }
            }
            // Canciones sin número de disco (0) al final
            val noDisk = songs.filter { it.discNumber == 0 }
            if (noDisk.isNotEmpty()) {
                if (items.isNotEmpty()) items.add(AlbumListItem.DiscHeader("Disco 1"))
                noDisk.forEach { items.add(AlbumListItem.SongItem(it)) }
            }
            adapter.submitList(items)
        } else {
            adapter.submitList(songs.map { AlbumListItem.SongItem(it) })
        }
    }

    private fun setupButtons(songs: List<Song>, albumName: String) {
        binding.btnPlayAll.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            viewModel.incrementPlayCount(songs.first())
            PlayerController.playSongs(songs, 0, queueName = albumName)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.btnShuffle.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            val shuffled = songs.shuffled()
            viewModel.incrementPlayCount(shuffled.first())
            PlayerController.playSongs(shuffled, 0, queueName = albumName)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}

// ── List item sealed class ─────────────────────────────────────────────────────
sealed class AlbumListItem {
    data class SongItem(val song: Song) : AlbumListItem()
    data class DiscHeader(val label: String) : AlbumListItem()
}

// ── Adapter de canciones del álbum (soporta separadores de disco) ─────────────
class AlbumSongAdapter(
    private val isMultiDisc: Boolean = false,
    private val onClick: (Song) -> Unit
) : ListAdapter<AlbumListItem, RecyclerView.ViewHolder>(AlbumItemDiff()) {

    companion object {
        private const val TYPE_SONG   = 0
        private const val TYPE_HEADER = 1
    }

    inner class SongVH(val b: ItemPlaylistSongBinding) : RecyclerView.ViewHolder(b.root) {
        var artJob: Job? = null
    }

    inner class HeaderVH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val tv: android.widget.TextView = itemView.findViewById(android.R.id.text1)
    }

    override fun getItemViewType(position: Int) = when (getItem(position)) {
        is AlbumListItem.SongItem   -> TYPE_SONG
        is AlbumListItem.DiscHeader -> TYPE_HEADER
    }

    override fun onCreateViewHolder(p: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val tv = android.widget.TextView(p.context).apply {
                id = android.R.id.text1
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                val dp = resources.displayMetrics.density
                setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (6 * dp).toInt())
                setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text_secondary))
                textSize = 12f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                text = ""
            }
            HeaderVH(tv)
        } else {
            val b = ItemPlaylistSongBinding.inflate(LayoutInflater.from(p.context), p, false)
            b.ivAlbumArt.clipToOutline   = true
            b.ivAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            SongVH(b)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        (holder as? SongVH)?.artJob?.cancel()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is AlbumListItem.DiscHeader -> {
                (holder as HeaderVH).tv.text = item.label.uppercase()
            }
            is AlbumListItem.SongItem -> {
                val song = item.song
                val vh = holder as SongVH
                vh.b.tvTitle.text    = song.title
                vh.b.tvArtist.text   = song.artist
                vh.b.tvDuration.text = FormatUtils.formatDuration(song.duration)

                val cached = AlbumArtUtils.getCached(song.id)
                if (cached != null) {
                    Glide.with(vh.b.ivAlbumArt).load(cached).centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade()).into(vh.b.ivAlbumArt)
                } else {
                    Glide.with(vh.b.ivAlbumArt).load(R.drawable.ic_music_placeholder).into(vh.b.ivAlbumArt)
                    vh.artJob?.cancel()
                    vh.artJob = (vh.b.ivAlbumArt.context as? androidx.lifecycle.LifecycleOwner)
                        ?.lifecycleScope?.launch {
                            val bmp = AlbumArtUtils.loadArt(song.id, song.path, song.artist, song.album)
                            if (bmp != null) {
                                Glide.with(vh.b.ivAlbumArt).load(bmp).centerCrop()
                                    .transition(DrawableTransitionOptions.withCrossFade())
                                    .into(vh.b.ivAlbumArt)
                            } else {
                                Glide.with(vh.b.ivAlbumArt).load(song.albumArtUri)
                                    .placeholder(R.drawable.ic_music_placeholder)
                                    .error(R.drawable.ic_music_placeholder)
                                    .centerCrop().into(vh.b.ivAlbumArt)
                            }
                        }
                }
                vh.b.root.setOnClickListener { onClick(song) }
            }
        }
    }

    class AlbumItemDiff : DiffUtil.ItemCallback<AlbumListItem>() {
        override fun areItemsTheSame(a: AlbumListItem, b: AlbumListItem): Boolean {
            if (a is AlbumListItem.SongItem && b is AlbumListItem.SongItem) return a.song.id == b.song.id
            if (a is AlbumListItem.DiscHeader && b is AlbumListItem.DiscHeader) return a.label == b.label
            return false
        }
        override fun areContentsTheSame(a: AlbumListItem, b: AlbumListItem) = a == b
    }
}
