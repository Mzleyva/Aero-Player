package com.aeroplayer.ui.library

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentLibraryBinding
import com.aeroplayer.ui.MainViewModel
import com.google.android.material.tabs.TabLayoutMediator

class LibraryFragment : Fragment() {

    private var _binding: FragmentLibraryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLibraryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupViewPager()
        observeCounts()
    }

    private fun setupViewPager() {
        val adapter = LibraryPagerAdapter(this)
        binding.viewPager.adapter = adapter
        binding.tabLayout.tabMode = com.google.android.material.tabs.TabLayout.MODE_SCROLLABLE

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.tab_files)
                1 -> getString(R.string.tab_albums)
                2 -> getString(R.string.tab_artists)
                3 -> getString(R.string.tab_genres)
                4 -> getString(R.string.tab_liked)
                5 -> getString(R.string.tab_playlists)
                else -> ""
            }
        }.attach()
    }

    private fun observeCounts() {
        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            binding.tabLayout.getTabAt(0)?.text = getString(R.string.tab_files_count, songs.size)
            val albumCount = songs.map { it.album }.distinct().size
            binding.tabLayout.getTabAt(1)?.text = getString(R.string.tab_albums_count, albumCount)
            val artistCount = songs.map { it.artist }.distinct().size
            binding.tabLayout.getTabAt(2)?.text = getString(R.string.tab_artists_count, artistCount)
            val genreCount = songs.map { it.genre.ifBlank { "?" } }.distinct().size
            binding.tabLayout.getTabAt(3)?.text = getString(R.string.tab_genres_count, genreCount)
        }
        viewModel.likedCount.observe(viewLifecycleOwner) { count ->
            binding.tabLayout.getTabAt(4)?.text = getString(R.string.tab_liked_count, count)
        }
        viewModel.playlistCount.observe(viewLifecycleOwner) { count ->
            binding.tabLayout.getTabAt(5)?.text = getString(R.string.tab_playlists_count, count)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
