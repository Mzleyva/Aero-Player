package com.aeroplayer.ui.video

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.model.LocalVideo
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * VideoPlayerActivity — Sesión 8
 * Modo AUDIO_ONLY: delega en PlayerController y abre PlayerActivity.
 * Modo VIDEO: fullscreen con MediaPlayer + controles overlay.
 */
class VideoPlayerActivity : AppCompatActivity() {

    private var mediaPlayer: android.media.MediaPlayer? = null
    private lateinit var surfaceView: SurfaceView
    private lateinit var tvTitle: TextView
    private lateinit var btnPlayPause: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var tvPosition: TextView
    private lateinit var tvDuration: TextView
    private lateinit var controls: LinearLayout
    private var isPlaying = false
    private var musicWasPaused = false  // para reanudar al salir si el usuario no lo pausó manualmente
    private val seekHandler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        supportActionBar?.hide()

        val videoUri   = Uri.parse(intent.getStringExtra("video_uri") ?: return finish())
        val videoTitle = intent.getStringExtra("video_title") ?: "Video"
        val duration   = intent.getLongExtra("video_duration", 0L)
        val thumbUri   = intent.getStringExtra("video_thumb")
        val playMode   = runCatching {
            LocalVideo.PlayMode.valueOf(intent.getStringExtra("play_mode") ?: "AUDIO_ONLY")
        }.getOrDefault(LocalVideo.PlayMode.AUDIO_ONLY)

        // ── MODO AUDIO_ONLY ────────────────────────────────────────────────────
        if (playMode == LocalVideo.PlayMode.AUDIO_ONLY) {
            val song = com.aeroplayer.model.Song(
                id          = intent.getLongExtra("video_id", 0L),
                title       = videoTitle,
                artist      = "",
                album       = "",
                duration    = duration,
                path        = "",
                uri         = videoUri,
                albumArtUri = thumbUri?.let { Uri.parse(it) },
                mimeType    = "video/mp4"
            )
            PlayerController.playSongs(listOf(song), 0, videoTitle)
            startActivity(android.content.Intent(this,
                com.aeroplayer.ui.player.PlayerActivity::class.java))
            finish(); return
        }

        // ── MODO VIDEO fullscreen ──────────────────────────────────────────────
        setImmersive()

        val root = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        surfaceView = SurfaceView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER)
        }
        root.addView(surfaceView)

        // ── Controles overlay ──────────────────────────────────────────────────
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xBB000000.toInt())
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        }

        tvTitle = TextView(this).apply {
            text = videoTitle; textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
            isSelected = true; setPadding(16.dp, 12.dp, 16.dp, 4.dp)
        }
        controls.addView(tvTitle)

        seekBar = SeekBar(this).apply {
            max = duration.toInt().coerceAtLeast(1)
            progressTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.accent_blue))
            thumbTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.accent_blue))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.setMargins(8.dp, 0, 8.dp, 0) }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) { mediaPlayer?.seekTo(p); tvPosition.text = formatMs(p.toLong()) }
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        controls.addView(seekBar)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp, 4.dp, 16.dp, 16.dp)
        }
        tvPosition = TextView(this).apply {
            text = "0:00"; textSize = 12f; setTextColor(0xCCFFFFFF.toInt())
        }
        btnPlayPause = TextView(this).apply {
            text = "⏸"; textSize = 28f; setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { togglePlayPause() }
        }
        tvDuration = TextView(this).apply {
            text = formatMs(duration); textSize = 12f; setTextColor(0xCCFFFFFF.toInt())
        }
        // Botón para cambiar a modo audio
        val btnAudio = TextView(this).apply {
            text = "🎵"; textSize = 22f; setPadding(12.dp, 0, 4.dp, 0)
            setTextColor(android.graphics.Color.WHITE)
            setOnClickListener {
                val song = com.aeroplayer.model.Song(
                    id = intent.getLongExtra("video_id", 0L), title = videoTitle,
                    artist = "", album = "", duration = duration, path = "",
                    uri = videoUri, albumArtUri = thumbUri?.let { Uri.parse(it) },
                    mimeType = "video/mp4"
                )
                mediaPlayer?.stop()
                PlayerController.playSongs(listOf(song), 0, videoTitle)
                startActivity(android.content.Intent(this@VideoPlayerActivity,
                    com.aeroplayer.ui.player.PlayerActivity::class.java))
                finish()
            }
        }
        val btnClose = TextView(this).apply {
            text = "✕"; textSize = 18f; setPadding(8.dp, 0, 4.dp, 0)
            setTextColor(0xCCFFFFFF.toInt()); setOnClickListener { finish() }
        }
        btnRow.addView(tvPosition); btnRow.addView(btnPlayPause)
        btnRow.addView(tvDuration); btnRow.addView(btnAudio); btnRow.addView(btnClose)
        controls.addView(btnRow)
        root.addView(controls)

        root.setOnClickListener { toggleControls() }
        setContentView(root)

        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) { initMediaPlayer(videoUri, holder, duration) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { mediaPlayer?.stop() }
        })

        lifecycleScope.launch {
            delay(3_000)
            controls.animate().alpha(0f).setDuration(400).withEndAction {
                controls.visibility = android.view.View.GONE; controls.alpha = 1f
            }.start()
        }
    }

    private fun initMediaPlayer(uri: Uri, holder: SurfaceHolder, durationHint: Long) {
        val activity = this
        mediaPlayer = android.media.MediaPlayer().apply {
            setDisplay(holder)
            setDataSource(activity, uri)
            setOnPreparedListener { mp ->
                val vw = mp.videoWidth; val vh = mp.videoHeight
                if (vw > 0 && vh > 0) {
                    val sw = activity.resources.displayMetrics.widthPixels
                    val sh = activity.resources.displayMetrics.heightPixels
                    val scale = minOf(sw.toFloat() / vw, sh.toFloat() / vh)
                    val lp = activity.surfaceView.layoutParams as FrameLayout.LayoutParams
                    lp.width = (vw * scale).toInt(); lp.height = (vh * scale).toInt()
                    activity.surfaceView.layoutParams = lp
                }
                activity.seekBar.max = mp.duration.coerceAtLeast(1)
                activity.tvDuration.text = activity.formatMs(mp.duration.toLong())
                // Pausar música antes de iniciar el video — BUG FIX
                if (PlayerController.isPlaying.value == true) {
                    PlayerController.pause()
                    activity.musicWasPaused = true
                }
                mp.start()
                activity.isPlaying = true
                activity.btnPlayPause.text = "⏸"
                activity.startSeekUpdate()
            }
            setOnCompletionListener {
                activity.isPlaying = false
                activity.btnPlayPause.text = "▶"
                // Reanudar música si nosotros la pausamos
                if (activity.musicWasPaused) {
                    PlayerController.play()
                    activity.musicWasPaused = false
                }
            }
            prepareAsync()
        }
    }

    private fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) { mp.pause(); isPlaying = false; btnPlayPause.text = "▶" }
        else { mp.start(); isPlaying = true; btnPlayPause.text = "⏸"; startSeekUpdate() }
    }

    private var controlsVisible = true
    private fun toggleControls() {
        controlsVisible = !controlsVisible
        controls.visibility =
            if (controlsVisible) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun startSeekUpdate() {
        seekHandler.postDelayed(object : Runnable {
            override fun run() {
                val mp = mediaPlayer ?: return
                if (mp.isPlaying) {
                    val pos = mp.currentPosition
                    seekBar.progress = pos; tvPosition.text = formatMs(pos.toLong())
                    seekHandler.postDelayed(this, 500)
                }
            }
        }, 500)
    }

    private fun setImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.hide(
                android.view.WindowInsets.Type.statusBars() or
                android.view.WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
        }
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s/3600, (s%3600)/60, s%60)
        else "%d:%02d".format(s/60, s%60)
    }

    override fun onPause() { super.onPause(); mediaPlayer?.pause(); isPlaying = false }

    override fun onDestroy() {
        seekHandler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
        // Si el usuario sale sin terminar el video, reanudar música
        if (musicWasPaused) {
            PlayerController.play()
            musicWasPaused = false
        }
        super.onDestroy()
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
