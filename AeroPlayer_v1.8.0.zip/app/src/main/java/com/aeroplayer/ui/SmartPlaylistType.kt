package com.aeroplayer.ui

enum class SmartPlaylistType(
    val titleEs: String,
    val descriptionEs: String,
    val emoji: String
) {
    RECENTLY_PLAYED("Reproducidas recientemente", "Las últimas canciones que escuchaste", "🕐"),
    MOST_PLAYED(    "Más escuchadas",             "Tus canciones favoritas de siempre",   "🔥"),
    HISTORY(        "Historial completo",          "Todo lo que has reproducido",          "📋"),
    LIKED(          "Me gusta",                   "Canciones que marcaste con ❤",         "❤️")
}
