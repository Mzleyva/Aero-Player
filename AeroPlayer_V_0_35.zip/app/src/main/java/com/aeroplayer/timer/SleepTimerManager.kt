package com.aeroplayer.timer

import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aeroplayer.service.PlayerController

/**
 * Sleep timer: pauses playback after a user-configured time.
 * Singleton so state is shared between PlayerActivity and MiniPlayer.
 *
 * Fix: all LiveData mutations go through the main thread via mainHandler
 * to avoid mixing .value (main-thread) and .postValue (any thread) on the
 * same object, which can cause race conditions.
 */
object SleepTimerManager {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _remainingMs = MutableLiveData(0L)
    val remainingMs: LiveData<Long> = _remainingMs

    private val _isRunning = MutableLiveData(false)
    val isRunning: LiveData<Boolean> = _isRunning

    private var timer: CountDownTimer? = null

    /** Starts the timer for the given number of minutes. */
    fun start(minutes: Int) {
        cancel()
        val totalMs = minutes * 60_000L
        mainHandler.post {
            _remainingMs.value = totalMs
            _isRunning.value   = true
        }

        timer = object : CountDownTimer(totalMs, 1_000) {
            override fun onTick(millisUntilFinished: Long) {
                mainHandler.post { _remainingMs.value = millisUntilFinished }
            }

            override fun onFinish() {
                mainHandler.post {
                    _remainingMs.value = 0L
                    _isRunning.value   = false
                }
                // pause() is thread-safe (posts to main looper internally)
                PlayerController.pause()
            }
        }.start()
    }

    /** Cancels the active timer. */
    fun cancel() {
        timer?.cancel()
        timer = null
        mainHandler.post {
            _remainingMs.value = 0L
            _isRunning.value   = false
        }
    }

    /** Returns remaining time formatted as "mm:ss". */
    fun formatRemaining(ms: Long): String {
        val totalSec = ms / 1000
        return "%02d:%02d".format(totalSec / 60, totalSec % 60)
    }
}
