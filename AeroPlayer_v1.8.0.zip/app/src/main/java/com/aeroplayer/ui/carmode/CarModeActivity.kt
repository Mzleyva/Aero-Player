package com.aeroplayer.ui.carmode

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityCarModeBinding
import com.aeroplayer.service.PlayerController
import com.aeroplayer.utils.AlbumArtUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Modo Coche: interfaz simplificada con botones grandes, sin distracciones.
 * - Pantalla siempre encendida
 * - Botones de 80dp mínimo
 * - Cover de álbum de fondo (blurreado)
 * - Sin gestos complejos
 * - Voz: muestra el título actual de forma prominente
 */
class CarModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCarModeBinding

    private val songReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            updateSongUI()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Pantalla siempre encendida en modo coche
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Inmersivo: sin barra de estado
        // FIX Android 16: systemUiVisibility fue eliminado en API 35+.
        // Usar WindowInsetsController en API 30+ y fallback legacy para API 29-.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { ctrl ->
                ctrl.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                ctrl.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            )
        }

        setupButtons()
        observePlayer()
        updateSongUI()
    }

    private fun setupButtons() {
        binding.btnCarBack.setOnClickListener { finish() }

        binding.btnCarPrev.setOnClickListener {
            PlayerController.previous()
        }
        binding.btnCarPlayPause.setOnClickListener {
            PlayerController.playPause()
        }
        binding.btnCarNext.setOnClickListener {
            PlayerController.next()
        }
        binding.btnCarShuffle.setOnClickListener {
            PlayerController.toggleShuffle()
        }
        binding.btnCarRepeat.setOnClickListener {
            PlayerController.toggleRepeat()
        }
    }

    private fun observePlayer() {
        PlayerController.currentSong.observe(this) { song ->
            if (song == null) return@observe
            binding.tvCarTitle.text  = song.title
            binding.tvCarArtist.text = song.artist
            binding.tvCarAlbum.text  = song.album

            val art = AlbumArtUtils.getCached(song.id) ?: song.albumArtUri
            Glide.with(binding.ivCarCover)
                .load(art)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(binding.ivCarCover)

            // Fondo blurreado
            Glide.with(binding.ivCarBg)
                .load(art)
                .placeholder(R.color.background_dark)
                .centerCrop()
                .into(binding.ivCarBg)
        }

        PlayerController.isPlaying.observe(this) { playing ->
            binding.btnCarPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }

        PlayerController.shuffleMode.observe(this) { enabled ->
            binding.btnCarShuffle.alpha = if (enabled) 1f else 0.4f
        }

        PlayerController.repeatMode.observe(this) { mode ->
            binding.btnCarRepeat.alpha = if (mode != androidx.media3.common.Player.REPEAT_MODE_OFF) 1f else 0.4f
        }
    }

    private fun updateSongUI() {
        PlayerController.currentSong.value?.let { song ->
            binding.tvCarTitle.text  = song.title
            binding.tvCarArtist.text = song.artist
        }
    }

    override fun onDestroy() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }
}
