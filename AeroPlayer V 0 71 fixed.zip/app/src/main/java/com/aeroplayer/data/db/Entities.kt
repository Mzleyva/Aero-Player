package com.aeroplayer.data.db

import androidx.room.*

@Entity(tableName = "liked_songs")
data class LikedSongEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val path: String,
    val duration: Long,
    val albumArtUri: String? = null,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val coverUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_songs",
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId")]
)
data class PlaylistSongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val path: String,
    val duration: Long,
    val albumArtUri: String? = null,
    val position: Int = 0
)

@Entity(tableName = "play_counts")
data class PlayCountEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val path: String,
    val albumArtUri: String? = null,
    val count: Int = 0,
    val lastPlayed: Long = System.currentTimeMillis()
)

/**
 * Almacena el GIF Canvas asignado a cada canción.
 * La URI apunta a un GIF en el almacenamiento del dispositivo, elegido
 * por el usuario desde el picker de archivos del player.
 */
@Entity(tableName = "song_canvas")
data class SongCanvasEntity(
    @PrimaryKey val songId: Long,
    /** URI del GIF elegido por el usuario (content:// o file://). */
    val gifUri: String,
    val assignedAt: Long = System.currentTimeMillis()
)

/**
 * Caché de canciones escaneadas desde MediaStore.
 * Evita re-escanear toda la biblioteca cada vez que se abre la app.
 * Se invalida cuando MediaStore notifica un cambio (archivo añadido/borrado).
 */
@Entity(tableName = "song_cache")
data class SongCacheEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val path: String,
    val albumArtUri: String?,
    val uri: String,
    val albumId: Long,
    val trackNumber: Int,
    val year: Int,
    val size: Long,
    val cachedAt: Long = System.currentTimeMillis()
)
