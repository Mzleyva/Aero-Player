package com.aeroplayer.ui.stats

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.aeroplayer.data.db.DailyPlayCount
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vista de gráfica de barras para reproducciones diarias.
 * Muestra los últimos 30 días sin dependencias externas (Canvas puro).
 */
class DailyBarChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF4A9EFF.toInt()
    }
    private val barHighPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF80BFFF.toInt()
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        textSize = 22f
        textAlign = Paint.Align.CENTER
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x22FFFFFF.toInt()
        strokeWidth = 1f
    }

    private var data: List<DailyPlayCount> = emptyList()
    private val dayFmt = SimpleDateFormat("d/M", Locale.getDefault())

    fun setData(days: List<DailyPlayCount>) {
        data = days
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) {
            // Sin datos: mensaje centrado
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x66FFFFFF.toInt()
                textSize = 32f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Sin datos aún", width / 2f, height / 2f, p)
            return
        }

        val padL = 16f; val padR = 16f
        val padT = 16f; val padB = 36f
        val chartH = height - padT - padB
        val chartW = width - padL - padR

        val maxVal = data.maxOf { it.playCount }.coerceAtLeast(1)

        // Grid line at max
        val gridY = padT
        canvas.drawLine(padL, gridY, padL + chartW, gridY, gridPaint)
        canvas.drawLine(padL, padT + chartH / 2f, padL + chartW, padT + chartH / 2f, gridPaint)

        val barCount = data.size
        val barW = chartW / barCount
        val barPad = barW * 0.18f

        data.forEachIndexed { i, day ->
            val frac   = day.playCount.toFloat() / maxVal
            val barH   = frac * chartH
            val left   = padL + i * barW + barPad
            val right  = padL + (i + 1) * barW - barPad
            val top    = padT + chartH - barH
            val bottom = padT + chartH

            // Highlight today
            val todayStart = (System.currentTimeMillis() / 86_400_000L) * 86_400_000L
            val paint = if (day.dayStart == todayStart) barHighPaint else barPaint

            val rect = RectF(left, top, right, bottom)
            canvas.drawRoundRect(rect, 4f, 4f, paint)

            // Label: only show every ~7 bars to avoid clutter
            if (i == 0 || i == barCount - 1 || i % 7 == 0) {
                val label = dayFmt.format(Date(day.dayStart))
                canvas.drawText(label, (left + right) / 2f, height - 8f, labelPaint)
            }
        }
    }
}
