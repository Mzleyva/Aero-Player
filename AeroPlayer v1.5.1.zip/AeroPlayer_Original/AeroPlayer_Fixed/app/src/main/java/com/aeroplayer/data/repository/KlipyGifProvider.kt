package com.aeroplayer.data.repository

import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

/**
 * Proveedor de GIFs animados usando la API pública de Tenor (Google).
 *
 * Usa la clave de demostración oficial de Tenor que Google provee para
 * desarrollo y pruebas — funciona sin registro y sin límites agresivos
 * para uso personal/no-comercial.
 *
 * Si la app se publica en producción, registra tu propia clave gratuita en:
 * https://developers.google.com/tenor/guides/quickstart
 *
 * MIGRACIÓN DESDE KLIPY:
 * Se reemplazó Klipy porque su API Key requería registro en Partner Panel
 * y la clave placeholder "TU_KLIPY_API_KEY_AQUI" causaba error 401/403
 * en todas las búsquedas. Tenor es la opción más estable y gratuita.
 */
object KlipyGifProvider {

    // Clave demo oficial de Tenor/Google — válida para desarrollo y uso personal.
    // Para producción reemplaza con tu clave de https://console.cloud.google.com
    private const val TENOR_API_KEY = "AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCDA"

    private const val BASE_URL = "https://tenor.googleapis.com/v2/search"
    private const val LIMIT = 16
    private const val CONTENT_FILTER = "medium" // off | low | medium | high

    // ── Modelo de resultado ───────────────────────────────────────────────────

    /** Un resultado de GIF con URLs de previsualización y tamaño completo. */
    data class GifResult(
        val id: String,
        /** URL del gif pequeño — thumbnail en el grid (≤ 220 px). */
        val previewUrl: String,
        /** URL del gif de calidad media — se usa como canvas (≈ 480 px). */
        val gifUrl: String,
        /** Título/descripción del GIF. */
        val title: String
    )

    // ── Búsqueda ──────────────────────────────────────────────────────────────

    /**
     * Busca GIFs en Tenor para [query].
     *
     * Debe llamarse en un hilo IO; lanza excepción si hay error de red.
     *
     * @param query  Texto de búsqueda (artista, canción, estado de ánimo…)
     * @param pos    Token de paginación de la llamada anterior (null = primera página).
     * @return       Par (lista de resultados, token para la siguiente página o null).
     */
    fun search(query: String, pos: String? = null): Pair<List<GifResult>, String?> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val sb = StringBuilder(
            "$BASE_URL?key=$TENOR_API_KEY" +
                    "&q=$encoded" +
                    "&limit=$LIMIT" +
                    "&contentfilter=$CONTENT_FILTER" +
                    "&media_filter=tinygif,mediumgif" +
                    "&ar_range=all"
        )
        if (pos != null) sb.append("&pos=$pos")

        val connection = URL(sb.toString()).openConnection() as java.net.HttpURLConnection
        connection.connectTimeout = 10_000
        connection.readTimeout    = 10_000
        connection.setRequestProperty("User-Agent", "AeroPlayer/1.2")
        val responseCode = connection.responseCode
        if (responseCode != 200) {
            throw java.io.IOException("Tenor API error $responseCode")
        }
        val json = JSONObject(connection.inputStream.bufferedReader().readText())

        val results = json.getJSONArray("results")
        val list = (0 until results.length()).mapNotNull { i ->
            runCatching {
                val item = results.getJSONObject(i)
                val mediaFormats = item.getJSONObject("media_formats")

                val previewUrl = mediaFormats
                    .optJSONObject("tinygif")
                    ?.optString("url") ?: return@mapNotNull null

                val gifUrl = mediaFormats
                    .optJSONObject("mediumgif")
                    ?.optString("url")
                    ?: mediaFormats.optJSONObject("tinygif")?.optString("url")
                    ?: return@mapNotNull null

                GifResult(
                    id = item.optString("id", i.toString()),
                    previewUrl = previewUrl,
                    gifUrl = gifUrl,
                    title = item.optString("title", "")
                )
            }.getOrNull()
        }

        val nextPos = json.optString("next").takeIf { it.isNotBlank() }
        return list to nextPos
    }
}
