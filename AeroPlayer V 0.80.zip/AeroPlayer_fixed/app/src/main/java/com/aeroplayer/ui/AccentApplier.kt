package com.aeroplayer.ui

import android.content.Context
import android.content.res.ColorStateList
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout

/**
 * Aplica el color de acento guardado en ThemeManager a todas las vistas
 * que en el XML tienen @color/accent_blue hardcodeado.
 *
 * Uso: llama AccentApplier.apply(context, rootView) en el onCreate/onViewCreated
 * de cada Activity/Fragment, DESPUÉS de inflar el layout.
 */
object AccentApplier {

    /**
     * Recorre toda la jerarquía de vistas y aplica el color de acento
     * a TextViews con texto de color azul, ProgressBars, TabLayouts, FABs y Switches.
     */
    fun apply(context: Context, root: ViewGroup) {
        val color = ThemeManager.getAccentColor(context)
        val csl   = ColorStateList.valueOf(color)
        applyRecursive(root, color, csl)
    }

    private fun applyRecursive(view: android.view.View, color: Int, csl: ColorStateList) {
        when (view) {
            is TabLayout -> {
                view.setSelectedTabIndicatorColor(color)
                view.setTabTextColors(
                    view.tabTextColors?.defaultColor ?: 0x88FFFFFF.toInt(),
                    color
                )
            }
            is ProgressBar -> {
                view.progressTintList = csl
                view.thumbTintList    = csl
            }
            is FloatingActionButton -> {
                view.backgroundTintList = csl
            }
            is com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton -> {
                view.backgroundTintList = csl
            }
            is com.google.android.material.switchmaterial.SwitchMaterial -> {
                view.thumbTintList  = csl
                view.trackTintList  = ColorStateList.valueOf(
                    android.graphics.Color.argb(
                        0x66,
                        android.graphics.Color.red(color),
                        android.graphics.Color.green(color),
                        android.graphics.Color.blue(color)
                    )
                )
            }
            is Switch -> {
                view.thumbTintList  = csl
                view.trackTintList  = ColorStateList.valueOf(
                    android.graphics.Color.argb(
                        0x66,
                        android.graphics.Color.red(color),
                        android.graphics.Color.green(color),
                        android.graphics.Color.blue(color)
                    )
                )
            }
            is TextView -> {
                // Solo re-tintamos TextViews cuyo color actual sea el azul por defecto (#4A9EFF)
                val currentColor = view.currentTextColor
                if (isDefaultAccentBlue(currentColor)) {
                    view.setTextColor(color)
                }
            }
            is ImageView -> {
                // Tintamos ImageViews que tienen tint azul explícito
                val tintList = view.imageTintList
                if (tintList != null && isDefaultAccentBlue(tintList.defaultColor)) {
                    view.imageTintList = csl
                }
            }
        }

        // Recursar en ViewGroups
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                applyRecursive(view.getChildAt(i), color, csl)
            }
        }
    }

    /**
     * Compara con tolerancia si el color es el azul por defecto #4A9EFF
     * o variantes con distintos valores de alpha.
     */
    private fun isDefaultAccentBlue(color: Int): Boolean {
        // Ignorar alpha, comparar solo RGB
        val r = android.graphics.Color.red(color)
        val g = android.graphics.Color.green(color)
        val b = android.graphics.Color.blue(color)
        // #4A9EFF = R:74 G:158 B:255
        return r in 60..90 && g in 140..175 && b == 255
    }
}
