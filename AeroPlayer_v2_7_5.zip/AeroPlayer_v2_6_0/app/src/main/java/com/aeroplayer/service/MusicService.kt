package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.R
import androidx.media3.common.util.UnstableApi

/**
 * MusicService — servicio de reproducción limpio basado en Media3 MediaSessionService.
 *
 * DISEÑO DELIBERADAMENTE SIMPLE:
 * Media3 genera la notificación de reproducción automáticamente.
 * NO creamos notificaciones manuales — una sola notificación, sin loops.
 *
 * Gapless: ExoPlayer precarga el siguiente item automáticamente con su
 * DefaultLoadControl interno. No necesitamos configurarlo manualmente;
 * el gapless funciona por defecto en Media3 con REPEAT_MODE_OFF.
 */
@UnstableApi
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
        @Volatile var instance: MusicService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setAllowedCapturePolicy(C.ALLOW_CAPTURE_BY_NONE)
            .build()

        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxAudioBitrate(Int.MAX_VALUE)
                    .setMaxAudioChannelCount(8)
                    .setPreferredAudioMimeTypes(
                        "audio/flac", "audio/alac", "audio/wav",
                        "audio/x-wav", "audio/vnd.wave", "audio/ogg",
                        "audio/opus", "audio/mpeg", "audio/aac"
                    )
                    .build()
            )
        }

        val renderersFactory = DefaultRenderersFactory(this).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        player = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()

        // FIX Android 11: registrar nuestro proveedor de notificaciones que escala
        // el bitmap de portada a máximo 256×256 antes de pasarlo a la notificación.
        // Sin esto, bitmaps de 600×600 (~1.4 MB) superan el límite IPC de SystemUI
        // en Android 11 y crashean el sistema operativo completo.
        setMediaNotificationProvider(AeroMediaNotificationProvider.create(this))

        AudioDeviceEqRouter.register(this)
        instance = this
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        AudioDeviceEqRouter.unregister(this)
        audioSessionId = 0
        instance = null
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}
