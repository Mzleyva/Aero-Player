package com.aeroplayer.model

/**
 * Resultado de búsqueda / stream de YouTube Music.
 *
 * [id]           → videoId de YouTube (ej. "dQw4w9WgXcQ")
 * [streamUrl]    → URL de stream resuelto por NewPipeExtractor (puede ser null hasta resolve)
 * [mimeType]     → "audio/mp4" o "audio/webm" según el formato elegido
 * [isYTMusic]    → siempre true; distingue canciones locales de YTM en el player
 */
data class YTSong(
    val id: String,                      // videoId
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0L,
    val thumbnailUrl: String? = null,
    var streamUrl: String? = null,       // resuelto de forma lazy
    val mimeType: String = "audio/mp4",
    val isYTMusic: Boolean = true
) {
    /** Convierte a Song local para que PlayerController / ExoPlayer lo reproduzca. */
    fun toSong(resolvedStreamUrl: String): com.aeroplayer.model.Song {
        val uri = android.net.Uri.parse(resolvedStreamUrl)
        val thumbUri = thumbnailUrl?.let { android.net.Uri.parse(it) }
        return Song(
            id           = id.hashCode().toLong(),
            title        = title,
            artist       = artist,
            album        = album.ifBlank { "YouTube Music" },
            duration     = durationMs,
            path         = resolvedStreamUrl,
            uri          = uri,
            albumArtUri  = thumbUri,
            mimeType     = mimeType,
            bitrate      = 0
        )
    }
}

/** Una playlist de YouTube Music. */
data class YTPlaylist(
    val id: String,               // playlistId (ej. "PLxxxxxxx")
    val name: String,
    val description: String = "",
    val thumbnailUrl: String? = null,
    val songCount: Int = 0,
    val songs: List<YTSong> = emptyList()
)

/** Estado del proceso de búsqueda / resolución de stream. */
sealed class YTResult<out T> {
    data class Success<T>(val data: T) : YTResult<T>()
    data class Error(val message: String, val cause: Throwable? = null) : YTResult<Nothing>()
    object Loading : YTResult<Nothing>()
}
