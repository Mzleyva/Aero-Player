package com.aeroplayer.data.repository

import android.content.Context
import android.provider.MediaStore
import com.aeroplayer.model.LocalVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Sesión 8: escanea videos locales de MediaStore.
 * Solo incluye formatos de video conocidos (mp4, mkv, webm, avi, mov, 3gp).
 * Excluye videos muy cortos (<3 segundos) para evitar GIFs y vídeos de sistema.
 */
class VideoRepository(private val context: Context) {

    companion object {
        private val VIDEO_MIME_TYPES = setOf(
            "video/mp4", "video/x-matroska", "video/webm",
            "video/avi", "video/quicktime", "video/3gpp",
            "video/x-msvideo", "video/mpeg", "video/mp2t"
        )
        private const val MIN_DURATION_MS = 3_000L
    }

    suspend fun getLocalVideos(): List<LocalVideo> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<LocalVideo>()

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_ADDED
        )

        val mimeFilter = VIDEO_MIME_TYPES.joinToString(",") { "?" }
        val selection = "${MediaStore.Video.Media.MIME_TYPE} IN ($mimeFilter) " +
                        "AND ${MediaStore.Video.Media.DURATION} >= ?"
        val selArgs = (VIDEO_MIME_TYPES.toList() + listOf(MIN_DURATION_MS.toString())).toTypedArray()
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection, selection, selArgs, sortOrder
        )?.use { cursor ->
            val idCol       = cursor.getColumnIndex(MediaStore.Video.Media._ID)
            val titleCol    = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
            val durCol      = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
            val pathCol     = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
            val mimeCol     = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
            val sizeCol     = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
            val widthCol    = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
            val heightCol   = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
            val dateAddCol  = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val contentUri = android.net.Uri.withAppendedPath(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()
                )
                // Thumbnail de MediaStore (frame del video)
                val thumbUri = android.net.Uri.parse(
                    "content://media/external/video/media/$id/thumbnail"
                )
                videos.add(LocalVideo(
                    id           = id,
                    title        = cursor.getString(titleCol) ?: "Video",
                    duration     = if (durCol >= 0) cursor.getLong(durCol) else 0L,
                    path         = if (pathCol >= 0) cursor.getString(pathCol) ?: "" else "",
                    uri          = contentUri,
                    thumbnailUri = thumbUri,
                    size         = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L,
                    width        = if (widthCol >= 0) cursor.getInt(widthCol) else 0,
                    height       = if (heightCol >= 0) cursor.getInt(heightCol) else 0,
                    mimeType     = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "" else "",
                    dateAdded    = if (dateAddCol >= 0) cursor.getLong(dateAddCol) else 0L
                ))
            }
        }
        videos
    }
}
