package com.aeroplayer.utils

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import com.aeroplayer.data.db.LikedSongEntity
import com.aeroplayer.data.db.PlaylistSongEntity
import com.aeroplayer.model.Song

/**
 * Reconstruye un objeto Song a partir de una entidad de la base de datos.
 *
 * IMPORTANTE: Siempre usa ContentUris.withAppendedId para reconstruir la URI
 * de reproducción en lugar de Uri.parse(path). En Android 10+ las rutas
 * /storage/emulated/0/... ya no son accesibles directamente y ExoPlayer
 * lanza un error al intentar reproducirlas. El content:// URI generado por
 * ContentUris siempre funciona si el archivo sigue existiendo en MediaStore.
 */
object SongBuilder {

    fun fromLiked(e: LikedSongEntity): Song = Song(
        id          = e.songId,
        title       = e.title,
        artist      = e.artist,
        album       = e.album,
        duration    = e.duration,
        path        = e.path,
        uri         = ContentUris.withAppendedId(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, e.songId
        ),
        albumArtUri = e.albumArtUri?.let { Uri.parse(it) },
        isLiked     = true
    )

    fun fromPlaylistSong(e: PlaylistSongEntity): Song = Song(
        id          = e.songId,
        title       = e.title,
        artist      = e.artist,
        album       = e.album,
        duration    = e.duration,
        path        = e.path,
        uri         = ContentUris.withAppendedId(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, e.songId
        ),
        albumArtUri = e.albumArtUri?.let { Uri.parse(it) }
    )
}
