package com.aeroplayer.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.collection.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object AlbumArtUtils {

    // Cache en memoria: hasta 1/6 de la RAM disponible, máx 32MB
    // (balance entre fluidez de scroll y no presionar al GC en dispositivos con poca RAM)
    private val memCache: LruCache<Long, Bitmap> = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 6).toInt().coerceAtMost(32 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }

    // IDs que ya intentamos y no tienen carátula — evita re-leer el archivo
    // Limitado a 2000 entradas para no crecer indefinidamente en librerías grandes
    private val noArtIds = object : LinkedHashSet<Long>() {
        override fun add(element: Long): Boolean {
            if (size >= 2000) iterator().also { it.next(); it.remove() }
            return super.add(element)
        }
    }

    // Scope propio para pre-carga en background sin atar al ciclo de vida de ninguna Activity
    private val preloadScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** Cache hit instantáneo — usar en onBindViewHolder */
    fun getCached(songId: Long): Bitmap? = memCache.get(songId)

    /** Invalida el caché de una canción específica (p.ej. al cambiar portada). */
    fun invalidateCache(songId: Long) {
        memCache.remove(songId)
        noArtIds.remove(songId)
    }

    /** Carga desde archivo en hilo IO. Si no hay carátula embebida, busca online. */
    suspend fun loadArt(songId: Long, filePath: String, artist: String = "", album: String = ""): Bitmap? {
        memCache.get(songId)?.let { return it }
        if (songId in noArtIds) return null

        return withContext(Dispatchers.IO) {
            // 1. Intentar extraer carátula embebida en el archivo de audio
            val embedded = runCatching {
                MediaMetadataRetriever().use { mmr ->
                    mmr.setDataSource(filePath)
                    val art = mmr.embeddedPicture ?: return@runCatching null
                    BitmapFactory.decodeByteArray(art, 0, art.size)
                }
            }.getOrNull()

            if (embedded != null) {
                memCache.put(songId, embedded)
                return@withContext embedded
            }

            // 2. Buscar online si tenemos metadatos
            if (artist.isNotBlank() || album.isNotBlank()) {
                val online = com.aeroplayer.data.repository.ArtworkProvider.fetchArtwork(artist, album)
                    ?: com.aeroplayer.data.repository.ArtworkProvider.fetchArtworkByTrack(artist, album)
                if (online != null) {
                    memCache.put(songId, online)
                    return@withContext online
                }
            }

            noArtIds.add(songId)
            null
        }
    }

    /**
     * Pre-carga en background pasando también artist/album para
     * activar búsqueda online si no hay carátula embebida.
     */
    fun preloadWithMeta(songs: List<Triple<Long, String, com.aeroplayer.model.Song>>) {
        songs.forEach { (id, path, song) ->
            if (memCache.get(id) == null && id !in noArtIds) {
                preloadScope.launch {
                    loadArt(id, path, song.artist, song.album)
                }
            }
        }
    }

    /**
     * Pre-carga en background una lista de canciones sin bloquear nada.
     */
    fun preload(songs: List<Pair<Long, String>>) {
        songs.forEach { (id, path) ->
            if (memCache.get(id) == null && id !in noArtIds) {
                preloadScope.launch {
                    loadArt(id, path)
                }
            }
        }
    }

    /** Versión síncrona — SOLO usar desde Dispatchers.IO */
    fun getAlbumArt(songId: Long, filePath: String): Bitmap? {
        memCache.get(songId)?.let { return it }
        if (songId in noArtIds) return null

        return runCatching {
            MediaMetadataRetriever().use { mmr ->
                mmr.setDataSource(filePath)
                val art = mmr.embeddedPicture ?: return null
                BitmapFactory.decodeByteArray(art, 0, art.size)
            }
        }.getOrNull().also { bmp ->
            if (bmp != null) memCache.put(songId, bmp)
            else noArtIds.add(songId)
        }
    }

    fun clearCache() {
        memCache.evictAll()
        noArtIds.clear()
    }

    /** Elimina una canción específica del caché para forzar re-búsqueda. */
    fun clearSongFromCache(songId: Long) {
        memCache.remove(songId)
        noArtIds.remove(songId)
    }
}
