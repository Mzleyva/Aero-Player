package com.aeroplayer.ui

import android.content.Context
import android.graphics.Color
import android.net.Uri

/**
 * Gestiona las preferencias de personalización visual de AeroPlayer:
 *  - Color de acento (6 opciones)
 *  - Fondo personalizado (URI de imagen)
 */
object ThemeManager {

    // ── Colores de acento disponibles ────────────────────────────────────────
    data class AccentColor(val nameEs: String, val color: Int, val key: String)

    val accentOptions = listOf(
        AccentColor("Azul",     Color.parseColor("#4A9EFF"), "blue"),
        AccentColor("Verde",    Color.parseColor("#3DDC84"), "green"),
        AccentColor("Rosa",     Color.parseColor("#FF5C8D"), "pink"),
        AccentColor("Naranja",  Color.parseColor("#FF8C42"), "orange"),
        AccentColor("Morado",   Color.parseColor("#A855F7"), "purple"),
        AccentColor("Rojo",     Color.parseColor("#FF4444"), "red"),
        AccentColor("Cyan",     Color.parseColor("#22D3EE"), "cyan"),
        AccentColor("Dorado",   Color.parseColor("#F59E0B"), "gold"),
    )

    fun getAccentColor(context: Context): Int {
        val key = prefs(context).getString("accent_color_key", "blue") ?: "blue"
        return accentOptions.firstOrNull { it.key == key }?.color
            ?: accentOptions[0].color
    }

    fun setAccentColor(context: Context, key: String) {
        prefs(context).edit().putString("accent_color_key", key).apply()
    }

    fun getCurrentAccentKey(context: Context): String =
        prefs(context).getString("accent_color_key", "blue") ?: "blue"

    // ── Fondo personalizado ──────────────────────────────────────────────────
    fun getCustomBackground(context: Context): Uri? {
        val uriStr = prefs(context).getString("custom_background_uri", null) ?: return null
        return Uri.parse(uriStr)
    }

    fun setCustomBackground(context: Context, uri: Uri) {
        // Persistir permiso
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        prefs(context).edit().putString("custom_background_uri", uri.toString()).apply()
    }

    fun clearCustomBackground(context: Context) {
        prefs(context).edit().remove("custom_background_uri").apply()
    }

    fun hasCustomBackground(context: Context): Boolean =
        prefs(context).contains("custom_background_uri")

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun prefs(context: Context) =
        context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
}
