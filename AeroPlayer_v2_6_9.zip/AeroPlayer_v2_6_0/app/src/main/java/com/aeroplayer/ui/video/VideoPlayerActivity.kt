package com.aeroplayer.ui.video

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.model.LocalVideo
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * VideoPlayerActivity v3 — UI estilo YouTube Music para videos.
 *
 * MODO AUDIO_ONLY → delega en PlayerController + PlayerActivity (igual que antes).
 * MODO VIDEO → UI inmersiva con:
 *   · Barra superior semitransparente con título y botón de cerrar.
 *   · Video centrado con ajuste automático de aspecto.
 *   · Barra inferior con: posición | ◀◀ | ▶/⏸ | ▶▶ | tiempo total | 🎵
 *   · SeekBar con color accent sobre fondo oscuro translúcido.
 *   · Auto-hide de controles a los 3s, tap para mostrar/ocultar.
 *   · Orientación automática según aspecto del video.
 */
class VideoPlayerActivity : AppCompatActivity() {

    private var mediaPlayer: android.media.MediaPlayer? = null
    private lateinit var surfaceView:  SurfaceView
    private lateinit var tvTitle:      TextView
    private lateinit var btnPlayPause: ImageView
    private lateinit var seekBar:      SeekBar
    private lateinit var tvPosition:   TextView
    private lateinit var tvDuration:   TextView
    private lateinit var topBar:       android.widget.FrameLayout
    private lateinit var bottomBar:    LinearLayout
    private var isPlaying      = false
    private var musicWasPaused = false
    private val seekHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var controlsVisible = true
    private var hideRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        supportActionBar?.hide()

        val videoUri   = Uri.parse(intent.getStringExtra("video_uri") ?: return finish())
        val videoTitle = intent.getStringExtra("video_title") ?: "Video"
        val duration   = intent.getLongExtra("video_duration", 0L)
        val thumbUri   = intent.getStringExtra("video_thumb")
        val playMode   = runCatching {
            LocalVideo.PlayMode.valueOf(intent.getStringExtra("play_mode") ?: "AUDIO_ONLY")
        }.getOrDefault(LocalVideo.PlayMode.AUDIO_ONLY)

        // ── MODO AUDIO_ONLY: abrir PlayerActivity con la canción ───────────────
        if (playMode == LocalVideo.PlayMode.AUDIO_ONLY) {
            val song = com.aeroplayer.model.Song(
                id          = intent.getLongExtra("video_id", 0L),
                title       = videoTitle,
                artist      = "",
                album       = "",
                duration    = duration,
                path        = "",
                uri         = videoUri,
                albumArtUri = thumbUri?.let { Uri.parse(it) },
                mimeType    = "video/mp4"
            )
            PlayerController.playSongs(listOf(song), 0, videoTitle)
            startActivity(android.content.Intent(this,
                com.aeroplayer.ui.player.PlayerActivity::class.java))
            finish(); return
        }

        // ── MODO VIDEO: UI estilo YT Music ────────────────────────────────────
        setImmersive()
        buildVideoUI(videoUri, videoTitle, duration, thumbUri)
    }

    // ── Construcción de la UI ─────────────────────────────────────────────────
    private fun buildVideoUI(videoUri: Uri, videoTitle: String, duration: Long, thumbUri: String?) {
        val root = android.widget.FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // ── Video surface ─────────────────────────────────────────────────────
        surfaceView = SurfaceView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER)
        }
        root.addView(surfaceView)

        // ── Tap para mostrar/ocultar controles ────────────────────────────────
        root.setOnClickListener { toggleControls() }

        // ── Barra SUPERIOR — título + cerrar ──────────────────────────────────
        topBar = android.widget.FrameLayout(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                72.dp, Gravity.TOP)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xCC000000.toInt(), 0x00000000)
            )
        }

        tvTitle = TextView(this).apply {
            text = videoTitle; textSize = 15f
            setTextColor(android.graphics.Color.WHITE)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
            isSelected = true
            val lp = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
            )
            lp.marginStart = 56.dp; lp.marginEnd = 56.dp
            lp.topMargin   = statusBarHeight()
            layoutParams   = lp
        }

        val btnClose = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(0xCCFFFFFF.toInt())
            val lp = android.widget.FrameLayout.LayoutParams(44.dp, 44.dp, Gravity.END or Gravity.CENTER_VERTICAL)
            lp.marginEnd = 8.dp; lp.topMargin = statusBarHeight()
            layoutParams = lp
            background = rippleDrawable()
            setOnClickListener { finish() }
        }

        topBar.addView(tvTitle)
        topBar.addView(btnClose)
        root.addView(topBar)

        // ── Barra INFERIOR — controles de reproducción ────────────────────────
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM)
            layoutParams = lp
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(0xDD000000.toInt(), 0x00000000)
            )
            setPadding(0, 24.dp, 0, navBarHeight() + 12.dp)
        }

        // SeekBar
        seekBar = SeekBar(this).apply {
            max = duration.toInt().coerceAtLeast(1)
            progressTintList  = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            thumbTintList     = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0x55FFFFFF)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(16.dp, 0, 16.dp, 0)
            layoutParams = lp
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) { mediaPlayer?.seekTo(p); tvPosition.text = formatMs(p.toLong()) }
                }
                override fun onStartTrackingTouch(sb: SeekBar)  {}
                override fun onStopTrackingTouch(sb: SeekBar)   {}
            })
        }
        bottomBar.addView(seekBar)

        // Fila de botones
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp, 4.dp, 16.dp, 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        tvPosition = TextView(this).apply {
            text = "0:00"; textSize = 12f
            setTextColor(0xCCFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // Spacer izquierdo
        val spLeft = android.view.View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }

        // Botón retroceder 10s
        val btnRewind = ImageView(this).apply {
            setImageResource(R.drawable.ic_replay_10)
            imageTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
            val lp = LinearLayout.LayoutParams(44.dp, 44.dp)
            lp.marginEnd = 8.dp; layoutParams = lp
            background = rippleDrawable()
            setOnClickListener {
                mediaPlayer?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) }
            }
        }

        // Botón play/pausa — más grande, estilo YT
        btnPlayPause = ImageView(this).apply {
            setImageResource(R.drawable.ic_pause)
            imageTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
            val lp = LinearLayout.LayoutParams(56.dp, 56.dp)
            layoutParams = lp
            background = rippleDrawable()
            setOnClickListener { togglePlayPause() }
        }

        // Botón adelantar 10s
        val btnForward = ImageView(this).apply {
            setImageResource(R.drawable.ic_forward_10)
            imageTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
            val lp = LinearLayout.LayoutParams(44.dp, 44.dp)
            lp.marginStart = 8.dp; layoutParams = lp
            background = rippleDrawable()
            setOnClickListener {
                mediaPlayer?.let { it.seekTo((it.currentPosition + 10_000).coerceAtMost(it.duration)) }
            }
        }

        // Spacer derecho
        val spRight = android.view.View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }

        tvDuration = TextView(this).apply {
            text = formatMs(duration); textSize = 12f
            setTextColor(0xCCFFFFFF.toInt())
        }

        // Botón cambiar a modo audio (ícono nota musical)
        val btnAudio = ImageView(this).apply {
            setImageResource(R.drawable.ic_music_note)
            imageTintList = android.content.res.ColorStateList.valueOf(0xCCFFFFFF.toInt())
            val lp = LinearLayout.LayoutParams(36.dp, 36.dp)
            lp.marginStart = 16.dp; layoutParams = lp
            background = rippleDrawable()
            setOnClickListener {
                val song = com.aeroplayer.model.Song(
                    id = intent.getLongExtra("video_id", 0L),
                    title = videoTitle, artist = "", album = "",
                    duration = duration, path = "", uri = videoUri,
                    albumArtUri = intent.getStringExtra("video_thumb")?.let { Uri.parse(it) },
                    mimeType = "video/mp4"
                )
                mediaPlayer?.stop()
                PlayerController.playSongs(listOf(song), 0, videoTitle)
                startActivity(android.content.Intent(this@VideoPlayerActivity,
                    com.aeroplayer.ui.player.PlayerActivity::class.java))
                finish()
            }
        }

        btnRow.addView(tvPosition)
        btnRow.addView(spLeft)
        btnRow.addView(btnRewind)
        btnRow.addView(btnPlayPause)
        btnRow.addView(btnForward)
        btnRow.addView(spRight)
        btnRow.addView(tvDuration)
        btnRow.addView(btnAudio)
        bottomBar.addView(btnRow)
        root.addView(bottomBar)

        setContentView(root)
        scheduleHideControls()

        // Iniciar MediaPlayer cuando el Surface esté listo
        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                initMediaPlayer(videoUri, holder, duration)
            }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { mediaPlayer?.stop() }
        })
    }

    // ── MediaPlayer ──────────────────────────────────────────────────────────
    private fun initMediaPlayer(uri: Uri, holder: SurfaceHolder, durationHint: Long) {
        val activity = this
        mediaPlayer = android.media.MediaPlayer().apply {
            setDisplay(holder)
            setDataSource(activity, uri)
            setOnPreparedListener { mp ->
                val vw = mp.videoWidth; val vh = mp.videoHeight
                if (vw > 0 && vh > 0) {
                    // Orientación automática según aspecto del video
                    requestedOrientation = if (vw > vh)
                        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    else
                        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT

                    // Ajustar tamaño del SurfaceView al aspecto del video
                    val sw = activity.resources.displayMetrics.widthPixels
                    val sh = activity.resources.displayMetrics.heightPixels
                    val scale = minOf(sw.toFloat() / vw, sh.toFloat() / vh)
                    val lp = activity.surfaceView.layoutParams as android.widget.FrameLayout.LayoutParams
                    lp.width  = (vw * scale).toInt()
                    lp.height = (vh * scale).toInt()
                    lp.gravity = Gravity.CENTER
                    activity.surfaceView.layoutParams = lp
                }
                activity.seekBar.max = mp.duration.coerceAtLeast(1)
                activity.tvDuration.text = activity.formatMs(mp.duration.toLong())
                // Pausar música del fondo antes de iniciar video
                if (PlayerController.isPlaying.value == true) {
                    PlayerController.pause()
                    activity.musicWasPaused = true
                }
                mp.start()
                activity.isPlaying = true
                activity.btnPlayPause.setImageResource(R.drawable.ic_pause)
                activity.startSeekUpdate()
            }
            setOnCompletionListener {
                activity.isPlaying = false
                activity.btnPlayPause.setImageResource(R.drawable.ic_play_arrow)
                if (activity.musicWasPaused) {
                    PlayerController.play()
                    activity.musicWasPaused = false
                }
                // Mostrar controles al terminar
                activity.showControls()
            }
            prepareAsync()
        }
    }

    // ── Controles ────────────────────────────────────────────────────────────
    private fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) {
            mp.pause(); isPlaying = false
            btnPlayPause.setImageResource(R.drawable.ic_play_arrow)
            cancelHideControls()
        } else {
            mp.start(); isPlaying = true
            btnPlayPause.setImageResource(R.drawable.ic_pause)
            startSeekUpdate()
            scheduleHideControls()
        }
    }

    private fun toggleControls() {
        if (controlsVisible) hideControls() else showControls()
    }

    private fun showControls() {
        controlsVisible = true
        topBar.visibility    = android.view.View.VISIBLE
        bottomBar.visibility = android.view.View.VISIBLE
        topBar.animate().alpha(1f).setDuration(200).start()
        bottomBar.animate().alpha(1f).setDuration(200).start()
        if (isPlaying) scheduleHideControls()
    }

    private fun hideControls() {
        controlsVisible = false
        topBar.animate().alpha(0f).setDuration(300).withEndAction {
            topBar.visibility = android.view.View.GONE
        }.start()
        bottomBar.animate().alpha(0f).setDuration(300).withEndAction {
            bottomBar.visibility = android.view.View.GONE
        }.start()
    }

    private fun scheduleHideControls() {
        cancelHideControls()
        hideRunnable = Runnable { if (isPlaying) hideControls() }
        seekHandler.postDelayed(hideRunnable!!, 3_500)
    }

    private fun cancelHideControls() {
        hideRunnable?.let { seekHandler.removeCallbacks(it) }
        hideRunnable = null
    }

    private fun startSeekUpdate() {
        seekHandler.postDelayed(object : Runnable {
            override fun run() {
                val mp = mediaPlayer ?: return
                if (mp.isPlaying) {
                    val pos = mp.currentPosition
                    seekBar.progress = pos
                    tvPosition.text  = formatMs(pos.toLong())
                    seekHandler.postDelayed(this, 500)
                }
            }
        }, 500)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun setImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.hide(
                android.view.WindowInsets.Type.statusBars() or
                android.view.WindowInsets.Type.navigationBars())
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
        }
    }

    private fun rippleDrawable(): android.graphics.drawable.RippleDrawable {
        val mask = android.graphics.drawable.ShapeDrawable(android.graphics.drawable.shapes.OvalShape())
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x44FFFFFF),
            null, mask
        )
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun navBarHeight(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s/3600, (s%3600)/60, s%60)
        else "%d:%02d".format(s/60, s%60)
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    // ── Ciclo de vida ────────────────────────────────────────────────────────
    override fun onPause() {
        super.onPause()
        mediaPlayer?.pause()
        isPlaying = false
        btnPlayPause.setImageResource(R.drawable.ic_play_arrow)
        cancelHideControls()
    }

    override fun onDestroy() {
        cancelHideControls()
        seekHandler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
        if (musicWasPaused) {
            PlayerController.play()
            musicWasPaused = false
        }
        super.onDestroy()
    }
}
