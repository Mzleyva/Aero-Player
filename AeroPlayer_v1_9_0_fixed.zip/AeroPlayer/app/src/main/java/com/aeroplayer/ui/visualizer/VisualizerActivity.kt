package com.aeroplayer.ui.visualizer

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.aeroplayer.R
import com.aeroplayer.service.MusicService
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide

/**
 * VisualizerActivity — v1.8.3
 * Pantalla fullscreen con el visualizador + info de la canción actual.
 * Se puede cambiar entre modos con los botones inferiores.
 */
class VisualizerActivity : AppCompatActivity() {

    private lateinit var visualizerView: AudioVisualizerView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var ivAlbumArt: android.widget.ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        // Fullscreen
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        supportActionBar?.hide()

        // Immersive mode: oculta status bar y navigation bar
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or
                        android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }

        val root = android.widget.FrameLayout(this).apply {
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // ── Visualizador (fondo completo) ─────────────────────────────────────
        visualizerView = AudioVisualizerView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT)
        }
        root.addView(visualizerView)

        // ── Album art difuminado como fondo ───────────────────────────────────
        ivAlbumArt = android.widget.ImageView(this).apply {
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            alpha = 0.15f
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT)
        }
        root.addView(ivAlbumArt)

        // Re-añadir visualizador encima del album art
        root.removeView(visualizerView)
        root.addView(visualizerView)

        // ── Info de canción (esquina superior) ────────────────────────────────
        val infoLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 48.dp, 24.dp, 0)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP)
        }
        tvTitle = TextView(this).apply {
            textSize = 20f
            setTextColor(getColor(R.color.text_primary))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
            isSelected = true
        }
        tvArtist = TextView(this).apply {
            textSize = 14f
            setTextColor(getColor(R.color.text_secondary))
        }
        val btnClose = TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(getColor(R.color.text_secondary))
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END).also { it.topMargin = 40.dp; it.marginEnd = 24.dp }
            setOnClickListener { finish() }
        }
        infoLayout.addView(tvTitle); infoLayout.addView(tvArtist)
        root.addView(infoLayout); root.addView(btnClose)

        // ── Selector de modo (parte inferior) ─────────────────────────────────
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER
            setPadding(0, 0, 0, 32.dp)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM)
        }
        val modes = listOf(
            AudioVisualizerView.Mode.BARS   to "▊ Barras",
            AudioVisualizerView.Mode.WAVE   to "〜 Onda",
            AudioVisualizerView.Mode.CIRCLE to "◉ Círculo"
        )
        modes.forEach { (m, label) ->
            modeRow.addView(com.google.android.material.chip.Chip(this).apply {
                text = label; textSize = 12f
                chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                    if (m == AudioVisualizerView.Mode.BARS) getColor(R.color.accent_blue)
                    else getColor(R.color.surface_card))
                setTextColor(android.graphics.Color.WHITE)
                chipStrokeWidth = 1.5f
                chipStrokeColor = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = 8.dp }
                setOnClickListener {
                    visualizerView.setMode(m)
                    // Update chip backgrounds
                    (modeRow.parent as? android.view.ViewGroup)?.let { }
                    for (i in 0 until modeRow.childCount) {
                        val chip = modeRow.getChildAt(i) as? com.google.android.material.chip.Chip
                        chip?.chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                            if (chip?.text == label) getColor(R.color.accent_blue)
                            else getColor(R.color.surface_card))
                    }
                }
            })
        }
        root.addView(modeRow)
        setContentView(root)

        // ── Observar canción actual ────────────────────────────────────────────
        PlayerController.currentSong.observe(this) { song ->
            tvTitle.text  = song?.title  ?: "Sin reproducción"
            tvArtist.text = song?.artist ?: ""
            song?.albumArtUri?.let { Glide.with(this).load(it).into(ivAlbumArt) }
        }
    }

    override fun onResume() {
        super.onResume()
        visualizerView.init()
    }

    override fun onPause() {
        super.onPause()
        visualizerView.release()
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}
