package com.aeroplayer.utils

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat
import com.aeroplayer.R

/**
 * FontLayoutInflaterFactory — aplica una fuente personalizada a la actividad.
 *
 * NOTA: El nombre "LayoutInflaterFactory" se conserva por compatibilidad pero
 * la implementación usa FontApplicator.apply() sobre el decorView, que es el
 * enfoque más seguro y compatible. El factory approach con reflexión causaba
 * crash porque AppCompat verifica que mFactory2 esté libre antes de instalarlo.
 *
 * Llamar desde onPostCreate() o desde window.decorView.post{} para asegurar
 * que el layout ya fue inflado completamente.
 */
object FontLayoutInflaterFactory {

    fun install(context: Context) {
        if (context !is Activity) return
        val fontKey = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
            .getString("selected_font", "inter") ?: "inter"
        if (fontKey == "inter") return

        val fontResId = when (fontKey) {
            "outfit"        -> R.font.outfit_regular
            "nunito"        -> R.font.nunito_regular
            "poppins"       -> R.font.poppins_regular
            "montserrat"    -> R.font.montserrat_regular
            "raleway"       -> R.font.raleway_regular
            "space_grotesk" -> R.font.space_grotesk_regular
            else            -> return
        }

        val typeface = runCatching {
            ResourcesCompat.getFont(context, fontResId)
        }.getOrNull() ?: return

        // Aplicar después del layout usando post{} para garantizar que
        // el decorView ya tiene todas las vistas infladas.
        context.window?.decorView?.post {
            FontApplicator.apply(context, typeface)
        }
    }
}
