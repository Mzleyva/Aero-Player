package com.aeroplayer.ui.home

import android.app.ActivityOptions
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentHomeBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.bumptech.glide.Glide

class HomeFragment : Fragment() {

    companion object {
        // Caché de selección rápida: persiste mientras el proceso vive.
        // Se limpia al presionar Home 2 veces (ver setupDoubleHomeRefresh).
        private var cachedQuickPick: List<com.aeroplayer.model.Song>? = null

        /** Llamado desde MainActivity al detectar doble toque Home */
        fun clearQuickPickCache() {
            cachedQuickPick = null
        }
    }


    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    private lateinit var quickPickAdapter: QuickPickPageAdapter
    private lateinit var mostPlayedAdapter: SongHorizontalAdapter
    private lateinit var shortcutsAdapter: ShortcutAdapter
    private lateinit var favPlaylistsAdapter: ShortcutAdapter

    // Chips activos: conjunto de tags de género/mood seleccionados
    private val activeFilters = mutableSetOf<String>()

    // Selector de imagen para el avatar del perfil.
    // BUGFIX: usa OpenDocument en lugar de GetContent para obtener
    // FLAG_GRANT_PERSISTABLE_URI_PERMISSION y que el URI sobreviva reinicios.
    private val avatarPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        // OpenDocument otorga permiso persistible — takePersistableUriPermission lo confirma.
        runCatching {
            requireContext().contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        requireContext().getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .edit().putString("user_avatar", uri.toString()).apply()
        loadAvatar(uri.toString())
    }

    private fun loadAvatar(uriString: String?) {
        if (uriString != null) {
            val uri = android.net.Uri.parse(uriString)

            // FIX BUG FOTO DE PERFIL: la verificación de permisos era demasiado
            // estricta. Las URIs del media picker moderno (content://media/picker/...)
            // de Android 13+ y las URIs http/https no aparecen en
            // persistedUriPermissions aunque sean perfectamente accesibles.
            // El código anterior las descartaba como "permiso perdido" y borraba
            // la preferencia, haciendo que la foto nunca se pudiera guardar.
            //
            // Nueva lógica: intentar cargar siempre con Glide. Si falla (URI
            // inaccesible), Glide mostrará el placeholder automáticamente.
            // Solo limpiar la preferencia si el esquema es claramente inválido.
            val scheme = uri.scheme ?: ""
            val isLoadable = scheme == "content" || scheme == "file" ||
                             scheme == "http" || scheme == "https"

            if (isLoadable) {
                Glide.with(this)
                    .load(uri)
                    .circleCrop()
                    .placeholder(com.aeroplayer.R.drawable.ic_person)
                    .error(com.aeroplayer.R.drawable.ic_person)
                    .into(binding.btnProfile)
            } else {
                // Esquema de URI no reconocido — mostrar ícono por defecto sin borrar la preferencia
                binding.btnProfile.setImageResource(com.aeroplayer.R.drawable.ic_person)
                binding.btnProfile.setColorFilter(
                    androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.text_secondary)
                )
            }
        } else {
            binding.btnProfile.setImageResource(com.aeroplayer.R.drawable.ic_person)
            binding.btnProfile.setColorFilter(
                androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.text_secondary)
            )
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupAdapters()
        setupButtons()
        setupChips()
        observeData()

        // Cargar avatar guardado
        val savedAvatar = requireContext()
            .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .getString("user_avatar", null)
        loadAvatar(savedAvatar)
    }

    // ── Adapters ─────────────────────────────────────────────────────────────
    private fun setupAdapters() {
        // Selección rápida — lista vertical estilo YT Music
        quickPickAdapter = QuickPickPageAdapter(
            onClick = { song, songs ->
                PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.quick_pick))
                viewModel.incrementPlayCount(song)
            },
            onAddToQueue = { song ->
                PlayerController.addToQueue(song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "\"${song.title}\" agregado a la cola",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            },
            onAddToPlaylist = { song -> showQuickPickAddToPlaylist(song) },
            onViewArtist    = { artistName -> showArtistSongs(artistName) }
        )
        // Carrusel con RecyclerView + PagerSnapHelper (snap entre páginas sin restricciones de ViewPager2)
        val snapHelper = androidx.recyclerview.widget.PagerSnapHelper()
        binding.vpQuickPick.apply {
            layoutManager = androidx.recyclerview.widget.LinearLayoutManager(
                context, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false
            )
            adapter = quickPickAdapter
            isNestedScrollingEnabled = false
        }
        snapHelper.attachToRecyclerView(binding.vpQuickPick)

        // Indicadores de página
        binding.vpQuickPick.addOnScrollListener(object : androidx.recyclerview.widget.RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: androidx.recyclerview.widget.RecyclerView, newState: Int) {
                if (newState == androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_IDLE) {
                    val lm = rv.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return
                    val pos = lm.findFirstCompletelyVisibleItemPosition()
                    if (pos >= 0) updatePageIndicators(pos)
                }
            }
        })

        // Más escuchadas
        mostPlayedAdapter = SongHorizontalAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = getString(R.string.most_played))
            viewModel.incrementPlayCount(song)
        }
        binding.rvMostPlayed.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = mostPlayedAdapter
        }

        // Accesos directos
        shortcutsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvShortcuts.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = shortcutsAdapter
        }

        // Playlists favoritas
        favPlaylistsAdapter = ShortcutAdapter { shortcut -> handleShortcutClick(shortcut) }
        binding.rvFavoritePlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = favPlaylistsAdapter
        }
    }

    private fun handleShortcutClick(shortcut: Shortcut) {
        when (shortcut.type) {
            ShortcutType.PLAYLIST -> startActivity(
                Intent(requireContext(),
                    com.aeroplayer.ui.playlist.PlaylistDetailActivity::class.java)
                    .putExtra("playlistId", shortcut.id)
                    .putExtra("playlistName", shortcut.name)
            )
            ShortcutType.LIKED -> findNavController().navigate(R.id.libraryFragment)
            ShortcutType.ALBUM -> {
                val allSongs = viewModel.allSongs.value ?: return
                val albumSongs = allSongs.filter { it.album == shortcut.name }
                if (albumSongs.isNotEmpty()) {
                    PlayerController.playSongs(albumSongs, 0, queueName = shortcut.name)
                }
            }
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private fun setupButtons() {

        var lastProfileTap = 0L
        binding.btnProfile.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastProfileTap < 400) {
                showMultiProfileDialog()  // doble tap → cambiar/crear perfil
            } else {
                showProfileMenu(it)       // tap simple → menú normal
            }
            lastProfileTap = now
        }
    }

    // ── Chips de filtro ───────────────────────────────────────────────────────
    /**
     * Sistema de clasificación mejorado con pesos por campo:
     *  - song.genre  → peso 10  (tag oficial del archivo, máxima precisión)
     *  - song.artist → peso  4  (artistas conocidos del género)
     *  - song.album  → peso  2  (el álbum suele mencionar el género)
     *  - song.title  → peso  1  (solo refuerzo, evita falsos positivos por palabras comunes)
     *
     * Una canción pasa el filtro si su score ≥ SCORE_THRESHOLD.
     * Esto elimina casos como "metal" en el título de "Heavy Metal Parking Lot (documental)"
     * clasificando una canción pop como metal.
     */
    private val SCORE_THRESHOLD = 4  // requiere al menos match en genre o artista

    data class ChipDef(
        val genreKeywords  : List<String>,  // palabras clave para song.genre
        val artistKeywords : List<String>,  // artistas/palabras típicos en artista
        val albumKeywords  : List<String>,  // palabras en álbum
        val titleKeywords  : List<String>   // palabras en título (menor peso)
    )

    private val chipDefs = mapOf(
        "relax" to ChipDef(
            genreKeywords  = listOf("ambient", "chill", "chillout", "sleep", "meditation",
                                    "nature", "relaxation", "spa", "new age", "lofi", "lo-fi",
                                    "lo fi", "acoustic", "instrumental", "classical", "clásica",
                                    "piano", "calm", "peaceful", "soft"),
            artistKeywords = listOf("brian eno", "moby", "bonobo", "nils frahm", "max richter",
                                    "hammock", "tycho", "explosions in the sky"),
            albumKeywords  = listOf("relax", "chill", "sleep", "calm", "peaceful", "ambient",
                                    "acoustic", "lofi", "lo-fi", "tranquil", "serene"),
            titleKeywords  = listOf("relax", "chill", "sleep", "calm", "tranquil")
        ),
        "sad" to ChipDef(
            genreKeywords  = listOf("blues", "soul", "emo", "gothic", "dark", "melancholic",
                                    "melancholy", "sad", "tristeza", "lament", "doom"),
            artistKeywords = listOf("adele", "billie eilish", "lana del rey", "the smiths",
                                    "radiohead", "nick cave", "elliot smith", "bon iver"),
            albumKeywords  = listOf("sad", "triste", "heartbreak", "farewell", "goodbye",
                                    "blues", "lament", "tears", "llanto", "despecho"),
            titleKeywords  = listOf("sad", "triste", "lloro", "dolor", "heartbreak",
                                    "lonely", "alone", "cry", "tears", "melanchol")
        ),
        "commute" to ChipDef(
            genreKeywords  = listOf("hip hop", "hip-hop", "rap", "trap", "reggaeton",
                                    "urban", "r&b", "funk", "disco", "upbeat", "party",
                                    "workout", "energetic", "driving", "road"),
            artistKeywords = listOf("drake", "eminem", "j balvin", "bad bunny", "daddy yankee",
                                    "cardi b", "travis scott", "nicki minaj", "post malone"),
            albumKeywords  = listOf("drive", "road", "trip", "workout", "energy", "power",
                                    "commute", "hustle", "grind", "motivation"),
            titleKeywords  = listOf("drive", "road", "trip", "energy", "pump", "power",
                                    "viaje", "mover")
        ),
        "pop" to ChipDef(
            genreKeywords  = listOf("pop", "pop rock", "synth-pop", "electropop", "teen pop",
                                    "dance pop", "k-pop", "latin pop", "indie pop"),
            artistKeywords = listOf("taylor swift", "ariana grande", "ed sheeran", "dua lipa",
                                    "the weeknd", "harry styles", "olivia rodrigo", "billie",
                                    "selena gomez", "justin bieber", "shakira"),
            albumKeywords  = listOf("pop", "hits", "top", "chart", "singles", "best of",
                                    "greatest hits"),
            titleKeywords  = listOf("pop", "hits", "radio edit", "remix")
        ),
        "electronica" to ChipDef(
            genreKeywords  = listOf("electronic", "electronica", "electro", "edm", "techno",
                                    "house", "trance", "drum and bass", "dnb", "dubstep",
                                    "synthwave", "synth", "dance", "club", "rave",
                                    "electrónica", "industrial"),
            artistKeywords = listOf("daft punk", "deadmau5", "tiesto", "avicii", "martin garrix",
                                    "skrillex", "aphex twin", "kraftwerk", "chemical brothers",
                                    "massive attack", "prodigy", "underworld"),
            albumKeywords  = listOf("electronic", "electro", "edm", "techno", "house", "dance",
                                    "synth", "trance", "rave", "club"),
            titleKeywords  = listOf("edm", "techno", "house", "trance", "synth", "remix",
                                    "edit", "mix")
        ),
        "banda" to ChipDef(
            genreKeywords  = listOf("banda", "norteño", "norteña", "corrido", "sierreño",
                                    "grupero", "grupera", "ranchera", "mariachi", "nortena",
                                    "duranguense", "cumbia", "regional mexicano",
                                    "regional mexicana", "musica mexicana", "tuba"),
            artistKeywords = listOf("banda ms", "banda el recodo", "calibre 50", "los bukis",
                                    "los tigres del norte", "alejandro fernandez", "vicente fernandez",
                                    "natanael cano", "peso pluma", "eslabon armado", "nodal",
                                    "christian nodal", "grupo firme", "los yonics"),
            albumKeywords  = listOf("banda", "norteño", "corrido", "sierreño", "grupero",
                                    "ranchera", "mariachi", "regional", "mexicano"),
            titleKeywords  = listOf("corrido", "banda", "ranchera", "norteño", "sierreño",
                                    "mariachi", "grupero")
        )
    )

    private fun setupChips() {
        val chipToKey = mapOf(
            binding.chipRelax       to "relax",
            binding.chipSad         to "sad",
            binding.chipCommute     to "commute",
            binding.chipPop         to "pop",
            binding.chipElectronica to "electronica",
            binding.chipBanda       to "banda"
        )

        binding.chipPodcasts.visibility = android.view.View.GONE

        chipToKey.forEach { (chip, key) ->
            chip.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) activeFilters.add(key) else activeFilters.remove(key)
                chip.animate()
                    .scaleX(if (isChecked) 1.12f else 1f)
                    .scaleY(if (isChecked) 1.12f else 1f)
                    .setDuration(120)
                    .setInterpolator(android.view.animation.OvershootInterpolator(3f))
                    .withEndAction {
                        chip.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    }
                    .start()
                applyChipFilter()
            }
        }
    }

    /**
     * Calcula el score de una canción para un ChipDef dado.
     * Cuanto más alto el score, más probable es que la canción sea de ese género/mood.
     */
    private fun scoreSong(song: Song, def: ChipDef): Int {
        val genre  = song.genre.lowercase()
        val artist = song.artist.lowercase()
        val album  = song.album.lowercase()
        val title  = song.title.lowercase()
        var score  = 0

        // Género (peso 10): match en el tag oficial del archivo
        for (kw in def.genreKeywords) {
            if (genre.contains(kw)) { score += 10; break }
        }
        // Artista (peso 4)
        for (kw in def.artistKeywords) {
            if (artist.contains(kw)) { score += 4; break }
        }
        // Álbum (peso 2)
        for (kw in def.albumKeywords) {
            if (album.contains(kw)) { score += 2; break }
        }
        // Título (peso 1) — solo suma si ya hay algo de score para evitar falsos positivos
        if (score > 0) {
            for (kw in def.titleKeywords) {
                if (title.contains(kw)) { score += 1; break }
            }
        }
        return score
    }

    private fun applyChipFilter() {
        val allSongs = viewModel.allSongs.value ?: return

        if (activeFilters.isEmpty()) {
            buildSmartQuickPick(allSongs, viewModel.topPlayed.value ?: emptyList())
            binding.tvQuickPickSubtitle.visibility = View.GONE
            return
        }

        // Calcular score para cada canción sumando los scores de todos los chips activos
        val filtered = allSongs
            .map { song ->
                val totalScore = activeFilters.sumOf { key ->
                    val def = chipDefs[key] ?: return@sumOf 0
                    scoreSong(song, def)
                }
                song to totalScore
            }
            .filter { (_, score) -> score >= SCORE_THRESHOLD }
            .sortedByDescending { (_, score) -> score }  // mejores primero
            .map { (song, _) -> song }

        if (filtered.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            quickPickAdapter.submitList(emptyList())
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "Sin resultados para estos filtros"
        } else {
            binding.tvQuickPickEmpty.visibility = View.GONE
            // Mezclar manteniendo los top-scored al frente (primeros 5 fijos, resto aleatorio)
            val top  = filtered.take(5)
            val rest = filtered.drop(5).shuffled()
            quickPickAdapter.submitList((top + rest).take(50))
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.text = "${filtered.size} canciones encontradas"
        }
    }

    // ── Observe ───────────────────────────────────────────────────────────────
    // FIX LENTITUD: debounce para rebuildShortcutsAndFavorites.
    // Los 3 observers (allSongs, playlists, favoritePlaylistIds) se disparan casi
    // al mismo tiempo en el arranque, causando 3 rebuilds seguidos en IO.
    // Con el debounce solo se ejecuta una vez cuando todos los datos han llegado.
    private val rebuildHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var rebuildRunnable: Runnable? = null

    private fun scheduleRebuildShortcuts() {
        rebuildRunnable?.let { rebuildHandler.removeCallbacks(it) }
        val r = Runnable { rebuildShortcutsAndFavorites() }
        rebuildRunnable = r
        rebuildHandler.postDelayed(r, 150)
    }

    private fun observeData() {
        updateGreeting()

        // — Selección rápida: varía cada sesión con mezcla de estrategias —
        viewModel.topPlayed.observe(viewLifecycleOwner) { topPlayed ->
            val allSongs = viewModel.allSongs.value ?: return@observe
            buildSmartQuickPick(allSongs, topPlayed)

            // Sección "Más escuchadas": siempre basada en play count
            if (topPlayed.isNotEmpty()) {
                val topIds = topPlayed.map { it.songId }.toSet()
                val mostPlayed = allSongs
                    .filter { it.id in topIds }
                    .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
                    .take(20)
                mostPlayedAdapter.submitList(mostPlayed)
                binding.sectionMostPlayed.visibility =
                    if (mostPlayed.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }

        viewModel.allSongs.observe(viewLifecycleOwner) { songs ->
            if (songs.isNotEmpty()) {
                // Sesión 3: usar caché si existe, construir solo si es la primera vez
                val cached = cachedQuickPick
                if (cached != null && cached.isNotEmpty()) {
                    quickPickAdapter.submitList(cached)
                    updatePageIndicators(0)
                    binding.vpQuickPick.visibility = android.view.View.VISIBLE
                    binding.tvQuickPickEmpty.visibility = android.view.View.GONE
                } else if (viewModel.topPlayed.value.isNullOrEmpty()) {
                    buildSmartQuickPick(songs, emptyList())
                }
            }
            // Accesos directos: reconstruir shortcuts cuando llegan las canciones,
            // ya que freshArtMap depende de allSongs para resolver las portadas.
            val playlists = viewModel.playlists.value
            when {
                playlists == null -> { /* esperar al observer de playlists */ }
                playlists.isEmpty() -> buildShortcutsFromAlbums(songs)
                else -> scheduleRebuildShortcuts() // debounced rebuild
            }
        }

        // Accesos directos + playlists favoritas se reconstruyen juntos (con debounce)
        viewModel.playlists.observe(viewLifecycleOwner) { _ -> scheduleRebuildShortcuts() }
        viewModel.favoritePlaylistIds.observe(viewLifecycleOwner) { _ -> scheduleRebuildShortcuts() }

        // Sesión 9: Mix diario y Playlist rápida (triggers desde PlaylistsFragment)
        viewModel.triggerDailyMix.observe(viewLifecycleOwner) { trigger ->
            if (trigger == true) {
                val songs = viewModel.allSongs.value ?: return@observe
                val top   = viewModel.topPlayed.value ?: emptyList()
                buildDailyMix(songs, top)
                viewModel.triggerDailyMix.value = false
            }
        }
        viewModel.triggerQuickPlaylist.observe(viewLifecycleOwner) { trigger ->
            if (trigger == true) {
                val songs = viewModel.allSongs.value ?: return@observe
                val top   = viewModel.topPlayed.value ?: emptyList()
                buildQuickPlaylist(songs, top)
                viewModel.triggerQuickPlaylist.value = false
            }
        }
    }

    /**
     * Selección rápida inteligente: mezcla 3 estrategias en cada sesión
     * para que siempre se sienta distinta:
     *   A) Las N más reproducidas
     *   B) Canciones del mismo artista/álbum que las más reproducidas
     *   C) Relleno aleatorio del resto de la biblioteca
     */
    // ── Indicadores de página para el carrusel de selección rápida ───────────
    private fun updatePageIndicators(activePage: Int) {
        val container = binding.quickPickIndicators
        container.removeAllViews()
        val pageCount = quickPickAdapter.itemCount
        if (pageCount <= 1) { container.visibility = android.view.View.GONE; return }
        container.visibility = android.view.View.VISIBLE
        val density = resources.displayMetrics.density
        val dotSize  = (6 * density).toInt()
        val dotMargin = (4 * density).toInt()
        for (i in 0 until pageCount) {
            val dot = android.view.View(requireContext()).apply {
                val params = android.widget.LinearLayout.LayoutParams(dotSize, dotSize).also {
                    it.marginStart = dotMargin; it.marginEnd = dotMargin
                }
                layoutParams = params
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(
                        if (i == activePage)
                            androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.accent_blue)
                        else
                            androidx.core.content.ContextCompat.getColor(requireContext(), com.aeroplayer.R.color.surface_card)
                    )
                }
            }
            container.addView(dot)
        }
    }

    
    private fun buildSmartQuickPick(allSongs: List<Song>, topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>) {
        if (allSongs.isEmpty()) {
            binding.tvQuickPickEmpty.visibility = View.VISIBLE
            return
        }

        // FIX BUG QuickPick: si ya existe un caché de esta sesión, NO reconstruir.
        // buildSmartQuickPick se dispara cada vez que topPlayed cambia, incluyendo
        // cuando el usuario toca una canción (incrementPlayCount → loadTopPlayed).
        // Sin esta guard, la lista se baraja de nuevo con cada toque.
        val existing = cachedQuickPick
        if (existing != null && existing.isNotEmpty()) {
            quickPickAdapter.submitList(existing)
            return
        }

        val result = mutableListOf<Song>()

        if (topPlayed.isNotEmpty()) {
            val topIds = topPlayed.map { it.songId }.toSet()
            val topSongs = allSongs
                .filter { it.id in topIds }
                .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }

            // A) Las 5 más reproducidas
            val seed = topSongs.take(5)
            result.addAll(seed)

            // B) Canciones del mismo artista o álbum (no duplicar)
            val seedArtists = seed.map { it.artist }.toSet()
            val seedAlbums  = seed.map { it.album }.toSet()
            val related = allSongs
                .filter { it.id !in topIds &&
                           (it.artist in seedArtists || it.album in seedAlbums) }
                .shuffled()
                .take(8)
            result.addAll(related)

            // C) Relleno aleatorio con canciones que no aparecen arriba
            val usedIds = result.map { it.id }.toSet()
            val filler = allSongs
                .filter { it.id !in usedIds }
                .shuffled()
                .take((15 - result.size).coerceAtLeast(0))
            result.addAll(filler)

            // Mezclar — máx 20, el scroll horizontal da acceso a todas
            val shuffled = result.shuffled().take(20)
            cachedQuickPick = shuffled
            quickPickAdapter.submitList(shuffled)
            updatePageIndicators(0)

            // Subtítulo oculto
            binding.tvQuickPickSubtitle.visibility = View.GONE
        } else {
            // Sin historial: aleatorio puro
            val shuffled = allSongs.shuffled().take(20)
            cachedQuickPick = shuffled
            quickPickAdapter.submitList(shuffled)
            updatePageIndicators(0)
            binding.tvQuickPickSubtitle.visibility = View.VISIBLE
            binding.tvQuickPickSubtitle.visibility = View.GONE
        }

        binding.tvQuickPickEmpty.visibility = View.GONE
    }

    // ── Mix diario (Sesión 9) ─────────────────────────────────────────────────
    /**
     * Mix diario: 25 canciones generadas una vez por día basadas en:
     *  - Top reproducidas (40%)
     *  - Artistas relacionados (30%)
     *  - Descubrimiento: canciones no escuchadas recientemente (30%)
     *
     * Se regenera automáticamente al pasar la medianoche.
     */
    private fun buildDailyMix(allSongs: List<Song>, topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>) {
        if (allSongs.isEmpty()) return

        val prefs = requireContext().getSharedPreferences("home_prefs", android.content.Context.MODE_PRIVATE)
        val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US)
            .format(java.util.Date())
        val savedDay = prefs.getString("daily_mix_day", "")

        // Si ya tenemos mix del día de hoy, simplemente disparar la reproducción
        if (savedDay == today) {
            val savedIds = prefs.getString("daily_mix_ids", "")
                ?.split(",")?.mapNotNull { it.toLongOrNull() }
                ?: emptyList()
            val songs = savedIds.mapNotNull { id -> allSongs.firstOrNull { it.id == id } }
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, "🎲 Mix del día")
                return
            }
        }

        // Construir nuevo mix
        val topIds = topPlayed.map { it.songId }.toSet()
        val topSongs = allSongs.filter { it.id in topIds }
            .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
        val seedArtists = topSongs.take(5).map { it.artist }.toSet()

        val top     = topSongs.take(10).shuffled()
        val related = allSongs.filter { it.id !in topIds && it.artist in seedArtists }.shuffled().take(8)
        val discover= allSongs.filter { it.id !in topIds && it.artist !in seedArtists }.shuffled().take(7)
        val mix     = (top + related + discover).shuffled().take(25)

        // Persistir para el día de hoy
        prefs.edit()
            .putString("daily_mix_day", today)
            .putString("daily_mix_ids", mix.joinToString(",") { it.id.toString() })
            .apply()

        PlayerController.playSongs(mix, 0, "🎲 Mix del día")
    }

    // ── Playlist rápida (Sesión 9) ────────────────────────────────────────────
    /**
     * Genera una playlist rápida combinando:
     *  - Hora del día (mañana/tarde/noche → ritmo suave/activo/tranquilo)
     *  - Las más escuchadas del artista actual (si hay canción reproduciéndose)
     *  - Las más gustadas (isLiked = true)
     */
    private fun buildQuickPlaylist(allSongs: List<Song>, topPlayed: List<com.aeroplayer.data.db.PlayCountEntity>) {
        if (allSongs.isEmpty()) return

        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val currentSong = PlayerController.currentSong.value

        // Selección por hora
        val moodKeywords = when {
            hour in 6..9   -> listOf("acoustic", "morning", "chill", "acoustic", "lofi")  // mañana suave
            hour in 10..17 -> listOf("energy", "pop", "rock", "workout", "motivation")     // tarde activa
            hour in 18..21 -> listOf("evening", "jazz", "blues", "indie", "mellow")        // tarde-noche
            else            -> listOf("ambient", "chill", "sleep", "calm", "relax")         // noche tranquila
        }

        val topIds = topPlayed.map { it.songId }.toSet()

        // Canciones del artista actual (si hay reproducción)
        val sameArtist = if (currentSong != null) {
            allSongs.filter { it.artist.equals(currentSong.artist, ignoreCase = true)
                              && it.id != currentSong.id }.take(5)
        } else emptyList()

        // Más gustadas
        val liked = allSongs.filter { it.isLiked }.shuffled().take(8)

        // Por mood/hora
        val byMood = allSongs.filter { song ->
            val hay = "${song.title} ${song.genre} ${song.artist}".lowercase()
            moodKeywords.any { hay.contains(it) }
        }.shuffled().take(7)

        // Top reproducidas como relleno
        val top = allSongs.filter { it.id in topIds }
            .sortedByDescending { s -> topPlayed.find { it.songId == s.id }?.count ?: 0 }
            .take(5)

        val combined = (sameArtist + liked + byMood + top)
            .distinctBy { it.id }
            .shuffled()
            .take(20)
            .let { if (it.isEmpty()) allSongs.shuffled().take(20) else it }

        PlayerController.playSongs(combined, 0, "⚡ Playlist rápida")
    }

    /**
     * Reconstruye los accesos directos de playlists favoritas en el Home.
     * Si no hay playlists, muestra los álbumes más escuchados.
     */
    private fun rebuildShortcutsAndFavorites() {
        val playlists = viewModel.playlists.value ?: return
        val favIds    = viewModel.favoritePlaylistIds.value ?: emptySet()

        // Mapa songId → albumArtUri fresca del MediaStore actual.
        // Evita usar la URI almacenada en playlist_songs que puede quedar stale
        // si el MediaStore rescaneó y cambió los albumIds.
        // FIX portadas: si allSongs aún no cargó, usar lista vacía e intentar de nuevo
        // cuando el observer de allSongs dispare buildShortcuts()
        val songs = viewModel.allSongs.value
        val freshArtMap: Map<Long, String?> = songs?.associate { it.id to it.albumArtUri?.toString() }
            ?: emptyMap()
        // Si no hay canciones aún, el observer de allSongs llamará buildShortcuts() cuando carguen
        if (songs.isNullOrEmpty()) return

        viewLifecycleOwner.lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            // FIX PORTADAS DEFINITIVO: construir URI de albumart directamente desde songId
            // via MediaStore en lugar de depender de URIs guardadas que quedan stale.
            suspend fun resolveAlbumArtUri(songId: Long): String? {
                // 1. freshArtMap: URIs de la sesión de MediaStore actual
                val fresh = freshArtMap[songId]
                if (fresh != null) return fresh
                // 2. Buscar en allSongs por si el mapa no tiene el key exacto
                val songFromList = songs?.firstOrNull { it.id == songId }
                if (songFromList?.albumArtUri != null) return songFromList.albumArtUri.toString()
                // 3. Construir URI directamente desde el ALBUM_ID actual en ContentResolver
                try {
                    val songUri = android.content.ContentUris.withAppendedId(
                        android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId)
                    val cursor = requireContext().contentResolver.query(
                        songUri,
                        arrayOf(android.provider.MediaStore.Audio.Media.ALBUM_ID),
                        null, null, null
                    )
                    cursor?.use { c ->
                        if (c.moveToFirst()) {
                            val albumId = c.getLong(0)
                            val artUri = android.content.ContentUris.withAppendedId(
                                android.net.Uri.parse("content://media/external/audio/albumart"),
                                albumId
                            )
                            requireContext().contentResolver.openInputStream(artUri)?.use {
                                return artUri.toString()
                            }
                        }
                    }
                } catch (_: Exception) {}
                return null
            }

            suspend fun playlistCover(p: com.aeroplayer.data.db.PlaylistEntity): String? {
                if (p.coverUri != null) return p.coverUri
                val firstSongId = viewModel.getPlaylistFirstSongId(p.id) ?: return null
                return resolveAlbumArtUri(firstSongId)
            }

            val favPlaylists = playlists
                .filter { it.id in favIds }
                .map { p -> com.aeroplayer.ui.home.Shortcut(p.id, p.name, playlistCover(p), ShortcutType.PLAYLIST) }

            val nonFavPlaylists = playlists
                .filter { it.id !in favIds }
                .take(6)
                .map { p -> com.aeroplayer.ui.home.Shortcut(p.id, p.name, playlistCover(p), ShortcutType.PLAYLIST) }
                .toMutableList()

            // "Me gusta" va primero — usar mismo resolveAlbumArtUri para evitar URIs stale
            val likedFirstSongId = viewModel.getLikedFirstSongId()
            val likedCover = if (likedFirstSongId != null) {
                resolveAlbumArtUri(likedFirstSongId) ?: viewModel.getLikedFirstArtUri()
            } else {
                viewModel.getLikedFirstArtUri()
            }
            nonFavPlaylists.add(0, com.aeroplayer.ui.home.Shortcut(-1L, "Me gusta", likedCover, ShortcutType.LIKED))

            withContext(kotlinx.coroutines.Dispatchers.Main) {
                if (!isAdded) return@withContext

                favPlaylistsAdapter.submitList(favPlaylists)
                binding.sectionFavoritePlaylists.visibility =
                    if (favPlaylists.isNotEmpty()) View.VISIBLE else View.GONE

                if (nonFavPlaylists.isNotEmpty()) {
                    shortcutsAdapter.submitList(nonFavPlaylists)
                    binding.rvShortcuts.visibility = View.VISIBLE
                } else {
                    buildShortcutsFromAlbums(viewModel.allSongs.value ?: emptyList())
                }
            }
        }
    }

    private fun buildShortcutsFromAlbums(songs: List<Song>) {
        if (!viewModel.playlists.value.isNullOrEmpty()) return
        val topAlbums = songs
            .groupBy { it.album }
            .entries
            .sortedByDescending { it.value.size }
            .take(6)
            .map { (album, albumSongs) ->
                Shortcut(
                    id       = album.hashCode().toLong(),
                    name     = album,
                    coverUri = albumSongs.firstOrNull()?.albumArtUri?.toString(),
                    type     = ShortcutType.ALBUM
                )
            }
        if (topAlbums.isNotEmpty()) shortcutsAdapter.submitList(topAlbums)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    // FIX: guardar el Runnable del saludo para cancelarlo antes de postear uno nuevo.
    // Sin esto, cada llamada a updateGreeting() apila un nuevo postDelayed de 1.8s
    // causando múltiples animaciones concurrentes si el usuario abre el profile dialog.
    private val greetingHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var greetingRunnable: Runnable? = null

    private fun updateGreeting() {
        val name = viewModel.getProfileName()
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val timeGreet = when {
            hour < 12 -> "Buenos días"
            hour < 18 -> "Buenas tardes"
            else      -> "Buenas noches"
        }
        // Si el usuario no configuró su nombre, mostrar solo el saludo de tiempo
        val greetText = if (name.isBlank()) timeGreet else "$timeGreet, $name"

        // FIX BUG#4: solo usamos tvAppName para el saludo animado.
        val appNameView = binding.tvAppName

        // Mostrar primero el nombre de la app
        appNameView.alpha = 1f
        appNameView.text  = getString(R.string.app_name)

        // Cancelar cualquier animación pendiente antes de programar una nueva
        greetingRunnable?.let { greetingHandler.removeCallbacks(it) }

        // Después de 1.8s, animar transición al saludo personalizado
        val runnable = Runnable {
            if (!isAdded) return@Runnable
            appNameView.animate()
                .alpha(0f)
                .setDuration(400)
                .withEndAction {
                    if (!isAdded) return@withEndAction
                    appNameView.text = greetText
                    appNameView.animate()
                        .alpha(1f)
                        .setDuration(400)
                        .start()
                }.start()
        }
        greetingRunnable = runnable
        greetingHandler.postDelayed(runnable, 1800)

        // Fetch del clima en background (solo si no hay dato ya mostrado)
        fetchWeather()
    }

    /**
     * Convierte la condición meteorológica de wttr.in a un emoji representativo.
     * Mejora la legibilidad sin depender de imágenes externas.
     */
    private fun weatherEmoji(condition: String): String {
        val c = condition.lowercase()
        return when {
            c.contains("sol") || c.contains("despejad") || c.contains("clear") || c.contains("sunny") -> "☀️"
            c.contains("parcial") || c.contains("partly") || c.contains("patchy") -> "⛅"
            c.contains("nublad") || c.contains("overcast") || c.contains("cloudy") -> "☁️"
            c.contains("lluvia") || c.contains("rain") || c.contains("drizzle") || c.contains("llovizna") -> "🌧️"
            c.contains("tormenta") || c.contains("thunder") || c.contains("storm") -> "⛈️"
            c.contains("nieve") || c.contains("snow") || c.contains("sleet") -> "❄️"
            c.contains("niebla") || c.contains("fog") || c.contains("mist") || c.contains("bruma") -> "🌫️"
            c.contains("viento") || c.contains("wind") -> "💨"
            c.contains("noche") || c.contains("night") -> "🌙"
            else -> "🌡️"
        }
    }

    private fun fetchWeather() {
        viewLifecycleOwner.lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val client = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                // wttr.in JSON v2 — más fiable para idioma que el formato texto
                val req = okhttp3.Request.Builder()
                    .url("https://wttr.in/?format=j1&lang=es")
                    .header("User-Agent", "AeroPlayer/1.0")
                    .header("Accept-Language", "es-ES,es;q=0.9")
                    .build()

                val body = client.newCall(req).execute().body?.string()?.trim()
                    ?: return@runCatching

                // Parsear JSON básico para extraer condición y temperatura
                val json = org.json.JSONObject(body)
                val current = json.getJSONArray("current_condition").getJSONObject(0)
                val tempC   = current.getString("temp_C")

                // La descripción en español viene en langDesc
                val langArray = current.optJSONArray("lang_es")
                val condEs = if (langArray != null && langArray.length() > 0) {
                    langArray.getJSONObject(0).optString("value", "")
                } else {
                    // Fallback: traducción manual de weatherDesc en inglés
                    val descEn = current.optJSONArray("weatherDesc")
                        ?.optJSONObject(0)?.optString("value", "") ?: ""
                    translateWeatherCondition(descEn)
                }

                if (condEs.isNotBlank()) {
                    val emoji = weatherEmoji(condEs)
                    val text  = "$emoji $condEs $tempC°C"
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        if (!isAdded) return@withContext
                        binding.tvWeather?.let { tv ->
                            tv.text = text
                            tv.alpha = 0f
                            tv.visibility = android.view.View.VISIBLE
                            tv.animate().alpha(1f).setDuration(400).start()
                        }
                    }
                }
            }
        }
    }

    /** Traduce condiciones meteorológicas comunes del inglés al español. */
    private fun translateWeatherCondition(en: String): String {
        val e = en.lowercase()
        return when {
            e.contains("sunny") || e.contains("clear")          -> "Despejado"
            e.contains("partly cloudy")                          -> "Parcialmente nublado"
            e.contains("cloudy") || e.contains("overcast")       -> "Nublado"
            e.contains("mist") || e.contains("fog")              -> "Niebla"
            e.contains("drizzle")                                -> "Llovizna"
            e.contains("heavy rain") || e.contains("torrential") -> "Lluvia intensa"
            e.contains("rain") || e.contains("shower")           -> "Lluvia"
            e.contains("snow") || e.contains("sleet")            -> "Nieve"
            e.contains("blizzard")                               -> "Tormenta de nieve"
            e.contains("thunder") || e.contains("storm")         -> "Tormenta"
            e.contains("wind") || e.contains("blowing")          -> "Viento"
            e.contains("haze")                                   -> "Bruma"
            e.contains("freezing")                               -> "Heladas"
            else                                                 -> en
        }
    }

    private fun showProfileMenu(anchor: View) {
        val popup = androidx.appcompat.widget.PopupMenu(requireContext(), anchor, android.view.Gravity.END)
        popup.menu.apply {
            add(0, 1, 0, getString(R.string.menu_settings)).setIcon(R.drawable.ic_settings)
            add(0, 2, 1, getString(R.string.menu_profile)).setIcon(R.drawable.ic_person)

            add(0, 3, 3, getString(R.string.menu_exclude_folders)).setIcon(R.drawable.ic_library)
            add(0, 5, 4, "Radio en línea").setIcon(R.drawable.ic_radio)
            add(0, 4, 5, getString(R.string.menu_about)).setIcon(R.drawable.ic_info)
        }
        popup.setForceShowIcon(true)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { startActivity(Intent(requireContext(), com.aeroplayer.ui.settings.SettingsActivity::class.java)); true }
                2 -> { avatarPicker.launch(arrayOf("image/*")); true }

                3 -> { showExcludeFoldersDialog(); true }
                5 -> { startActivity(Intent(requireContext(), com.aeroplayer.ui.OnlineRadioActivity::class.java)); true }
                4 -> { showAboutDialog(); true }
                else -> false
            }
        }
        popup.show()
    }

    // ── Multi-perfiles ────────────────────────────────────────────────────────

    private fun getProfilePrefs() =
        requireContext().getSharedPreferences("aero_profiles", android.content.Context.MODE_PRIVATE)

    private fun loadProfiles(): List<String> {
        val raw = getProfilePrefs().getString("profile_list", "Principal") ?: "Principal"
        return raw.split("|").filter { it.isNotBlank() }
    }

    private fun saveProfiles(profiles: List<String>) {
        getProfilePrefs().edit().putString("profile_list", profiles.joinToString("|")).apply()
    }

    private fun getActiveProfile(): String =
        getProfilePrefs().getString("active_profile", "Principal") ?: "Principal"

    private fun setActiveProfile(name: String) {
        getProfilePrefs().edit().putString("active_profile", name).apply()
        viewModel.setProfileName(name)
        updateGreeting()
        applyProfileWallpaper(name)
        com.google.android.material.snackbar.Snackbar.make(
            binding.root, "Perfil: $name", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    private fun applyProfileWallpaper(profileName: String) {
        val uriStr = getProfilePrefs().getString("wallpaper_$profileName", null)
        if (uriStr != null) {
            try {
                val uri = android.net.Uri.parse(uriStr)
                com.bumptech.glide.Glide.with(this)
                    .load(uri)
                    .into(object : com.bumptech.glide.request.target.CustomTarget<android.graphics.drawable.Drawable>() {
                        override fun onResourceReady(r: android.graphics.drawable.Drawable,
                            t: com.bumptech.glide.request.transition.Transition<in android.graphics.drawable.Drawable>?) {
                            if (!isAdded) return
                            // FIX FONDO DEFINITIVO:
                            // binding.root es un NestedScrollView transparente — el fondo del tema
                            // (negro en AMOLED) se ve a través de él. La solución es aplicar el
                            // wallpaper como Drawable escalado directamente al window de la Activity,
                            // Y también al root del fragment como respaldo.
                            val scaled = android.graphics.drawable.BitmapDrawable(
                                resources,
                                (r as? android.graphics.drawable.BitmapDrawable)?.bitmap
                                    ?: android.graphics.drawable.Icon.createWithAdaptiveBitmap(
                                        android.graphics.Bitmap.createBitmap(1,1,android.graphics.Bitmap.Config.ARGB_8888)
                                    ).let { null }
                            ).also { it.setTileModeXY(android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP) }

                            // Aplicar al root del fragment (cover del NestedScrollView)
                            binding.root.background = r
                            // Aplicar a la ventana para que cubra el windowBackground AMOLED negro
                            requireActivity().window.setBackgroundDrawable(r)
                        }
                        override fun onLoadCleared(p: android.graphics.drawable.Drawable?) {
                            applyDefaultBackground()
                        }
                        override fun onLoadFailed(errorDrawable: android.graphics.drawable.Drawable?) {
                            applyDefaultBackground()
                        }
                    })
            } catch (_: Exception) { applyDefaultBackground() }
        } else {
            applyDefaultBackground()
        }
    }

    private fun applyDefaultBackground() {
        if (!isAdded) return
        // Resolver color de fondo del tema activo (AMOLED = #000, normal = surface_dark)
        val typedVal = android.util.TypedValue()
        val resolved = requireContext().theme.resolveAttribute(android.R.attr.colorBackground, typedVal, true)
        val bgColor = if (resolved) typedVal.data else requireContext().getColor(R.color.background_dark)
        binding.root.setBackgroundColor(bgColor)
        // Restaurar el windowBackground al color del tema (quitar cualquier wallpaper previo)
        requireActivity().window.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(bgColor))
    }

    // Wallpaper picker launcher
    private var wallpaperTargetProfile: String? = null
    private val wallpaperPicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        val profile = wallpaperTargetProfile ?: return@registerForActivityResult
        if (uri != null) {
            // Persistir permiso de URI y guardar
            try {
                requireContext().contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            getProfilePrefs().edit().putString("wallpaper_$profile", uri.toString()).apply()
            applyProfileWallpaper(profile)
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "Fondo de $profile actualizado ✓",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun showMultiProfileDialog() {
        val profiles = loadProfiles()
        val active = getActiveProfile()
        val labels = profiles.map { if (it == active) "✓ $it" else "   $it" }.toTypedArray()

        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("👥 Perfiles")
            .setItems(labels) { _, idx ->
                val selected = profiles[idx]
                // Toque en perfil activo → opciones de edición
                if (selected == active) {
                    showProfileEditMenu(selected)
                } else {
                    setActiveProfile(selected)
                }
            }
            .setPositiveButton("+ Nuevo perfil") { _, _ ->
                val input = android.widget.EditText(requireContext()).apply {
                    hint = "Nombre del perfil"
                    setPadding(64, 24, 64, 8)
                }
                com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Nuevo perfil")
                    .setView(input)
                    .setPositiveButton("Crear") { _, _ ->
                        val name = input.text.toString().trim().ifBlank { return@setPositiveButton }
                        val updated = (loadProfiles() + name).distinct()
                        saveProfiles(updated)
                        setActiveProfile(name)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showProfileEditMenu(profile: String) {
        val options = arrayOf(
            "🖼️  Cambiar fondo de pantalla",
            "✏️  Renombrar perfil",
            "🗑️  Eliminar perfil"
        )
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("✓ $profile (activo)")
            .setItems(options) { _, idx ->
                when (idx) {
                    0 -> {
                        wallpaperTargetProfile = profile
                        wallpaperPicker.launch("image/*")
                    }
                    1 -> {
                        val input = android.widget.EditText(requireContext()).apply {
                            setText(profile); selectAll(); setPadding(64, 24, 64, 8)
                        }
                        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                            .setTitle("Renombrar perfil")
                            .setView(input)
                            .setPositiveButton("Guardar") { _, _ ->
                                val newName = input.text.toString().trim().ifBlank { return@setPositiveButton }
                                val updated = loadProfiles().map { if (it == profile) newName else it }
                                saveProfiles(updated)
                                getProfilePrefs().edit()
                                    .putString("active_profile", newName)
                                    .putString("wallpaper_$newName",
                                        getProfilePrefs().getString("wallpaper_$profile", null))
                                    .remove("wallpaper_$profile").apply()
                                viewModel.setProfileName(newName)
                                updateGreeting()
                            }
                            .setNegativeButton("Cancelar", null).show()
                    }
                    2 -> {
                        if (loadProfiles().size <= 1) {
                            com.google.android.material.snackbar.Snackbar.make(
                                binding.root, "No puedes eliminar el único perfil",
                                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
                            return@setItems
                        }
                        val updated = loadProfiles().filter { it != profile }
                        saveProfiles(updated)
                        getProfilePrefs().edit().remove("wallpaper_$profile").apply()
                        setActiveProfile(updated.first())
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showProfileDialog() {
        val current = viewModel.getProfileName()
        val input = android.widget.EditText(requireContext()).apply {
            setText(current)
            hint = getString(R.string.profile_name_hint)
            setPadding(64, 24, 64, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSelection(text.length)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.edit_profile_title))
            .setView(input)
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setProfileName(input.text.toString().trim())
                updateGreeting()
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, getString(R.string.profile_saved),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showExcludeFoldersDialog() {
        val songs = viewModel.allSongs.value ?: emptyList()
        val folders = songs.map { java.io.File(it.path).parent ?: "/" }
            .distinct().sorted().toTypedArray()
        if (folders.isEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, "No se encontraron carpetas de música",
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show(); return
        }
        val excluded = viewModel.getExcludedFolders().toMutableSet()
        val checked = BooleanArray(folders.size) { folders[it] in excluded }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_exclude_folders))
            .setMultiChoiceItems(folders, checked) { _, which, isChecked ->
                if (isChecked) excluded.add(folders[which]) else excluded.remove(folders[which])
            }
            .setPositiveButton(getString(R.string.done)) { _, _ ->
                viewModel.setExcludedFolders(excluded)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Carpetas actualizadas",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton(getString(R.string.cancel), null).show()
    }

    private fun showAboutDialog() {
        val version = try {
            requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName
        } catch (e: Exception) { "1.2.0" }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.menu_about))
            .setIcon(R.drawable.ic_info)
            .setMessage("Aero Player v$version\n\n${getString(R.string.about_description)}")
            .setPositiveButton(getString(R.string.done), null).show()
    }

    // ── Quick Pick helpers ────────────────────────────────────────────────────
    private fun showQuickPickAddToPlaylist(song: Song) {
        val playlists = viewModel.playlists.value ?: emptyList()
        if (playlists.isEmpty()) {
            com.google.android.material.snackbar.Snackbar.make(
                binding.root, getString(R.string.create_playlist_first),
                com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
            ).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.add_to_playlist))
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                com.google.android.material.snackbar.Snackbar.make(
                    binding.root, "Agregado a ${playlists[idx].name}",
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun showArtistSongs(artistName: String) {
        val allSongs = viewModel.allSongs.value ?: return
        val artistSongs = allSongs.filter { it.artist == artistName }
        if (artistSongs.isEmpty()) return
        // Reproducir todas las canciones del artista y abrir el player
        PlayerController.playSongs(artistSongs, 0, queueName = artistName)
    }

    override fun onResume() {
        super.onResume()
        applyProfileWallpaper(getActiveProfile())
        // Refresh shortcuts on resume to pick up new liked songs / playlist changes
        scheduleRebuildShortcuts()
        // Recargar avatar cada vez que el fragment vuelve a primer plano
        val savedAvatar = requireContext()
            .getSharedPreferences("aero_prefs", android.content.Context.MODE_PRIVATE)
            .getString("user_avatar", null)
        loadAvatar(savedAvatar)

        // NOTA: updateGreeting() NO se llama aquí para evitar duplicar la animación
        // y la petición HTTP del clima en cada vuelta al Home. Solo se ejecuta en
        // onViewCreated (primera carga del Fragment).

        // Si el caché fue limpiado (doble Home), reconstruir la selección rápida
        if (cachedQuickPick == null && quickPickAdapter.itemCount == 0) {
            val allSongs = viewModel.allSongs.value ?: return
            if (allSongs.isNotEmpty()) {
                buildSmartQuickPick(allSongs, viewModel.topPlayed.value ?: emptyList())
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        greetingRunnable?.let { greetingHandler.removeCallbacks(it) }
        greetingRunnable = null
        rebuildRunnable?.let { rebuildHandler.removeCallbacks(it) }
        rebuildRunnable = null
        _binding = null
    }
}
