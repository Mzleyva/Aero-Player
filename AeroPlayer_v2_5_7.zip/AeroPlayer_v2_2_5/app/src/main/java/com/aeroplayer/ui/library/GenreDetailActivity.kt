package com.aeroplayer.ui.library

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.palette.graphics.Palette
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityGenreDetailBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.AccentApplier
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.aeroplayer.utils.AlbumArtUtils
import com.aeroplayer.utils.FormatUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Detalle de género: lista todas las canciones de un género con
 * portada collagepull del más reproducido, header con paleta de colores,
 * y botones de reproducción aleatoria / secuencial.
 */
class GenreDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GENRE = "genre_name"
    }

    private lateinit var binding: ActivityGenreDetailBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityGenreDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AccentApplier.apply(this, binding.root)

        val genreName = intent.getStringExtra(EXTRA_GENRE) ?: run { finish(); return }
        val unknownLabel = getString(R.string.genre_unknown)

        binding.btnBack.setOnClickListener { finish() }
        binding.tvGenreName.text = genreName

        viewModel.allSongs.observe(this) { allSongs ->
            val songs = allSongs
                .filter {
                    val g = it.genre.ifBlank { unknownLabel }
                    g == genreName
                }
                .sortedWith(compareBy({ it.artist }, { it.album }, { it.trackNumber }))

            binding.tvSongCount.text =
                "${songs.size} canción${if (songs.size != 1) "es" else ""}"

            // Artistas únicos
            val artists = songs.map { it.artist }.distinct()
            binding.tvArtistCount.text =
                "${artists.size} artista${if (artists.size != 1) "s" else ""}"

            loadCover(songs)
            setupList(songs)
            setupButtons(songs, genreName)
        }
    }

    private fun loadCover(songs: List<Song>) {
        val rep = songs.maxByOrNull { it.playCount } ?: songs.firstOrNull() ?: return
        val cached = AlbumArtUtils.getCached(rep.id)
        if (cached != null) {
            Glide.with(binding.ivGenreCover).load(cached).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(binding.ivGenreCover)
            applyPalette(cached)
        } else {
            Glide.with(binding.ivGenreCover).load(rep.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder).centerCrop()
                .into(binding.ivGenreCover)
            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    AlbumArtUtils.loadArt(rep.id, rep.path, rep.artist, rep.album)
                }
                if (bmp != null) {
                    Glide.with(binding.ivGenreCover).load(bmp).centerCrop()
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .into(binding.ivGenreCover)
                    applyPalette(bmp)
                }
            }
        }
    }

    private fun applyPalette(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val fallback = ContextCompat.getColor(this, R.color.surface_dark)
            val dominant = palette?.getDarkVibrantColor(
                palette.getDarkMutedColor(fallback)
            ) ?: fallback
            binding.headerContainer.setBackgroundColor(dominant)
        }
    }

    private fun setupList(songs: List<Song>) {
        val adapter = com.aeroplayer.ui.library.PlaylistDetailSongAdapter(
            onSongClick = { song ->
                viewModel.incrementPlayCount(song)
                PlayerController.playSongs(
                    songs, songs.indexOf(song),
                    queueName = binding.tvGenreName.text.toString()
                )
                startActivity(Intent(this, PlayerActivity::class.java))
            },
            onMoreClick = { _, _ -> }
        )
        binding.rvSongs.layoutManager = LinearLayoutManager(this)
        binding.rvSongs.adapter = adapter
        binding.rvSongs.isNestedScrollingEnabled = false
        adapter.submitList(songs)
    }

    private fun setupButtons(songs: List<Song>, genreName: String) {
        binding.btnPlayAll.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            PlayerController.playSongs(songs, 0, queueName = genreName)
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        binding.btnShuffle.setOnClickListener {
            if (songs.isEmpty()) return@setOnClickListener
            val shuffled = songs.shuffled()
            PlayerController.playSongs(shuffled, 0, queueName = "$genreName (aleatorio)")
            startActivity(Intent(this, PlayerActivity::class.java))
        }
    }
}

// ── Minimal adapter reusing PlaylistSong layout ───────────────────────────────

class PlaylistDetailSongAdapter(
    private val onSongClick: (Song) -> Unit,
    private val onMoreClick: (Song, android.view.View) -> Unit
) : androidx.recyclerview.widget.ListAdapter<Song, PlaylistDetailSongAdapter.VH>(SongDetailDiff()) {

    inner class VH(val b: com.aeroplayer.databinding.ItemPlaylistSongBinding) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val b = com.aeroplayer.databinding.ItemPlaylistSongBinding.inflate(
            android.view.LayoutInflater.from(parent.context), parent, false
        )
        b.ivAlbumArt.clipToOutline   = true
        b.ivAlbumArt.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.b.tvTitle.text    = song.title
        holder.b.tvArtist.text   = song.artist
        holder.b.tvDuration.text = FormatUtils.formatDuration(song.duration)

        com.bumptech.glide.Glide.with(holder.b.ivAlbumArt)
            .load(AlbumArtUtils.getCached(song.id) ?: song.albumArtUri)
            .placeholder(com.aeroplayer.R.drawable.ic_music_placeholder)
            .centerCrop()
            .into(holder.b.ivAlbumArt)

        holder.b.root.setOnClickListener { onSongClick(song) }
        holder.b.ivMore.setOnClickListener { onMoreClick(song, it) }
    }

    class SongDetailDiff : androidx.recyclerview.widget.DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
