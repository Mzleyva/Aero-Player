package com.aeroplayer.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import kotlinx.coroutines.launch

class SmartPlaylistActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    companion object {
        const val EXTRA_TYPE = "smart_playlist_type"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val typeName = intent.getStringExtra(EXTRA_TYPE) ?: SmartPlaylistType.RECENTLY_PLAYED.name
        val type = runCatching { SmartPlaylistType.valueOf(typeName) }
            .getOrDefault(SmartPlaylistType.RECENTLY_PLAYED)

        // ── Layout programático ──────────────────────────────────────────────
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }

        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }

        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(12.dp, 0, 0, 0)
        }

        val tvTitle = TextView(this).apply {
            text = "${type.emoji}  ${type.titleEs}"
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(R.color.text_primary))
        }

        val tvDesc = TextView(this).apply {
            text = type.descriptionEs
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
        }

        headerLayout.addView(tvTitle)
        headerLayout.addView(tvDesc)

        val btnPlayAll = ImageButton(this).apply {
            setImageResource(R.drawable.ic_play)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(44.dp, 44.dp)
        }

        toolbar.addView(btnBack)
        toolbar.addView(headerLayout)
        toolbar.addView(btnPlayAll)

        val tvCount = TextView(this).apply {
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(20.dp, 4.dp, 20.dp, 8.dp)
        }

        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@SmartPlaylistActivity)
            setPadding(0, 0, 0, 80.dp)
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        val tvEmpty = TextView(this).apply {
            text = "Aún no hay canciones aquí.\nEmpieza a reproducir música."
            textSize = 14f
            setTextColor(getColor(R.color.text_secondary))
            gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        root.addView(toolbar)
        root.addView(tvCount)
        root.addView(rv)
        root.addView(tvEmpty)
        setContentView(root)

        // ── Adapter ──────────────────────────────────────────────────────────
        val adapter = SmartSongAdapter { song, songs ->
            PlayerController.playSongs(songs, songs.indexOf(song), queueName = type.titleEs)
            viewModel.incrementPlayCount(song)
        }
        rv.adapter = adapter

        btnPlayAll.setOnClickListener {
            val songs = adapter.currentList
            if (songs.isNotEmpty()) {
                PlayerController.playSongs(songs, 0, queueName = type.titleEs)
                viewModel.incrementPlayCount(songs[0])
            }
        }

        // ── Cargar datos ──────────────────────────────────────────────────────
        lifecycleScope.launch {
            val songs = viewModel.getSmartPlaylistSongs(type)
            adapter.submitList(songs)
            val count = songs.size
            tvCount.text = "$count canción${if (count != 1) "es" else ""}"
            rv.visibility    = if (songs.isEmpty()) View.GONE else View.VISIBLE
            tvEmpty.visibility = if (songs.isEmpty()) View.VISIBLE else View.GONE
        }

        // Recargar si cambia el estado del ViewModel (ej: nueva canción reproducida)
        viewModel.listeningHistory.observe(this) {
            lifecycleScope.launch {
                val songs = viewModel.getSmartPlaylistSongs(type)
                if (songs != adapter.currentList) {
                    adapter.submitList(songs)
                    tvCount.text = "${songs.size} canción${if (songs.size != 1) "es" else ""}"
                }
            }
        }
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}

// ── Adapter de canciones para la smart playlist ───────────────────────────────
private class SmartSongAdapter(
    private val onClick: (Song, List<Song>) -> Unit
) : ListAdapter<Song, SmartSongAdapter.VH>(SongDiff()) {

    inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        val iv: ImageView    = root.findViewWithTag("iv")
        val tvTitle: TextView = root.findViewWithTag("title")
        val tvSub: TextView   = root.findViewWithTag("sub")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp = ctx.resources.displayMetrics.density

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            isClickable = true
            isFocusable = true
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
        }

        val size = (48 * dp).toInt()
        val iv = ImageView(ctx).apply {
            tag = "iv"
            layoutParams = LinearLayout.LayoutParams(size, size).also {
                it.marginEnd = (12 * dp).toInt()
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = ctx.getDrawable(R.drawable.bg_album_art_small)
            clipToOutline   = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvTitle = TextView(ctx).apply {
            tag = "title"
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_primary))
        }

        val tvSub = TextView(ctx).apply {
            tag = "sub"
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ctx.getColor(R.color.text_secondary))
        }

        texts.addView(tvTitle)
        texts.addView(tvSub)
        row.addView(iv)
        row.addView(texts)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        holder.tvTitle.text = song.title
        holder.tvSub.text   = "${song.artist} · ${song.album}"
        Glide.with(holder.iv)
            .load(song.albumArtUri)
            .placeholder(R.drawable.ic_music_placeholder)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(holder.iv)
        holder.root.setOnClickListener { onClick(song, currentList) }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
