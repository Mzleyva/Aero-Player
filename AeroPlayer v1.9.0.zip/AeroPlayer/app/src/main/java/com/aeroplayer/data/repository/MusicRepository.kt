package com.aeroplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.aeroplayer.data.db.*
import com.aeroplayer.model.Playlist
import com.aeroplayer.model.Song
import com.aeroplayer.utils.SongUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val likedDao = db.likedSongDao()
    private val historyDao = db.historyDao()
    private val playlistDao = db.playlistDao()
    private val playCountDao = db.playCountDao()
    private val canvasDao = db.songCanvasDao()
    private val songCacheDao = db.songCacheDao()

    // ── Local files (interno + SD card) ─────────────────────────────────────
    // Cuánto tiempo es válido el caché — 30 minutos
    private val CACHE_TTL_MS = 30 * 60 * 1000L

    /**
     * Devuelve canciones desde el caché de Room si está vigente (<30 min).
     * Solo re-escanea MediaStore si el caché está vacío, expirado, o si
     * [forceRefresh] es true (llamado por el ContentObserver cuando MediaStore cambia).
     */
    suspend fun getAllSongs(forceRefresh: Boolean = false): List<Song> = withContext(Dispatchers.IO) {
        val likedIds = likedDao.getAllLikedSync().map { it.songId }.toSet()

        if (!forceRefresh) {
            val count = songCacheDao.count()
            val lastCached = songCacheDao.getLastCachedAt() ?: 0L
            val age = System.currentTimeMillis() - lastCached
            if (count > 0 && age < CACHE_TTL_MS) {
                // Caché vigente — devolver sin tocar MediaStore
                return@withContext songCacheDao.getAll().map { e ->
                    com.aeroplayer.model.Song(
                        id           = e.songId,
                        title        = e.title,
                        artist       = e.artist,
                        album        = e.album,
                        duration     = e.duration,
                        path         = e.path,
                        uri          = android.net.Uri.parse(e.uri),
                        albumArtUri  = e.albumArtUri?.let { android.net.Uri.parse(it) },
                        trackNumber  = e.trackNumber,
                        year         = e.year,
                        size         = e.size,
                        isLiked      = e.songId in likedIds,
                        dateAdded    = e.dateAdded,
                        dateModified = e.dateModified
                    )
                }
            }
        }

        // Escanear MediaStore y guardar en caché
        scanMediaStoreAndCache(likedIds)
    }

    private suspend fun scanMediaStoreAndCache(likedIds: Set<Long>): List<com.aeroplayer.model.Song> {
        // FIX BUG3: eliminada la re-query redundante de likedIds — se usa el parámetro recibido
        val songs = mutableListOf<Song>()
        val seenIds = HashSet<Long>() // FIX PERF: O(1) dedup en lugar de songs.none{} que era O(n²)

        // Android 10+: cada volumen por separado (interno + cada SD insertada)
        // Android 9-: EXTERNAL_CONTENT_URI ya incluye SD en la mayoría de ROMs
        val collections: List<Uri> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.getExternalVolumeNames(context).map { volumeName ->
                MediaStore.Audio.Media.getContentUri(volumeName)
            }
        } else {
            listOf(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            // Bloque 1: nuevos campos
            MediaStore.Audio.Media.COMPOSER,
            "genre",  // MediaStore.Audio.Media.GENRE disponible en API 30+ como String
            // FIX RENDIMIENTO: incluir DATE_ADDED y DATE_MODIFIED en la proyección para
            // que FilesFragment pueda ordenar sin hacer File.lastModified() por cada canción.
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED
        )
        // Ampliar para incluir lossless que algunos fabricantes marcan IS_MUSIC=0
        // OR por MIME_TYPE cubre ALAC en .m4a, WAV, WavPack, APE, MQA
        // IS_RINGTONE/IS_ALARM/IS_NOTIFICATION=0 excluye tonos aunque IS_MUSIC=1 en algunas ROMs
        val selection =
            "(${MediaStore.Audio.Media.IS_MUSIC} != 0 " +
            "OR ${MediaStore.Audio.Media.MIME_TYPE} IN " +
            "('audio/flac','audio/x-flac','audio/alac','audio/wav'," +
            "'audio/x-wav','audio/vnd.wave','audio/wv','audio/ape'," +
            "'audio/x-ape','audio/mqa')) " +
            "AND ${MediaStore.Audio.Media.IS_RINGTONE} = 0 " +
            "AND ${MediaStore.Audio.Media.IS_ALARM} = 0 " +
            "AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 " +
            "AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        // Escanear cada volumen; si uno falla (SD extraída) continúa con los demás
        for (collection in collections) {
            runCatching {
                context.contentResolver.query(
                    collection, projection, selection, null, sortOrder
                )?.use { cursor ->
                    val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val dataCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                    val albumIdCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                    val trackCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                    val yearCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                    val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val mimeCol     = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                    val bitrateCol  = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                        cursor.getColumnIndex(MediaStore.Audio.Media.BITRATE) else -1
                    // Bloque 1: columnas adicionales
                    val composerCol      = cursor.getColumnIndex(MediaStore.Audio.Media.COMPOSER)
                    val genreCol         = cursor.getColumnIndex("genre")
                    val dateAddedCol     = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                    val dateModifiedCol  = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)

                    while (cursor.moveToNext()) {
                        val id      = cursor.getLong(idCol)
                        val albumId = cursor.getLong(albumIdCol)

                        val contentUri = ContentUris.withAppendedId(collection, id)

                        val albumArtUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            ContentUris.withAppendedId(
                                MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, albumId
                            )
                        } else {
                            Uri.parse("content://media/external/audio/albumart/$albumId")
                        }

                        val mimeType = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "" else ""
                        val bitrate  = if (bitrateCol >= 0) cursor.getInt(bitrateCol) else 0
                        // Bloque 1: leer campos extra
                        val composer      = if (composerCol >= 0) cursor.getString(composerCol) ?: "" else ""
                        val genre         = if (genreCol >= 0) cursor.getString(genreCol) ?: "" else ""
                        val dateAdded     = if (dateAddedCol >= 0) cursor.getLong(dateAddedCol) else 0L
                        val dateModified  = if (dateModifiedCol >= 0) cursor.getLong(dateModifiedCol) else 0L
                        // discNumber: el trackNumber de MediaStore codifica disco*1000 + pista
                        // (ej. 201 = disco 2, pista 1). Extraer la parte del disco.
                        val rawTrack    = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK))
                        val discNumber  = if (rawTrack >= 1000) rawTrack / 1000 else 0
                        val trackNumber = if (rawTrack >= 1000) rawTrack % 1000 else rawTrack

                        if (seenIds.add(id)) {
                            songs.add(
                                Song(
                                    id          = id,
                                    title       = cursor.getString(titleCol)  ?: context.getString(com.aeroplayer.R.string.unknown_title),
                                    artist      = SongUtils.cleanArtistName(cursor.getString(artistCol) ?: context.getString(com.aeroplayer.R.string.unknown_artist)),
                                    album       = cursor.getString(albumCol)  ?: context.getString(com.aeroplayer.R.string.unknown_album),
                                    duration    = cursor.getLong(durationCol),
                                    path        = cursor.getString(dataCol)   ?: "",
                                    uri         = contentUri,
                                    albumArtUri = albumArtUri,
                                    trackNumber = trackNumber,
                                    discNumber  = discNumber,
                                    year        = cursor.getInt(yearCol),
                                    size        = cursor.getLong(sizeCol),
                                    isLiked     = id in likedIds,
                                    mimeType    = mimeType,
                                    bitrate     = bitrate,
                                    genre        = genre,
                                    composer     = composer,
                                    dateAdded    = dateAdded,
                                    dateModified = dateModified
                                )
                            )
                        }
                    }
                }
            }
        }
        val sorted = songs.sortedBy { it.title.lowercase() }

        // FIX: No persistir un caché vacío — puede ocurrir cuando el permiso de audio
        // aún no fue concedido (el init del ViewModel llama loadSongs antes que el usuario
        // acepte el permiso). Si guardamos 0 canciones, el caché queda "vigente" 30 min
        // y la siguiente llamada (con permiso ya concedido) devuelve la lista vacía.
        if (sorted.isEmpty()) return sorted

        // Persistir en caché para la próxima apertura
        val now = System.currentTimeMillis()
        val cacheEntities = sorted.map { s ->
            com.aeroplayer.data.db.SongCacheEntity(
                songId       = s.id,
                title        = s.title,
                artist       = s.artist,
                album        = s.album,
                duration     = s.duration,
                path         = s.path,
                albumArtUri  = s.albumArtUri?.toString(),
                uri          = s.uri.toString(),
                albumId      = 0L,
                trackNumber  = s.trackNumber,
                year         = s.year,
                size         = s.size,
                cachedAt     = now,
                dateAdded    = s.dateAdded,
                dateModified = s.dateModified
            )
        }
        songCacheDao.clearAll()
        songCacheDao.insertAll(cacheEntities)

        return sorted
    }

    // ── Liked songs ──────────────────────────────────────────────────────────
    fun getLikedSongsLive() = likedDao.getAllLiked()
    fun getLikedCountLive() = likedDao.getCount()
    suspend fun getLikedFirstArtUri(): String? = likedDao.getFirstAlbumArtUri()
    suspend fun getLikedFirstSongId(): Long? = likedDao.getFirstSongId()

    suspend fun toggleLike(song: Song): Boolean {
        return if (likedDao.isLiked(song.id)) {
            likedDao.deleteById(song.id)
            false
        } else {
            likedDao.insert(LikedSongEntity(
                songId      = song.id,
                title       = song.title,
                artist      = song.artist,
                album       = song.album,
                path        = song.path,
                duration    = song.duration,
                albumArtUri = song.albumArtUri?.toString()
            ))
            true
        }
    }

    suspend fun isLiked(id: Long) = likedDao.isLiked(id)

    // ── Playlists ────────────────────────────────────────────────────────────
    fun getAllPlaylistsLive()   = playlistDao.getAllPlaylists()
    fun getPlaylistCountLive()  = playlistDao.getPlaylistCount()

    suspend fun createPlaylist(name: String, coverUri: String? = null): Long =
        playlistDao.insertPlaylist(PlaylistEntity(name = name, coverUri = coverUri))

    suspend fun updatePlaylist(id: Long, name: String, coverUri: String? = null) =
        playlistDao.updatePlaylist(PlaylistEntity(id = id, name = name, coverUri = coverUri))

    suspend fun deletePlaylist(id: Long) =
        playlistDao.deletePlaylist(PlaylistEntity(id = id, name = ""))

    suspend fun addSongToPlaylist(playlistId: Long, song: Song) {
        val existing = playlistDao.getSongsForPlaylistSync(playlistId)
        // FIX BUG2: evitar duplicados — si la canción ya está en la playlist, no insertar
        if (existing.any { it.songId == song.id }) return
        playlistDao.insertSongToPlaylist(PlaylistSongEntity(
            playlistId  = playlistId,
            songId      = song.id,
            title       = song.title,
            artist      = song.artist,
            album       = song.album,
            path        = song.path,
            duration    = song.duration,
            albumArtUri = song.albumArtUri?.toString(),
            position    = existing.size
        ))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) =
        playlistDao.removeSongFromPlaylist(playlistId, songId)

    /** Updates the `position` column for every song in the list to match the given order. */
    suspend fun reorderPlaylistSongs(playlistId: Long, songs: List<Song>) {
        songs.forEachIndexed { index, song ->
            playlistDao.updateSongPosition(playlistId, song.id, index)
        }
    }

    fun getPlaylistSongsLive(playlistId: Long) = playlistDao.getSongsForPlaylist(playlistId)
    fun getPlaylistSongCount(playlistId: Long)  = playlistDao.getSongCount(playlistId)
    suspend fun getPlaylistFirstArtUri(playlistId: Long): String? =
        playlistDao.getFirstAlbumArtUri(playlistId)

    suspend fun getPlaylistFirstSongId(playlistId: Long): Long? =
        playlistDao.getFirstSongId(playlistId)

    suspend fun getFullPlaylists(): List<Playlist> =
        playlistDao.getAllPlaylistsSync().map { pe ->
            val songs = playlistDao.getSongsForPlaylistSync(pe.id).map { se ->
                Song(
                    id          = se.songId,
                    title       = se.title,
                    artist      = se.artist,
                    album       = se.album,
                    duration    = se.duration,
                    path        = se.path,
                    // FIX: ContentUris en lugar de Uri.parse(path) para Android 10+
                    uri         = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, se.songId
                    ),
                    albumArtUri = se.albumArtUri?.let { android.net.Uri.parse(it) }
                )
            }
            Playlist(id = pe.id, name = pe.name, songs = songs.toMutableList(),
                     coverUri = pe.coverUri, createdAt = pe.createdAt)
        }

    // ── Play counts ──────────────────────────────────────────────────────────
    suspend fun incrementPlayCount(song: Song, listenedMs: Long = 0L) {
        if (playCountDao.getByid(song.id) == null) {
            playCountDao.insert(PlayCountEntity(
                songId      = song.id,
                title       = song.title,
                artist      = song.artist,
                path        = song.path,
                albumArtUri = song.albumArtUri?.toString(),
                count       = 1,
                listenTimeMs = listenedMs
            ))
        } else {
            playCountDao.incrementWithTime(song.id, listenedMs)
        }
        // Registrar en historial cada vez que se reproduce
        addToHistory(song)
    }

    suspend fun getTotalListenTimeMs(): Long = playCountDao.getTotalListenTimeMs() ?: 0L
    suspend fun getUniqueSongsPlayed(): Int  = playCountDao.getUniqueSongsPlayed()
    suspend fun getTopByListenTime(limit: Int = 10) = playCountDao.getTopByListenTime(limit)

    suspend fun getDailyPlays(days: Int = 30): List<com.aeroplayer.data.db.DailyPlayCount> {
        val from = System.currentTimeMillis() - days * 86_400_000L
        return historyDao.getDailyPlays(from)
    }

    suspend fun getDailyListenTime(days: Int = 30): List<com.aeroplayer.data.db.DailyListenTime> {
        val from = System.currentTimeMillis() - days * 86_400_000L
        return historyDao.getDailyListenTime(from)
    }

    // ── Estadísticas anuales ──────────────────────────────────────────────────
    suspend fun getTopSongsInYear(year: Int, limit: Int = 5): List<com.aeroplayer.data.db.PlayCountEntity> {
        val (start, end) = yearRange(year)
        return playCountDao.getTopPlayedInYear(start, end, limit)
    }
    suspend fun getTotalListenTimeMsInYear(year: Int): Long {
        val (start, end) = yearRange(year)
        return playCountDao.getTotalListenTimeMsInYear(start, end) ?: 0L
    }
    private fun yearRange(year: Int): Pair<Long, Long> {
        val cal = java.util.Calendar.getInstance()
        cal.set(year, java.util.Calendar.JANUARY, 1, 0, 0, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.set(year + 1, java.util.Calendar.JANUARY, 1, 0, 0, 0)
        return Pair(start, cal.timeInMillis)
    }

    suspend fun addToHistory(song: Song) {
        historyDao.insert(
            ListeningHistoryEntity(
                songId      = song.id,
                title       = song.title,
                artist      = song.artist,
                album       = song.album,
                path        = song.path,
                albumArtUri = song.albumArtUri?.toString(),
                duration    = song.duration
            )
        )
        historyDao.trimToLast500()
    }

    fun getHistoryLive(limit: Int = 200) = historyDao.getRecentHistory(limit)
    suspend fun getHistorySync(limit: Int = 200) = historyDao.getRecentHistorySync(limit)
    suspend fun getRecentUniqueSongs(limit: Int = 50) = historyDao.getRecentUniqueSongs(limit)
    suspend fun clearHistory() = historyDao.clearAll()

    suspend fun getTopPlayedSongs(limit: Int = 10) = playCountDao.getTopPlayed(limit)

    // ── Lyrics ───────────────────────────────────────────────────────────────
    /**
     * Busca letras con sistema de fallback en 3 proveedores:
     *  1. Archivo .lrc local (junto al audio) — instantáneo, sin red
     *  2. lrclib.net — letras sincronizadas gratis
     *  3. Búsqueda alternativa en lrclib (query libre)
     * Si encuentra letras sincronizadas las guarda como .lrc local para uso futuro.
     */
    suspend fun getLyricsResponse(
        artist: String,
        title: String,
        songPath: String = ""
    ): LyricsResult = withContext(Dispatchers.IO) {

        // ── 1. Leer .lrc local si existe ─────────────────────────────────────
        if (songPath.isNotBlank()) {
            val local = LyricsFileManager.readLrc(songPath)
            if (!local.isNullOrBlank()) {
                val isSynced = local.contains(Regex("\\[\\d+:\\d+\\.\\d+]"))
                return@withContext LyricsResult.Success(
                    LrclibResponse(
                        plainLyrics  = if (!isSynced) local else null,
                        syncedLyrics = if (isSynced) local else null,
                        error        = null
                    )
                )
            }
        }

        // ── 2. lrclib.net (proveedor principal) ───────────────────────────────
        val primary = runCatching {
            val resp = LyricsApi.service.getLyrics(artist, title)
            if (!resp.plainLyrics.isNullOrBlank() || !resp.syncedLyrics.isNullOrBlank()) resp
            else null
        }.getOrNull()

        if (primary != null) {
            // Guardar .lrc localmente si tenemos letras sincronizadas
            if (songPath.isNotBlank()) {
                LyricsFileManager.saveLrc(songPath, primary.syncedLyrics, primary.plainLyrics)
            }
            return@withContext LyricsResult.Success(primary)
        }

        // ── 3. Búsqueda alternativa (query libre en lrclib) ───────────────────
        val fallback = GeniusLyricsProvider.fetch(artist, title)
        if (!fallback.isNullOrBlank()) {
            val isSynced = fallback.contains(Regex("\\[\\d+:\\d+\\.\\d+]"))
            val resp = LrclibResponse(
                plainLyrics  = if (!isSynced) fallback else null,
                syncedLyrics = if (isSynced) fallback else null,
                error        = null
            )
            if (songPath.isNotBlank()) {
                LyricsFileManager.saveLrc(songPath, resp.syncedLyrics, resp.plainLyrics)
            }
            return@withContext LyricsResult.Success(resp)
        }

        LyricsResult.NotFound
    }

    // ── Paging 3 ─────────────────────────────────────────────────────────────

    /**
     * Devuelve un [SongPagingSource] fresco sobre la lista [songs] ya ordenada.
     * El ViewModel invalida la fuente cuando cambia el sort o se refresca MediaStore.
     */
    fun getPagingSource(songs: List<Song>): SongPagingSource = SongPagingSource(songs)

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /** Asigna o reemplaza el canvas GIF de una canción. */
    suspend fun setCanvas(songId: Long, gifUri: String) =
        canvasDao.setCanvas(SongCanvasEntity(songId = songId, gifUri = gifUri))

    /** Elimina el canvas GIF de una canción. */
    suspend fun deleteCanvas(songId: Long) = canvasDao.deleteCanvas(songId)

    /** Obtiene el canvas actual (suspending, para leer una sola vez). */
    suspend fun getCanvas(songId: Long): String? =
        canvasDao.getCanvas(songId)?.gifUri

    /** Flujo reactivo del canvas — el player lo observa para mostrar/ocultar el GIF. */
    fun getCanvasLive(songId: Long) = canvasDao.getCanvasLive(songId)

    // Added to fix MainViewModel.exportPlaylistToM3u reference
    suspend fun getPlaylistSongs(playlistId: Long): List<com.aeroplayer.model.Song> {
        return playlistDao.getSongsForPlaylistSync(playlistId).map { entity ->
            com.aeroplayer.utils.SongBuilder.fromPlaylistSong(entity)
        }
    }


    // ── Android Auto helpers ──────────────────────────────────────────────────

    /** Devuelve las N canciones más escuchadas (por play count). */
    suspend fun getMostPlayed(limit: Int = 30): List<com.aeroplayer.model.Song> {
        return runCatching {
            val ids = playCountDao.getTopPlayedIds(limit)
            val all = sortedSongs.value.orEmpty()
            ids.mapNotNull { id -> all.find { it.id == id } }
        }.getOrDefault(emptyList())
    }

    /** Devuelve las canciones marcadas como "Me gusta". */
    suspend fun getLikedSongs(): List<com.aeroplayer.model.Song> {
        return runCatching {
            likedDao.getAllLikedOnce().map { liked ->
                sortedSongs.value.orEmpty().find { it.id == liked.songId }
            }.filterNotNull()
        }.getOrDefault(emptyList())
    }

    /** Devuelve la lista de álbumes únicos de la biblioteca. */
    suspend fun getAllAlbums(): List<AlbumInfo> {
        return runCatching {
            sortedSongs.value.orEmpty()
                .groupBy { it.album }
                .map { (album, songs) ->
                    AlbumInfo(
                        id     = songs.first().id,
                        name   = album,
                        artist = songs.first().artist,
                        count  = songs.size
                    )
                }.sortedBy { it.name }
        }.getOrDefault(emptyList())
    }

    /** Devuelve canciones de un álbum por id (usamos el id de la primera canción del álbum). */
    suspend fun getSongsForAlbum(albumId: Long): List<com.aeroplayer.model.Song> {
        val ref = sortedSongs.value.orEmpty().find { it.id == albumId } ?: return emptyList()
        return sortedSongs.value.orEmpty().filter { it.album == ref.album }
    }

    /** Devuelve la lista de artistas únicos. */
    suspend fun getAllArtists(): List<ArtistInfo> {
        return runCatching {
            sortedSongs.value.orEmpty()
                .groupBy { it.artist }
                .map { (artist, songs) ->
                    ArtistInfo(
                        name       = artist,
                        albumCount = songs.map { it.album }.distinct().size,
                        songCount  = songs.size
                    )
                }.sortedBy { it.name }
        }.getOrDefault(emptyList())
    }

    /** Devuelve canciones de un artista ordenadas por álbum + track number. */
    suspend fun getSongsByArtist(artistName: String): List<com.aeroplayer.model.Song> {
        return sortedSongs.value.orEmpty()
            .filter { it.artist.equals(artistName, ignoreCase = true) }
            .sortedWith(compareBy({ it.album }, { it.trackNumber }))
    }

    /** Busca una canción por id. */
    suspend fun getSongById(id: Long): com.aeroplayer.model.Song? {
        return sortedSongs.value.orEmpty().find { it.id == id }
    }

    /** Busca canciones por título o artista. */
    suspend fun searchSongs(query: String): List<com.aeroplayer.model.Song> {
        val q = query.lowercase()
        return sortedSongs.value.orEmpty().filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
        }
    }

    data class AlbumInfo(val id: Long, val name: String, val artist: String, val count: Int)
    data class ArtistInfo(val name: String, val albumCount: Int, val songCount: Int)


}