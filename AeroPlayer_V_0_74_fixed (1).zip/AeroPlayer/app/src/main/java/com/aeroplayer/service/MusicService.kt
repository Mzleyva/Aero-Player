package com.aeroplayer.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aeroplayer.ui.player.PlayerActivity

/**
 * Servicio de reproducción basado en MediaSessionService (Media3).
 *
 * El canal de notificación se crea en AeroPlayerApp.onCreate() — antes de
 * que el sistema pueda arrancar este servicio. Aquí NO llamamos
 * startForeground() ni creamos el canal: Media3 lo hace internamente cuando
 * player.play() se invoca, usando el canal ya registrado por la Application.
 *
 * Lecciones aprendidas:
 *  - Llamar startForeground() manualmente + MediaSessionService = doble foreground
 *    → crash de audio pipeline en Android 11.
 *  - DefaultMediaNotificationProvider.setChannelId() en Media3 1.4.1 no garantiza
 *    el orden de creación del canal en Android 11 → canal no encontrado → crash.
 *  - La única solución fiable: canal en Application, nada manual en el servicio.
 */
class MusicService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer

    companion object {
        @Volatile var audioSessionId: Int = 0
            private set
    }

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        audioSessionId = player.audioSessionId

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        audioSessionId = 0
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player ?: return
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }
}
