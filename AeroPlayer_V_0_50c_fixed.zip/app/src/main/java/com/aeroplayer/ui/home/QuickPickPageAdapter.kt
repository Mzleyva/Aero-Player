package com.aeroplayer.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.aeroplayer.utils.AlbumArtUtils

/**
 * Adapter para el carrusel de selección rápida estilo YT Music.
 * Agrupa las canciones en páginas de PAGE_SIZE=4 ítems en columna vertical.
 * Usado con un RecyclerView horizontal + PagerSnapHelper (en lugar de ViewPager2)
 * para evitar las restricciones de medición dentro de NestedScrollView.
 */
class QuickPickPageAdapter(
    private val onClick:         (Song, List<Song>) -> Unit,
    private val onAddToQueue:    (Song) -> Unit,
    private val onAddToPlaylist: (Song) -> Unit,
    private val onViewArtist:    (String) -> Unit
) : RecyclerView.Adapter<QuickPickPageAdapter.PageVH>() {

    companion object {
        const val PAGE_SIZE = 4
    }

    private var songs: List<Song> = emptyList()

    fun submitList(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }

    fun getCurrentList(): List<Song> = songs

    override fun getItemCount(): Int =
        if (songs.isEmpty()) 0 else (songs.size + PAGE_SIZE - 1) / PAGE_SIZE

    inner class PageVH(val container: LinearLayout) : RecyclerView.ViewHolder(container)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
        // Cada página ocupa exactamente el ancho del RecyclerView (una página a la vez)
        val container = LinearLayout(parent.context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                parent.width.takeIf { it > 0 } ?: ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return PageVH(container)
    }

    override fun onBindViewHolder(holder: PageVH, position: Int) {
        // Asegurar que el ancho de página sea siempre el del RecyclerView
        val lp = holder.container.layoutParams
        if (lp is RecyclerView.LayoutParams && holder.container.parent != null) {
            val rv = holder.container.parent as? RecyclerView
            if (rv != null && rv.width > 0) {
                lp.width = rv.width
                holder.container.layoutParams = lp
            }
        }

        holder.container.removeAllViews()
        val startIdx = position * PAGE_SIZE
        val endIdx   = minOf(startIdx + PAGE_SIZE, songs.size)

        for (i in startIdx until endIdx) {
            val song = songs[i]
            val rowView = LayoutInflater.from(holder.container.context)
                .inflate(R.layout.item_quick_pick_row, holder.container, false)

            val ivCover = rowView.findViewById<android.widget.ImageView>(R.id.ivCover)
            Glide.with(ivCover)
                .load(AlbumArtUtils.getCached(song.id) ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivCover)

            if (AlbumArtUtils.getCached(song.id) == null) {
                AlbumArtUtils.preload(listOf(Pair(song.id, song.path)))
            }

            rowView.findViewById<android.widget.TextView>(R.id.tvTitle).text  = song.title
            rowView.findViewById<android.widget.TextView>(R.id.tvArtist).text = song.artist
            rowView.setOnClickListener { onClick(song, songs) }
            rowView.findViewById<android.widget.ImageButton>(R.id.btnMore)
                .setOnClickListener { v -> showMenu(v, song) }

            holder.container.addView(rowView)
        }
    }

    private fun showMenu(anchor: View, song: Song) {
        val popup = androidx.appcompat.widget.PopupMenu(anchor.context, anchor)
        popup.menu.apply {
            add(0, 0, 0, "🎤  Ver artista")
            add(0, 1, 1, "➕  Agregar a cola")
            add(0, 2, 2, "📋  Agregar a playlist")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                0 -> { onViewArtist(song.artist); true }
                1 -> { onAddToQueue(song); true }
                2 -> { onAddToPlaylist(song); true }
                else -> false
            }
        }
        popup.show()
    }
}
