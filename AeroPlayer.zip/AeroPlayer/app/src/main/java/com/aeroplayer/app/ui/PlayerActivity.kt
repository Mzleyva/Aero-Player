package com.aeroplayer.app.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import com.aeroplayer.app.R
import com.aeroplayer.app.databinding.ActivityPlayerBinding
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private val viewModel: PlayerViewModel by viewModels(
        factoryProducer = { (application as AeroApp).playerViewModelFactory }
    )

    private val handler = Handler(Looper.getMainLooper())
    private val updateProgress = object : Runnable {
        override fun run() {
            val ctrl = viewModel.controller
            if (ctrl != null) {
                binding.seekBar.progress = ctrl.currentPosition.toInt()
                binding.tvCurrentTime.text = formatTime(ctrl.currentPosition)
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupControls()
        observeViewModel()
        handler.post(updateProgress)
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnPlayPause.setOnClickListener { viewModel.togglePlayPause() }
        binding.btnNext.setOnClickListener { viewModel.skipNext() }
        binding.btnPrevious.setOnClickListener { viewModel.skipPrevious() }
        binding.btnShuffle.setOnClickListener { viewModel.toggleShuffle() }
        binding.btnRepeat.setOnClickListener { viewModel.cycleRepeat() }
        binding.btnLike.setOnClickListener {
            viewModel.currentSong.value?.let { viewModel.toggleLike(it) }
        }

        // Tab letras / info
        binding.btnShowLyrics.setOnClickListener {
            binding.tvLyrics.visibility = android.view.View.VISIBLE
            binding.btnShowLyrics.alpha = 1f
        }

        binding.seekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) viewModel.seekTo(progress.toLong())
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
        })
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.currentSong.collect { song ->
                song ?: return@collect
                binding.tvTitle.text = song.title
                binding.tvArtist.text = song.artist
                binding.tvAlbum.text = song.album
                binding.btnLike.setImageResource(
                    if (song.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
                )
                Glide.with(this@PlayerActivity)
                    .load(song.albumArtUri)
                    .placeholder(R.drawable.ic_music_placeholder)
                    .into(binding.ivAlbumArt)

                // Actualizar seekbar max
                binding.seekBar.max = song.duration.toInt()
                binding.tvTotalTime.text = formatTime(song.duration)
            }
        }

        lifecycleScope.launch {
            viewModel.isPlaying.collect { playing ->
                binding.btnPlayPause.setImageResource(
                    if (playing) R.drawable.ic_pause_circle else R.drawable.ic_play_circle
                )
            }
        }

        lifecycleScope.launch {
            viewModel.lyrics.collect { lyrics ->
                binding.tvLyrics.text = lyrics ?: "Buscando letra..."
            }
        }

        lifecycleScope.launch {
            viewModel.shuffleEnabled.collect { enabled ->
                binding.btnShuffle.alpha = if (enabled) 1f else 0.4f
            }
        }

        lifecycleScope.launch {
            viewModel.repeatMode.collect { mode ->
                binding.btnRepeat.setImageResource(
                    when (mode) {
                        Player.REPEAT_MODE_ONE -> R.drawable.ic_repeat_one
                        Player.REPEAT_MODE_ALL -> R.drawable.ic_repeat_all
                        else -> R.drawable.ic_repeat_off
                    }
                )
                binding.btnRepeat.alpha = if (mode == Player.REPEAT_MODE_OFF) 0.4f else 1f
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val total = ms / 1000
        val min = total / 60
        val sec = total % 60
        return "%d:%02d".format(min, sec)
    }

    override fun onDestroy() {
        handler.removeCallbacks(updateProgress)
        super.onDestroy()
    }
}
