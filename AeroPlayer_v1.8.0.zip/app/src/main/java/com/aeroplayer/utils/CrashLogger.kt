package com.aeroplayer.utils

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Captura crashes no manejados y los guarda en un archivo de texto interno.
 * El archivo se puede leer desde Settings para diagnosticar sin necesidad de ADB.
 *
 * Uso: CrashLogger.init(context) en Application.onCreate()
 */
object CrashLogger {

    private const val LOG_FILE = "crash_log.txt"
    private const val MAX_LOG_SIZE = 50_000 // 50KB máximo

    fun init(context: Context) {
        val appContext = context.applicationContext
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                saveCrash(appContext, thread, throwable)
            } catch (_: Exception) {
                // No hacer nada si falla el logging — no queremos un crash dentro del crash handler
            }
            // Dejar que el sistema maneje el crash normalmente
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun saveCrash(context: Context, thread: Thread, throwable: Throwable) {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val stackTrace = sw.toString()

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = buildString {
            appendLine("════════════════════════════════")
            appendLine("CRASH: $timestamp")
            appendLine("Thread: ${thread.name}")
            appendLine("Error: ${throwable::class.java.simpleName}: ${throwable.message}")
            appendLine("────────────────────────────────")
            appendLine(stackTrace)
        }

        val file = File(context.filesDir, LOG_FILE)

        // Rotar si el archivo es muy grande
        if (file.exists() && file.length() > MAX_LOG_SIZE) {
            val existing = file.readText()
            // Quedarse solo con la segunda mitad (los crashes más recientes)
            file.writeText(existing.drop(existing.length / 2))
        }

        file.appendText(entry)
    }

    /**
     * Lee todos los crashes guardados.
     * Devuelve string vacío si no hay crashes registrados.
     */
    fun readLogs(context: Context): String {
        val file = File(context.filesDir, LOG_FILE)
        return if (file.exists()) file.readText() else ""
    }

    /**
     * Borra el archivo de logs.
     */
    fun clearLogs(context: Context) {
        File(context.filesDir, LOG_FILE).delete()
    }

    fun hasLogs(context: Context): Boolean {
        val file = File(context.filesDir, LOG_FILE)
        return file.exists() && file.length() > 0
    }
}
