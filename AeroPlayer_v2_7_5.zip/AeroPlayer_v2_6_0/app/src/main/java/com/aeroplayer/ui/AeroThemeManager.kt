package com.aeroplayer.ui

import android.app.Activity
import android.content.Context
import android.graphics.Color
import androidx.appcompat.app.AppCompatDelegate
import com.aeroplayer.R

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║            AERO THEME MANAGER — Windows Vista Aero Theme               ║
 * ║                                                                          ║
 * ║  Gestiona la activación del Tema Windows Vista Aero en AeroPlayer.      ║
 * ║                                                                          ║
 * ║  USO:                                                                    ║
 * ║    // Activar el tema Aero (llamar ANTES de setContentView):             ║
 * ║    AeroThemeManager.applyTheme(this)                                     ║
 * ║                                                                          ║
 * ║    // En AccentApplier, obtener los colores Aero:                        ║
 * ║    AeroThemeManager.getAccentColor(context)                              ║
 * ║                                                                          ║
 * ║  INTEGRACIÓN CON ThemeManager EXISTENTE:                                 ║
 * ║    El tema Aero se registra como una opción más en ThemeManager          ║
 * ║    bajo la key "aero". AeroThemeManager delega a ThemeManager para       ║
 * ║    persistencia y añade la lógica de recreate/style.                     ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
object AeroThemeManager {

    // ── Constantes ────────────────────────────────────────────────────────────
    const val THEME_KEY_AERO = "aero"
    private const val PREFS_NAME = "aero_prefs"
    private const val KEY_FONT   = "selected_font"

    /** Fuentes disponibles: id → (nombre visible, @font res name) */
    val FONT_OPTIONS = listOf(
        "inter"        to "Inter (por defecto)",
        "outfit"       to "Outfit",
        "nunito"       to "Nunito",
        "poppins"      to "Poppins",
        "montserrat"   to "Montserrat",
        "raleway"      to "Raleway",
        "space_grotesk" to "Space Grotesk"
    )

    fun getSelectedFont(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FONT, "inter") ?: "inter"

    fun setFont(context: Context, fontKey: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_FONT, fontKey).apply()
    }

    /** Aplica la fuente seleccionada a una Activity usando updateConfiguration (API 17+). */
    fun applyFont(activity: Activity) {
        val fontKey = getSelectedFont(activity)
        if (fontKey == "inter") return  // Inter es la fuente por defecto en el tema, nada que hacer

        val fontRes = when (fontKey) {
            "outfit"         -> R.font.outfit_regular
            "nunito"         -> R.font.nunito_regular
            "poppins"        -> R.font.poppins_regular
            "montserrat"     -> R.font.montserrat_regular
            "raleway"        -> R.font.raleway_regular
            "space_grotesk"  -> R.font.space_grotesk_regular
            else             -> return
        }
        try {
            val typeface = androidx.core.content.res.ResourcesCompat.getFont(activity, fontRes) ?: return
            // Sobreescribir la fuente en el Configuration para que se aplique a todas las vistas
            val config = activity.resources.configuration
            // Android no expone setDefaultFont directamente, pero podemos aplicar
            // la fuente globalmente usando ViewTreeObserver en el decorView.
            // Más simple y fiable: aplicar via custom TypefaceSpan en el theme.
            // Usamos el método de subclassing del LayoutInflater para interceptar TextViews.
            com.aeroplayer.utils.FontApplicator.apply(activity, typeface)
        } catch (_: Exception) {}
    }
    private const val KEY_ACTIVE_THEME = "active_custom_theme"

    // ── Colores del tema Aero (hardcoded para AccentApplier) ─────────────────

    /**
     * Paleta de colores de acento del tema Aero.
     * Corresponden a las variantes de la barra de título de Vista.
     */
    val aeroAccentColors = listOf(
        // Azul barra de título Vista — EL color icónico
        ThemeManager.AccentColor("Aero Azul",   Color.parseColor("#4580C4"), "aero_blue"),
        // Cyan eléctrico — modo Aero Black/oscuro
        ThemeManager.AccentColor("Aero Cyan",   Color.parseColor("#5BA3E8"), "aero_cyan"),
        // Teal — alternativa Aero verde-azulada
        ThemeManager.AccentColor("Aero Teal",   Color.parseColor("#2E8B6E"), "aero_teal"),
        // Violeta — Aero con ventanas personalizadas de Vista
        ThemeManager.AccentColor("Aero Violeta",Color.parseColor("#7050B8"), "aero_violet"),
        // Plata — Aero Silver (el segundo tema de Vista)
        ThemeManager.AccentColor("Aero Plata",  Color.parseColor("#8096B0"), "aero_silver"),
    )

    // ── Color de glass/fondo del player para cada acento ──────────────────────
    /**
     * Devuelve el color de fondo oscuro del player que acompaña al acento.
     * Simula el vidrio translúcido de Vista sobre fondo oscuro.
     */
    fun getPlayerBackgroundColor(accentKey: String): Int = when (accentKey) {
        "aero_blue"   -> Color.parseColor("#060D18")
        "aero_cyan"   -> Color.parseColor("#041218")
        "aero_teal"   -> Color.parseColor("#040F12")
        "aero_violet" -> Color.parseColor("#0A0614")
        "aero_silver" -> Color.parseColor("#0A0D12")
        else          -> Color.parseColor("#060D18")
    }

    /**
     * Color de specular highlight (el brillo blanco superior del botón Aero).
     * Se usa en drawables y vistas custom del player.
     */
    val aeroGlassHighlight = Color.parseColor("#80FFFFFF")
    val aeroGlassBorder    = Color.parseColor("#60A0C8E0")

    // ── Activación del tema ────────────────────────────────────────────────────

    /**
     * Verifica si el tema Aero está activo.
     */
    fun isAeroActive(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACTIVE_THEME, null) == THEME_KEY_AERO
    }

    /**
     * Activa el tema Aero y persiste la preferencia.
     * Llama a [activity].recreate() para aplicar el nuevo tema inmediatamente.
     *
     * @param activity Activity actual (necesaria para setTheme + recreate)
     * @param accentKey Clave del color de acento Aero (default: "aero_blue")
     */
    fun activateAero(activity: Activity, accentKey: String = "aero_blue") {
        val prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_ACTIVE_THEME, THEME_KEY_AERO)
            .putString("theme_mode", "aero")
            .putString("aero_accent_key", accentKey)
            .apply()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        activity.recreate()
    }

    /**
     * Desactiva el tema Aero y vuelve al tema base de AeroPlayer.
     */
    fun deactivateAero(activity: Activity) {
        val prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_ACTIVE_THEME).apply()
        activity.recreate()
    }

    /**
     * Desactiva el tema Aero sin llamar recreate (para cuando SettingsActivity
     * ya va a llamar recreate() por su cuenta al cambiar de modo).
     */
    fun deactivateAeroSilent(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_ACTIVE_THEME).apply()
    }

    /**
     * Obtiene la clave del acento Aero activo.
     */
    fun getActiveAeroAccentKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString("aero_accent_key", "aero_blue") ?: "aero_blue"
    }

    /**
     * Obtiene el color de acento Aero activo como Int.
     * Compatible con AccentApplier.apply().
     */
    fun getAccentColor(context: Context): Int {
        val key = getActiveAeroAccentKey(context)
        return aeroAccentColors.firstOrNull { it.key == key }?.color
            ?: Color.parseColor("#4580C4")
    }

    // ── Aplicación del estilo ──────────────────────────────────────────────────

    /**
     * Aplica el estilo XML del tema Aero a la Activity.
     * DEBE llamarse ANTES de super.onCreate() y de setContentView().
     *
     * Ejemplo de uso en MainActivity / PlayerActivity:
     *
     *   override fun onCreate(savedInstanceState: Bundle?) {
     *       AeroThemeManager.applyTheme(this)   // ← PRIMERA línea
     *       super.onCreate(savedInstanceState)
     *       setContentView(R.layout.activity_main)
     *       ...
     *   }
     */
    fun applyTheme(activity: Activity) {
        // FIX fuentes: instalar el LayoutInflater factory ANTES de que se infle
        // el layout, para que todos los TextViews reciban la fuente correcta al crearse.
        com.aeroplayer.utils.FontLayoutInflaterFactory.install(activity)

        val prefs = activity.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
        val themeMode = prefs.getString("active_custom_theme", null)
            ?: prefs.getString("theme_mode", "dark")
        val isPlayer = activity.javaClass.simpleName.contains("Player")
        val isAmoled = prefs.getBoolean("amoled_theme", false)

        when (themeMode) {
            THEME_KEY_AERO -> {
                // Tema Windows Vista Aero
                when {
                    isAmoled && isPlayer -> activity.setTheme(R.style.Theme_AeroPlayer_AMOLED_Player)
                    isAmoled             -> activity.setTheme(R.style.Theme_AeroPlayer_AMOLED)
                    isPlayer             -> activity.setTheme(R.style.Theme_AeroPlayer_Aero_Player)
                    else                 -> activity.setTheme(R.style.Theme_AeroPlayer_Aero)
                }
            }
            "light" -> {
                // FIX tema claro: forzar el estilo Light explícitamente.
                // Sin esto las actividades heredan Theme.AeroPlayer (Dark) aunque
                // AppCompatDelegate esté en MODE_NIGHT_NO.
                if (isPlayer) activity.setTheme(R.style.Theme_AeroPlayer_Player_Light)
                else          activity.setTheme(R.style.Theme_AeroPlayer_Light)
            }
            // "dark" y "auto" usan el tema base (ya es oscuro por defecto)
            else -> { /* sin cambios — Theme.AeroPlayer es oscuro por defecto */ }
        }

        applyFont(activity)
    }

    // ── Helpers para drawables y vistas custom ────────────────────────────────

    /**
     * Crea un ColorStateList para botones con el estilo de borde brillante Aero.
     * States: [pressed] → darker, [default] → accent
     */
    fun getAeroButtonColorStateList(context: Context): android.content.res.ColorStateList {
        val accent = getAccentColor(context)
        val pressed = darkenColor(accent, 0.75f)
        return android.content.res.ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_pressed),
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf()
            ),
            intArrayOf(pressed, Color.parseColor("#80808080"), accent)
        )
    }

    /**
     * Oscurece un color por el factor dado (0..1).
     */
    private fun darkenColor(color: Int, factor: Float): Int {
        val a = Color.alpha(color)
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }
}
