package com.aeroplayer.utils

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat

/**
 * FontLayoutInflaterFactory — intercepta el inflado de layouts para
 * aplicar la fuente personalizada a todos los TextViews en el momento
 * de su creación, sin necesidad de recorrer el árbol después.
 *
 * Uso:
 *   override fun onCreate(savedInstanceState: Bundle?) {
 *       FontLayoutInflaterFactory.install(this)
 *       super.onCreate(savedInstanceState)
 *       ...
 *   }
 */
object FontLayoutInflaterFactory {

    fun install(context: Context) {
        val fontKey = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
            .getString("selected_font", "inter") ?: "inter"
        if (fontKey == "inter") return  // fuente por defecto, nada que hacer

        val fontResId = when (fontKey) {
            "outfit"         -> com.aeroplayer.R.font.outfit_regular
            "nunito"         -> com.aeroplayer.R.font.nunito_regular
            "poppins"        -> com.aeroplayer.R.font.poppins_regular
            "montserrat"     -> com.aeroplayer.R.font.montserrat_regular
            "raleway"        -> com.aeroplayer.R.font.raleway_regular
            "space_grotesk"  -> com.aeroplayer.R.font.space_grotesk_regular
            else             -> return
        }

        val typeface = runCatching {
            ResourcesCompat.getFont(context, fontResId)
        }.getOrNull() ?: return

        // Instalar factory en el LayoutInflater de la actividad
        if (context is androidx.appcompat.app.AppCompatActivity) {
            val inflater = LayoutInflater.from(context)
            // Solo instalar si no hay ya un factory de fuentes
            if (inflater.factory2 !is FontFactory) {
                val delegate = inflater.factory2
                val factory = FontFactory(typeface, delegate)
                // AppCompat ya instaló su factory; necesitamos "envolver" el existente
                try {
                    val field = LayoutInflater::class.java.getDeclaredField("mFactory2")
                    field.isAccessible = true
                    field.set(inflater, factory)
                } catch (_: Exception) {}
            }
        }
    }

    private class FontFactory(
        private val typeface: Typeface,
        private val delegate: LayoutInflater.Factory2?
    ) : LayoutInflater.Factory2 {

        override fun onCreateView(
            parent: View?,
            name: String,
            context: Context,
            attrs: AttributeSet
        ): View? {
            val view = delegate?.onCreateView(parent, name, context, attrs)
                ?: tryCreateView(name, context, attrs)
            if (view is TextView) {
                applyTypeface(view)
            }
            return view
        }

        override fun onCreateView(name: String, context: Context, attrs: AttributeSet): View? {
            val view = delegate?.onCreateView(name, context, attrs)
                ?: tryCreateView(name, context, attrs)
            if (view is TextView) {
                applyTypeface(view)
            }
            return view
        }

        private fun tryCreateView(name: String, context: Context, attrs: AttributeSet): View? = null

        private fun applyTypeface(tv: TextView) {
            val style = tv.typeface?.style ?: Typeface.NORMAL
            tv.typeface = when (style) {
                Typeface.BOLD        -> Typeface.create(typeface, Typeface.BOLD)
                Typeface.ITALIC      -> Typeface.create(typeface, Typeface.ITALIC)
                Typeface.BOLD_ITALIC -> Typeface.create(typeface, Typeface.BOLD_ITALIC)
                else                 -> typeface
            }
        }
    }
}
