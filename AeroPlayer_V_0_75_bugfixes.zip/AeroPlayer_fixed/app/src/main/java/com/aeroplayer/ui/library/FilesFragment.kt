package com.aeroplayer.ui.library

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentFilesBinding
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.player.PlayerActivity
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class SortOrder { TITLE, ARTIST, ALBUM, DURATION }

class FilesFragment : Fragment() {

    private var _binding: FragmentFilesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: SongListAdapter

    private var currentSort = SortOrder.TITLE

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFilesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupSortButton()
        observePagingData()
        observeLiked()
        observeLoadState()
    }

    private fun setupRecyclerView() {
        adapter = SongListAdapter(
            viewLifecycleOwner.lifecycleScope,
            // FIX BUG#1: usar la lista completa del ViewModel (NO snapshot del pager).
            // snapshot() solo devuelve las páginas visibles cargadas (~22 items).
            // Ahora siempre usamos la lista completa ordenada según el sort activo.
            onSongClick     = { song, _ ->
                val all = viewModel.allSongs.value ?: listOf(song)
                val songs = when (currentSort) {
                    SortOrder.TITLE    -> all.sortedBy    { it.title.lowercase() }
                    SortOrder.ARTIST   -> all.sortedBy    { it.artist.lowercase() }
                    SortOrder.ALBUM    -> all.sortedBy    { it.album.lowercase() }
                    SortOrder.DURATION -> all.sortedByDescending { it.duration }
                }
                PlayerController.playSongs(songs, songs.indexOf(song).coerceAtLeast(0), queueName = getString(R.string.tab_files))
                viewModel.incrementPlayCount(song)
            },
            onLikeClick     = { song -> viewModel.toggleLike(song) },
            onAddToPlaylist = { song -> showAddToPlaylistDialog(song) },
            onAddToQueue    = { song -> PlayerController.addToQueue(song) }
        )
        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(context)
            adapter       = this@FilesFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupSortButton() {
        binding.btnSort.setOnClickListener {
            val options = arrayOf(
                "Por título${if (currentSort == SortOrder.TITLE)    " ✓" else ""}",
                "Por artista${if (currentSort == SortOrder.ARTIST)  " ✓" else ""}",
                "Por álbum${if (currentSort == SortOrder.ALBUM)     " ✓" else ""}",
                "Por duración${if (currentSort == SortOrder.DURATION)" ✓" else ""}"
            )
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Ordenar por")
                .setItems(options) { _, idx ->
                    currentSort = SortOrder.entries[idx]
                    applySortToViewModel()
                }
                .show()
        }
    }

    // ── Paging 3 ─────────────────────────────────────────────────────────────

    /**
     * Colecta el Flow<PagingData<Song>> del ViewModel y lo envía al adapter.
     * Se re-emite automáticamente cuando cambia el sort (vía submitSortedSongs).
     */
    private fun observePagingData() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.songsPagingData.collectLatest { pagingData ->
                adapter.submitData(pagingData)
            }
        }

        // Cuando allSongs cambia (MediaStore refresh) re-aplicar el sort actual
        viewModel.allSongs.observe(viewLifecycleOwner) { _ ->
            applySortToViewModel()
        }
    }

    private fun applySortToViewModel() {
        val all = viewModel.allSongs.value ?: return
        val sorted = when (currentSort) {
            SortOrder.TITLE    -> all.sortedBy    { it.title.lowercase() }
            SortOrder.ARTIST   -> all.sortedBy    { it.artist.lowercase() }
            SortOrder.ALBUM    -> all.sortedBy    { it.album.lowercase() }
            SortOrder.DURATION -> all.sortedByDescending { it.duration }
        }
        val label = when (currentSort) {
            SortOrder.TITLE    -> "título"
            SortOrder.ARTIST   -> "artista"
            SortOrder.ALBUM    -> "álbum"
            SortOrder.DURATION -> "duración"
        }
        viewModel.submitSortedSongs(sorted)
        binding.tvCount.text = "${sorted.size} canciones · ordenadas por $label"
    }

    /** Muestra un spinner mientras la primera página carga. */
    private fun observeLoadState() {
        viewLifecycleOwner.lifecycleScope.launch {
            adapter.loadStateFlow.collectLatest { states ->
                val refresh = states.refresh
                binding.tvEmpty.visibility =
                    if (refresh is LoadState.NotLoading && adapter.itemCount == 0)
                        View.VISIBLE else View.GONE
            }
        }
    }

    private fun observeLiked() {
        viewModel.likedSongs.observe(viewLifecycleOwner) { liked ->
            adapter.updateLikedIds(liked.map { it.songId }.toSet())
        }
    }

    private fun showAddToPlaylistDialog(song: Song) {
        val playlists = viewModel.playlists.value ?: return
        if (playlists.isEmpty()) {
            Snackbar.make(binding.root, "Crea una playlist primero",
                Snackbar.LENGTH_SHORT).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Agregar a playlist")
            .setItems(names) { _, idx ->
                viewModel.addSongToPlaylist(playlists[idx].id, song)
                Snackbar.make(binding.root, "Agregado a ${playlists[idx].name}",
                    Snackbar.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
