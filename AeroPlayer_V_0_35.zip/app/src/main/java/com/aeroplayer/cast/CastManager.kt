package com.aeroplayer.cast

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.CastState
import com.google.android.gms.cast.framework.CastStateListener
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.aeroplayer.model.Song

/**
 * Singleton que gestiona el estado de la sesión de Chromecast.
 * Se inicializa en MainActivity y se usa desde PlayerActivity.
 */
object CastManager {

    private val _isCasting = MutableLiveData(false)
    val isCasting: LiveData<Boolean> = _isCasting

    private val _isAvailable = MutableLiveData(false)
    val isAvailable: LiveData<Boolean> = _isAvailable

    private var castContext: CastContext? = null
    private var currentSession: CastSession? = null

    private val castStateListener = CastStateListener { state ->
        _isAvailable.postValue(state != CastState.NO_DEVICES_AVAILABLE)
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            currentSession = session
            _isCasting.postValue(true)
        }
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            currentSession = session
            _isCasting.postValue(true)
        }
        override fun onSessionEnded(session: CastSession, error: Int) {
            currentSession = null
            _isCasting.postValue(false)
        }
        override fun onSessionSuspended(session: CastSession, reason: Int) {
            _isCasting.postValue(false)
        }
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionStartFailed(session: CastSession, error: Int) {
            _isCasting.postValue(false)
        }
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
    }

    fun init(context: Context) {
        runCatching {
            castContext = CastContext.getSharedInstance(context)
            castContext?.addCastStateListener(castStateListener)
            castContext?.sessionManager?.addSessionManagerListener(
                sessionListener, CastSession::class.java
            )
        }
    }

    fun release() {
        castContext?.removeCastStateListener(castStateListener)
        castContext?.sessionManager?.removeSessionManagerListener(
            sessionListener, CastSession::class.java
        )
    }

    /**
     * Envía una canción al dispositivo Chromecast conectado.
     *
     * NOTA: Chromecast no puede acceder a URIs locales (content://). Para que
     * el cast funcione completamente, la app necesitaría levantar un servidor
     * HTTP local que sirva el archivo. Por ahora se envían los metadatos y
     * la URI tal cual; en dispositivos con acceso a red compartida puede funcionar.
     */
    fun castSong(song: Song) {
        val session = currentSession ?: return
        val remoteClient = session.remoteMediaClient ?: return

        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MUSIC_TRACK).apply {
            putString(MediaMetadata.KEY_TITLE,  song.title)
            putString(MediaMetadata.KEY_ARTIST, song.artist)
            putString(MediaMetadata.KEY_ALBUM_TITLE, song.album)
            song.albumArtUri?.let {
                addImage(com.google.android.gms.common.images.WebImage(
                    android.net.Uri.parse(it.toString())
                ))
            }
        }

        val mediaInfo = MediaInfo.Builder(song.uri.toString())
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType("audio/*")
            .setMetadata(metadata)
            .setStreamDuration(song.duration)
            .build()

        remoteClient.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(mediaInfo)
                .setAutoplay(true)
                .build()
        )
    }

    /** Obtiene el CastContext para inflar el botón MediaRouteButton en los menús. */
    fun getCastContext(): CastContext? = castContext
}
