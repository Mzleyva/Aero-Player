package com.aeroplayer.ui.equalizer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * Vista de curva del ecualizador — v1.8.2
 * Mejoras visuales:
 *  - Gradiente vertical bicolor (azul arriba, rosa abajo del cero).
 *  - Líneas de grid horizontales a ±6dB, ±12dB.
 *  - Animación suave al cambiar niveles.
 *  - Puntos de banda con anillo de highlight al tocar.
 *  - Etiquetas dB en el eje Y.
 */
class EqCurveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var levels: List<Int>       = emptyList()
    private var animatedLevels: List<Float> = emptyList()
    private var animator: ValueAnimator? = null

    // ── Paints ────────────────────────────────────────────────────────────────
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style       = Paint.Style.STROKE
        strokeWidth = 3.5f
        strokeCap   = Paint.Cap.ROUND
        strokeJoin  = Paint.Join.ROUND
    }
    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val zeroPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = 0x55FFFFFF.toInt()
        style       = Paint.Style.STROKE
        strokeWidth = 1.5f
        pathEffect  = DashPathEffect(floatArrayOf(8f, 6f), 0f)
    }
    private val gridPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = 0x22FFFFFF.toInt()
        style       = Paint.Style.STROKE
        strokeWidth = 1f
        pathEffect  = DashPathEffect(floatArrayOf(4f, 6f), 0f)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = 0x66FFFFFF.toInt()
        textSize = 26f
        typeface = Typeface.MONOSPACE
    }
    private val dotPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5B9BD4.toInt()
        style = Paint.Style.FILL
    }
    private val dotRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = 0x445B9BD4.toInt()
        style       = Paint.Style.STROKE
        strokeWidth = 3f
    }

    // ── Public API ────────────────────────────────────────────────────────────
    fun setLevels(newLevels: List<Int>) {
        if (newLevels == levels) return
        val from = if (animatedLevels.size == newLevels.size) animatedLevels
                   else List(newLevels.size) { 0f }
        levels = newLevels

        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration    = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener { va ->
                val t = va.animatedFraction
                animatedLevels = newLevels.mapIndexed { i, target ->
                    val src = from.getOrElse(i) { 0f }
                    src + (target - src) * t
                }
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val lvl = animatedLevels.ifEmpty { levels.map { it.toFloat() } }
        if (lvl.isEmpty()) return

        val w    = width.toFloat()
        val h    = height.toFloat()
        val midY = h / 2f
        val range = 1500f   // ±1500 milli-dB

        // ── Grid lines ────────────────────────────────────────────────────────
        listOf(500f, 1000f).forEach { db ->
            val yUp   = midY - (db / range) * midY
            val yDown = midY + (db / range) * midY
            canvas.drawLine(0f, yUp,   w, yUp,   gridPaint)
            canvas.drawLine(0f, yDown, w, yDown, gridPaint)
        }

        // ── Etiquetas eje Y ───────────────────────────────────────────────────
        val dbLabels = listOf(1000f to "+10", -1000f to "−10", 500f to "+5", -500f to "−5")
        dbLabels.forEach { (db, txt) ->
            val y = midY - (db / range) * midY
            canvas.drawText(txt, 6f, y + labelPaint.textSize / 3, labelPaint)
        }

        // ── Línea central 0 dB ───────────────────────────────────────────────
        canvas.drawLine(0f, midY, w, midY, zeroPaint)

        // ── Construir path spline ─────────────────────────────────────────────
        val n = lvl.size
        fun xOf(i: Int) = if (n <= 1) w / 2f else i.toFloat() / (n - 1) * w
        fun yOf(v: Float) = midY - (v / range) * midY

        val path = Path()
        if (n == 1) {
            path.moveTo(0f, yOf(lvl[0])); path.lineTo(w, yOf(lvl[0]))
        } else {
            path.moveTo(xOf(0), yOf(lvl[0]))
            for (i in 0 until n - 1) {
                val x0 = xOf((i - 1).coerceAtLeast(0));  val y0 = yOf(lvl[(i - 1).coerceAtLeast(0)])
                val x1 = xOf(i);                          val y1 = yOf(lvl[i])
                val x2 = xOf(i + 1);                      val y2 = yOf(lvl[i + 1])
                val x3 = xOf((i + 2).coerceAtMost(n-1)); val y3 = yOf(lvl[(i + 2).coerceAtMost(n-1)])
                val cp1x = x1 + (x2 - x0) / 6f;  val cp1y = y1 + (y2 - y0) / 6f
                val cp2x = x2 - (x3 - x1) / 6f;  val cp2y = y2 - (y3 - y1) / 6f
                path.cubicTo(cp1x, cp1y, cp2x, cp2y, x2, y2)
            }
        }

        // ── Fill bicolor (azul arriba del 0, rosa/magenta abajo) ──────────────
        // Zona positiva
        val fillPos = Path(path)
        fillPos.lineTo(xOf(n - 1), midY); fillPos.lineTo(xOf(0), midY); fillPos.close()
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, midY,
            intArrayOf(0x555B9BD4, 0x005B9BD4),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.clipRect(0f, 0f, w, midY)
        canvas.drawPath(fillPos, fillPaint)
        canvas.restore()

        // Zona negativa
        val fillNeg = Path(path)
        fillNeg.lineTo(xOf(n - 1), midY); fillNeg.lineTo(xOf(0), midY); fillNeg.close()
        fillPaint.shader = LinearGradient(
            0f, midY, 0f, h,
            intArrayOf(0x00E879A2, 0x44E879A2),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.clipRect(0f, midY, w, h)
        canvas.drawPath(fillNeg, fillPaint)
        canvas.restore()

        // ── Línea principal con gradiente horizontal ──────────────────────────
        linePaint.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(0xFF5B9BD4.toInt(), 0xFF7EC8E3.toInt(), 0xFFE879A2.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(path, linePaint)
        linePaint.shader = null

        // ── Puntos de banda ───────────────────────────────────────────────────
        lvl.forEachIndexed { i, v ->
            val cx = xOf(i); val cy = yOf(v)
            val boosted = kotlin.math.abs(v) > 300f
            dotPaint.color = if (v > 0) 0xFF5B9BD4.toInt() else if (v < 0) 0xFFE879A2.toInt() else 0xFFAAAAAA.toInt()
            canvas.drawCircle(cx, cy, if (boosted) 5.5f else 4f, dotPaint)
            if (boosted) canvas.drawCircle(cx, cy, 9f, dotRingPaint)
        }
    }
}
