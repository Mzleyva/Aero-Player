package com.aeroplayer.service

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import com.aeroplayer.ui.widget.PlayerWidget
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aeroplayer.model.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors

object PlayerController {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var prefs: SharedPreferences? = null

    private val _currentSong = MutableLiveData<Song?>(null)
    val currentSong: LiveData<Song?> = _currentSong

    private val _isPlaying = MutableLiveData(false)
    val isPlaying: LiveData<Boolean> = _isPlaying

    private val _queue = MutableLiveData<List<Song>>(emptyList())
    val queue: LiveData<List<Song>> = _queue

    /** Nombre descriptivo de la cola actual (ej. "Playlist", "Álbum", "Me gusta"). */
    private val _queueName = MutableLiveData<String?>(null)
    val queueName: LiveData<String?> = _queueName

    private val _currentIndex = MutableLiveData(0)
    val currentIndex: LiveData<Int> = _currentIndex

    private val _shuffleMode = MutableLiveData(false)
    val shuffleMode: LiveData<Boolean> = _shuffleMode

    private val _repeatMode = MutableLiveData(Player.REPEAT_MODE_OFF)
    val repeatMode: LiveData<Int> = _repeatMode

    private val _playbackSpeed = MutableLiveData(1.0f)
    val playbackSpeed: LiveData<Float> = _playbackSpeed

    // ── Crossfade ────────────────────────────────────────────────────────────
    private val _crossfadeEnabled = MutableLiveData(false)
    val crossfadeEnabled: LiveData<Boolean> = _crossfadeEnabled

    private val crossfadeHandler = Handler(Looper.getMainLooper())
    private const val CROSSFADE_DURATION_MS = 2_000L
    private const val CROSSFADE_INTERVAL_MS = 50L
    private var isFadingOut = false
    private var isFadingIn  = false
    private var fadeInStart = 0L

    private val crossfadeRunnable = object : Runnable {
        override fun run() {
            // Si no hay controller conectado no reprogramar — se relanzará en connect()
            val ctrl = controller ?: return
            // FIX: si crossfade está desactivado, no reprogramar — se lanzará de nuevo en setCrossfadeEnabled(true)
            if (_crossfadeEnabled.value != true) return
            val duration = ctrl.duration
            val position = ctrl.currentPosition
            if (duration <= 0) { crossfadeHandler.postDelayed(this, CROSSFADE_INTERVAL_MS); return }

            val remaining = duration - position
            if (remaining in 1..CROSSFADE_DURATION_MS && !isFadingOut) isFadingOut = true
            if (isFadingOut && remaining > 0) {
                ctrl.volume = (remaining.toFloat() / CROSSFADE_DURATION_MS).coerceIn(0f, 1f)
            }
            if (isFadingIn) {
                val elapsed = System.currentTimeMillis() - fadeInStart
                val ratio = (elapsed.toFloat() / CROSSFADE_DURATION_MS).coerceIn(0f, 1f)
                ctrl.volume = ratio
                if (ratio >= 1f) { isFadingIn = false; ctrl.volume = 1f }
            }
            crossfadeHandler.postDelayed(this, CROSSFADE_INTERVAL_MS)
        }
    }

    fun setCrossfadeEnabled(enabled: Boolean) {
        _crossfadeEnabled.postValue(enabled)
        prefs?.edit()?.putBoolean(PREF_CROSSFADE, enabled)?.apply()
        if (enabled) {
            // FIX: relanzar el loop ahora que se activó (fue detenido cuando se desactivó)
            crossfadeHandler.removeCallbacks(crossfadeRunnable)
            crossfadeHandler.post(crossfadeRunnable)
        } else {
            isFadingOut = false; isFadingIn = false; controller?.volume = 1f
        }
    }

    // ── A-B Repeat ───────────────────────────────────────────────────────────
    enum class ABRepeatState { OFF, A_SET, AB_ACTIVE }

    private val _abRepeatState = MutableLiveData(ABRepeatState.OFF)
    val abRepeatState: LiveData<ABRepeatState> = _abRepeatState
    private var abPointA = 0L
    private var abPointB = 0L

    private val abRepeatHandler = Handler(Looper.getMainLooper())
    private val abRepeatRunnable = object : Runnable {
        override fun run() {
            val ctrl = controller ?: return
            if (_abRepeatState.value == ABRepeatState.AB_ACTIVE) {
                if (ctrl.currentPosition >= abPointB) ctrl.seekTo(abPointA)
                abRepeatHandler.postDelayed(this, 100)
            }
        }
    }

    fun cycleABRepeat() {
        when (_abRepeatState.value) {
            ABRepeatState.OFF -> {
                abPointA = controller?.currentPosition ?: 0L
                _abRepeatState.postValue(ABRepeatState.A_SET)
            }
            ABRepeatState.A_SET -> {
                abPointB = controller?.currentPosition ?: 0L
                if (abPointB > abPointA) {
                    _abRepeatState.postValue(ABRepeatState.AB_ACTIVE)
                    abRepeatHandler.post(abRepeatRunnable)
                } else {
                    _abRepeatState.postValue(ABRepeatState.OFF)
                }
            }
            else -> resetABRepeat()
        }
    }

    private fun resetABRepeat() {
        abRepeatHandler.removeCallbacks(abRepeatRunnable)
        abPointA = 0L; abPointB = 0L
        _abRepeatState.postValue(ABRepeatState.OFF)
    }

    // ── Prefs keys ───────────────────────────────────────────────────────────
    private const val PREFS_NAME          = "aero_prefs"
    private const val PREF_CROSSFADE      = "crossfade_enabled"
    private const val PREF_SPEED          = "playback_speed"
    private const val PREF_LAST_SONG_ID   = "last_song_id"
    private const val PREF_LAST_INDEX     = "last_queue_index"
    private const val PREF_LAST_POSITION  = "last_position_ms"

    private var queueSongs: List<Song> = emptyList()
    private var appContext: Context? = null

    // ── Player listener ──────────────────────────────────────────────────────
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.postValue(isPlaying)
            appContext?.let { PlayerWidget.update(it) }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = controller?.currentMediaItemIndex ?: return
            if (idx in queueSongs.indices) {
                _currentSong.postValue(queueSongs[idx])
                _currentIndex.postValue(idx)
                // Persistir última canción e índice para restaurar tras kill
                prefs?.edit()
                    ?.putLong(PREF_LAST_SONG_ID, queueSongs[idx].id)
                    ?.putInt(PREF_LAST_INDEX, idx)
                    ?.putLong(PREF_LAST_POSITION, 0L)
                    ?.apply()
            }
            resetABRepeat()
            if (_crossfadeEnabled.value == true) {
                isFadingOut = false; isFadingIn = true
                fadeInStart = System.currentTimeMillis()
                controller?.volume = 0f
            }
            appContext?.let { PlayerWidget.update(it) }

            // Pre-cargar carátulas de las 3 canciones siguientes y 1 anterior en background
            val preloadRange = (-1..3).mapNotNull { offset ->
                val target = idx + offset
                if (target in queueSongs.indices) {
                    val s = queueSongs[target]
                    Triple(s.id, s.path, s)
                } else null
            }
            com.aeroplayer.utils.AlbumArtUtils.preloadWithMeta(preloadRange)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffleMode.postValue(shuffleModeEnabled)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeatMode.postValue(repeatMode)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            // FIX BUG1: cuando la cola termina ExoPlayer pasa a STATE_ENDED.
            // NO llamar seekTo(0,0) aquí — si el usuario ha lanzado playSongs()
            // justo antes de que llegue este callback, seekTo() puede mover el
            // reproductor a la posición 0 de la nueva cola, saltándose la canción
            // elegida. Solo pausar limpiamente si no hay siguiente item.
            if (playbackState == Player.STATE_ENDED) {
                val ctrl = controller ?: return
                if (!ctrl.hasNextMediaItem()) {
                    ctrl.pause()
                    // NO hacer seekTo aquí — dejar que playSongs() maneje el estado
                }
            }
            syncStateFromController()
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    fun connect(context: Context) {
        // Guard: si ya hay un controller activo, no reconectar (evita fuga en rotaciones)
        if (controller != null) return
        appContext = context.applicationContext
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val savedCrossfade = prefs?.getBoolean(PREF_CROSSFADE, false) ?: false
        _crossfadeEnabled.postValue(savedCrossfade)

        val savedSpeed = prefs?.getFloat(PREF_SPEED, 1.0f) ?: 1.0f
        _playbackSpeed.postValue(savedSpeed)

        val token = SessionToken(context, ComponentName(context, MusicService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            controller = runCatching { controllerFuture?.get() }.getOrNull()
            controller?.addListener(listener)
            syncStateFromController()
            if (savedSpeed != 1.0f) {
                controller?.playbackParameters =
                    controller!!.playbackParameters.withSpeed(savedSpeed)
            }
            // FIX: solo iniciar el loop de crossfade si está activo — evita timer innecesario
            if (savedCrossfade) crossfadeHandler.post(crossfadeRunnable)
        }, MoreExecutors.directExecutor())
    }

    /** Safe disconnect — tolerates Activity recreation (rotation). */
    fun disconnect() {
        crossfadeHandler.removeCallbacks(crossfadeRunnable)
        abRepeatHandler.removeCallbacks(abRepeatRunnable)
        controller?.removeListener(listener)
        val future = controllerFuture ?: return
        MediaController.releaseFuture(future)
        controllerFuture = null
        controller = null
    }

    private fun syncStateFromController() {
        val ctrl = controller ?: return
        _isPlaying.postValue(ctrl.isPlaying)
        _shuffleMode.postValue(ctrl.shuffleModeEnabled)
        _repeatMode.postValue(ctrl.repeatMode)
        _playbackSpeed.postValue(ctrl.playbackParameters.speed)
        val idx = ctrl.currentMediaItemIndex
        if (queueSongs.isNotEmpty() && idx in queueSongs.indices) {
            _currentSong.postValue(queueSongs[idx])
            _currentIndex.postValue(idx)
            _queue.postValue(queueSongs)
        }
    }

    // ── Playback commands ────────────────────────────────────────────────────
    fun playSongs(songs: List<Song>, startIndex: Int = 0, queueName: String? = null) {
        val ctrl = controller ?: return
        if (songs.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, songs.lastIndex)
        queueSongs = songs
        _queue.postValue(songs)
        _queueName.postValue(queueName)
        resetABRepeat()

        val items = songs.map { song ->
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                ).build()
        }

        // FIX BUG1: detener reproducción actual ANTES de setMediaItems.
        // Si el player está en STATE_ENDED, llamar setMediaItems sin stop() previo
        // puede dejar el MediaController en un estado inconsistente donde prepare()
        // y play() no tienen efecto. stop() garantiza que el player vuelva a IDLE
        // antes de cargar la nueva lista.
        ctrl.stop()

        if (_crossfadeEnabled.value == true) {
            isFadingOut = false; isFadingIn = true
            fadeInStart = System.currentTimeMillis()
            ctrl.volume = 0f
        } else {
            ctrl.volume = 1f
        }

        ctrl.setMediaItems(items, safeIndex, 0)
        ctrl.prepare()
        ctrl.play()
        _currentSong.postValue(songs[safeIndex])
        _currentIndex.postValue(safeIndex)
    }

    fun addToQueue(song: Song) {
        val ctrl = controller ?: return
        val newQueue = queueSongs.toMutableList().also { it.add(song) }
        queueSongs = newQueue
        _queue.postValue(newQueue)
        ctrl.addMediaItem(
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(song.albumArtUri)
                        .build()
                ).build()
        )
    }

    fun removeFromQueue(index: Int) {
        val ctrl = controller ?: return
        if (index in queueSongs.indices) {
            val newQueue = queueSongs.toMutableList().also { it.removeAt(index) }
            queueSongs = newQueue
            _queue.postValue(newQueue)
            ctrl.removeMediaItem(index)
        }
    }

    /**
     * Reordena la cola completa tras un drag & drop.
     * Reconstruye los MediaItems en ExoPlayer con el nuevo orden
     * y actualiza currentIndex para apuntar a la misma canción.
     */
    fun reorderQueue(newOrder: List<Song>, currentSongIndex: Int) {
        val ctrl = controller ?: return
        queueSongs = newOrder.toMutableList()
        _queue.postValue(queueSongs)

        // Reconstruir MediaItems en ExoPlayer
        val mediaItems = newOrder.map { song ->
            androidx.media3.common.MediaItem.Builder()
                .setUri(song.uri)
                .setMediaId(song.id.toString())
                .build()
        }
        val playingUri = ctrl.currentMediaItem?.localConfiguration?.uri
        ctrl.clearMediaItems()
        ctrl.addMediaItems(mediaItems)

        // Buscar el índice de la canción que estaba sonando en el nuevo orden
        val newIdx = newOrder.indexOfFirst {
            it.uri == playingUri
        }.takeIf { it >= 0 } ?: currentSongIndex.coerceIn(0, newOrder.lastIndex)

        ctrl.seekTo(newIdx, ctrl.currentPosition)
        _currentIndex.postValue(newIdx)
    }

    fun playPause() {
        controller?.let {
            if (it.isPlaying) {
                it.volume = 1f; isFadingOut = false; isFadingIn = false
                it.pause()
            } else {
                it.play()
            }
        }
    }

    /** Always pauses without toggle — used by SleepTimer. */
    fun pause() {
        controller?.let {
            it.volume = 1f; isFadingOut = false; isFadingIn = false
            savePosition()
            it.pause()
        }
    }

    /** Persiste la posición actual para restaurarla tras kill de proceso. */
    fun savePosition() {
        val pos = controller?.currentPosition ?: return
        val idx = controller?.currentMediaItemIndex ?: return
        prefs?.edit()
            ?.putLong(PREF_LAST_POSITION, pos)
            ?.putInt(PREF_LAST_INDEX, idx)
            ?.apply()
    }

    /** Devuelve (lastIndex, lastPositionMs) guardados, o null si no hay nada. */
    fun getSavedPlaybackState(): Pair<Int, Long>? {
        val prefs = prefs ?: return null
        val idx = prefs.getInt(PREF_LAST_INDEX, -1)
        val pos = prefs.getLong(PREF_LAST_POSITION, 0L)
        return if (idx >= 0) Pair(idx, pos) else null
    }

    fun next()     { resetABRepeat(); controller?.seekToNextMediaItem() }
    fun previous() { resetABRepeat(); controller?.seekToPreviousMediaItem() }
    fun seekTo(ms: Long)     { controller?.seekTo(ms) }
    fun getCurrentPosition() = controller?.currentPosition ?: 0L
    fun getDuration()        = controller?.duration ?: 0L
    fun getAudioSessionId(): Int = MusicService.audioSessionId

    fun setPlaybackSpeed(speed: Float) {
        val ctrl = controller ?: return
        val clamped = speed.coerceIn(0.25f, 3.0f)
        ctrl.playbackParameters = ctrl.playbackParameters.withSpeed(clamped)
        _playbackSpeed.postValue(clamped)
        prefs?.edit()?.putFloat(PREF_SPEED, clamped)?.apply()
    }

    fun toggleShuffle() {
        val ctrl = controller ?: return
        ctrl.shuffleModeEnabled = !ctrl.shuffleModeEnabled
    }

    fun toggleRepeat() {
        val ctrl = controller ?: return
        ctrl.repeatMode = when (ctrl.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else                   -> Player.REPEAT_MODE_OFF
        }
        // FIX: forzar actualización del LiveData para que la UI refleje el cambio
        _repeatMode.postValue(ctrl.repeatMode)
    }
}
