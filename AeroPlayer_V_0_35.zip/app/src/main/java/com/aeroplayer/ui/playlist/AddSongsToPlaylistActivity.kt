package com.aeroplayer.ui.playlist

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ActivityAddSongsBinding
import com.aeroplayer.databinding.ItemAddSongBinding
import com.aeroplayer.model.Song
import com.aeroplayer.ui.MainViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.snackbar.Snackbar

class AddSongsToPlaylistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddSongsBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: AddSongAdapter
    private var playlistId: Long = -1L
    private val selectedIds = mutableSetOf<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddSongsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        playlistId = intent.getLongExtra("playlistId", -1L)
        if (playlistId == -1L) { finish(); return }

        setupToolbar()
        setupSearch()
        setupRecyclerView()
        setupDoneButton()
        observeSongs()
    }

    private fun setupToolbar() {
        binding.btnBack.setOnClickListener { finish() }
        binding.tvTitle.text = getString(R.string.add_songs)
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                filterSongs(query)
            }
        })
    }

    private fun setupRecyclerView() {
        adapter = AddSongAdapter(
            onToggle = { song, selected ->
                if (selected) selectedIds.add(song.id) else selectedIds.remove(song.id)
                updateDoneButton()
            }
        )
        binding.rvSongs.apply {
            layoutManager = LinearLayoutManager(this@AddSongsToPlaylistActivity)
            adapter = this@AddSongsToPlaylistActivity.adapter
            setHasFixedSize(true)
        }
    }

    private fun setupDoneButton() {
        binding.btnDone.setOnClickListener {
            val songs = viewModel.allSongs.value ?: return@setOnClickListener
            val selected = songs.filter { it.id in selectedIds }
            selected.forEach { song ->
                viewModel.addSongToPlaylist(playlistId, song)
            }
            Snackbar.make(
                binding.root,
                getString(R.string.songs_added, selected.size),
                Snackbar.LENGTH_SHORT
            ).show()
            finish()
        }
        updateDoneButton()
    }

    private fun observeSongs() {
        // FIX: observe both all songs and current playlist songs, then exclude already-added ones
        viewModel.allSongs.observe(this) { allSongs ->
            val existingIds = existingSongIds
            val available = allSongs.filter { it.id !in existingIds }
            allSongsList = available
            filterSongs(binding.etSearch.text?.toString()?.trim() ?: "")
        }
        viewModel.getPlaylistSongs(playlistId).observe(this) { entities ->
            existingSongIds = entities.map { it.songId }.toSet()
            // Re-filter when playlist changes
            val available = (allSongsList).filter { it.id !in existingSongIds }
            filterSongs(binding.etSearch.text?.toString()?.trim() ?: "")
        }
    }

    private var allSongsList: List<com.aeroplayer.model.Song> = emptyList()
    private var existingSongIds: Set<Long> = emptySet()

    private fun filterSongs(query: String) {
        val base = allSongsList.filter { it.id !in existingSongIds }
        val filtered = if (query.isEmpty()) base
        else base.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.artist.contains(query, ignoreCase = true)
        }
        adapter.submitList(filtered)
    }

    private fun updateDoneButton() {
        val count = selectedIds.size
        binding.btnDone.text = if (count > 0)
            getString(R.string.add_count, count)
        else
            getString(R.string.done)
        binding.btnDone.isEnabled = count > 0
    }
}

// ── Adapter interno ──────────────────────────────────────────────────────────
class AddSongAdapter(
    private val onToggle: (Song, Boolean) -> Unit
) : ListAdapter<Song, AddSongAdapter.VH>(SongDiff()) {

    private val selectedIds = mutableSetOf<Long>()

    inner class VH(val b: ItemAddSongBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAddSongBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val song = getItem(position)
        with(holder.b) {
            tvTitle.text = song.title
            tvArtist.text = song.artist

            Glide.with(ivAlbumArt)
                .load(
                    com.aeroplayer.utils.AlbumArtUtils.getAlbumArt(song.id, song.path)
                        ?: song.albumArtUri
                )
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(ivAlbumArt)

            checkBox.isChecked = song.id in selectedIds
            checkBox.setOnCheckedChangeListener(null)
            checkBox.setOnCheckedChangeListener { _, checked ->
                if (checked) selectedIds.add(song.id) else selectedIds.remove(song.id)
                onToggle(song, checked)
            }
            root.setOnClickListener { checkBox.toggle() }
        }
    }

    class SongDiff : DiffUtil.ItemCallback<Song>() {
        override fun areItemsTheSame(a: Song, b: Song) = a.id == b.id
        override fun areContentsTheSame(a: Song, b: Song) = a == b
    }
}
