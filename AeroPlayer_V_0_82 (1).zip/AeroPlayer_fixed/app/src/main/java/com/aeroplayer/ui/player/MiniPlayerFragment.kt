package com.aeroplayer.ui.player

import android.content.Intent
import android.app.ActivityOptions
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentMiniPlayerBinding
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class MiniPlayerFragment : Fragment() {

    private var _binding: FragmentMiniPlayerBinding? = null
    private val binding get() = _binding!!

    private val handler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            // FIX #12: guardia nula — si la vista ya fue destruida no actualizar
            val b = _binding ?: return
            val pos = PlayerController.getCurrentPosition()
            val dur = PlayerController.getDuration()
            if (dur > 0) {
                b.progressBar.progress = ((pos * 100) / dur).toInt()
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMiniPlayerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), view as android.view.ViewGroup)
        setupControls()
        observePlayer()
    }

    private fun View.hapticTap() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun setupControls() {
        // FIX BUG#3: marcar botones como clickable+focusable explícitamente.
        // Aunque el XML ya los tiene, esto garantiza que consuman el evento
        // y NO lo propaguen al root (que abriría el reproductor completo).
        binding.btnPrev.isClickable      = true
        binding.btnPrev.isFocusable      = true
        binding.btnPlayPause.isClickable = true
        binding.btnPlayPause.isFocusable = true
        binding.btnNext.isClickable      = true
        binding.btnNext.isFocusable      = true

        binding.btnPrev.setOnClickListener {
            it.hapticTap()
            PlayerController.previous()
        }
        binding.btnPlayPause.setOnClickListener {
            it.hapticTap()
            PlayerController.playPause()
        }
        binding.btnNext.setOnClickListener {
            it.hapticTap()
            PlayerController.next()
        }

        // FIX BUG#3: El root abre el reproductor SOLO si el toque no cayó sobre
        // ninguno de los botones de control. Se usa OnTouchListener con hit-test
        // para diferenciar toques en el fondo del mini-player vs. en los botones.
        // setOnClickListener solo en root ya no es suficiente porque ConstraintLayout
        // puede consumir el MotionEvent antes de que llegue a los hijos en algunos
        // dispositivos con implementaciones de ViewGroup no estándar.
        binding.root.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener false
            val controlViews = listOf(binding.btnPrev, binding.btnPlayPause, binding.btnNext)
            val touchedControl = controlViews.any { btn ->
                val loc = IntArray(2)
                btn.getLocationOnScreen(loc)
                event.rawX >= loc[0] && event.rawX <= loc[0] + btn.width &&
                event.rawY >= loc[1] && event.rawY <= loc[1] + btn.height
            }
            if (!touchedControl) {
                v.performClick()
            }
            false  // no consumir — dejar que los hijos manejen su propio evento
        }
        binding.root.setOnClickListener {
            val options = android.app.ActivityOptions.makeCustomAnimation(
                requireContext(),
                R.anim.slide_up,
                R.anim.fade_out
            )
            startActivity(
                android.content.Intent(requireContext(), PlayerActivity::class.java),
                options.toBundle()
            )
        }
    }

    private fun observePlayer() {
        // FIX #12: re-suscribir siempre que la vista exista (viewLifecycleOwner)
        // para que tras volver de fondo el estado se sincronice correctamente
        PlayerController.currentSong.observe(viewLifecycleOwner) { song ->
            val b = _binding ?: return@observe
            if (song == null) {
                b.root.visibility = View.GONE
                return@observe
            }
            b.root.visibility = View.VISIBLE
            b.tvTitle.text  = song.title
            b.tvArtist.text = song.artist

            val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
            Glide.with(b.ivAlbumArt)
                .load(cached ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(b.ivAlbumArt)
        }

        // FIX #12: observar isPlaying para actualizar el ícono en tiempo real
        PlayerController.isPlaying.observe(viewLifecycleOwner) { playing ->
            _binding?.btnPlayPause?.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    override fun onResume() {
        super.onResume()
        // FIX #12: sincronizar estado inmediatamente al volver a primer plano
        // (el LiveData puede haberse perdido mientras el fragment estaba en background)
        PlayerController.currentSong.value?.let { song ->
            _binding?.tvTitle?.text  = song.title
            _binding?.tvArtist?.text = song.artist
        }
        _binding?.btnPlayPause?.setImageResource(
            if (PlayerController.isPlaying.value == true) R.drawable.ic_pause
            else R.drawable.ic_play
        )
        handler.post(progressRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(progressRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(progressRunnable)
        _binding = null
    }
}
