package com.aeroplayer.ui.player

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.databinding.ItemAlbumArtPagerBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

/**
 * Adapter para el ViewPager2 de album art en el player.
 *
 * Carrusel infinito virtual con [TOTAL_PAGES] páginas centradas en [CENTER_PAGE].
 * Soporta GIF Canvas: si la canción actual tiene un GIF asignado se muestra
 * en loop como fondo animado y el album art se vuelve transparente.
 *
 * Providers:
 *   [uriProvider]    → URI del album art dado un offset relativo (-1, 0, +1)
 *   [canvasProvider] → URI del GIF Canvas de la canción en offset 0 (solo actual)
 */
class AlbumArtPagerAdapter : RecyclerView.Adapter<AlbumArtPagerAdapter.AlbumArtViewHolder>() {

    companion object {
        const val TOTAL_PAGES = 2001
        const val CENTER_PAGE = 1000
    }

    var uriProvider: ((offset: Int) -> Uri?) = { null }

    /**
     * Provee la URI del GIF Canvas solo para la posición central (canción actual).
     * Para las páginas adyacentes siempre devuelve null — no mostramos el canvas
     * de canciones que aún no están sonando.
     */
    var canvasProvider: (() -> Uri?) = { null }

    inner class AlbumArtViewHolder(val b: ItemAlbumArtPagerBinding) :
        RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumArtViewHolder {
        return AlbumArtViewHolder(
            ItemAlbumArtPagerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun getItemCount() = TOTAL_PAGES

    override fun onBindViewHolder(holder: AlbumArtViewHolder, position: Int) {
        val offset   = position - CENTER_PAGE
        val artUri   = uriProvider(offset)
        val gifUri   = if (offset == 0) canvasProvider() else null
        val hasCanvas = gifUri != null

        with(holder.b) {

            // ── Album art ────────────────────────────────────────────────────
            // Con canvas activo lo volvemos invisible para mostrar solo el GIF;
            // sin canvas, album art normal a pantalla completa.
            ivPagerAlbumArt.alpha = if (hasCanvas) 0f else 1f

            Glide.with(ivPagerAlbumArt)
                .load(artUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .error(R.drawable.ic_music_placeholder)
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .transition(DrawableTransitionOptions.withCrossFade(150))
                .centerCrop()
                .into(ivPagerAlbumArt)

            // ── GIF Canvas ───────────────────────────────────────────────────
            if (hasCanvas) {
                ivGifCanvas.visibility = View.VISIBLE
                Glide.with(ivGifCanvas)
                    .asGif()
                    .load(gifUri)
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
                    .centerCrop()
                    .into(ivGifCanvas)
            } else {
                // Limpiar explícitamente para evitar GIF de reciclado en otras páginas
                Glide.with(ivGifCanvas).clear(ivGifCanvas)
                ivGifCanvas.visibility = View.GONE
            }
        }
    }
}
