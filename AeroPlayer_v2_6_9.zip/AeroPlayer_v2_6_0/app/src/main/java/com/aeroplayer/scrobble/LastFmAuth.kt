package com.aeroplayer.scrobble

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.io.OutputStreamWriter
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Autenticación y scrobbling con Last.fm API v2.
 *
 * Implementa:
 * - getSessionKey(username, password) → Last.fm mobile auth
 * - scrobble(sessionKey, song) → registrar reproducción
 * - updateNowPlaying(sessionKey, song) → "escuchando ahora"
 */
object LastFmAuth {

    // ⚠️ CONFIGURAR: reemplaza con tu propia API key y secret de https://www.last.fm/api/account/create
    // La API_KEY ya está configurada (pública). El API_SECRET es obligatorio para firmar peticiones.
    private const val API_KEY    = "43654bd59c8e90695c88f7c5ac191d57"
    private const val API_SECRET = "YOUR_LASTFM_API_SECRET_HERE" // TODO: completar antes de publicar
    private const val API_BASE   = "https://ws.audioscrobbler.com/2.0/"

    /**
     * Autenticación mobile de Last.fm.
     * Returns session key on success, null on failure.
     */
    suspend fun getSessionKey(username: String, password: String): String? =
        withContext(Dispatchers.IO) {
            try {
                val params = sortedMapOf(
                    "api_key"  to API_KEY,
                    "method"   to "auth.getMobileSession",
                    "password" to password,
                    "username" to username
                )
                params["api_sig"] = sign(params)
                params["format"]  = "json"

                val body = params.entries.joinToString("&") {
                    "${it.key}=${java.net.URLEncoder.encode(it.value, "UTF-8")}"
                }

                val conn = (URL(API_BASE).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                }
                OutputStreamWriter(conn.outputStream).use { it.write(body) }

                val response = conn.inputStream.bufferedReader().readText()
                val jsonObj  = org.json.JSONObject(response)

                if (jsonObj.has("error")) {
                    null
                } else {
                    jsonObj.getJSONObject("session").getString("key")
                }
            } catch (e: Exception) {
                null
            }
        }

    /**
     * Scrobble a track to Last.fm.
     * Call after the user has listened to > 50% or > 4 minutes of a track.
     */
    suspend fun scrobble(
        sessionKey: String,
        artist: String,
        track: String,
        album: String,
        timestamp: Long = System.currentTimeMillis() / 1000L
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val params = sortedMapOf(
                "api_key"    to API_KEY,
                "artist[0]"  to artist,
                "method"     to "track.scrobble",
                "sk"         to sessionKey,
                "timestamp[0]" to timestamp.toString(),
                "track[0]"   to track
            )
            if (album.isNotBlank()) params["album[0]"] = album
            params["api_sig"] = sign(params)
            params["format"]  = "json"
            post(params)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Update Now Playing on Last.fm.
     * Call when a new track starts.
     */
    suspend fun updateNowPlaying(
        sessionKey: String,
        artist: String,
        track: String,
        album: String,
        durationSecs: Long = 0L
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val params = sortedMapOf(
                "api_key" to API_KEY,
                "artist"  to artist,
                "method"  to "track.updateNowPlaying",
                "sk"      to sessionKey,
                "track"   to track
            )
            if (album.isNotBlank())     params["album"]    = album
            if (durationSecs > 0)       params["duration"] = durationSecs.toString()
            params["api_sig"] = sign(params)
            params["format"]  = "json"
            post(params)
        } catch (e: Exception) {
            false
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** MD5 signature required by Last.fm API v2. */
    private fun sign(params: Map<String, String>): String {
        // Exclude "format" and "callback" from signature
        val str = params
            .filterKeys { it != "format" && it != "callback" }
            .entries
            .sortedBy { it.key }
            .joinToString("") { "${it.key}${it.value}" } + API_SECRET

        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(str.toByteArray(Charsets.UTF_8))
        return BigInteger(1, digest).toString(16).padStart(32, '0')
    }

    private fun post(params: Map<String, String>): Boolean {
        val body = params.entries.joinToString("&") {
            "${it.key}=${java.net.URLEncoder.encode(it.value, "UTF-8")}"
        }
        val conn = (URL(API_BASE).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connectTimeout = 8_000
            readTimeout    = 8_000
        }
        OutputStreamWriter(conn.outputStream).use { it.write(body) }
        return conn.responseCode == 200
    }
}

/**
 * Scrobble manager — se conecta a MusicService para detectar cuándo
 * corresponde enviar el scrobble (>50% de la canción escuchada).
 */
object ScrobbleManager {

    private var trackStartTime = 0L
    private var lastScrobbledId = -1L
    // Scope propio — no depende del ciclo de vida de ninguna Activity
    private val scope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.IO
    )

    fun onTrackStart(context: Context, songId: Long, artist: String, track: String, album: String, durationMs: Long) {
        trackStartTime = System.currentTimeMillis()
        lastScrobbledId = -1L

        val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("lastfm_connected", false)) return
        if (!prefs.getBoolean("lastfm_scrobble_enabled", true)) return
        val sessionKey = prefs.getString("lastfm_session_key", null) ?: return

        scope.launch {
            LastFmAuth.updateNowPlaying(sessionKey, artist, track, album, durationMs / 1000L)
        }
    }

    fun onTrackProgress(context: Context, songId: Long, artist: String, track: String, album: String, positionMs: Long, durationMs: Long) {
        if (lastScrobbledId == songId) return
        if (durationMs <= 0) return

        // Scrobble si escuchó > 50% o > 4 minutos
        val listened = positionMs.toFloat() / durationMs.toFloat()
        val shouldScrobble = listened >= 0.5f || positionMs >= 240_000L

        if (shouldScrobble) {
            lastScrobbledId = songId
            val prefs = context.getSharedPreferences("aero_prefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("lastfm_connected", false)) return
            if (!prefs.getBoolean("lastfm_scrobble_enabled", true)) return
            val sessionKey = prefs.getString("lastfm_session_key", null) ?: return

            scope.launch {
                LastFmAuth.scrobble(
                    sessionKey = sessionKey,
                    artist     = artist,
                    track      = track,
                    album      = album,
                    timestamp  = trackStartTime / 1000L
                )
            }
        }
    }
}
