package com.aeroplayer.ui.library

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.databinding.FragmentPlaylistsBinding
import com.aeroplayer.ui.MainViewModel
import com.aeroplayer.ui.SmartPlaylistActivity
import com.aeroplayer.ui.SmartPlaylistType
import com.aeroplayer.ui.playlist.CreatePlaylistActivity
import com.aeroplayer.ui.playlist.PlaylistDetailActivity

class PlaylistsFragment : Fragment() {

    private var _binding: FragmentPlaylistsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PlaylistAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlaylistsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        com.aeroplayer.ui.AccentApplier.apply(requireContext(), binding.root)
        setupSmartPlaylists()
        setupRecyclerView()
        observePlaylists()
        setupFab()
    }

    private fun setupSmartPlaylists() {
        val smartAdapter = SmartPlaylistCardAdapter { type ->
            startActivity(
                Intent(requireContext(), SmartPlaylistActivity::class.java)
                    .putExtra(SmartPlaylistActivity.EXTRA_TYPE, type.name)
            )
        }
        binding.rvSmartPlaylists.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = smartAdapter
        }
        smartAdapter.submitList(SmartPlaylistType.entries.toList())
    }

    private fun setupRecyclerView() {
        adapter = PlaylistAdapter(
            onPlaylistClick = { playlist ->
                startActivity(
                    Intent(requireContext(), PlaylistDetailActivity::class.java)
                        .putExtra("playlistId", playlist.id)
                        .putExtra("playlistName", playlist.name)
                )
            },
            onDeleteClick = { playlist ->
                androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar playlist")
                    .setMessage("¿Eliminar \"${playlist.name}\"?")
                    .setPositiveButton("Eliminar") { _, _ -> viewModel.deletePlaylist(playlist.id) }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        )
        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@PlaylistsFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun observePlaylists() {
        viewModel.playlists.observe(viewLifecycleOwner) { playlists ->
            adapter.submitList(playlists)
            binding.tvEmpty.visibility = if (playlists.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text       = "${playlists.size} playlist${if (playlists.size != 1) "s" else ""}"
            playlists.forEach { playlist ->
                viewModel.getPlaylistSongCount(playlist.id)
                    .observe(viewLifecycleOwner) { count ->
                        adapter.updateSongCount(playlist.id, count ?: 0)
                    }
            }
        }
    }

    private fun setupFab() {
        binding.fabNewPlaylist.setOnClickListener {
            startActivity(Intent(requireContext(), CreatePlaylistActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// ── Adapter de tarjetas de smart playlist (scroll horizontal) ─────────────────
private class SmartPlaylistCardAdapter(
    private val onClick: (SmartPlaylistType) -> Unit
) : ListAdapter<SmartPlaylistType, SmartPlaylistCardAdapter.VH>(TypeDiff()) {

    private val cardColors = listOf(
        intArrayOf(Color.parseColor("#1A3A6E"), Color.parseColor("#0D1F3C")), // Azul
        intArrayOf(Color.parseColor("#6E1A3A"), Color.parseColor("#3C0D1F")), // Rosa
        intArrayOf(Color.parseColor("#1A6E3A"), Color.parseColor("#0D3C1F")), // Verde
        intArrayOf(Color.parseColor("#6E3A1A"), Color.parseColor("#3C1F0D"))  // Naranja
    )

    inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card) {
        val tvEmoji: TextView = card.findViewWithTag("emoji")
        val tvName: TextView  = card.findViewWithTag("name")
        val tvDesc: TextView  = card.findViewWithTag("desc")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            layoutParams = RecyclerView.LayoutParams(
                (152 * dp).toInt(), (118 * dp).toInt()
            ).also { it.marginEnd = (10 * dp).toInt() }
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#1E2330"), Color.parseColor("#161A22"))
            ).apply { cornerRadius = 16 * dp }
            isClickable = true
            isFocusable = true
            elevation = 4 * dp
        }

        val tvEmoji = TextView(ctx).apply {
            tag = "emoji"; textSize = 26f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = (6 * dp).toInt() }
        }
        val tvName = TextView(ctx).apply {
            tag = "name"; textSize = 12f; maxLines = 2
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        val tvDesc = TextView(ctx).apply {
            tag = "desc"; textSize = 10f; maxLines = 2
            setTextColor(Color.parseColor("#99FFFFFF"))
            gravity = android.view.Gravity.CENTER
            setPadding(0, (3 * dp).toInt(), 0, 0)
        }

        card.addView(tvEmoji)
        card.addView(tvName)
        card.addView(tvDesc)
        return VH(card)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val type   = getItem(position)
        val colors = cardColors[position % cardColors.size]
        holder.tvEmoji.text = type.emoji
        holder.tvName.text  = type.titleEs
        holder.tvDesc.text  = type.descriptionEs
        val dp = holder.card.resources.displayMetrics.density
        holder.card.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, colors
        ).apply { cornerRadius = 16 * dp }
        holder.card.setOnClickListener { onClick(type) }
    }

    class TypeDiff : DiffUtil.ItemCallback<SmartPlaylistType>() {
        override fun areItemsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
        override fun areContentsTheSame(a: SmartPlaylistType, b: SmartPlaylistType) = a == b
    }
}
