# ────────────────────────────────────────────────────────────────────────────
#  AeroPlayer — ProGuard / R8 rules
# ────────────────────────────────────────────────────────────────────────────

# Mantener nombres de clases para stack traces legibles en Crashlytics / logcat
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions

# ── Retrofit + OkHttp ────────────────────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}

# ── Gson / modelos de la API de letras ───────────────────────────────────────
-keep class com.google.gson.** { *; }
-keep class com.aeroplayer.data.repository.LrclibResponse { *; }
-keepclassmembers,allowobfuscation class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# ── Room ─────────────────────────────────────────────────────────────────────
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao class *
-dontwarn androidx.room.paging.**

# ── Media3 / ExoPlayer ───────────────────────────────────────────────────────
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# ── Google Cast SDK ──────────────────────────────────────────────────────────
-keep class com.google.android.gms.cast.** { *; }
-keep class com.google.android.gms.cast.framework.** { *; }
-dontwarn com.google.android.gms.cast.**
-keep class com.aeroplayer.cast.CastOptionsProvider { *; }

# ── Glide ────────────────────────────────────────────────────────────────────
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { <init>(...); }
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** {
    **[] $VALUES;
    public *;
}
-dontwarn com.bumptech.glide.**

# ── WorkManager ──────────────────────────────────────────────────────────────
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ── AppWidget ────────────────────────────────────────────────────────────────
-keep class com.aeroplayer.ui.widget.PlayerWidget { *; }

# ── Ecualizador ──────────────────────────────────────────────────────────────
-keep class com.aeroplayer.ui.equalizer.EqualizerActivity { *; }

# ── Kotlin ───────────────────────────────────────────────────────────────────
-keep class kotlin.** { *; }
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlin.**
-dontwarn kotlinx.**

# ── ViewBinding ──────────────────────────────────────────────────────────────
-keep class com.aeroplayer.databinding.** { *; }

# ── Modelos ──────────────────────────────────────────────────────────────────
-keep class com.aeroplayer.model.** { *; }

# ── NewPipeExtractor ─────────────────────────────────────────────────────────
# Mantener todas las clases de NewPipeExtractor para que R8 no rompa
# la reflexión interna que usa para parsear respuestas de YouTube.
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**

# nanojson (parser JSON interno de NewPipeExtractor)
-keep class com.grack.nanojson.** { *; }
-dontwarn com.grack.nanojson.**

# Rhino JS engine (evalúa código ofuscado de YouTube)
-keep class org.mozilla.javascript.** { *; }
-dontwarn org.mozilla.javascript.**

# Modelos YTMusic de AeroPlayer
-keep class com.aeroplayer.model.YTSong { *; }
-keep class com.aeroplayer.model.YTPlaylist { *; }

