package com.aeroplayer.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.collection.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object AlbumArtUtils {

    // Cache en memoria: hasta 1/4 de la RAM disponible, máx 48MB
    // (antes era 1/8 y 20MB — duplicado para que más carátulas queden en memoria)
    private val memCache: LruCache<Long, Bitmap> = object : LruCache<Long, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 4).toInt().coerceAtMost(48 * 1024)
    ) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount / 1024
    }

    // IDs que ya intentamos y no tienen carátula — evita re-leer el archivo
    private val noArtIds = mutableSetOf<Long>()

    // Scope propio para pre-carga en background sin atar al ciclo de vida de ninguna Activity
    private val preloadScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    /** Cache hit instantáneo — usar en onBindViewHolder */
    fun getCached(songId: Long): Bitmap? = memCache.get(songId)

    /** Carga desde archivo en hilo IO. Llamar desde coroutine. */
    suspend fun loadArt(songId: Long, filePath: String): Bitmap? {
        memCache.get(songId)?.let { return it }
        if (songId in noArtIds) return null

        return withContext(Dispatchers.IO) {
            runCatching {
                MediaMetadataRetriever().use { mmr ->
                    mmr.setDataSource(filePath)
                    val art = mmr.embeddedPicture ?: return@runCatching null
                    BitmapFactory.decodeByteArray(art, 0, art.size)
                }
            }.getOrNull().also { bmp ->
                if (bmp != null) memCache.put(songId, bmp)
                else noArtIds.add(songId)
            }
        }
    }

    /**
     * Pre-carga en background una lista de canciones sin bloquear nada.
     * Llamar cuando el usuario abre la cola o cambia de canción para que
     * las siguientes carátulas ya estén listas cuando las necesite.
     * Las que ya están en cache se saltan en O(1).
     */
    fun preload(songs: List<Pair<Long, String>>) {
        songs.forEach { (id, path) ->
            if (memCache.get(id) == null && id !in noArtIds) {
                preloadScope.launch {
                    loadArt(id, path)
                }
            }
        }
    }

    /** Versión síncrona — SOLO usar desde Dispatchers.IO */
    fun getAlbumArt(songId: Long, filePath: String): Bitmap? {
        memCache.get(songId)?.let { return it }
        if (songId in noArtIds) return null

        return runCatching {
            MediaMetadataRetriever().use { mmr ->
                mmr.setDataSource(filePath)
                val art = mmr.embeddedPicture ?: return null
                BitmapFactory.decodeByteArray(art, 0, art.size)
            }
        }.getOrNull().also { bmp ->
            if (bmp != null) memCache.put(songId, bmp)
            else noArtIds.add(songId)
        }
    }

    fun clearCache() {
        memCache.evictAll()
        noArtIds.clear()
    }
}
