# AeroPlayer — Changelog

## v1.3.4 — YouTube Music + correcciones de rendimiento

### Nueva función
- **YouTube Music** (opcional): búsqueda de pistas, carga de playlists por URL/ID y
  reproducción directa vía NewPipeExtractor + ExoPlayer.
- La pestaña YT Music se activa/desactiva desde **Ajustes → YouTube Music** (switch).
  Cuando está desactivada no aparece en la barra de navegación.

### Correcciones de rendimiento
- OkHttp con **HTTP/2 multiplexado** — reduce latencia de búsqueda ~2 s → ~600 ms.
- **Connection pool ampliado** (10 conexiones, 5 min keepalive) para reutilizar
  conexiones TLS entre búsqueda y resolución de stream.
- **Cache de stream URLs** con TTL de 5 h — evita re-resolver la misma pista.
- `chooseBestAudioStream()` ahora filtra por MIME antes de iterar — O(n) → O(1) promedio.
- `NewPipe.init()` con **doble-checked locking** — ya no se puede llamar dos veces desde
  coroutines concurrentes causando `IllegalStateException` silenciosa.

### Correcciones de bugs
- **videoId extraído con regex robusta** (`\bv=([^&]+)`) — antes fallaba con URLs del
  tipo `?feature=share&v=xxx` o `youtu.be/xxx`.
- **Charset correcto en OkHttpDownloader** — respetaba siempre UTF-8 sin importar lo que
  declarara el `Content-Type`, causando que NewPipe parseara HTML corrupto.
- **Streams con `content == null` filtrados** antes de elegir el mejor stream — evitaba
  NPE al reproducir manifiestos DASH incompletos.
- **`resolvePlaylistQueue()`** ya no reinicia la cola con cada canción resuelta; las
  canciones después de la primera se añaden con `addToQueue()` sin interrumpir.
- **`clearSearch()` resetea `lastQuery`** — antes impedía relanzar la misma búsqueda
  después de borrar el campo.



### Bug corregido
- **MIGRATION_4_5 faltante** (`AppDatabase.kt`): La cadena de migraciones de Room
  referenciaba `MIGRATION_4_5` en `addMigrations()` pero el objeto nunca estaba
  definido, causando `Unresolved reference: MIGRATION_4_5` en tiempo de compilación.
  Se agregó una migración no-op (vacía) para cerrar el gap entre versiones 4 y 5
  de la base de datos sin destruir datos existentes.


## v0.83 — Pitch Control · LRC mejorado · Carpetas favoritas

### ⚡ Pitch Control (control de tono)
- **`PlayerController`**: nuevo `pitchSemitones: LiveData<Int>` (-12..+12) y `pitchLock: LiveData<Boolean>`.
  - `setPitchSemitones(n)` — desplaza el tono en semitonos usando `PlaybackParameters(speed, pitch)`.
  - `togglePitchLock()` — activa/desactiva pitch correction. Con lock activo, el pitch siempre es 1.0 sin importar la velocidad (se acabó el efecto "chipmunk" al acelerar).
  - Persistido en `aero_prefs` con claves `playback_pitch_semitones` y `playback_pitch_lock`.
- **`PlayerActivity`**: el botón de velocidad ahora abre un menú "Velocidad y tono" con dos opciones:
  - *Velocidad* → selector existente.
  - *Tono (pitch)* → nuevo `showPitchDialog()` con lista de -12 a +12 semitonos y botón para activar/desactivar pitch lock.

### 🎵 LRC local mejorado (offline lyrics)
- **`LyricsFileManager`**: búsqueda multi-ruta para `.lrc`:
  - Caché en memoria (`ConcurrentHashMap`) — evita I/O repetido al volver a la misma canción.
  - Busca `<nombre>.lrc`, `<nombre>.LRC`, `<nombre_lowercase>.lrc` en la carpeta del audio.
  - Fallback con búsqueda case-insensitive en el directorio (funciona en tarjetas SD con FAT32/exFAT).
  - `clearCache()` expuesto para invalidar si el usuario mueve archivos.

### 📁 Carpetas favoritas
- **`MainViewModel`**: nuevas funciones `getFavoriteFolders()`, `setFavoriteFolders()`, `addFavoriteFolder()`, `removeFavoriteFolder()`.
  - Si el conjunto está vacío → se muestran todas las canciones (comportamiento anterior).
  - Si hay carpetas favoritas → solo se muestran canciones cuya ruta empieza por alguna de ellas.
  - El filtro se combina con excluidas y canciones ocultas en `loadSongs()`.
- **`SettingsActivity`**: nueva fila "Carpetas favoritas" (`rowFavoriteFolders`) con diálogo para agregar/eliminar rutas.
- **`activity_settings.xml`**: nueva fila debajo de "Carpetas excluidas" con ícono `ic_bookmark_outline` y `tvFavoriteFoldersCount`.



## v0.81 — Corrección de bugs

### Bugs corregidos
- **BUG1 — NPE en `PlayerController.connect()`** (`PlayerController.kt`): Se reemplazó
  `controller!!.playbackParameters.withSpeed(savedSpeed)` por una llamada segura con
  `controller?.let { ctrl -> ... }`. Si el `MediaController` fallaba al conectarse,
  la app crasheaba con `NullPointerException`.
- **BUG2 — Duplicados silenciosos en playlists** (`MusicRepository.kt`): `addSongToPlaylist()`
  ahora verifica `if (existing.any { it.songId == song.id }) return` antes de insertar.
  El `PrimaryKey(autoGenerate=true)` de Room no prevenía duplicados, lo que permitía
  agregar la misma canción múltiples veces sin advertencia.
- **BUG3 — Variable shadow en `scanMediaStoreAndCache()`** (`MusicRepository.kt`): Se
  eliminó la re-query interna `val likedIds = likedDao.getAllLikedSync()...` que ignoraba
  el parámetro recibido y hacía una consulta redundante a la BD, potencialmente
  devolviendo datos inconsistentes en escenarios concurrentes.
- **BUG4 — `searchRunnable!!` innecesario** (`PlaylistDetailActivity.kt`): Reemplazado
  `searchHandler.postDelayed(searchRunnable!!, 150)` por
  `searchRunnable?.let { searchHandler.postDelayed(it, 150) }` para evitar NPE futuro.
- **BUG5 — `ivCustomBackground!!` en MainActivity** (`MainActivity.kt`): Reemplazado
  por `binding.ivCustomBackground?.let { into(it) }`. En layouts sin esta vista
  (landscape, tablets) la aserción non-null causaría crash al cargar fondo personalizado.
- **BUG6 — Memory retention en `PlayerController.disconnect()`** (`PlayerController.kt`):
  Se limpian `appContext = null` y `prefs = null` al desconectar para que el GC pueda
  liberar el contexto de la aplicación cuando el ViewModel se destruye.

## v0.20.0 — Bugs, Paging 3, GIF Canvas, UI polish

### Correcciones de bugs
- **animateBackground**: el degradado del player ahora anima desde el color real
  de la carátula anterior en lugar de siempre partir desde `surface_dark`.
  Se agregó `currentDominantColor` como campo de clase para rastrear el valor previo.
- **AlbumArtPagerAdapter**: reemplazado `notifyDataSetChanged()` por tres llamadas
  `notifyItemChanged(CENTER_PAGE ± 1)` al cambiar de canción. Elimina la invalidación
  masiva de 2001 páginas en cada transición.
- **crossfadeRunnable**: movido el guard `val ctrl = controller ?: return` al tope
  del Runnable. Cuando el controller es null el loop se detiene en lugar de
  reprogramarse cada 50 ms indefinidamente (background, sin música).
- **SettingsActivity back**: `overridePendingTransition(0,0)` reemplazado por
  `(R.anim.fade_in, R.anim.slide_out_right)`, consistente con el resto del app.

### Paging 3 — bibliotecas grandes
- **SongPagingSource**: nuevo `PagingSource` que sirve páginas de 60 canciones
  desde la lista en memoria. La lista se carga una vez desde MediaStore y se
  repagina en cada cambio de sort o refresh sin recargar el disco.
- **SongListAdapter**: migrado de `ListAdapter` a `PagingDataAdapter`.
- **FilesFragment**: reescrito para colectar `Flow<PagingData<Song>>` via
  `collectLatest`. Sort y MediaStore refresh invalidan la fuente automáticamente.
- **MainViewModel**: expone `songsPagingData: Flow<PagingData<Song>>` usando
  `flatMapLatest` sobre `_sortedSongs` + `cachedIn(viewModelScope)`.
- **build.gradle**: agregado `room-paging:2.6.1` y `paging-runtime-ktx:3.3.2`.

### GIF Canvas por canción
- **SongCanvasEntity / SongCanvasDao**: nueva tabla Room `song_canvas` con migración
  `MIGRATION_1_2` (DB versión 1 → 2). Sin destructive fallback.
- **AppDatabase**: versión 2, expone `songCanvasDao()`.
- **MusicRepository**: métodos `setCanvas`, `deleteCanvas`, `getCanvas`,
  `getCanvasLive` sobre `SongCanvasDao`.
- **MainViewModel**: `setCanvas`, `deleteCanvas`, `getCanvasLive` expuestos.
- **item_album_art_pager.xml**: FrameLayout con `ivGifCanvas` (GONE por defecto)
  + `ivPagerAlbumArt` encima.
- **AlbumArtPagerAdapter**: nuevo campo `canvasProvider: () -> Uri?`. Si hay
  canvas activo carga el GIF con `Glide.asGif()` y oculta el album art;
  si no hay canvas, limpia `ivGifCanvas` explícitamente para evitar reciclado.
- **PlayerActivity**: campo `activeCanvasUri`, launcher `gifPicker`
  (ActivityResultContracts.GetContent + `takePersistableUriPermission`),
  `observeCanvas(songId)` que refresca la página central y actualiza el tint del
  botón, `showCanvasMenu()` con opciones Cambiar / Quitar.
- **activity_player.xml**: `btnCanvas` agregado al panel lateral con ícono
  `ic_gif_canvas` vectorial.

### Mejoras de UI
- **Marquee en título**: `tvSongTitle.isSelected = true` al cambiar de canción,
  activando el scroll automático en títulos largos.
- **Indicador de posición**: `tvPlaylistContext` muestra el nombre de la cola
  (Playlist, álbum, artista, "Me gusta", etc.) y `tvArtistTop` muestra
  `#N · pos/total` igual a las capturas de referencia. `PlayerController.playSongs`
  acepta nuevo parámetro opcional `queueName` que todos los lanzadores pasan.
- **Spring animation en chips**: al activar/desactivar un chip de filtro en Home
  se ejecuta una animación overshoot (scale 1→1.12→1, 200 ms total).
- **Búsqueda dentro de playlist**: `btnSearch` ya existía en el layout pero no
  estaba conectado. Ahora muestra un `EditText` colapsable con debounce 150 ms,
  botón de cerrar, y contador `"filtradas / total"`.

### Calidad de código
- `PlayerController.queueName: LiveData<String?>` nuevo campo para propagar el
  nombre de la cola a cualquier observer sin tocar los Intents.
- `LikedFragment`: migrado a `PagingData.from(songs)` + `snapshot()` para ser
  compatible con el nuevo `PagingDataAdapter`.
