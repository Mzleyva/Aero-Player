package com.aeroplayer.ui

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.service.MultiQueueManager
import com.aeroplayer.service.PlayerController
import com.aeroplayer.utils.CueSheetParser
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Pantalla para navegar y reproducir archivos CUE (.cue standalone).
 * También puede ser lanzada desde FolderBrowserActivity cuando el usuario
 * toca un archivo .cue.
 */
class CueSheetBrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CUE_PATH = "cue_file_path"
    }

    private lateinit var root: LinearLayout
    private lateinit var rv: RecyclerView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(4.dp, 4.dp, 16.dp, 4.dp)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null; layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        val tvTitle = TextView(this).apply {
            text = "CUE Sheet"
            textSize = 18f; setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        val btnPlayAll = TextView(this).apply {
            text = "▶ Todo"; textSize = 13f
            setTextColor(getColor(R.color.accent_blue))
            setPadding(8.dp, 8.dp, 0, 8.dp)
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(btnPlayAll)
        root.addView(toolbar)

        progress = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(progress)

        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@CueSheetBrowserActivity)
            addItemDecoration(DividerItemDecoration(this@CueSheetBrowserActivity, DividerItemDecoration.VERTICAL))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(rv)
        setContentView(root)

        val cuePath = intent.getStringExtra(EXTRA_CUE_PATH) ?: run {
            Snackbar.make(root, "Sin ruta de archivo CUE", Snackbar.LENGTH_LONG).show()
            finish(); return
        }
        tvTitle.text = File(cuePath).nameWithoutExtension

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { CueSheetParser.parseCueFile(cuePath) }
            val songs  = withContext(Dispatchers.IO) { CueSheetParser.toSongs(result.tracks, this@CueSheetBrowserActivity) }
            progress.visibility = android.view.View.GONE

            if (result.errors.isNotEmpty()) {
                Snackbar.make(root, result.errors.first(), Snackbar.LENGTH_LONG).show()
            }
            if (songs.isEmpty()) {
                root.addView(TextView(this@CueSheetBrowserActivity).apply {
                    text = "No se encontraron pistas en este CUE"
                    gravity = Gravity.CENTER; textSize = 14f
                    setTextColor(getColor(R.color.text_hint))
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 200.dp)
                }); return@launch
            }

            rv.adapter = CueTrackAdapter(result.tracks) { idx ->
                MultiQueueManager.setActiveQueueSongs(songs, tvTitle.text.toString(), idx)
                PlayerController.loadQueue(songs, idx)
                finish()
            }

            btnPlayAll.setOnClickListener {
                MultiQueueManager.setActiveQueueSongs(songs, tvTitle.text.toString(), 0)
                PlayerController.loadQueue(songs, 0)
                finish()
            }
        }
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}

private class CueTrackAdapter(
    private val tracks: List<CueSheetParser.CueTrack>,
    private val onPlay: (Int) -> Unit
) : RecyclerView.Adapter<CueTrackAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvNum:   TextView = row.getChildAt(0) as TextView
        val tvTitle: TextView = (row.getChildAt(1) as LinearLayout).getChildAt(0) as TextView
        val tvSub:   TextView = (row.getChildAt(1) as LinearLayout).getChildAt(1) as TextView
        val tvTime:  TextView = row.getChildAt(2) as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): VH {
        val ctx = parent.context
        val dp  = { n: Int -> (n * ctx.resources.displayMetrics.density).toInt() }
        val tvN = TextView(ctx).apply {
            textSize = 12f; setTextColor(ctx.getColor(R.color.text_hint))
            gravity = Gravity.CENTER; minWidth = dp(32)
        }
        val tvT = TextView(ctx).apply { textSize = 14f; setTextColor(ctx.getColor(R.color.text_primary)) }
        val tvS = TextView(ctx).apply { textSize = 12f; setTextColor(ctx.getColor(R.color.text_secondary)) }
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(tvT); addView(tvS)
        }
        val tvTime = TextView(ctx).apply {
            textSize = 12f; setTextColor(ctx.getColor(R.color.text_hint))
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addView(tvN); addView(texts); addView(tvTime)
        }
        return VH(row)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val t = tracks[pos]
        h.tvNum.text   = "%02d".format(t.trackNumber)
        h.tvTitle.text = t.title.ifBlank { "Pista ${t.trackNumber}" }
        h.tvSub.text   = t.performer.ifBlank { t.albumArtist }
        h.tvTime.text  = formatMs(t.startMs)
        h.row.setOnClickListener { onPlay(pos) }
    }

    override fun getItemCount() = tracks.size

    private fun formatMs(ms: Long): String {
        val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60)
    }
}
