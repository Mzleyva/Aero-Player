package com.aeroplayer.ui

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import com.aeroplayer.model.Song
import com.aeroplayer.service.MultiQueueManager
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

/**
 * Pantalla de gestión de múltiples colas — v1.8.3
 *
 * Layout:
 *  - Panel superior: tabs con las colas disponibles (nombre + chip activo)
 *  - Área central: lista de canciones de la cola seleccionada con drag-to-reorder
 *  - FAB: crear nueva cola
 *  - Long press en tab: renombrar / eliminar cola
 */
class MultiQueueActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var tabContainer: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var rvSongs: RecyclerView
    private lateinit var songAdapter: QueueSongsAdapter
    private lateinit var tvEmpty: TextView

    private var selectedQueueId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // ── Toolbar ────────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(4.dp, 4.dp, 16.dp, 4.dp)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        val tvTitle = TextView(this).apply {
            text = "Colas de reproducción"
            textSize = 18f
            setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle)
        root.addView(toolbar)

        // ── Tabs de colas ──────────────────────────────────────────────────────
        val tabHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(16.dp, 4.dp, 8.dp, 0)
        }
        val tvQueuesLabel = TextView(this).apply {
            text = "Colas"; textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnNewQueue = TextView(this).apply {
            text = "+ Nueva"
            textSize = 13f
            setTextColor(getColor(R.color.accent_blue))
            setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            setOnClickListener { showCreateQueueDialog() }
        }
        tabHeader.addView(tvQueuesLabel); tabHeader.addView(btnNewQueue)
        root.addView(tabHeader)

        tabScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        tabContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12.dp, 4.dp, 12.dp, 8.dp)
        }
        tabScroll.addView(tabContainer); root.addView(tabScroll)

        // Separador
        root.addView(android.view.View(this).apply {
            setBackgroundColor(0x22FFFFFF)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Lista de canciones ─────────────────────────────────────────────────
        tvEmpty = TextView(this).apply {
            text = "Esta cola está vacía.\nArrastra canciones aquí o crea una nueva cola."
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(getColor(R.color.text_hint))
            visibility = android.view.View.GONE
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(tvEmpty)

        rvSongs = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MultiQueueActivity)
            addItemDecoration(DividerItemDecoration(this@MultiQueueActivity, DividerItemDecoration.VERTICAL))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        songAdapter = QueueSongsAdapter(
            onPlay   = { idx -> switchToQueueAndPlay(idx) },
            onRemove = { idx ->
                MultiQueueManager.removeFromActiveQueue(idx)
                refreshSongs()
            }
        )
        rvSongs.adapter = songAdapter

        // Drag to reorder
        val touch = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, ItemTouchHelper.RIGHT
        ) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val songs = songAdapter.songs.toMutableList()
                val f = from.bindingAdapterPosition; val t = to.bindingAdapterPosition
                if (f < 0 || t < 0 || f >= songs.size || t >= songs.size) return false
                val moved = songs.removeAt(f); songs.add(t, moved)
                songAdapter.songs = songs
                songAdapter.notifyItemMoved(f, t)
                // BUG FIX: usar postDelayed para que ExoPlayer no se pause durante el drag
                rvSongs.post { MultiQueueManager.reorderActiveQueue(songs) }
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {
                val idx = vh.bindingAdapterPosition
                if (idx < 0 || idx >= songAdapter.songs.size) return
                MultiQueueManager.removeFromActiveQueue(idx)
                refreshSongs()
                Snackbar.make(root, "Canción eliminada de la cola", Snackbar.LENGTH_SHORT).show()
            }
        })
        touch.attachToRecyclerView(rvSongs)
        root.addView(rvSongs)

        setContentView(root)

        // ── Observar colas ─────────────────────────────────────────────────────
        MultiQueueManager.allQueues.observe(this) { queues ->
            rebuildTabs(queues)
            refreshSongs()
        }
        MultiQueueManager.activeQueueId.observe(this) { id ->
            selectedQueueId = id
            rebuildTabs(MultiQueueManager.allQueues.value.orEmpty())
            refreshSongs()
        }

        // Si no hay ninguna cola, crear una con la cola actual del player
        if (MultiQueueManager.allQueues.value.isNullOrEmpty()) {
            val current = PlayerController.queue.value.orEmpty()
            if (current.isNotEmpty()) {
                MultiQueueManager.createQueue("Cola principal", current,
                    PlayerController.currentIndex.value ?: 0)
            }
        }
    }

    private fun rebuildTabs(queues: List<MultiQueueManager.NamedQueue>) {
        tabContainer.removeAllViews()
        if (queues.isEmpty()) {
            tabContainer.addView(TextView(this).apply {
                text = "Sin colas activas"; textSize = 12f
                setTextColor(getColor(R.color.text_hint))
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            }); return
        }
        val activeId = MultiQueueManager.activeQueueId.value
        queues.forEach { q ->
            val isActive = q.id == activeId
            val chip = com.google.android.material.chip.Chip(this).apply {
                text = "${q.name} (${q.songs.size})"
                textSize = 12f
                chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                    if (isActive) getColor(R.color.accent_blue) else getColor(R.color.surface_card))
                setTextColor(if (isActive) Color.WHITE else getColor(R.color.text_primary))
                chipStrokeColor = android.content.res.ColorStateList.valueOf(getColor(R.color.accent_blue))
                chipStrokeWidth = if (isActive) 0f else 1.5f
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = 8.dp }
                setOnClickListener {
                    MultiQueueManager.switchTo(q.id)?.let { nq ->
                        PlayerController.loadQueue(nq.songs, nq.currentIndex)
                    }
                }
                setOnLongClickListener {
                    showQueueOptions(q); true
                }
            }
            tabContainer.addView(chip)
        }
    }

    private fun refreshSongs() {
        val songs = MultiQueueManager.getActiveSongs()
        songAdapter.songs = songs
        songAdapter.activeIdx = MultiQueueManager.getActiveIndex()
        songAdapter.notifyDataSetChanged()
        tvEmpty.visibility = if (songs.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        rvSongs.visibility = if (songs.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun showCreateQueueDialog() {
        val input = EditText(this).apply { hint = "Nombre de la cola"; setPadding(48.dp, 24.dp, 48.dp, 8.dp) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nueva cola")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Cola ${(MultiQueueManager.allQueues.value?.size ?: 0) + 1}" }
                MultiQueueManager.createQueue(name, emptyList())
                Snackbar.make(root, "\"$name\" creada", Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun showQueueOptions(q: MultiQueueManager.NamedQueue) {
        val items = arrayOf("Renombrar", "Duplicar", "Eliminar")
        MaterialAlertDialogBuilder(this)
            .setTitle(q.name)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> {
                        val input = EditText(this).apply { setText(q.name); setPadding(48.dp, 24.dp, 48.dp, 8.dp) }
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Renombrar cola")
                            .setView(input)
                            .setPositiveButton("Guardar") { _, _ ->
                                val n = input.text.toString().trim().ifBlank { q.name }
                                MultiQueueManager.renameQueue(q.id, n)
                            }
                            .setNegativeButton("Cancelar", null).show()
                    }
                    1 -> {
                        MultiQueueManager.createQueue("${q.name} (copia)", q.songs, q.currentIndex)
                        Snackbar.make(root, "Cola duplicada", Snackbar.LENGTH_SHORT).show()
                    }
                    2 -> {
                        if ((MultiQueueManager.allQueues.value?.size ?: 0) <= 1) {
                            Snackbar.make(root, "No puedes eliminar la última cola", Snackbar.LENGTH_SHORT).show()
                        } else {
                            MaterialAlertDialogBuilder(this)
                                .setTitle("Eliminar \"${q.name}\"")
                                .setMessage("¿Eliminar esta cola? Las canciones no se borrarán.")
                                .setPositiveButton("Eliminar") { _, _ -> MultiQueueManager.deleteQueue(q.id) }
                                .setNegativeButton("Cancelar", null).show()
                        }
                    }
                }
            }.show()
    }

    private fun switchToQueueAndPlay(index: Int) {
        val songs = MultiQueueManager.getActiveSongs()
        if (songs.isEmpty()) return
        PlayerController.loadQueue(songs, index)
        MultiQueueManager.saveProgress(index, 0L)
        finish()
    }

    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
}

// ── Adapter para canciones de la cola ────────────────────────────────────────
class QueueSongsAdapter(
    private val onPlay: (Int) -> Unit,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<QueueSongsAdapter.VH>() {

    var songs: List<Song> = emptyList()
    var activeIdx: Int = -1

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        // BUG FIX: usar tags en lugar de getChildAt() + cast que causaba ClassCastException
        val iv: ImageView      = row.findViewWithTag("iv")
        val tvTitle: TextView  = row.findViewWithTag("tvTitle")
        val tvSub: TextView    = row.findViewWithTag("tvSub")
        val btnRemove: ImageButton = row.findViewWithTag("btnRemove")
    }

    override fun onCreateViewHolder(parent: ViewGroup, type: Int): VH {
        val ctx = parent.context
        val dp  = { n: Int -> (n * ctx.resources.displayMetrics.density).toInt() }
        val iv = ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(48.dp(ctx), 48.dp(ctx)).also { it.marginEnd = 12.dp(ctx) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            tag = "iv"
        }
        val tvT = TextView(ctx).apply { textSize = 14f; setTextColor(ctx.getColor(R.color.text_primary)); tag = "tvTitle" }
        val tvS = TextView(ctx).apply { textSize = 12f; setTextColor(ctx.getColor(R.color.text_secondary)); tag = "tvSub" }
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(tvT); addView(tvS)
        }
        val btnR = ImageButton(ctx).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            background = null
            layoutParams = LinearLayout.LayoutParams(40.dp(ctx), 40.dp(ctx))
            tag = "btnRemove"
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(8), dp(10))
            addView(iv); addView(texts); addView(btnR)
        }
        return VH(row)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val s = songs[pos]
        h.tvTitle.text = s.title; h.tvSub.text = "${s.artist} · ${s.album}"
        h.row.setBackgroundColor(
            if (pos == activeIdx) androidx.core.content.ContextCompat.getColor(h.row.context, R.color.surface_card)
            else Color.TRANSPARENT)
        Glide.with(h.iv).load(s.albumArtUri).placeholder(R.drawable.ic_music_placeholder).into(h.iv)
        h.row.setOnClickListener { onPlay(pos) }
        h.btnRemove.setOnClickListener { onRemove(pos) }
    }

    override fun getItemCount() = songs.size
    private fun Int.dp(ctx: android.content.Context) = (this * ctx.resources.displayMetrics.density).toInt()
}
