package com.aeroplayer.ui.equalizer

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.aeroplayer.R
import com.aeroplayer.service.PlayerController
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import org.json.JSONObject

class EqualizerActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private val bandSeekBars   = mutableListOf<SeekBar>()
    private val bandValueLabels = mutableListOf<TextView>()
    private lateinit var rootLayout: LinearLayout
    private lateinit var customPresetRow: LinearLayout
    private lateinit var bandContainer: LinearLayout
    private lateinit var curveView: EqCurveView

    private val PREFS_NAME      = "eq_custom_presets"
    private val KEY_PRESETS     = "presets"
    private val KEY_BAND_LEVELS = "eq_band_levels"
    private val KEY_EQ_ENABLED  = "eq_enabled"
    private val KEY_BAND_COUNT  = "eq_band_count"
    private val KEY_PROFILE     = "eq_profile"          // headphones / speakers / bluetooth

    // ── 30 presets de género ─────────────────────────────────────────────────
    // Niveles en milli-dB para 10 bandas (31Hz,62Hz,125Hz,250Hz,500Hz,1kHz,2kHz,4kHz,8kHz,16kHz)
    // Se escalan automáticamente si el dispositivo tiene más bandas.
    private val GENRE_PRESETS = linkedMapOf(
        "Plano"         to listOf(0,0,0,0,0,0,0,0,0,0),
        "Rock"          to listOf(300,200,100,-100,-200,-200,0,200,300,350),
        "Pop"           to listOf(-100,0,200,300,200,0,-100,-100,-100,-100),
        "Jazz"          to listOf(200,100,0,200,400,300,200,100,200,300),
        "Clásica"       to listOf(0,0,0,0,0,0,-200,-200,-200,-300),
        "Hip-Hop"       to listOf(500,400,100,300,0,-200,-100,100,200,300),
        "Electrónica"   to listOf(400,350,0,-200,-100,0,200,150,400,500),
        "Dance"         to listOf(300,200,-100,-200,0,300,400,300,200,0),
        "R&B"           to listOf(700,400,100,200,0,-100,200,300,300,200),
        "Metal"         to listOf(400,100,300,-100,-300,-100,0,200,500,500),
        "Punk"          to listOf(300,0,-100,-200,-100,0,200,300,400,400),
        "Blues"         to listOf(300,200,100,0,-100,200,300,200,100,200),
        "Reggae"        to listOf(0,0,0,-200,300,400,300,0,0,0),
        "Soul"          to listOf(200,100,0,200,200,0,-100,200,300,200),
        "Country"       to listOf(300,200,100,100,-100,-100,200,300,300,200),
        "Folk"          to listOf(300,200,100,0,0,100,0,200,100,200),
        "Indie"         to listOf(200,100,0,-100,-100,0,100,200,300,400),
        "Lo-Fi"         to listOf(300,400,200,100,-100,-200,-300,-400,-400,-500),
        "Acústica"      to listOf(500,300,200,100,-100,0,0,200,300,400),
        "Vocal"         to listOf(-200,-100,0,100,300,500,400,200,100,0),
        "Podcast"       to listOf(-300,-200,-100,100,500,600,500,300,100,-100),
        "Audiobooks"    to listOf(-200,-100,0,100,400,500,400,200,100,0),
        "Gaming"        to listOf(200,300,400,200,0,-100,100,300,400,500),
        "Cine"          to listOf(300,200,100,0,-100,-100,100,200,300,500),
        "Bass Boost"    to listOf(600,500,400,200,0,-100,-200,-100,0,100),
        "Treble Boost"  to listOf(-200,-100,0,0,0,100,200,300,400,500),
        "Sub-Woofer"    to listOf(800,600,400,100,-100,-200,-300,-300,-200,-100),
        "Karaoke"       to listOf(0,0,0,100,300,-800,-800,200,100,0),
        "Medianoche"    to listOf(500,400,200,100,-100,-100,0,100,200,300),
        "Deportes"      to listOf(300,200,100,0,0,100,200,300,400,500)
    )

    // ── Perfiles por dispositivo ──────────────────────────────────────────────
    private val DEVICE_PROFILES = listOf("General", "Auriculares", "Bocinas", "Bluetooth", "Hi-Fi DAC")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rootLayout = buildUI()
        val scroll = ScrollView(this).apply {
            addView(rootLayout)
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }
        setContentView(scroll)

        val sessionId = PlayerController.getAudioSessionId()
        if (sessionId == 0) {
            Snackbar.make(findViewById(android.R.id.content),
                "Reproduce una canción primero", Snackbar.LENGTH_LONG).show()
            finish(); return
        }
        runCatching {
            equalizer   = Equalizer(0, sessionId).also { it.enabled = true }
            bassBoost   = BassBoost(0, sessionId).also { it.enabled = false }
            virtualizer = Virtualizer(0, sessionId).also { it.enabled = false }
        }.onFailure {
            Snackbar.make(scroll, "No se pudo inicializar el ecualizador", Snackbar.LENGTH_LONG).show()
            finish(); return
        }
        val eq = equalizer ?: run { finish(); return }
        populateBands(eq)
        restoreBandLevels(eq)
        loadCustomPresets()
        loadGenrePresets()
    }

    // ── UI skeleton ──────────────────────────────────────────────────────────
    private fun buildUI(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4.dp, 4.dp, 16.dp, 4.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            background = null
            setOnClickListener { finish() }
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
        }
        val tvTitle = TextView(this).apply {
            text = "Ecualizador"
            textSize = 20f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        // Switch habilitado
        val switchEq = SwitchMaterial(this).apply {
            text = "Activo"
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(switchEq)
        root.addView(toolbar)

        // Selector de perfil de dispositivo
        root.addView(sectionLabel("Perfil de dispositivo"))
        val profileScroll = HorizontalScrollView(this).apply { setPadding(12.dp, 0, 12.dp, 0) }
        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4.dp, 4.dp, 4.dp, 4.dp) }
        val savedProfile = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PROFILE, "General") ?: "General"
        DEVICE_PROFILES.forEach { profile ->
            profileRow.addView(makeChip(profile, selected = profile == savedProfile) {
                switchProfile(profile)
            })
        }
        profileScroll.addView(profileRow)
        root.addView(profileScroll)

        // Selector de número de bandas
        root.addView(sectionLabel("Número de bandas"))
        val bandCountRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20.dp, 4.dp, 20.dp, 4.dp)
        }
        val bandCounts = listOf(5, 10, 15, 20)
        val savedCount = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BAND_COUNT, 10)
        val tvBandCount = TextView(this).apply {
            text = "$savedCount bandas"
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val seekBandCount = SeekBar(this).apply {
            max = bandCounts.size - 1
            progress = bandCounts.indexOf(savedCount).coerceAtLeast(1)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    val count = bandCounts[p]
                    tvBandCount.text = "$count bandas"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    val count = bandCounts[progress]
                    getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putInt(KEY_BAND_COUNT, count).apply()
                    equalizer?.let { rebuildBands(it, count) }
                }
            })
        }
        bandCountRow.addView(tvBandCount); bandCountRow.addView(seekBandCount)
        root.addView(bandCountRow)

        // Curva visual
        curveView = EqCurveView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 80.dp)
            setPadding(16.dp, 4.dp, 16.dp, 0)
        }
        root.addView(curveView)

        // Bandas (placeholder, se rellenan en populateBands)
        bandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(12.dp, 8.dp, 12.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (260 * resources.displayMetrics.density).toInt())
        }
        root.addView(bandContainer)

        // Botón de reset
        val resetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(16.dp, 0, 16.dp, 8.dp)
        }
        resetRow.addView(com.google.android.material.button.MaterialButton(this).apply {
            text = "Restablecer"
            textSize = 12f
            setOnClickListener { resetBands() }
        })
        root.addView(resetRow)

        // Bass Boost + Virtualizer
        root.addView(sectionLabel("Efectos de audio"))
        root.addView(buildEffectsRow())

        // Presets del sistema
        root.addView(sectionLabel("Presets del sistema"))
        val sysPresetScroll = HorizontalScrollView(this).apply {
            id = R.id.ids_chip_container
            setPadding(12.dp, 0, 12.dp, 0)
        }
        root.addView(sysPresetScroll)

        // Presets de género (30)
        root.addView(sectionLabel("Presets por género (${GENRE_PRESETS.size})"))
        val genreScroll = HorizontalScrollView(this).apply { setPadding(12.dp, 0, 12.dp, 8.dp) }
        val genreRow = LinearLayout(this).apply {
            id = android.R.id.custom
            orientation = LinearLayout.HORIZONTAL
            setPadding(4.dp, 4.dp, 4.dp, 4.dp)
        }
        genreScroll.addView(genreRow); root.addView(genreScroll)

        // Mis presets
        val customHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20.dp, 4.dp, 16.dp, 0)
        }
        customHeader.addView(sectionLabel("Mis presets").also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        customHeader.addView(com.google.android.material.button.MaterialButton(this).apply {
            text = "Guardar"
            textSize = 11f
            setOnClickListener { showSavePresetDialog() }
        })
        root.addView(customHeader)
        customPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16.dp, 4.dp, 16.dp, 24.dp)
        }
        root.addView(HorizontalScrollView(this).apply { addView(customPresetRow) })

        // Conectar switch
        switchEq.isChecked = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_EQ_ENABLED, true)
        switchEq.setOnCheckedChangeListener { _, checked ->
            equalizer?.enabled = checked
            bandSeekBars.forEach { it.isEnabled = checked }
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_EQ_ENABLED, checked).apply()
        }

        return root
    }

    private fun buildEffectsRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 4.dp, 20.dp, 8.dp)
        }
        // Bass Boost
        row.addView(buildSliderRow("Bass Boost", 0, 1000) { strength ->
            bassBoost?.setStrength(strength.toShort())
            bassBoost?.enabled = strength > 0
        })
        // Virtualizer (Surround)
        row.addView(buildSliderRow("Virtualizer (surround)", 0, 1000) { strength ->
            virtualizer?.setStrength(strength.toShort())
            virtualizer?.enabled = strength > 0
        })
        return row
    }

    private fun buildSliderRow(label: String, min: Int, max: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8.dp, 0, 4.dp)
        }
        val tv = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sb = SeekBar(this).apply {
            this.max = max - min
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p + min) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        row.addView(tv); row.addView(sb)
        return row
    }

    // ── Band population ──────────────────────────────────────────────────────
    private fun populateBands(eq: Equalizer) {
        val targetCount = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_BAND_COUNT, 10)
        rebuildBands(eq, targetCount)
    }

    private fun rebuildBands(eq: Equalizer, requestedCount: Int) {
        bandContainer.removeAllViews()
        bandSeekBars.clear(); bandValueLabels.clear()

        val hardwareCount = eq.numberOfBands.toInt()
        // Interpolar bandas si el hardware tiene menos que las solicitadas.
        // Si el hardware tiene más, mostrar solo las primeras 'requestedCount'.
        val displayCount  = requestedCount.coerceAtMost(hardwareCount)

        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel   = levelRange[0].toInt()
        val maxLevel   = levelRange[1].toInt()
        val range      = (maxLevel - minLevel).coerceAtLeast(1)

        (0 until displayCount).forEach { i ->
            // Mapear banda lógica a banda hardware (interpolación lineal)
            val hwBand = ((i.toFloat() / displayCount) * hardwareCount).toInt()
                .coerceIn(0, hardwareCount - 1).toShort()

            val hz = runCatching { eq.getCenterFreq(hwBand) / 1000 }.getOrDefault(0)
            val freqLabel = when {
                hz >= 1000 -> "${hz / 1000}k"
                hz > 0     -> "${hz}Hz"
                else       -> "${i + 1}"
            }
            val currentLevel = runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            }
            val tvDb = TextView(this).apply {
                text = formatDb(currentLevel)
                textSize = 9f
                setTextColor(dbColor(currentLevel))
                gravity = Gravity.CENTER
            }
            bandValueLabels.add(tvDb)

            val sb = SeekBar(this).apply {
                rotation = -90f
                max = range
                progress = (currentLevel - minLevel).coerceIn(0, range)
                progressTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                thumbTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(220, 32.dp).also {
                    it.topMargin = 4; it.bottomMargin = 4
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val level = (p + minLevel).toShort()
                        runCatching { eq.setBandLevel(hwBand, level) }
                        tvDb.text = formatDb(level.toInt())
                        tvDb.setTextColor(dbColor(level.toInt()))
                        updateCurve(eq)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) { saveBandLevels() }
                })
            }
            bandSeekBars.add(sb)

            val tvFreq = TextView(this).apply {
                text = freqLabel
                textSize = 9f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
                gravity = Gravity.CENTER
            }
            col.addView(tvDb); col.addView(sb); col.addView(tvFreq)
            bandContainer.addView(col)
        }
        updateCurve(eq)
    }

    private fun updateCurve(eq: Equalizer) {
        val levels = bandSeekBars.indices.map { i ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
        }
        curveView.setLevels(levels)
    }

    // ── Genre presets ─────────────────────────────────────────────────────────
    private fun loadGenrePresets() {
        val genreRow = rootLayout.findViewById<LinearLayout>(android.R.id.custom) ?: return
        genreRow.removeAllViews()
        GENRE_PRESETS.forEach { (name, levels10) ->
            genreRow.addView(makeChip(name) {
                applyScaledPreset(levels10)
                toast("Preset: $name")
            })
        }
    }

    /** Aplica un preset de 10 bandas escalado al número actual de bandas del eq. */
    private fun applyScaledPreset(levels10: List<Int>) {
        val eq = equalizer ?: return
        val n  = bandSeekBars.size
        (0 until n).forEach { i ->
            val src   = (i.toFloat() / n * 10).toInt().coerceIn(0, 9)
            val level = levels10[src].toShort()
            val hwBand = ((i.toFloat() / n) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.setBandLevel(hwBand, level) }
        }
        refreshBands(eq); saveBandLevels()
    }

    // ── Device profile switching ──────────────────────────────────────────────
    private fun switchProfile(profile: String) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_PROFILE, profile).apply()
        // Cargar niveles guardados para este perfil
        val key = "eq_band_levels_$profile"
        val raw = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(key, null)
        val eq = equalizer ?: return
        if (raw != null) {
            val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
            levels.forEachIndexed { i, level ->
                val hwBand = ((i.toFloat() / levels.size) * eq.numberOfBands)
                    .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
                runCatching { eq.setBandLevel(hwBand, level.toShort()) }
            }
            refreshBands(eq)
        }
        toast("Perfil: $profile")
    }

    // ── Custom preset management ─────────────────────────────────────────────
    private fun showSavePresetDialog() {
        val eq = equalizer ?: return
        val input = EditText(this).apply {
            hint = "Nombre del preset"
            setPadding(48.dp, 24.dp, 48.dp, 8.dp)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Guardar preset")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { toast("El nombre no puede estar vacío"); return@setPositiveButton }
                val levels = bandSeekBars.indices.map { i ->
                    val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands)
                        .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
                    runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
                }
                saveCustomPreset(name, levels)
                loadCustomPresets()
                toast("Preset \"$name\" guardado")
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun saveCustomPreset(name: String, levels: List<Int>) {
        val prefs    = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned  = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        cleaned.put(JSONObject().apply { put("name", name); put("levels", JSONArray(levels)) })
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun loadCustomPresets() {
        customPresetRow.removeAllViews()
        val prefs   = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val presets = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        if (presets.length() == 0) {
            customPresetRow.addView(TextView(this).apply {
                text = "Aún no tienes presets guardados"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            }); return
        }
        for (i in 0 until presets.length()) {
            val obj       = presets.getJSONObject(i)
            val name      = obj.getString("name")
            val levelsArr = obj.getJSONArray("levels")
            val levels    = (0 until levelsArr.length()).map { levelsArr.getInt(it) }
            customPresetRow.addView(makeChip(name, longPress = {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Eliminar preset")
                    .setMessage("¿Eliminar \"$name\"?")
                    .setPositiveButton("Eliminar") { _, _ ->
                        deleteCustomPreset(name); loadCustomPresets(); toast("Preset eliminado")
                    }
                    .setNegativeButton("Cancelar", null).show()
            }) { applyScaledPreset(levels); toast("Preset: $name") })
        }
    }

    private fun deleteCustomPreset(name: String) {
        val prefs    = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned  = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun refreshBands(eq: Equalizer) {
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel   = levelRange[0].toInt()
        val range      = (levelRange[1].toInt() - minLevel).coerceAtLeast(1)
        bandSeekBars.forEachIndexed { i, sb ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            val level  = runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
            sb.progress = (level - minLevel).coerceIn(0, range)
            bandValueLabels.getOrNull(i)?.apply {
                text = formatDb(level); setTextColor(dbColor(level))
            }
        }
        updateCurve(eq)
    }

    private fun resetBands() {
        val eq = equalizer ?: return
        (0 until eq.numberOfBands).forEach { i -> runCatching { eq.setBandLevel(i.toShort(), 0) } }
        refreshBands(eq); saveBandLevels(); toast("Ecualizador restablecido")
    }

    private fun saveBandLevels() {
        val eq      = equalizer ?: return
        val profile = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PROFILE, "General") ?: "General"
        val levels  = bandSeekBars.indices.map { i ->
            val hwBand = ((i.toFloat() / bandSeekBars.size) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.getBandLevel(hwBand).toInt() }.getOrDefault(0)
        }
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_BAND_LEVELS, levels.joinToString(","))
            .putString("eq_band_levels_$profile", levels.joinToString(","))
            .putBoolean(KEY_EQ_ENABLED, eq.enabled)
            .apply()
    }

    private fun restoreBandLevels(eq: Equalizer) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw   = prefs.getString(KEY_BAND_LEVELS, null) ?: return
        val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
        levels.forEachIndexed { i, level ->
            val hwBand = ((i.toFloat() / levels.size.coerceAtLeast(1)) * eq.numberOfBands)
                .toInt().coerceIn(0, eq.numberOfBands.toInt() - 1).toShort()
            runCatching { eq.setBandLevel(hwBand, level.toShort()) }
        }
        eq.enabled = prefs.getBoolean(KEY_EQ_ENABLED, true)
        refreshBands(eq)
    }

    private fun populateSystemPresets(eq: Equalizer) {
        val scroll = rootLayout.findViewById<HorizontalScrollView>(R.id.ids_chip_container) ?: return
        val row    = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4.dp, 4.dp, 4.dp, 4.dp) }
        val count  = eq.numberOfPresets.toInt()
        if (count > 0) {
            (0 until count).forEach { i ->
                val name = eq.getPresetName(i.toShort())
                row.addView(makeChip(name) {
                    eq.usePreset(i.toShort()); refreshBands(eq); saveBandLevels(); toast("Preset: $name")
                })
            }
        } else {
            row.addView(TextView(this).apply {
                text = "No hay presets del sistema disponibles"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            })
        }
        scroll.addView(row)
    }

    private fun dbColor(milliDb: Int) = ContextCompat.getColor(
        this,
        when { milliDb > 0 -> R.color.accent_blue; milliDb < 0 -> R.color.accent_pink; else -> R.color.text_secondary }
    )

    private fun formatDb(milliDb: Int): String {
        val db = milliDb / 100
        return if (db > 0) "+${db}dB" else "${db}dB"
    }

    private fun makeChip(
        text: String,
        selected: Boolean = false,
        longPress: (() -> Unit)? = null,
        onClick: () -> Unit
    ) = Chip(this).apply {
        this.text = text
        textSize = 12f
        chipBackgroundColor = android.content.res.ColorStateList.valueOf(
            if (selected)
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue)
            else
                ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
        setTextColor(ContextCompat.getColor(this@EqualizerActivity,
            if (selected) android.R.color.white else R.color.text_primary))
        chipStrokeColor = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
        chipStrokeWidth = 1.5f
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).also { it.marginEnd = 8.dp }
        setOnClickListener { onClick() }
        longPress?.let { lp -> setOnLongClickListener { lp(); true } }
    }

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = 16.dp; it.bottomMargin = 4.dp }
        setPadding(24.dp, 0, 24.dp, 0)
    }

    private fun toast(msg: String) = Snackbar.make(rootLayout, msg, Snackbar.LENGTH_SHORT).show()
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        saveBandLevels()
        equalizer?.release();  equalizer  = null
        bassBoost?.release();  bassBoost   = null
        virtualizer?.release(); virtualizer = null
        super.onDestroy()
    }
}


class EqualizerActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private val bandSeekBars = mutableListOf<SeekBar>()
    private val bandValueLabels = mutableListOf<TextView>()
    private lateinit var rootLayout: LinearLayout
    private lateinit var customPresetRow: LinearLayout

    private val PREFS_NAME = "eq_custom_presets"
    private val KEY_PRESETS = "presets"
    private val KEY_BAND_LEVELS = "eq_band_levels"
    private val KEY_EQ_ENABLED  = "eq_enabled"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rootLayout = buildUI()
        val scroll = ScrollView(this).apply {
            addView(rootLayout)
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }
        setContentView(scroll)

        val sessionId = PlayerController.getAudioSessionId()
        if (sessionId == 0) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Reproduce una canción primero para usar el ecualizador",
                Snackbar.LENGTH_LONG
            ).show()
            finish()
            return
        }
        runCatching {
            equalizer = Equalizer(0, sessionId).also { it.enabled = true }
        }.onFailure {
            Snackbar.make(scroll, "No se pudo inicializar el ecualizador", Snackbar.LENGTH_LONG).show()
            finish()
            return
        }
        val eq = equalizer ?: run { finish(); return }
        populateEqualizer(eq)
        restoreBandLevels(eq)
        loadCustomPresets()
    }

    // ── Build skeleton UI ────────────────────────────────────────────────────
    private fun buildUI(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@EqualizerActivity, R.color.background_dark))
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 16, 4)
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            setColorFilter(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            setBackgroundResource(android.R.color.transparent)
            setPadding(16)
            setOnClickListener { finish() }
        }
        val tvTitle = TextView(this).apply {
            text = "Ecualizador"
            textSize = 19f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 4 }
        }
        val swEnable = SwitchMaterial(this).apply {
            isChecked = true
            text = "Activo"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
            thumbTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            trackTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
            setOnCheckedChangeListener { _, checked ->
                equalizer?.enabled = checked
                bandSeekBars.forEach { it.isEnabled = checked }
            }
        }
        toolbar.addView(btnBack); toolbar.addView(tvTitle); toolbar.addView(swEnable)
        root.addView(toolbar)
        root.addView(dividerView())

        // System presets section
        root.addView(sectionLabel("Presets del sistema"))
        val sysPresetScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            id = R.id.ids_chip_container  // placeholder id reused
        }
        root.addView(sysPresetScroll)

        // Custom presets section
        val customHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 20, 16, 4)
        }
        customHeader.addView(sectionLabel("Mis presets").also {
            (it.layoutParams as LinearLayout.LayoutParams).apply {
                width = 0; weight = 1f; topMargin = 0
            }
            it.setPadding(0, 0, 0, 0)
        })
        val btnSavePreset = com.google.android.material.button.MaterialButton(
            this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
        ).apply {
            text = "Guardar preset"
            textSize = 12f
            strokeColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            setOnClickListener { showSavePresetDialog() }
        }
        customHeader.addView(btnSavePreset)
        root.addView(customHeader)

        customPresetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 4, 16, 4) }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(customPresetRow)
        })

        root.addView(dividerView())
        root.addView(sectionLabel("Bandas"))

        // Band container placeholder
        root.addView(FrameLayout(this).apply { id = android.R.id.content + 100 })

        // Reset button
        root.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(com.google.android.material.button.MaterialButton(
                this@EqualizerActivity, null,
                com.google.android.material.R.attr.materialButtonOutlinedStyle
            ).apply {
                text = "Restablecer"
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = 24; it.bottomMargin = 32 }
                setOnClickListener { resetBands() }
            })
        })
        return root
    }

    // ── Populate EQ bands ────────────────────────────────────────────────────
    private fun populateEqualizer(eq: Equalizer) {
        // System presets chips
        val sysPresetScroll = rootLayout.findViewById<HorizontalScrollView>(R.id.ids_chip_container)
        val sysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(16, 4, 16, 8) }
        val presetCount = eq.numberOfPresets.toInt()
        if (presetCount > 0) {
            (0 until presetCount).forEach { i ->
                val name = eq.getPresetName(i.toShort())
                sysRow.addView(makeChip(name) {
                    eq.usePreset(i.toShort())
                    refreshBands(eq)
                    toast("Preset: $name")
                })
            }
        } else {
            sysRow.addView(TextView(this).apply {
                text = "No hay presets del sistema disponibles"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8, 8, 8, 8)
            })
        }
        sysPresetScroll?.addView(sysRow)

        // Band level range
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel = levelRange[0].toInt()
        val maxLevel = levelRange[1].toInt()
        val range = (maxLevel - minLevel).coerceAtLeast(1)

        // Bands
        val bandContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(12, 8, 12, 8)
            // FIX: usar TypedValue en lugar de .dp — resources.displayMetrics puede
            // no estar disponible correctamente antes de setContentView en Android 11
            val heightPx = (280 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, heightPx)
        }
        bandSeekBars.clear(); bandValueLabels.clear()

        (0 until eq.numberOfBands).forEach { i ->
            val band = i.toShort()
            val hz = runCatching { eq.getCenterFreq(band) / 1000 }.getOrDefault(0)
            val freqLabel = if (hz >= 1000) "${hz / 1000}k" else "${hz}Hz"
            val currentLevel = runCatching { eq.getBandLevel(band).toInt() }.getOrDefault(0)

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            }

            val tvDb = TextView(this).apply {
                text = formatDb(currentLevel)
                textSize = 10f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                gravity = Gravity.CENTER
            }
            bandValueLabels.add(tvDb)

            val sb = SeekBar(this).apply {
                rotation = -90f
                max = range
                progress = (currentLevel - minLevel).coerceIn(0, range)
                progressTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                thumbTintList = android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
                layoutParams = LinearLayout.LayoutParams(240, 36).also { it.topMargin = 4; it.bottomMargin = 4 }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        val level = (p + minLevel).toShort()
                        runCatching { eq.setBandLevel(band, level) }
                        tvDb.text = formatDb(level.toInt())
                        tvDb.setTextColor(ContextCompat.getColor(
                            this@EqualizerActivity,
                            when { level > 0 -> R.color.accent_blue; level < 0 -> R.color.accent_pink; else -> R.color.text_secondary }
                        ))
                    }
                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) { saveBandLevels() }
                })
            }
            bandSeekBars.add(sb)

            val tvFreq = TextView(this).apply {
                text = freqLabel
                textSize = 10f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = 4 }
            }
            col.addView(tvDb); col.addView(sb); col.addView(tvFreq)
            bandContainer.addView(col)
        }

        // Replace placeholder
        val placeholder = rootLayout.findViewById<FrameLayout>(android.R.id.content + 100)
        val idx = (0 until rootLayout.childCount).indexOfFirst { rootLayout.getChildAt(it) == placeholder }
        if (idx >= 0) {
            rootLayout.removeViewAt(idx)
            rootLayout.addView(bandContainer, idx)
        } else {
            rootLayout.addView(bandContainer)
        }
    }

    // ── Custom preset management ─────────────────────────────────────────────
    private fun showSavePresetDialog() {
        val eq = equalizer ?: return
        val input = EditText(this).apply {
            hint = "Nombre del preset"
            setPadding(48, 24, 48, 8)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Guardar preset")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { toast("El nombre no puede estar vacío"); return@setPositiveButton }
                val levels = (0 until eq.numberOfBands).map { i ->
                    runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
                }
                saveCustomPreset(name, levels)
                loadCustomPresets()
                toast("Preset \"$name\" guardado")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun saveCustomPreset(name: String, levels: List<Int>) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        cleaned.put(JSONObject().apply { put("name", name); put("levels", JSONArray(levels)) })
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun loadCustomPresets() {
        customPresetRow.removeAllViews()
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val presets = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())

        if (presets.length() == 0) {
            customPresetRow.addView(TextView(this).apply {
                text = "Aún no tienes presets guardados"
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_hint))
                setPadding(8, 8, 8, 8)
            })
            return
        }
        for (i in 0 until presets.length()) {
            val obj = presets.getJSONObject(i)
            val name = obj.getString("name")
            val levelsArr = obj.getJSONArray("levels")
            val levels = (0 until levelsArr.length()).map { levelsArr.getInt(it) }

            val chip = makeChip(name, longPress = {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Eliminar preset")
                    .setMessage("¿Eliminar \"$name\"?")
                    .setPositiveButton("Eliminar") { _, _ ->
                        deleteCustomPreset(name); loadCustomPresets(); toast("Preset eliminado")
                    }
                    .setNegativeButton("Cancelar", null).show()
            }) {
                applyCustomPreset(levels); toast("Preset: $name")
            }
            customPresetRow.addView(chip)
        }
    }

    private fun deleteCustomPreset(name: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = runCatching { JSONArray(prefs.getString(KEY_PRESETS, "[]")) }.getOrDefault(JSONArray())
        val cleaned = JSONArray()
        for (i in 0 until existing.length()) {
            val obj = existing.getJSONObject(i)
            if (obj.getString("name") != name) cleaned.put(obj)
        }
        prefs.edit().putString(KEY_PRESETS, cleaned.toString()).apply()
    }

    private fun applyCustomPreset(levels: List<Int>) {
        val eq = equalizer ?: return
        levels.forEachIndexed { i, level ->
            if (i < eq.numberOfBands) runCatching { eq.setBandLevel(i.toShort(), level.toShort()) }
        }
        refreshBands(eq)
        saveBandLevels()
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun refreshBands(eq: Equalizer) {
        val levelRange = runCatching { eq.bandLevelRange }.getOrNull() ?: shortArrayOf(-1500, 1500)
        val minLevel = levelRange[0].toInt()
        val range = (levelRange[1].toInt() - minLevel).coerceAtLeast(1)
        bandSeekBars.forEachIndexed { i, sb ->
            val level = runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
            sb.progress = (level - minLevel).coerceIn(0, range)
            bandValueLabels.getOrNull(i)?.apply {
                text = formatDb(level)
                setTextColor(ContextCompat.getColor(
                    this@EqualizerActivity,
                    when { level > 0 -> R.color.accent_blue; level < 0 -> R.color.accent_pink; else -> R.color.text_secondary }
                ))
            }
        }
    }

    private fun resetBands() {
        val eq = equalizer ?: return
        (0 until eq.numberOfBands).forEach { i -> runCatching { eq.setBandLevel(i.toShort(), 0) } }
        refreshBands(eq)
        saveBandLevels()
        toast("Ecualizador restablecido")
    }

    // ── Persist / restore band levels ───────────────────────────────────────
    private fun saveBandLevels() {
        val eq = equalizer ?: return
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val levels = (0 until eq.numberOfBands).map { i ->
            runCatching { eq.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
        }
        prefs.edit()
            .putString(KEY_BAND_LEVELS, levels.joinToString(","))
            .putBoolean(KEY_EQ_ENABLED, eq.enabled)
            .apply()
    }

    private fun restoreBandLevels(eq: Equalizer) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_BAND_LEVELS, null) ?: return
        val levels = raw.split(",").mapNotNull { it.trim().toIntOrNull() }
        if (levels.size != eq.numberOfBands.toInt()) return
        levels.forEachIndexed { i, level ->
            runCatching { eq.setBandLevel(i.toShort(), level.toShort()) }
        }
        eq.enabled = prefs.getBoolean(KEY_EQ_ENABLED, true)
        refreshBands(eq)
    }

    private fun formatDb(milliDb: Int): String {
        val db = milliDb / 100
        return if (db > 0) "+${db}dB" else "${db}dB"
    }

    private fun makeChip(text: String, longPress: (() -> Unit)? = null, onClick: () -> Unit): Chip {
        return Chip(this).apply {
            this.text = text
            textSize = 12f
            chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.surface_card))
            setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_primary))
            chipStrokeColor = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@EqualizerActivity, R.color.accent_blue))
            chipStrokeWidth = 1.5f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8 }
            setOnClickListener { onClick() }
            longPress?.let { lp -> setOnLongClickListener { lp(); true } }
        }
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(ContextCompat.getColor(this@EqualizerActivity, R.color.text_secondary))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = 20; it.bottomMargin = 4 }
        setPadding(24, 0, 24, 0)
    }

    private fun dividerView(): View {
        val v = View(this)
        v.setBackgroundColor(ContextCompat.getColor(this, R.color.divider))
        v.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            .also { it.topMargin = 8; it.bottomMargin = 4 }
        return v
    }

    private fun toast(msg: String) = Snackbar.make(rootLayout, msg, Snackbar.LENGTH_SHORT).show()

    private val Int.dp: Int get() = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        saveBandLevels()
        equalizer?.release()
        equalizer = null
        super.onDestroy()
    }
}
