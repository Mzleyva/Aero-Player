package com.aeroplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.aeroplayer.data.db.*
import com.aeroplayer.model.Playlist
import com.aeroplayer.model.Song
import com.aeroplayer.utils.SongUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val likedDao = db.likedSongDao()
    private val playlistDao = db.playlistDao()
    private val playCountDao = db.playCountDao()
    private val canvasDao = db.songCanvasDao()
    private val songCacheDao = db.songCacheDao()

    // ── Local files (interno + SD card) ─────────────────────────────────────
    // Cuánto tiempo es válido el caché — 30 minutos
    private val CACHE_TTL_MS = 30 * 60 * 1000L

    /**
     * Devuelve canciones desde el caché de Room si está vigente (<30 min).
     * Solo re-escanea MediaStore si el caché está vacío, expirado, o si
     * [forceRefresh] es true (llamado por el ContentObserver cuando MediaStore cambia).
     */
    suspend fun getAllSongs(forceRefresh: Boolean = false): List<Song> = withContext(Dispatchers.IO) {
        val likedIds = likedDao.getAllLikedSync().map { it.songId }.toSet()

        if (!forceRefresh) {
            val count = songCacheDao.count()
            val lastCached = songCacheDao.getLastCachedAt() ?: 0L
            val age = System.currentTimeMillis() - lastCached
            if (count > 0 && age < CACHE_TTL_MS) {
                // Caché vigente — devolver sin tocar MediaStore
                return@withContext songCacheDao.getAll().map { e ->
                    com.aeroplayer.model.Song(
                        id          = e.songId,
                        title       = e.title,
                        artist      = e.artist,
                        album       = e.album,
                        duration    = e.duration,
                        path        = e.path,
                        uri         = android.net.Uri.parse(e.uri),
                        albumArtUri = e.albumArtUri?.let { android.net.Uri.parse(it) },
                        trackNumber = e.trackNumber,
                        year        = e.year,
                        size        = e.size,
                        isLiked     = e.songId in likedIds
                    )
                }
            }
        }

        // Escanear MediaStore y guardar en caché
        scanMediaStoreAndCache(likedIds)
    }

    private suspend fun scanMediaStoreAndCache(likedIds: Set<Long>): List<com.aeroplayer.model.Song> {
        val likedIds = likedDao.getAllLikedSync().map { it.songId }.toSet()
        val songs = mutableListOf<Song>()

        // Android 10+: cada volumen por separado (interno + cada SD insertada)
        // Android 9-: EXTERNAL_CONTENT_URI ya incluye SD en la mayoría de ROMs
        val collections: List<Uri> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.getExternalVolumeNames(context).map { volumeName ->
                MediaStore.Audio.Media.getContentUri(volumeName)
            }
        } else {
            listOf(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.SIZE
        )
        // Soporta: MP3, FLAC, AAC, OGG, WAV, M4A, OPUS, WMA, APE y cualquier audio
        // IS_MUSIC filtra por el flag del sistema; DURATION >= 30s evita efectos/notificaciones
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 " +
            "AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        // Escanear cada volumen; si uno falla (SD extraída) continúa con los demás
        for (collection in collections) {
            runCatching {
                context.contentResolver.query(
                    collection, projection, selection, null, sortOrder
                )?.use { cursor ->
                    val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val dataCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                    val albumIdCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                    val trackCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                    val yearCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                    val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

                    while (cursor.moveToNext()) {
                        val id      = cursor.getLong(idCol)
                        val albumId = cursor.getLong(albumIdCol)

                        // URI del archivo correcto para cada volumen
                        val contentUri = ContentUris.withAppendedId(collection, id)

                        // Carátula: API correcta según versión Android
                        val albumArtUri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            ContentUris.withAppendedId(
                                MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, albumId
                            )
                        } else {
                            Uri.parse("content://media/external/audio/albumart/$albumId")
                        }

                        // Evitar duplicados entre volúmenes
                        if (songs.none { it.id == id }) {
                            songs.add(
                                Song(
                                    id          = id,
                                    title       = cursor.getString(titleCol)  ?: context.getString(com.aeroplayer.R.string.unknown_title),
                                    artist      = SongUtils.cleanArtistName(cursor.getString(artistCol) ?: context.getString(com.aeroplayer.R.string.unknown_artist)),
                                    album       = cursor.getString(albumCol)  ?: context.getString(com.aeroplayer.R.string.unknown_album),
                                    duration    = cursor.getLong(durationCol),
                                    path        = cursor.getString(dataCol)   ?: "",
                                    uri         = contentUri,
                                    albumArtUri = albumArtUri,
                                    trackNumber = cursor.getInt(trackCol),
                                    year        = cursor.getInt(yearCol),
                                    size        = cursor.getLong(sizeCol),
                                    isLiked     = id in likedIds
                                )
                            )
                        }
                    }
                }
            }
        }
        val sorted = songs.sortedBy { it.title.lowercase() }

        // Persistir en caché para la próxima apertura
        val now = System.currentTimeMillis()
        val cacheEntities = sorted.map { s ->
            com.aeroplayer.data.db.SongCacheEntity(
                songId      = s.id,
                title       = s.title,
                artist      = s.artist,
                album       = s.album,
                duration    = s.duration,
                path        = s.path,
                albumArtUri = s.albumArtUri?.toString(),
                uri         = s.uri.toString(),
                albumId     = 0L,
                trackNumber = s.trackNumber,
                year        = s.year,
                size        = s.size,
                cachedAt    = now
            )
        }
        songCacheDao.clearAll()
        songCacheDao.insertAll(cacheEntities)

        return sorted
    }

    // ── Liked songs ──────────────────────────────────────────────────────────
    fun getLikedSongsLive() = likedDao.getAllLiked()
    fun getLikedCountLive() = likedDao.getCount()

    suspend fun toggleLike(song: Song): Boolean {
        return if (likedDao.isLiked(song.id)) {
            likedDao.deleteById(song.id)
            false
        } else {
            likedDao.insert(LikedSongEntity(
                songId      = song.id,
                title       = song.title,
                artist      = song.artist,
                album       = song.album,
                path        = song.path,
                duration    = song.duration,
                albumArtUri = song.albumArtUri?.toString()
            ))
            true
        }
    }

    suspend fun isLiked(id: Long) = likedDao.isLiked(id)

    // ── Playlists ────────────────────────────────────────────────────────────
    fun getAllPlaylistsLive()   = playlistDao.getAllPlaylists()
    fun getPlaylistCountLive()  = playlistDao.getPlaylistCount()

    suspend fun createPlaylist(name: String, coverUri: String? = null): Long =
        playlistDao.insertPlaylist(PlaylistEntity(name = name, coverUri = coverUri))

    suspend fun updatePlaylist(id: Long, name: String, coverUri: String? = null) =
        playlistDao.updatePlaylist(PlaylistEntity(id = id, name = name, coverUri = coverUri))

    suspend fun deletePlaylist(id: Long) =
        playlistDao.deletePlaylist(PlaylistEntity(id = id, name = ""))

    suspend fun addSongToPlaylist(playlistId: Long, song: Song) {
        val existing = playlistDao.getSongsForPlaylistSync(playlistId)
        playlistDao.insertSongToPlaylist(PlaylistSongEntity(
            playlistId  = playlistId,
            songId      = song.id,
            title       = song.title,
            artist      = song.artist,
            album       = song.album,
            path        = song.path,
            duration    = song.duration,
            albumArtUri = song.albumArtUri?.toString(),
            position    = existing.size
        ))
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) =
        playlistDao.removeSongFromPlaylist(playlistId, songId)

    /** Updates the `position` column for every song in the list to match the given order. */
    suspend fun reorderPlaylistSongs(playlistId: Long, songs: List<Song>) {
        songs.forEachIndexed { index, song ->
            playlistDao.updateSongPosition(playlistId, song.id, index)
        }
    }

    fun getPlaylistSongsLive(playlistId: Long) = playlistDao.getSongsForPlaylist(playlistId)
    fun getPlaylistSongCount(playlistId: Long)  = playlistDao.getSongCount(playlistId)

    suspend fun getFullPlaylists(): List<Playlist> =
        playlistDao.getAllPlaylistsSync().map { pe ->
            val songs = playlistDao.getSongsForPlaylistSync(pe.id).map { se ->
                Song(
                    id          = se.songId,
                    title       = se.title,
                    artist      = se.artist,
                    album       = se.album,
                    duration    = se.duration,
                    path        = se.path,
                    // FIX: ContentUris en lugar de Uri.parse(path) para Android 10+
                    uri         = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, se.songId
                    ),
                    albumArtUri = se.albumArtUri?.let { android.net.Uri.parse(it) }
                )
            }
            Playlist(id = pe.id, name = pe.name, songs = songs.toMutableList(),
                     coverUri = pe.coverUri, createdAt = pe.createdAt)
        }

    // ── Play counts ──────────────────────────────────────────────────────────
    suspend fun incrementPlayCount(song: Song) {
        if (playCountDao.getByid(song.id) == null) {
            playCountDao.insert(PlayCountEntity(
                songId      = song.id,
                title       = song.title,
                artist      = song.artist,
                path        = song.path,
                albumArtUri = song.albumArtUri?.toString(),
                count       = 1
            ))
        } else {
            playCountDao.increment(song.id)
        }
    }

    suspend fun getTopPlayedSongs(limit: Int = 10) = playCountDao.getTopPlayed(limit)

    // ── Lyrics ───────────────────────────────────────────────────────────────
    /**
     * Returns the full lrclib response, or null if lyrics were not found (404/empty).
     * Throws IOException / network exceptions so the caller can distinguish
     * "not found" from "network error".
     */
    suspend fun getLyricsResponse(
        artist: String,
        title: String
    ): LyricsResult = withContext(Dispatchers.IO) {
        runCatching {
            val resp = LyricsApi.service.getLyrics(artist, title)
            if (resp.plainLyrics.isNullOrBlank() && resp.syncedLyrics.isNullOrBlank()) {
                LyricsResult.NotFound
            } else {
                LyricsResult.Success(resp)
            }
        }.getOrElse { e -> LyricsResult.Error(e) }
    }

    // ── Paging 3 ─────────────────────────────────────────────────────────────

    /**
     * Devuelve un [SongPagingSource] fresco sobre la lista [songs] ya ordenada.
     * El ViewModel invalida la fuente cuando cambia el sort o se refresca MediaStore.
     */
    fun getPagingSource(songs: List<Song>): SongPagingSource = SongPagingSource(songs)

    // ── GIF Canvas ───────────────────────────────────────────────────────────

    /** Asigna o reemplaza el canvas GIF de una canción. */
    suspend fun setCanvas(songId: Long, gifUri: String) =
        canvasDao.setCanvas(SongCanvasEntity(songId = songId, gifUri = gifUri))

    /** Elimina el canvas GIF de una canción. */
    suspend fun deleteCanvas(songId: Long) = canvasDao.deleteCanvas(songId)

    /** Obtiene el canvas actual (suspending, para leer una sola vez). */
    suspend fun getCanvas(songId: Long): String? =
        canvasDao.getCanvas(songId)?.gifUri

    /** Flujo reactivo del canvas — el player lo observa para mostrar/ocultar el GIF. */
    fun getCanvasLive(songId: Long) = canvasDao.getCanvasLive(songId)

}
