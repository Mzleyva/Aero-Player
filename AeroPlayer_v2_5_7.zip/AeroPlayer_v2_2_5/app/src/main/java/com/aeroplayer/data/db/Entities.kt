package com.aeroplayer.data.db

import androidx.room.*

@Entity(tableName = "liked_songs")
data class LikedSongEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val path: String,
    val duration: Long,
    val albumArtUri: String? = null,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val coverUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_songs",
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId")]
)
data class PlaylistSongEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val path: String,
    val duration: Long,
    val albumArtUri: String? = null,
    val position: Int = 0
)

@Entity(tableName = "play_counts")
data class PlayCountEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val path: String,
    val albumArtUri: String? = null,
    val count: Int = 0,
    val lastPlayed: Long = System.currentTimeMillis(),
    /** Tiempo total escuchado en milisegundos (acumulado). */
    val listenTimeMs: Long = 0L
)

/**
 * Almacena el GIF Canvas asignado a cada canción.
 * La URI apunta a un GIF en el almacenamiento del dispositivo, elegido
 * por el usuario desde el picker de archivos del player.
 */
@Entity(tableName = "song_canvas")
data class SongCanvasEntity(
    @PrimaryKey val songId: Long,
    /** URI del GIF elegido por el usuario (content:// o file://). */
    val gifUri: String,
    val assignedAt: Long = System.currentTimeMillis(),
    /** Sesión 8: URI de un video (.mp4) como fondo. Si no es null tiene
     *  prioridad sobre gifUri cuando la batería no está baja. */
    val videoUri: String? = null
)

/**
 * Registro de historial de reproducción.
 * Cada vez que el usuario reproduce una canción se inserta un registro.
 */
@Entity(tableName = "listening_history")
data class ListeningHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val path: String,
    val albumArtUri: String? = null,
    val duration: Long = 0,
    val playedAt: Long = System.currentTimeMillis(),
    /** Duración real escuchada en ms (para gráfica de tiempo diario). */
    val durationMs: Long = 0L
)

/**
 * Caché de canciones escaneadas desde MediaStore.
 * Evita re-escanear toda la biblioteca cada vez que se abre la app.
 * Se invalida cuando MediaStore notifica un cambio (archivo añadido/borrado).
 */
@Entity(tableName = "song_cache")
data class SongCacheEntity(
    @PrimaryKey val songId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val path: String,
    val albumArtUri: String?,
    val uri: String,
    val albumId: Long,
    val trackNumber: Int,
    val year: Int,
    val size: Long,
    val cachedAt: Long = System.currentTimeMillis(),
    /** FIX RENDIMIENTO: cachear dateAdded/dateModified para sort sin File.lastModified(). */
    val dateAdded: Long = 0L,
    val dateModified: Long = 0L,
    /** SESSION 3: cachear genre para que los chips de mood/género funcionen sin re-escanear. */
    val genre: String = ""
)

/**
 * Marcador de posición para podcasts y audiolibros.
 * Permite retomar exactamente donde se dejó.
 */
@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: Long,
    val title: String,        // título de la canción/episodio
    val label: String,        // etiqueta del marcador (ej. "Capítulo 3", "Minuto interesante")
    val positionMs: Long,     // posición en ms
    val durationMs: Long,     // duración total del archivo
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Radio online — URL de stream + metadatos.
 */
@Entity(tableName = "online_radios")
data class RadioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val streamUrl: String,
    val genre: String = "",
    val country: String = "",
    val logoUrl: String? = null,
    val isFavorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)
