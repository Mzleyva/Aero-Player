package com.aeroplayer.ui.visualizer

import android.content.Context
import android.graphics.*
import android.media.audiofx.Visualizer
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

/**
 * AudioVisualizerView — v1.8.3
 * Modos: BARS (spectrum), WAVE (waveform), CIRCLE (radial pulsante).
 */
class AudioVisualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { BARS, WAVE, CIRCLE }

    private var visualizer: Visualizer? = null
    private var fftBytes:  ByteArray = ByteArray(0)
    private var waveBytes: ByteArray = ByteArray(0)
    private var mode: Mode = Mode.BARS
    private var smoothedFft: FloatArray = FloatArray(0)
    private val SMOOTH = 0.25f

    private val barPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }
    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f
    }

    fun init(audioSessionId: Int) {
        release()
        if (audioSessionId == 0) return
        runCatching {
            visualizer = Visualizer(audioSessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onFftDataCapture(v: Visualizer, fft: ByteArray, sr: Int) {
                        fftBytes = fft; smooth(fft); postInvalidateOnAnimation()
                    }
                    override fun onWaveFormDataCapture(v: Visualizer, wave: ByteArray, sr: Int) {
                        waveBytes = wave
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
        }
    }

    fun release() { runCatching { visualizer?.enabled = false; visualizer?.release() }; visualizer = null }
    fun setMode(m: Mode) { mode = m; invalidate() }
    fun getMode() = mode

    private fun smooth(fft: ByteArray) {
        val n = fft.size / 2
        if (smoothedFft.size != n) { smoothedFft = FloatArray(n); return }
        for (i in 0 until n) {
            val raw = (fft[i].toInt() and 0xFF).toFloat()
            smoothedFft[i] = smoothedFft[i] * (1 - SMOOTH) + raw * SMOOTH
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (smoothedFft.isEmpty() && waveBytes.isEmpty()) { drawIdle(canvas); return }
        when (mode) {
            Mode.BARS   -> drawBars(canvas)
            Mode.WAVE   -> drawWave(canvas)
            Mode.CIRCLE -> drawCircle(canvas)
        }
    }

    private fun drawBars(canvas: Canvas) {
        if (smoothedFft.isEmpty()) return
        val fft = smoothedFft
        val w = width.toFloat(); val h = height.toFloat()
        val nBars = minOf(fft.size, 64); val barW = w / nBars; val gap = barW * 0.15f
        barPaint.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(0xFF7EC8E3.toInt(), 0xFF5B9BD4.toInt(), 0xFFE879A2.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        glowPaint.shader = barPaint.shader
        for (i in 0 until nBars) {
            val mag = fft[i * fft.size / nBars] / 255f
            val barH = (mag * h * 0.85f).coerceAtLeast(3f)
            val x = i * barW + gap / 2
            val rect = RectF(x, h - barH, x + barW - gap, h)
            canvas.drawRoundRect(rect, 4f, 4f, barPaint)
            if (mag > 0.6f) {
                glowPaint.alpha = ((mag - 0.6f) / 0.4f * 80).toInt()
                canvas.drawRoundRect(rect, 4f, 4f, glowPaint)
            }
        }
    }

    private fun drawWave(canvas: Canvas) {
        if (waveBytes.isEmpty()) return
        val wave = waveBytes
        val w = width.toFloat(); val h = height.toFloat(); val midY = h / 2f
        val step = wave.size.toFloat() / w
        wavePaint.shader = LinearGradient(0f, 0f, w, 0f,
            intArrayOf(0xFF5B9BD4.toInt(), 0xFF7EC8E3.toInt(), 0xFFE879A2.toInt()),
            null, Shader.TileMode.CLAMP)
        val path = Path()
        fun waveY(i: Int): Float {
            val s = wave[(i * step).toInt().coerceIn(wave.indices)].toInt() / 128f
            return midY - s * midY * 0.9f
        }
        path.moveTo(0f, waveY(0))
        for (i in 1 until w.toInt()) {
            val prev = PointF((i - 1).toFloat(), waveY(i - 1))
            val cur  = PointF(i.toFloat(), waveY(i))
            val cpx  = (prev.x + cur.x) / 2f
            path.cubicTo(cpx, prev.y, cpx, cur.y, cur.x, cur.y)
        }
        canvas.drawPath(path, wavePaint)
        val cp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x22FFFFFF; style = Paint.Style.STROKE; strokeWidth = 1f
            pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
        }
        canvas.drawLine(0f, midY, w, midY, cp)
    }

    private fun drawCircle(canvas: Canvas) {
        if (smoothedFft.isEmpty()) return
        val fft = smoothedFft
        val cx = width / 2f; val cy = height / 2f
        val baseR = minOf(cx, cy) * 0.45f
        val energy = fft.take(32).map { it / 255f }.average().toFloat()
        circlePaint.shader = SweepGradient(cx, cy,
            intArrayOf(0xFF5B9BD4.toInt(), 0xFF7EC8E3.toInt(), 0xFFE879A2.toInt(), 0xFF5B9BD4.toInt()), null)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x885B9BD4.toInt()
        }
        canvas.drawCircle(cx, cy, baseR + energy * 20f, pp)
        val nSpokes = minOf(fft.size, 128)
        for (i in 0 until nSpokes) {
            val angle = (i.toFloat() / nSpokes) * 2f * PI.toFloat()
            val mag   = fft[i * fft.size / nSpokes] / 255f
            val r2    = baseR + mag * baseR * 0.8f
            val x1 = cx + baseR * cos(angle).toFloat(); val y1 = cy + baseR * sin(angle).toFloat()
            val x2 = cx + r2    * cos(angle).toFloat(); val y2 = cy + r2    * sin(angle).toFloat()
            circlePaint.alpha = (100 + mag * 155).toInt().coerceIn(0, 255)
            canvas.drawLine(x1, y1, x2, y2, circlePaint)
        }
        glowPaint.color = 0x335B9BD4.toInt()
        glowPaint.maskFilter = BlurMaskFilter(30f + energy * 30f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(cx, cy, baseR * 0.3f + energy * 15f, glowPaint)
    }

    private fun drawIdle(canvas: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x33FFFFFF; style = Paint.Style.STROKE; strokeWidth = 2f
            pathEffect = DashPathEffect(floatArrayOf(8f, 8f), 0f)
        }
        canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, p)
    }
}
