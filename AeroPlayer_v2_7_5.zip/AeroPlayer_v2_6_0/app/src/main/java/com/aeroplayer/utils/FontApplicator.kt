package com.aeroplayer.utils

import android.app.Activity
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * FontApplicator — aplica una fuente personalizada a TODOS los TextViews
 * de una Activity de forma recursiva.
 *
 * FIX v2.6.9: Usar post() para esperar al layout completo Y también
 * forzar invalidate() en cada TextView para que se redibuje con la nueva fuente.
 * Se aplica también a vistas infladas dinámicamente (diálogos, etc.) mediante
 * el LayoutInflater factory.
 */
object FontApplicator {

    fun apply(activity: Activity, typeface: Typeface) {
        // Aplicar a todas las vistas ya existentes
        activity.window?.decorView?.let { root ->
            applyToView(root, typeface)
            // post() asegura que vistas creadas justo después del inflate también reciban la fuente
            root.post {
                applyToView(root, typeface)
            }
        }
    }

    fun applyToView(view: View, typeface: Typeface) {
        when {
            view is TextView -> {
                // Preservar negrita/cursiva si ya estaba aplicada
                val style = view.typeface?.style ?: Typeface.NORMAL
                val newTypeface = when (style) {
                    Typeface.BOLD        -> Typeface.create(typeface, Typeface.BOLD)
                    Typeface.ITALIC      -> Typeface.create(typeface, Typeface.ITALIC)
                    Typeface.BOLD_ITALIC -> Typeface.create(typeface, Typeface.BOLD_ITALIC)
                    else                 -> typeface
                }
                if (view.typeface != newTypeface) {
                    view.typeface = newTypeface
                    view.invalidate()
                }
            }
            view is ViewGroup -> {
                for (i in 0 until view.childCount) {
                    applyToView(view.getChildAt(i), typeface)
                }
            }
        }
    }
}
