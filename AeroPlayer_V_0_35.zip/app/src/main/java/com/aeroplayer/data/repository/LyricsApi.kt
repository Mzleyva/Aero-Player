package com.aeroplayer.data.repository

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// Using lrclib.net — stable, free, no API key required.
// Returns both plain and time-synced lyrics.

data class LrclibResponse(
    @SerializedName("plainLyrics")  val plainLyrics: String?,
    @SerializedName("syncedLyrics") val syncedLyrics: String?,
    @SerializedName("error")        val error: String?
)

interface LyricsApiService {
    @GET("api/get")
    suspend fun getLyrics(
        @Query("artist_name") artist: String,
        @Query("track_name")  title:  String
    ): LrclibResponse
}

object LyricsApi {
    private const val BASE_URL = "https://lrclib.net/"

    // FIX: removed unused HttpLoggingInterceptor import and reference
    val service: LyricsApiService by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LyricsApiService::class.java)
    }
}

/** Sealed result for lyrics fetch, distinguishing success / not-found / network error. */
sealed class LyricsResult {
    data class Success(val response: LrclibResponse) : LyricsResult()
    object NotFound : LyricsResult()
    data class Error(val throwable: Throwable) : LyricsResult()
}
