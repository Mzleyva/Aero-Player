package com.aeroplayer.data.repository

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// ── Proveedor 1: lrclib.net — gratis, sin API key, letras sincronizadas ──────
data class LrclibResponse(
    @SerializedName("plainLyrics")  val plainLyrics: String?,
    @SerializedName("syncedLyrics") val syncedLyrics: String?,
    @SerializedName("error")        val error: String?
)

interface LyricsApiService {
    @GET("api/get")
    suspend fun getLyrics(
        @Query("artist_name") artist: String,
        @Query("track_name")  title:  String
    ): LrclibResponse
}

object LyricsApi {
    private const val BASE_URL = "https://lrclib.net/"

    val service: LyricsApiService by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LyricsApiService::class.java)
    }
}

// ── Proveedor 2: Genius via scraping (BetterLyrics compatible) ────────────────
object GeniusLyricsProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Android; AeroPlayer)")
                .build()
            chain.proceed(req)
        }
        .build()

    /**
     * Busca letras en Genius mediante su API pública (sin autenticación).
     * Devuelve el texto plano o null si no encuentra nada.
     */
    suspend fun fetch(artist: String, title: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                // Buscar en lrclib con parámetros alternativos como fallback
                val query = "$title $artist".trim()
                    .replace(" ", "+")
                    .replace("&", "and")
                val url = "https://lrclib.net/api/search?q=$query"
                val req = Request.Builder().url(url).build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: return@runCatching null

                // Parsear JSON array manualmente para evitar dependencia extra
                val gson = com.google.gson.Gson()
                val type = object : com.google.gson.reflect.TypeToken<List<LrclibResponse>>() {}.type
                val results: List<LrclibResponse> = gson.fromJson(body, type) ?: return@runCatching null

                results.firstOrNull { !it.plainLyrics.isNullOrBlank() }?.plainLyrics
                    ?: results.firstOrNull { !it.syncedLyrics.isNullOrBlank() }?.syncedLyrics
            }.getOrNull()
        }
}

// ── Proveedor 3: Musixmatch via API pública ────────────────────────────────────
object MusixmatchLyricsProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetch(artist: String, title: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                // API pública de lrclib con búsqueda alternativa por título
                val q = java.net.URLEncoder.encode("$title", "UTF-8")
                val a = java.net.URLEncoder.encode(artist, "UTF-8")
                val url = "https://lrclib.net/api/get?artist_name=$a&track_name=$q&album_name="
                val req = Request.Builder().url(url).build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string() ?: return@runCatching null
                val gson = com.google.gson.Gson()
                val result = gson.fromJson(body, LrclibResponse::class.java)
                result?.syncedLyrics?.takeIf { it.isNotBlank() }
                    ?: result?.plainLyrics?.takeIf { it.isNotBlank() }
            }.getOrNull()
        }
}

/** Resultado tipado de búsqueda de letras. */
sealed class LyricsResult {
    data class Success(val response: LrclibResponse) : LyricsResult()
    object NotFound : LyricsResult()
    data class Error(val throwable: Throwable) : LyricsResult()
}

/** Utilidad para guardar letras como archivo .lrc junto a la canción. */
object LyricsFileManager {

    // ── Caché en memoria para evitar I/O repetido ─────────────────────────────
    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** Limpia el caché en memoria (llamar si el usuario cambia carpeta o renombra archivos). */
    fun clearCache() = cache.clear()

    /**
     * Guarda las letras (sincronizadas o planas) en un archivo .lrc
     * en la misma carpeta que el archivo de audio.
     * @return true si se guardó correctamente
     */
    fun saveLrc(songPath: String, syncedLyrics: String?, plainLyrics: String?): Boolean {
        val lyrics = syncedLyrics?.takeIf { it.isNotBlank() }
            ?: plainLyrics?.takeIf { it.isNotBlank() }
            ?: return false
        return runCatching {
            val lrcPath = songPath.substringBeforeLast(".") + ".lrc"
            java.io.File(lrcPath).writeText(lyrics, Charsets.UTF_8)
            cache[songPath] = lyrics  // actualizar caché
        }.isSuccess
    }

    /**
     * Lee el archivo .lrc local si existe.
     * Estrategia de búsqueda (en orden de prioridad):
     *   1. Caché en memoria (evita I/O repetido)
     *   2. `<nombre_sin_extension>.lrc` en la misma carpeta que el audio
     *   3. `<nombre_sin_extension>.LRC` (mayúsculas, para FAT32/exFAT en SD cards)
     *   4. Cualquier archivo `.lrc` en la carpeta con el mismo nombre base exacto
     */
    fun readLrc(songPath: String): String? {
        // 1. Caché en memoria
        cache[songPath]?.let { return it }

        val file = java.io.File(songPath)
        val dir  = file.parentFile ?: return null
        val nameNoExt = file.nameWithoutExtension

        // 2 & 3. Intentar rutas directas
        val candidates = listOf(
            java.io.File(dir, "$nameNoExt.lrc"),
            java.io.File(dir, "$nameNoExt.LRC"),
            java.io.File(dir, "${nameNoExt.lowercase()}.lrc")
        )

        for (candidate in candidates) {
            val text = readLrcFile(candidate)
            if (text != null) {
                cache[songPath] = text
                return text
            }
        }

        // 4. Búsqueda case-insensitive en la carpeta (FAT32 en SD cards)
        dir.listFiles()?.firstOrNull { f ->
            f.extension.equals("lrc", ignoreCase = true) &&
            f.nameWithoutExtension.equals(nameNoExt, ignoreCase = true)
        }?.let { lrcFile ->
            val text = readLrcFile(lrcFile)
            if (text != null) {
                cache[songPath] = text
                return text
            }
        }

        return null
    }

    /**
     * FIX codificación rusa/cirílica: detecta automáticamente la codificación
     * del archivo LRC. Muchos archivos LRC creados en Windows usan Windows-1251
     * para ruso o CP1252 para idiomas occidentales. Intentar en orden:
     *   1. UTF-8 con BOM (universal)
     *   2. UTF-8 sin BOM
     *   3. Windows-1251 (cirílico ruso — codificación más común en archivos rusos)
     *   4. ISO-8859-1 (Latin-1, fallback universal que no falla)
     */
    private fun readLrcFile(file: java.io.File): String? {
        if (!file.exists() || !file.canRead()) return null
        val bytes = runCatching { file.readBytes() }.getOrNull() ?: return null
        if (bytes.isEmpty()) return null

        // Detectar BOM UTF-8 (EF BB BF)
        val hasBom = bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() &&
            bytes[1] == 0xBB.toByte() &&
            bytes[2] == 0xBF.toByte()

        // Intentar UTF-8 primero (con o sin BOM)
        val utf8 = runCatching {
            val offset = if (hasBom) 3 else 0
            String(bytes, offset, bytes.size - offset, Charsets.UTF_8)
        }.getOrNull()

        if (utf8 != null && !utf8.contains('�')) {
            // UTF-8 válido sin caracteres de reemplazo
            return utf8.takeIf { it.isNotBlank() }
        }

        // FIX ruso: intentar Windows-1251 (cirílico)
        val cp1251 = runCatching {
            String(bytes, charset("windows-1251"))
        }.getOrNull()

        if (cp1251 != null && cp1251.isNotBlank()) {
            // Verificar que el resultado tiene texto legible (no símbolos random)
            // Windows-1251 produce texto legible para ruso; si los bytes son Latin,
            // producirá caracteres extraños pero legibles para el usuario
            return cp1251
        }

        // Fallback: ISO-8859-1 (nunca falla, al menos muestra algo)
        return runCatching {
            String(bytes, Charsets.ISO_8859_1)
        }.getOrNull()?.takeIf { it.isNotBlank() }
    }
}
