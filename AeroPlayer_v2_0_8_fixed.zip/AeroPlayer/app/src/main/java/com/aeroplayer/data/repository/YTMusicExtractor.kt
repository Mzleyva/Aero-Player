package com.aeroplayer.data.repository

import android.content.Context
import android.util.Log
import com.aeroplayer.model.Song
import com.aeroplayer.model.YTPlaylist
import com.aeroplayer.model.YTResult
import com.aeroplayer.model.YTSong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamExtractor
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request as NPRequest
import org.schabi.newpipe.extractor.downloader.Response as NPResponse
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * YTMusicExtractor  —  v1.3.5
 *
 * Extrae información de búsqueda y streams de YouTube Music sin API key.
 *
 * BUGS CORREGIDOS en esta versión:
 *
 *  BUG 1 — "Could not get ytInitialData"
 *  ─────────────────────────────────────
 *  NewPipeExtractor intentaba parsear la página HTML de YouTube buscando
 *  la variable `ytInitialData` incrustada en el JS. YouTube cambió su
 *  estructura en 2024-2025: ahora la variable puede llamarse `ytInitialData`
 *  O estar bajo `window["ytInitialData"]`, y los headers User-Agent y
 *  Accept-Language son obligatorios o el servidor devuelve una versión
 *  simplificada sin los datos necesarios.
 *
 *  Fix aplicado:
 *   · OkHttpDownloader con headers correctos: User-Agent de Chrome moderno,
 *     Accept-Language en español/inglés, y x-youtube-client-name/version
 *     para simular la app web de YT Music.
 *   · Fallback a la API Innertube (endpoint interno de YouTube) cuando
 *     NewPipeExtractor falla al parsear ytInitialData. Innertube es el
 *     mismo endpoint que usa la app oficial de YouTube Music; no requiere
 *     API key, solo los headers correctos de cliente.
 *   · La búsqueda usa directamente Innertube (`/youtubei/v1/search`) en
 *     lugar de scraping HTML, lo que es más robusto y rápido.
 *
 *  BUG 2 — "Could not get ytInitialData" en playlist
 *  ───────────────────────────────────────────────────
 *  Mismo problema que en búsqueda pero para playlists. Fix: usar endpoint
 *  Innertube `/youtubei/v1/browse` con `browseId = "VL<playlistId>"`.
 *
 *  BUG 3 — NewPipe.init() llamado múltiples veces (IllegalStateException)
 *  ────────────────────────────────────────────────────────────────────────
 *  Solucionado con AtomicBoolean + doble-checked locking en getInstance().
 *
 *  BUG 4 — Stream URLs caducadas (403 Forbidden al reproducir)
 *  ────────────────────────────────────────────────────────────
 *  Las stream URLs de YouTube caducan en ~6 horas. El cache anterior no
 *  tenía TTL. Fix: TTL de 5 horas en StreamCacheEntry, expiración evaluada
 *  antes de devolver la entrada cacheada.
 */
class YTMusicExtractor private constructor(context: Context) {

    private val appContext = context.applicationContext

    // ── OkHttpClient ──────────────────────────────────────────────────────────
    // Pool ampliado + timeouts razonables para streams lentos.
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .connectionPool(okhttp3.ConnectionPool(10, 5, TimeUnit.MINUTES))
        .build()

    // ── Stream cache con TTL ──────────────────────────────────────────────────
    private data class StreamCacheEntry(
        val streamUrl: String,
        val mimeType: String,
        val cachedAt: Long = System.currentTimeMillis()
    ) {
        fun isExpired() = System.currentTimeMillis() - cachedAt > TTL_MS
        companion object { const val TTL_MS = 5 * 60 * 60 * 1000L } // 5 horas
    }
    private val streamCache = ConcurrentHashMap<String, StreamCacheEntry>()

    // ── Headers de cliente YT Music ───────────────────────────────────────────
    // Estos headers son críticos: sin ellos YouTube devuelve HTML sin ytInitialData.
    private val ytClientHeaders = mapOf(
        "User-Agent"               to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                                      "AppleWebKit/537.36 (KHTML, like Gecko) " +
                                      "Chrome/124.0.0.0 Safari/537.36",
        "Accept-Language"          to "es-ES,es;q=0.9,en;q=0.8",
        "Accept"                   to "application/json",
        "Content-Type"             to "application/json",
        "X-YouTube-Client-Name"    to "67",   // 67 = WEB_REMIX
        "X-YouTube-Client-Version" to "1.20250101.01.00",
        "Origin"                   to "https://music.youtube.com",
        "Referer"                  to "https://music.youtube.com/",
        "X-Origin"                 to "https://music.youtube.com"
    )

    // Cuerpo base de contexto para todas las peticiones Innertube
    private fun innertubeContext() = JSONObject().apply {
        put("context", JSONObject().apply {
            put("client", JSONObject().apply {
                put("clientName", "WEB_REMIX")
                put("clientVersion", "1.20250101.01.00")
                put("hl", "es")
                put("gl", "ES")
                put("userAgent", ytClientHeaders["User-Agent"])
                put("platform", "DESKTOP")
            })
        })
    }
    // ── Singleton ─────────────────────────────────────────────────────────────
    companion object {
        private const val TAG = "YTMusicExtractor"
        private val INNERTUBE_BASE = "https://music.youtube.com/youtubei/v1"
        // La key de Innertube fue revocada por Google a principios de 2025.
        // Los endpoints /search, /browse y /player funcionan sin key si se
        // envían los headers de cliente correctos (X-YouTube-Client-Name/Version).

        @Volatile private var instance: YTMusicExtractor? = null
        private val newPipeInitialized = AtomicBoolean(false)

        fun getInstance(context: Context): YTMusicExtractor {
            return instance ?: synchronized(this) {
                instance ?: YTMusicExtractor(context.applicationContext).also {
                    instance = it
                    it.initNewPipe()
                }
            }
        }
    }

    /** NewPipe deshabilitado: usa URLDecoder.decode(String, Charset) inexistente en API 30.
     *  Toda la resolución se hace via Innertube directamente. */
    private fun initNewPipe() {
        // No-op: NewPipe incompatible con Android 11 (API 30)
    }

    // ── Búsqueda ──────────────────────────────────────────────────────────────
    /**
     * Busca canciones en YouTube Music usando la API Innertube directamente.
     *
     * FIX BUG 1: en lugar de scraping HTML (que falla cuando YT cambia
     * la estructura de ytInitialData), usamos el endpoint interno de YT Music
     * que devuelve JSON estructurado y es significativamente más estable.
     */
    suspend fun search(query: String): YTResult<List<YTSong>> = withContext(Dispatchers.IO) {
        try {
            val body = innertubeContext().apply {
                put("query", query)
                put("params", "EgWKAQIIAWoMEA4QChADEAQQCRAF")  // filtro songs para WEB_REMIX
            }

            val request = Request.Builder()
                .url("$INNERTUBE_BASE/search")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .apply { ytClientHeaders.forEach { (k, v) -> header(k, v) } }
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext YTResult.Error("HTTP ${response.code} en búsqueda")
            }

            val json = JSONObject(response.body?.string() ?: return@withContext
                YTResult.Error("Respuesta vacía de búsqueda"))

            val songs = parseSearchResults(json)
            if (songs.isEmpty()) YTResult.Error("Sin resultados para \"$query\"")
            else YTResult.Success(songs)

        } catch (e: Exception) {
            Log.e(TAG, "Error en búsqueda: ${e.message}", e)
            YTResult.Error("Error al buscar: ${e.message ?: "Error desconocido"}")
        }
    }

    /** Parsea la respuesta JSON de Innertube search → lista de YTSong. */
    private fun parseSearchResults(json: JSONObject): List<YTSong> {
        val songs = mutableListOf<YTSong>()
        try {
            val contents = json
                .optJSONObject("contents")
                ?.optJSONObject("tabbedSearchResultsRenderer")
                ?.optJSONArray("tabs")
                ?.optJSONObject(0)
                ?.optJSONObject("tabRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("sectionListRenderer")
                ?.optJSONArray("contents")
                ?: return songs

            for (i in 0 until contents.length()) {
                val shelf = contents.getJSONObject(i)
                    .optJSONObject("musicShelfRenderer") ?: continue
                val items = shelf.optJSONArray("contents") ?: continue

                for (j in 0 until items.length()) {
                    parseMusicShelfItem(items.getJSONObject(j))?.let { songs.add(it) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error parseando resultados de búsqueda: ${e.message}")
        }
        return songs
    }

    private fun parseMusicShelfItem(item: JSONObject): YTSong? {
        return try {
            val renderer = item.optJSONObject("musicResponsiveListItemRenderer") ?: return null

            // videoId — en el navigationEndpoint
            val videoId = renderer
                .optJSONObject("flexColumns")?.let { null } // continuar abajo
                ?: run {
                    renderer.optJSONObject("overlay")
                        ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                        ?.optJSONObject("content")
                        ?.optJSONObject("musicPlayButtonRenderer")
                        ?.optJSONObject("playNavigationEndpoint")
                        ?.optJSONObject("watchEndpoint")
                        ?.optString("videoId")
                }

            // Intentar obtener videoId desde navigationEndpoint directo
            val vid = videoId ?: renderer
                .optJSONObject("flexColumns")
                ?.let { null } // placeholder
            val realVideoId = renderer
                .optJSONObject("overlay")
                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")
                ?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")
                ?.optString("videoId") ?: return null

            val flexColumns = renderer.optJSONArray("flexColumns") ?: return null

            // Título (primera columna)
            val title = flexColumns.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
                ?.optJSONObject(0)
                ?.optString("text") ?: return null

            // Artista + álbum (segunda columna, múltiples runs)
            val secondCol = flexColumns.optJSONObject(1)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")

            val artist = secondCol?.optJSONObject(0)?.optString("text") ?: ""
            val album  = secondCol?.optJSONObject(2)?.optString("text") ?: ""

            // Duración (última columna o en fixedColumns)
            val durationText = renderer.optJSONArray("fixedColumns")
                ?.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFixedColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
                ?.optJSONObject(0)
                ?.optString("text") ?: ""
            val durationMs = parseDurationMs(durationText)

            // Thumbnail
            val thumbUrl = renderer
                .optJSONObject("thumbnail")
                ?.optJSONObject("musicThumbnailRenderer")
                ?.optJSONObject("thumbnail")
                ?.optJSONArray("thumbnails")
                ?.let { thumbs ->
                    // Preferir resolución media (no demasiado grande)
                    thumbs.optJSONObject(thumbs.length().coerceAtMost(2) - 1)
                        ?.optString("url")
                }

            YTSong(
                id           = realVideoId,
                title        = title,
                artist       = artist,
                album        = album,
                durationMs   = durationMs,
                thumbnailUrl = thumbUrl
            )
        } catch (e: Exception) {
            null
        }
    }

    // ── Playlist ──────────────────────────────────────────────────────────────
    /**
     * Carga una playlist de YT Music por URL o ID.
     *
     * FIX BUG 2: usa Innertube `/browse` con `browseId = "VL<playlistId>"`
     * en lugar de scraping HTML. Más estable y sin problemas de ytInitialData.
     */
    suspend fun getPlaylist(urlOrId: String): YTResult<YTPlaylist> = withContext(Dispatchers.IO) {
        try {
            val playlistId = extractPlaylistId(urlOrId)
                ?: return@withContext YTResult.Error("ID de playlist no válido: $urlOrId")

            val body = innertubeContext().apply {
                put("browseId", "VL$playlistId")
            }

            val request = Request.Builder()
                .url("$INNERTUBE_BASE/browse")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .apply { ytClientHeaders.forEach { (k, v) -> header(k, v) } }
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext YTResult.Error("HTTP ${response.code} al cargar playlist")
            }

            val json = JSONObject(response.body?.string() ?: return@withContext
                YTResult.Error("Respuesta vacía de playlist"))

            parsePlaylist(playlistId, json)
        } catch (e: Exception) {
            Log.e(TAG, "Error cargando playlist: ${e.message}", e)
            YTResult.Error("Error al cargar playlist: ${e.message ?: "Error desconocido"}")
        }
    }

    private fun parsePlaylist(id: String, json: JSONObject): YTResult<YTPlaylist> {
        return try {
            val header = json.optJSONObject("header")
                ?.optJSONObject("musicDetailHeaderRenderer")
                ?: json.optJSONObject("header")
                    ?.optJSONObject("musicImmersiveHeaderRenderer")

            val name = header?.optJSONObject("title")
                ?.optJSONArray("runs")
                ?.optJSONObject(0)
                ?.optString("text") ?: "Playlist"

            val songs = mutableListOf<YTSong>()

            // WEB_REMIX devuelve twoColumnBrowseResultsRenderer
            // Intentar primero la ruta de WEB_REMIX, luego la de mobile como fallback
            val browseContents = json.optJSONObject("contents")

            val contents =
                // Ruta WEB_REMIX: twoColumnBrowseResultsRenderer
                browseContents
                    ?.optJSONObject("twoColumnBrowseResultsRenderer")
                    ?.optJSONArray("secondaryContents")
                    ?.optJSONObject(0)
                    ?.optJSONObject("sectionListRenderer")
                    ?.optJSONArray("contents")
                    ?.optJSONObject(0)
                    ?.optJSONObject("musicShelfRenderer")
                    ?.optJSONArray("contents")
                // Fallback: singleColumnBrowseResultsRenderer (mobile/android)
                ?: browseContents
                    ?.optJSONObject("singleColumnBrowseResultsRenderer")
                    ?.optJSONArray("tabs")
                    ?.optJSONObject(0)
                    ?.optJSONObject("tabRenderer")
                    ?.optJSONObject("content")
                    ?.optJSONObject("sectionListRenderer")
                    ?.optJSONArray("contents")
                    ?.optJSONObject(0)
                    ?.optJSONObject("musicPlaylistShelfRenderer")
                    ?.optJSONArray("contents")

            if (contents != null) {
                for (i in 0 until contents.length()) {
                    parsePlaylistItem(contents.getJSONObject(i))?.let { songs.add(it) }
                }
            }

            YTResult.Success(
                YTPlaylist(
                    id        = id,
                    name      = name,
                    songCount = songs.size,
                    songs     = songs
                )
            )
        } catch (e: Exception) {
            YTResult.Error("Error parseando playlist: ${e.message}")
        }
    }

    private fun parsePlaylistItem(item: JSONObject): YTSong? {
        return try {
            val renderer = item.optJSONObject("musicResponsiveListItemRenderer") ?: return null

            val videoId = renderer
                .optJSONObject("flexColumns")?.let { null }
                ?: run { null }

            val realVideoId = renderer
                .optJSONObject("overlay")
                ?.optJSONObject("musicItemThumbnailOverlayRenderer")
                ?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")
                ?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")
                ?.optString("videoId") ?: return null

            val flexColumns = renderer.optJSONArray("flexColumns") ?: return null

            val title = flexColumns.optJSONObject(0)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")
                ?.optJSONObject(0)
                ?.optString("text") ?: return null

            val secondRuns = flexColumns.optJSONObject(1)
                ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
                ?.optJSONObject("text")
                ?.optJSONArray("runs")

            val artist = secondRuns?.optJSONObject(0)?.optString("text") ?: ""

            val thumbUrl = renderer
                .optJSONObject("thumbnail")
                ?.optJSONObject("musicThumbnailRenderer")
                ?.optJSONObject("thumbnail")
                ?.optJSONArray("thumbnails")
                ?.optJSONObject(0)
                ?.optString("url")

            YTSong(id = realVideoId, title = title, artist = artist, thumbnailUrl = thumbUrl)
        } catch (e: Exception) {
            null
        }
    }

    // ── Stream resolution ─────────────────────────────────────────────────────
    /**
     * Resuelve la URL de stream para una [YTSong].
     *
     * Estrategia:
     *  1. Cache con TTL de 5 horas → devolver directamente.
     *  2. NewPipeExtractor → más formatos disponibles.
     *  3. Fallback Innertube `/player` → si NewPipe falla (ytInitialData bug).
     */
    suspend fun resolveToSong(ytSong: YTSong): YTResult<Song> = withContext(Dispatchers.IO) {
        // 1. Cache
        streamCache[ytSong.id]?.takeIf { !it.isExpired() }?.let { cached ->
            return@withContext YTResult.Success(
                ytSong.toSong(cached.streamUrl).also {
                    (it as? com.aeroplayer.model.Song)
                }
                // toSong está en YTSong, devolver directamente
            )
        }
        // Asegurarnos de llamar toSong correctamente
        val cached = streamCache[ytSong.id]?.takeIf { !it.isExpired() }
        if (cached != null) {
            return@withContext YTResult.Success(ytSong.toSong(cached.streamUrl))
        }

        // NewPipe usa URLDecoder.decode(String, Charset) que no existe en API 30 (Android 11).
        // Saltamos directamente a Innertube que es más estable y no tiene esa dependencia.

        // Fallback: Innertube /player
        try {
            val result = resolveViaInnertube(ytSong.id)
            if (result != null) {
                streamCache[ytSong.id] = StreamCacheEntry(result.first, result.second)
                return@withContext YTResult.Success(ytSong.toSong(result.first))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Innertube también falló para ${ytSong.id}: ${e.message}")
        }

        YTResult.Error("No se pudo obtener stream para \"${ytSong.title}\"")
    }

    /**
     * Fallback de resolución de stream via Innertube /player.
     * Devuelve (streamUrl, mimeType) o null si falla.
     */
    private fun resolveViaInnertube(videoId: String): Pair<String, String>? {
        // Cliente iOS (clientName=IOS, id=5): el único que devuelve URLs directas
        // sin signatureCipher en 2025. Es lo mismo que usan InnerTune, Muzza y RiMusic.
        // WEB_REMIX y TVHTML5 cifran las URLs → campo "url" vacío → stream nulo.
        val body = JSONObject().apply {
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", "IOS")
                    put("clientVersion", "19.29.1")
                    put("deviceModel", "iPhone14,3")
                    put("osVersion", "17.0.0.21A329")
                    put("hl", "es")
                    put("gl", "ES")
                })
            })
            put("videoId", videoId)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
        }
        val request = Request.Builder()
            .url("https://music.youtube.com/youtubei/v1/player")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .header("User-Agent", "com.google.ios.youtubemusic/6.21 (iPhone; CPU iPhone OS 17_0 like Mac OS X)")
            .header("Content-Type", "application/json")
            .header("X-YouTube-Client-Name", "26")
            .header("X-YouTube-Client-Version", "6.21")
            .header("Origin", "https://music.youtube.com")
            .header("Referer", "https://music.youtube.com/")
            .build()

        val response = httpClient.newCall(request).execute()
        if (!response.isSuccessful) return null

        val json = JSONObject(response.body?.string() ?: return null)
        val streamingData = json.optJSONObject("streamingData") ?: return null

        // iOS siempre devuelve URLs directas en adaptiveFormats
        val adaptive = streamingData.optJSONArray("adaptiveFormats")
        val regular  = streamingData.optJSONArray("formats")

        var bestUrl: String? = null
        var bestMime = "audio/mp4"
        var bestBitrate = 0

        listOfNotNull(adaptive, regular).forEach { arr ->
            for (i in 0 until arr.length()) {
                val fmt = arr.getJSONObject(i)
                val mime = fmt.optString("mimeType", "")
                if (!mime.startsWith("audio/")) continue
                val bitrate = fmt.optInt("bitrate", 0)
                val url = fmt.optString("url", "")
                if (url.isBlank()) continue
                if (bitrate > bestBitrate) {
                    bestBitrate = bitrate
                    bestUrl = url
                    bestMime = mime.substringBefore(";")
                }
            }
        }

        return bestUrl?.let { it to bestMime }
    }

    /** Elige el mejor AudioStream: preferir opus/webm > m4a > cualquier otro. */
    private fun chooseBestAudioStream(streams: List<AudioStream>?): AudioStream? {
        if (streams.isNullOrEmpty()) return null
        // Filtrar streams sin contenido válido
        val valid = streams.filter {
            (!it.content.isNullOrBlank() || !it.url.isNullOrBlank()) &&
            it.format != null
        }
        if (valid.isEmpty()) return streams.firstOrNull()
        // Preferir opus (mejor calidad/tamaño), luego m4a
        return valid.maxByOrNull { stream ->
            val mime = stream.format?.mimeType ?: ""
            when {
                mime.contains("opus") -> 3
                mime.contains("mp4")  -> 2
                mime.contains("webm") -> 1
                else                  -> 0
            } * 1_000_000 + (stream.averageBitrate ?: 0)
        }
    }

    // ── Utilidades ────────────────────────────────────────────────────────────

    /** Extrae el playlistId de una URL o lo devuelve directamente si ya es un ID. */
    private fun extractPlaylistId(urlOrId: String): String? {
        // Ya es un ID (empieza por PL, RDAMVM, etc.)
        if (!urlOrId.startsWith("http")) {
            return urlOrId.trim().takeIf { it.isNotBlank() }
        }
        // URL completa: buscar parámetro "list"
        val listRegex = Regex("""[?&]list=([^&]+)""")
        return listRegex.find(urlOrId)?.groupValues?.get(1)
    }

    /** Parsea "3:45" o "1:03:22" → milisegundos. */
    private fun parseDurationMs(text: String): Long {
        if (text.isBlank()) return 0L
        return try {
            val parts = text.trim().split(":").map { it.toLong() }
            when (parts.size) {
                2 -> (parts[0] * 60 + parts[1]) * 1000L
                3 -> (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000L
                else -> 0L
            }
        } catch (e: Exception) { 0L }
    }

    fun clearStreamCache() {
        streamCache.clear()
    }
}

// ── OkHttpDownloader para NewPipeExtractor ────────────────────────────────────
/**
 * Implementación de Downloader para NewPipeExtractor usando OkHttp.
 *
 * FIX BUG 1: el Downloader original de NewPipe no enviaba los headers
 * User-Agent y Accept-Language correctos para YouTube Music, causando
 * que el servidor devolviera HTML sin ytInitialData.
 */
private class OkHttpDownloaderImpl(private val client: OkHttpClient) : Downloader() {

    override fun execute(request: NPRequest): NPResponse {
        val builder = Request.Builder().url(request.url())

        // Cabeceras de la request de NewPipe
        request.headers()?.forEach { (name, values) ->
            values.forEach { value -> builder.addHeader(name, value) }
        }

        // Headers requeridos por YouTube (sobrescriben los de NewPipe si coinciden)
        builder.header(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36"
        )
        builder.header("Accept-Language", "es-ES,es;q=0.9,en;q=0.8")
        builder.header("Accept-Charset", "UTF-8")   // FIX: charset explícito

        val httpRequest = when (val body = request.dataToSend()) {
            null -> builder.get().build()
            else -> builder.post(body.toRequestBody()).build()
        }

        val response = client.newCall(httpRequest).execute()
        val responseBody = response.body?.string() ?: ""

        return NPResponse(
            response.code,
            response.message,
            response.headers.toMultimap(),
            responseBody,
            request.url()
        )
    }
}
