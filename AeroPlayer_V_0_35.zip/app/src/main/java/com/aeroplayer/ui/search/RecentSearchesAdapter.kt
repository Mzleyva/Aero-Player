package com.aeroplayer.ui.search

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.databinding.ItemRecentSearchBinding

class RecentSearchesAdapter(
    private val onQueryClick: (String) -> Unit,
    private val onRemoveClick: (String) -> Unit
) : ListAdapter<String, RecentSearchesAdapter.VH>(StringDiff()) {

    inner class VH(val b: ItemRecentSearchBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRecentSearchBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val query = getItem(position)
        holder.b.tvQuery.text = query
        holder.b.btnRemove.setOnClickListener { onRemoveClick(query) }
        holder.b.root.setOnClickListener { onQueryClick(query) }
    }

    class StringDiff : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(a: String, b: String) = a == b
        override fun areContentsTheSame(a: String, b: String) = a == b
    }
}
