package com.aeroplayer.utils

import android.app.Activity
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * FontApplicator — aplica una fuente personalizada a todos los TextView
 * de una Activity de forma recursiva tras el inflado de la vista.
 *
 * Técnica: recorrer el árbol de vistas con un ViewTreeObserver una sola vez
 * y aplicar el Typeface a cada TextView encontrado.
 */
object FontApplicator {

    fun apply(activity: Activity, typeface: Typeface) {
        val root = activity.window?.decorView?.rootView ?: return
        root.viewTreeObserver.addOnGlobalLayoutListener(
            object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    applyToView(root, typeface)
                }
            }
        )
    }

    private fun applyToView(view: View, typeface: Typeface) {
        when (view) {
            is TextView   -> {
                val style = view.typeface?.style ?: Typeface.NORMAL
                view.typeface = Typeface.create(typeface, style)
            }
            is ViewGroup  -> (0 until view.childCount).forEach { applyToView(view.getChildAt(it), typeface) }
        }
    }
}
