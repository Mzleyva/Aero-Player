package com.aeroplayer.ui

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aeroplayer.R
import com.aeroplayer.data.db.PlayCountEntity
import com.aeroplayer.scrobble.LastFmAuth
import com.aeroplayer.ui.stats.DailyBarChartView
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class StatsActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // ── Toolbar ──────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { finish() }
        }
        val tvToolbarTitle = TextView(this).apply {
            text = "Estadísticas"
            textSize = 20f
            setTextColor(getColor(R.color.text_primary))
            setPadding(12.dp, 0, 0, 0)
        }
        toolbar.addView(btnBack)
        toolbar.addView(tvToolbarTitle)
        root.addView(toolbar)

        // ── Tarjetas de resumen ───────────────────────────────────────────────
        val cardRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16.dp, 8.dp, 16.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tvTotalTime  = makeSummaryCard("Tiempo total", "Cargando…")
        val tvTotalSongs = makeSummaryCard("Canciones", "Cargando…")
        cardRow.addView(tvTotalTime.first,  LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        cardRow.addView(tvTotalSongs.first, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(cardRow)

        // ── Botón recopilación anual ──────────────────────────────────────────
        val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        val btnWrap = android.widget.Button(this).apply {
            text = "🎉 Ver recopilación $currentYear"
            textSize = 15f
            setTextColor(getColor(android.R.color.white))
            setBackgroundColor(getColor(R.color.accent_blue))
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                52.dp
            ).also { it.setMargins(16.dp, 16.dp, 16.dp, 0) }
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(getColor(R.color.accent_blue))
                cornerRadius = 12.dp.toFloat()
            }
            setOnClickListener {
                startActivity(
                    android.content.Intent(this@StatsActivity, YearlyWrapActivity::class.java)
                        .putExtra("year", currentYear)
                )
            }
        }
        root.addView(btnWrap, 2) // después del cardRow

        // ── Gráfica diaria ────────────────────────────────────────────────────
        root.addView(sectionTitle("📈 Actividad (últimos 30 días)"))
        val chartContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 160.dp
            ).also { it.setMargins(16.dp, 0, 16.dp, 8.dp) }
            setBackgroundResource(R.drawable.bg_card_dark)
        }
        val chartView = DailyBarChartView(this)
        chartContainer.addView(chartView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        root.addView(chartContainer)

        // ── Last.fm scrobbling ────────────────────────────────────────────────
        root.addView(sectionTitle("🎙️ Last.fm"))
        val lastFmCard = buildLastFmCard()
        root.addView(lastFmCard)

        // ── Top canciones más reproducidas ────────────────────────────────────
        root.addView(sectionTitle("🎵 Más reproducidas"))
        val topPlaysContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 8.dp)
        }
        root.addView(topPlaysContainer)

        // ── Top 10 por tiempo escuchado ───────────────────────────────────────
        root.addView(sectionTitle("⏱ Más tiempo escuchadas"))
        val topTimeContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 80.dp)
        }
        root.addView(topTimeContainer)

        scroll.addView(root)
        setContentView(scroll)

        // ── Cargar datos ──────────────────────────────────────────────────────
        lifecycleScope.launch {
            val totalMs     = viewModel.getTotalListenTimeMs()
            val uniqueSongs = viewModel.getUniqueSongsPlayed()
            runOnUiThread {
                tvTotalTime.second.text  = formatDuration(totalMs)
                tvTotalSongs.second.text = "$uniqueSongs canciones"
            }
        }

        lifecycleScope.launch {
            val daily = viewModel.getDailyPlays(30)
            runOnUiThread { chartView.setData(daily) }
        }

        viewModel.topPlayed.observe(this) { list ->
            topPlaysContainer.removeAllViews()
            list.take(10).forEachIndexed { i, entry ->
                topPlaysContainer.addView(makeSongRow(i + 1, entry, showTime = false))
            }
        }

        lifecycleScope.launch {
            val topTime = viewModel.getTopByListenTime(10)
            runOnUiThread {
                topTimeContainer.removeAllViews()
                topTime.forEachIndexed { i, entry ->
                    topTimeContainer.addView(makeSongRow(i + 1, entry, showTime = true))
                }
            }
        }
    }

    // ── Last.fm card ──────────────────────────────────────────────────────────

    private fun buildLastFmCard(): LinearLayout {
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)
        val isConnected = prefs.getBoolean("lastfm_connected", false)
        val username    = prefs.getString("lastfm_username", "") ?: ""

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 16.dp, 20.dp, 16.dp)
            setBackgroundResource(R.drawable.bg_card_dark)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(16.dp, 0, 16.dp, 8.dp) }
            layoutParams = lp
        }

        val tvStatus = TextView(this).apply {
            text = if (isConnected) "✅  Conectado como @$username" else "⚪  No conectado"
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
        }
        val tvDesc = TextView(this).apply {
            text = "Habilita el scrobbling para registrar tus reproducciones en Last.fm automáticamente."
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, 6.dp, 0, 12.dp)
        }

        val btnConnect = android.widget.Button(this).apply {
            text = if (isConnected) "Desconectar" else "Conectar con Last.fm"
            setTextColor(getColor(android.R.color.white))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (isConnected) 0xFF555555.toInt() else 0xFFD51007.toInt())
                cornerRadius = 8.dp.toFloat()
            }
            setOnClickListener { toggleLastFm(prefs, isConnected, tvStatus, this) }
        }

        // Switch de scrobbling activo
        val switchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 8.dp, 0, 0)
        }
        val tvSwitch = TextView(this).apply {
            text = "Scrobbling activo"
            textSize = 14f
            setTextColor(getColor(R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = com.google.android.material.switchmaterial.SwitchMaterial(this).apply {
            isChecked = prefs.getBoolean("lastfm_scrobble_enabled", true)
            isEnabled = isConnected
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("lastfm_scrobble_enabled", checked).apply()
            }
        }
        switchRow.addView(tvSwitch)
        switchRow.addView(sw)

        card.addView(tvStatus)
        card.addView(tvDesc)
        card.addView(btnConnect)
        if (isConnected) card.addView(switchRow)
        return card
    }

    private fun toggleLastFm(
        prefs: android.content.SharedPreferences,
        isConnected: Boolean,
        tvStatus: TextView,
        btnConnect: android.widget.Button
    ) {
        if (isConnected) {
            prefs.edit()
                .putBoolean("lastfm_connected", false)
                .remove("lastfm_username")
                .remove("lastfm_session_key")
                .apply()
            tvStatus.text = "⚪  No conectado"
            btnConnect.text = "Conectar con Last.fm"
            (btnConnect.background as? android.graphics.drawable.GradientDrawable)
                ?.setColor(0xFFD51007.toInt())
            android.widget.Toast.makeText(this, "Desconectado de Last.fm", android.widget.Toast.LENGTH_SHORT).show()
        } else {
            // Abrir diálogo de credenciales Last.fm
            showLastFmLoginDialog(prefs, tvStatus, btnConnect)
        }
    }

    private fun showLastFmLoginDialog(
        prefs: android.content.SharedPreferences,
        tvStatus: TextView,
        btnConnect: android.widget.Button
    ) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 16.dp, 24.dp, 8.dp)
        }
        val etUser = EditText(this).apply { hint = "Usuario de Last.fm" }
        val etPass = EditText(this).apply {
            hint = "Contraseña"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        layout.addView(etUser)
        layout.addView(etPass)

        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Iniciar sesión en Last.fm")
            .setView(layout)
            .setPositiveButton("Conectar") { _, _ ->
                val user = etUser.text.toString().trim()
                val pass = etPass.text.toString()
                if (user.isNotEmpty() && pass.isNotEmpty()) {
                    authenticateLastFm(user, pass, prefs, tvStatus, btnConnect)
                } else {
                    android.widget.Toast.makeText(this, "Completa los campos", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun authenticateLastFm(
        username: String, password: String,
        prefs: android.content.SharedPreferences,
        tvStatus: TextView, btnConnect: android.widget.Button
    ) {
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val sessionKey = LastFmAuth.getSessionKey(username, password)
                runOnUiThread {
                    if (sessionKey != null) {
                        prefs.edit()
                            .putBoolean("lastfm_connected", true)
                            .putString("lastfm_username", username)
                            .putString("lastfm_session_key", sessionKey)
                            .putBoolean("lastfm_scrobble_enabled", true)
                            .apply()
                        tvStatus.text = "✅  Conectado como @$username"
                        btnConnect.text = "Desconectar"
                        (btnConnect.background as? android.graphics.drawable.GradientDrawable)
                            ?.setColor(0xFF555555.toInt())
                        android.widget.Toast.makeText(this@StatsActivity, "¡Conectado! El scrobbling está activo.", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        android.widget.Toast.makeText(this@StatsActivity, "Error: usuario o contraseña incorrectos", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    android.widget.Toast.makeText(this@StatsActivity, "Error de conexión: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Helpers de UI ─────────────────────────────────────────────────────────

    private fun makeSummaryCard(label: String, value: String): Pair<LinearLayout, TextView> {
        val tvValue = TextView(this).apply {
            text = value
            textSize = 22f
            setTextColor(getColor(R.color.text_primary))
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val tvLabel = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            gravity = Gravity.CENTER
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12.dp, 16.dp, 12.dp, 16.dp)
            setBackgroundResource(R.drawable.bg_card_dark)
            val m = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(8.dp, 0, 8.dp, 0) }
            layoutParams = m
        }
        card.addView(tvValue)
        card.addView(tvLabel)
        return Pair(card, tvValue)
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(getColor(R.color.text_primary))
        setPadding(20.dp, 16.dp, 16.dp, 8.dp)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun makeSongRow(rank: Int, entry: PlayCountEntity, showTime: Boolean): LinearLayout {
        val dp = resources.displayMetrics.density

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp, 10.dp, 16.dp, 10.dp)
            background = android.util.TypedValue().also {
                theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { getDrawable(it) }
            isClickable = true
            isFocusable = true
        }

        // Número
        val tvRank = TextView(this).apply {
            text = rank.toString()
            textSize = 13f
            setTextColor(getColor(R.color.text_secondary))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams((28 * dp).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // Carátula
        val size = (44 * dp).toInt()
        val iv = android.widget.ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).also {
                it.marginEnd = (12 * dp).toInt()
            }
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            background = getDrawable(R.drawable.bg_album_art_small)
            clipToOutline = true
        }
        Glide.with(iv)
            .load(entry.albumArtUri?.let { android.net.Uri.parse(it) })
            .placeholder(R.drawable.ic_music_placeholder)
            .centerCrop()
            .into(iv)

        // Textos
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(this).apply {
            text = entry.title
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(getColor(R.color.text_primary))
        }
        val tvSub = TextView(this).apply {
            text = if (showTime)
                "${entry.artist} · ${formatDuration(entry.listenTimeMs)}"
            else
                "${entry.artist} · ${entry.count} reproduccion${if (entry.count != 1) "es" else ""}"
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(getColor(R.color.text_secondary))
        }
        texts.addView(tvTitle)
        texts.addView(tvSub)

        row.addView(tvRank)
        row.addView(iv)
        row.addView(texts)

        row.setOnClickListener {
            com.aeroplayer.service.PlayerController.playSongs(
                listOf(entry.toSong()), 0, queueName = "Estadísticas"
            )
        }
        return row
    }

    private fun PlayCountEntity.toSong() = com.aeroplayer.model.Song(
        id = songId, title = title, artist = artist, album = "",
        duration = 0L, path = path,
        albumArtUri = albumArtUri?.let { android.net.Uri.parse(it) },
        uri = android.net.Uri.parse("file://$path"),
        trackNumber = 0, year = 0, size = 0
    )

    private fun formatDuration(ms: Long): String {
        if (ms <= 0L) return "0 min"
        val totalSeconds = ms / 1000
        val hours   = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return when {
            hours > 0   -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m ${seconds}s"
            else        -> "${seconds}s"
        }
    }
}
