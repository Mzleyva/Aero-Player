package com.aeroplayer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aeroplayer.utils.CrashLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AeroPlayerApp : Application() {

    // Scope de aplicación para tareas de inicio en background
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        // ── Hilo principal: solo lo que es estrictamente necesario ────────────
        // CrashLogger se registra primero para capturar cualquier crash en el resto del init.
        CrashLogger.init(this)
        createNotificationChannels()

        // FIX RENDIMIENTO (startup lento):
        // ArtworkProvider.init() y ArtistImageProvider.init() crean directorios en
        // disco (mkdirs) y construyen instancias de OkHttpClient, operaciones que
        // pueden tardar 100-300 ms en dispositivos lentos. Ejecutarlas en el main
        // thread bloqueaba la SplashActivity y retrasaba la primera pantalla visible.
        //
        // Moverlas a Dispatchers.IO garantiza que el main thread queda libre para
        // inflar el layout de MainActivity mientras los proveedores se inicializan
        // en paralelo en el pool de I/O. Como ambos objetos comprueban internamente
        // si ya están inicializados antes de cada uso, no hay condición de carrera
        // si el primer fetchArtwork() llega antes de que termine el init.
        appScope.launch(Dispatchers.IO) {
            com.aeroplayer.data.repository.ArtworkProvider.init(applicationContext)
            com.aeroplayer.data.repository.ArtistImageProvider.init(applicationContext)
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            // FIX doble notificación: Media3 DefaultMediaNotificationProvider usa
            // "default_channel_id" internamente. Si creamos un canal DISTINTO y además
            // Media3 crea el suyo, aparecen DOS notificaciones de música simultáneas.
            // Solución: crear UN SOLO canal con el mismo ID que usa Media3, con los
            // atributos que queremos (sin sonido, sin vibración, lockscreen público).
            // Ya no creamos "aero_playback_channel" — ese canal huérfano era la segunda notificación.
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK,           // = "default_channel_id" — mismo que Media3
                "Reproducción de música",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controles de reproducción de AeroPlayer"
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            nm.createNotificationChannel(playbackChannel)
        }
    }

    companion object {
        // Debe coincidir con el ID interno de Media3 DefaultMediaNotificationProvider
        const val CHANNEL_PLAYBACK = "default_channel_id"
    }
}
