package com.aeroplayer.auto

import android.content.Intent
import android.os.Bundle
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.media.MediaBrowserServiceCompat
import com.aeroplayer.R
import com.aeroplayer.data.repository.MusicRepository
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * AeroAutoService — v1.8.3
 *
 * Servicio MediaBrowserServiceCompat que expone la biblioteca de AeroPlayer
 * a Android Auto / Automotive OS.
 *
 * Árbol de navegación:
 *   ROOT
 *   ├── now_playing        → Cola actual
 *   ├── recents            → Más escuchadas (top 20)
 *   ├── liked              → Me gusta
 *   ├── albums             → Álbumes (lista)
 *   │   └── album_<id>     → Canciones del álbum
 *   └── artists            → Artistas (lista)
 *       └── artist_<name>  → Álbumes del artista
 *
 * Requerimientos en AndroidManifest:
 *   - El servicio debe tener intent-filter con
 *     "android.media.browse.MediaBrowserService"
 *   - meta-data "com.google.android.gms.car.application" apuntando a
 *     un XML con <uses-library android:name="com.google.android.maps"/>
 */
class AeroAutoService : MediaBrowserServiceCompat() {

    companion object {
        private const val ROOT_ID          = "root"
        private const val NOW_PLAYING_ID   = "now_playing"
        private const val RECENTS_ID       = "recents"
        private const val LIKED_ID         = "liked"
        private const val ALBUMS_ID        = "albums"
        private const val ARTISTS_ID       = "artists"
        private const val PREFIX_ALBUM     = "album_"
        private const val PREFIX_ARTIST    = "artist_"
        private const val PREFIX_SONG      = "song_"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var repo: MusicRepository

    private var mediaSession: MediaSessionCompat? = null
    private val stateBuilder = PlaybackStateCompat.Builder()
        .setActions(
            PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID or
            PlaybackStateCompat.ACTION_PLAY_FROM_SEARCH
        )

    override fun onCreate() {
        super.onCreate()
        repo = MusicRepository(this)

        mediaSession = MediaSessionCompat(this, "AeroAutoSession").apply {
            setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                     MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setPlaybackState(stateBuilder.setState(
                PlaybackStateCompat.STATE_NONE, 0L, 1f).build())
            isActive = true
            setCallback(AutoSessionCallback())
        }
        sessionToken = mediaSession!!.sessionToken

        // Sincronizar estado con PlayerController
        PlayerController.isPlaying.observeForever { playing ->
            val state = if (playing) PlaybackStateCompat.STATE_PLAYING
                        else         PlaybackStateCompat.STATE_PAUSED
            mediaSession?.setPlaybackState(
                stateBuilder.setState(state, PlayerController.currentPositionMs(), 1f).build())
        }

        PlayerController.currentSong.observeForever { song ->
            if (song == null) return@observeForever
            val meta = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE,  song.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, song.artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM,  song.album)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION,  song.duration)
                .putString(MediaMetadataCompat.METADATA_KEY_ART_URI, song.albumArtUri?.toString() ?: "")
                .build()
            mediaSession?.setMetadata(meta)
        }
    }

    // ── MediaBrowserServiceCompat ─────────────────────────────────────────────

    override fun onGetRoot(clientPackage: String, clientUid: Int, hints: Bundle?): BrowserRoot {
        // Permitir Android Auto y apps del sistema
        return BrowserRoot(ROOT_ID, null)
    }

    override fun onLoadChildren(parentId: String, result: Result<List<MediaBrowserCompat.MediaItem>>) {
        result.detach()
        scope.launch {
            val items = when {
                parentId == ROOT_ID        -> buildRootItems()
                parentId == NOW_PLAYING_ID -> buildNowPlayingItems()
                parentId == RECENTS_ID     -> buildRecentItems()
                parentId == LIKED_ID       -> buildLikedItems()
                parentId == ALBUMS_ID      -> buildAlbumItems()
                parentId == ARTISTS_ID     -> buildArtistItems()
                parentId.startsWith(PREFIX_ALBUM)  -> buildAlbumSongs(parentId.removePrefix(PREFIX_ALBUM))
                parentId.startsWith(PREFIX_ARTIST) -> buildArtistAlbums(parentId.removePrefix(PREFIX_ARTIST))
                else -> emptyList()
            }
            result.sendResult(ArrayList(items))
        }
    }

    // ── Root ──────────────────────────────────────────────────────────────────

    private fun buildRootItems(): List<MediaBrowserCompat.MediaItem> = listOf(
        browseItem(NOW_PLAYING_ID, "Reproduciendo ahora",   "Cola actual",    R.drawable.ic_queue),
        browseItem(RECENTS_ID,     "Más escuchadas",         "Tus favoritas",  R.drawable.ic_history),
        browseItem(LIKED_ID,       "Me gusta",               "",               R.drawable.ic_heart_outline),
        browseItem(ALBUMS_ID,      "Álbumes",                "",               R.drawable.ic_music_placeholder),
        browseItem(ARTISTS_ID,     "Artistas",               "",               R.drawable.ic_person)
    )

    // ── Now playing ───────────────────────────────────────────────────────────

    private fun buildNowPlayingItems(): List<MediaBrowserCompat.MediaItem> {
        val songs = PlayerController.queue.value.orEmpty()
        return songs.mapIndexed { i, s -> playableItem("$PREFIX_SONG${s.id}_q$i", s) }
    }

    // ── Recents ───────────────────────────────────────────────────────────────

    private suspend fun buildRecentItems(): List<MediaBrowserCompat.MediaItem> {
        val songs = runCatching { repo.getMostPlayed(limit = 30) }.getOrDefault(emptyList())
        return songs.map { s -> playableItem("$PREFIX_SONG${s.id}_recent", s) }
    }

    // ── Liked ─────────────────────────────────────────────────────────────────

    private suspend fun buildLikedItems(): List<MediaBrowserCompat.MediaItem> {
        val songs = runCatching { repo.getLikedSongs() }.getOrDefault(emptyList())
        return songs.map { s -> playableItem("$PREFIX_SONG${s.id}_liked", s) }
    }

    // ── Albums ────────────────────────────────────────────────────────────────

    private suspend fun buildAlbumItems(): List<MediaBrowserCompat.MediaItem> {
        val albums = runCatching { repo.getAllAlbums() }.getOrDefault(emptyList())
        return albums.take(100).map { album ->
            browseItem("$PREFIX_ALBUM${album.id}", album.name, album.artist, R.drawable.ic_music_placeholder)
        }
    }

    private suspend fun buildAlbumSongs(albumId: String): List<MediaBrowserCompat.MediaItem> {
        val songs = runCatching { repo.getSongsForAlbum(albumId.toLongOrNull() ?: -1) }
            .getOrDefault(emptyList())
        return songs.map { s -> playableItem("$PREFIX_SONG${s.id}_alb$albumId", s) }
    }

    // ── Artists ───────────────────────────────────────────────────────────────

    private suspend fun buildArtistItems(): List<MediaBrowserCompat.MediaItem> {
        val artists = runCatching { repo.getAllArtists() }.getOrDefault(emptyList())
        return artists.take(100).map { artist ->
            browseItem("$PREFIX_ARTIST${artist.name}", artist.name,
                "${artist.albumCount} álbumes", R.drawable.ic_person)
        }
    }

    private suspend fun buildArtistAlbums(artistName: String): List<MediaBrowserCompat.MediaItem> {
        val songs = runCatching { repo.getSongsByArtist(artistName) }.getOrDefault(emptyList())
        return songs.map { s -> playableItem("$PREFIX_SONG${s.id}_art$artistName", s) }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun browseItem(id: String, title: String, subtitle: String, iconRes: Int) =
        MediaBrowserCompat.MediaItem(
            MediaDescriptionCompat.Builder()
                .setMediaId(id).setTitle(title).setSubtitle(subtitle)
                .build(),
            MediaBrowserCompat.MediaItem.FLAG_BROWSABLE
        )

    private fun playableItem(id: String, song: Song) =
        MediaBrowserCompat.MediaItem(
            MediaDescriptionCompat.Builder()
                .setMediaId(id)
                .setTitle(song.title)
                .setSubtitle(song.artist)
                .setDescription(song.album)
                .setIconUri(song.albumArtUri)
                .setMediaUri(song.uri)
                .build(),
            MediaBrowserCompat.MediaItem.FLAG_PLAYABLE
        )

    // ── Session Callback ──────────────────────────────────────────────────────

    inner class AutoSessionCallback : MediaSessionCompat.Callback() {
        override fun onPlay()  { PlayerController.play() }
        override fun onPause() { PlayerController.pause() }
        override fun onSkipToNext()     { PlayerController.skipToNext() }
        override fun onSkipToPrevious() { PlayerController.skipToPrevious() }
        override fun onSeekTo(pos: Long){ PlayerController.seekTo(pos) }

        override fun onPlayFromMediaId(mediaId: String?, extras: Bundle?) {
            mediaId ?: return
            scope.launch {
                val songId = extractSongId(mediaId) ?: return@launch
                val songs  = PlayerController.queue.value.orEmpty()
                val idx    = songs.indexOfFirst { it.id == songId }
                if (idx >= 0) {
                    kotlinx.coroutines.withContext(Dispatchers.Main) {
                        PlayerController.seekToIndex(idx)
                        PlayerController.play()
                    }
                } else {
                    // Buscar en biblioteca completa
                    val song = runCatching { repo.getSongById(songId) }.getOrNull() ?: return@launch
                    kotlinx.coroutines.withContext(Dispatchers.Main) {
                        PlayerController.loadQueue(listOf(song), 0)
                    }
                }
            }
        }

        override fun onPlayFromSearch(query: String?, extras: Bundle?) {
            if (query.isNullOrBlank()) { onPlay(); return }
            scope.launch {
                val results = runCatching { repo.searchSongs(query) }.getOrDefault(emptyList())
                if (results.isNotEmpty()) {
                    kotlinx.coroutines.withContext(Dispatchers.Main) {
                        PlayerController.loadQueue(results, 0)
                    }
                }
            }
        }
    }

    private fun extractSongId(mediaId: String): Long? {
        // IDs tienen formato "song_<id>_<suffix>"
        val match = Regex("""song_(\d+)""").find(mediaId) ?: return null
        return match.groupValues[1].toLongOrNull()
    }

    override fun onDestroy() {
        mediaSession?.release(); mediaSession = null
        super.onDestroy()
    }
}
