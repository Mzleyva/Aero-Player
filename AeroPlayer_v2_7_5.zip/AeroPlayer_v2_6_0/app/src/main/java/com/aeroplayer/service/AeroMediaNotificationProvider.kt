package com.aeroplayer.service

import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.aeroplayer.R

/**
 * AeroMediaNotificationProvider — corrige el crash de SystemUI en Android 11.
 *
 * CAUSA: DefaultMediaNotificationProvider pasa el bitmap de portada sin escalar
 * (~1.4 MB) a SystemUI via Binder IPC. Android 11 limita las transacciones IPC
 * a ~1 MB → TransactionTooLargeException en SystemUI → crash del OS.
 *
 * setBitmapLoader() solo existe en Media3 ≥ 1.5.x, no en 1.4.1.
 *
 * SOLUCIÓN para Media3 1.4.1: delegar al DefaultMediaNotificationProvider,
 * luego interceptar la Notification resultante y reemplazar el largeIcon
 * con una versión escalada a máx 256×256 px antes de que llegue a SystemUI.
 */
@UnstableApi
class AeroMediaNotificationProvider(private val context: Context) : MediaNotification.Provider {

    companion object {
        private const val MAX_PX = 256  // 256×256 × 4 bytes ≈ 256 KB, seguro para IPC
    }

    // Delegate al proveedor estándar de Media3 para toda la lógica de acciones/estilo
    private val delegate = DefaultMediaNotificationProvider(context)

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: com.google.common.collect.ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        // 1. Obtener la notificación del proveedor estándar
        val original = delegate.createNotification(
            mediaSession, customLayout, actionFactory, onNotificationChangedCallback
        )

        // 2. Escalar el largeIcon si existe y es demasiado grande
        val originalNotif = original.notification
        val largeIcon = originalNotif.getLargeIcon()?.bitmap
        if (largeIcon == null || (largeIcon.width <= MAX_PX && largeIcon.height <= MAX_PX)) {
            return original  // ya es pequeño o no hay portada, devolver sin cambios
        }

        // 3. Reconstruir la notificación con el bitmap escalado
        val scaled = scaleBitmap(largeIcon)
        val rebuilt = NotificationCompat.Builder(context, originalNotif)
            .setLargeIcon(scaled)
            .build()

        return MediaNotification(original.notificationId, rebuilt)
    }

    override fun handleCustomCommand(
        session: MediaSession,
        action: String,
        extras: Bundle
    ): Boolean = delegate.handleCustomCommand(session, action, extras)

    private fun scaleBitmap(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= MAX_PX && h <= MAX_PX) return bitmap
        val factor = MAX_PX.toFloat() / maxOf(w, h)
        return runCatching {
            Bitmap.createScaledBitmap(
                bitmap,
                (w * factor).toInt().coerceAtLeast(1),
                (h * factor).toInt().coerceAtLeast(1),
                true
            )
        }.getOrElse { bitmap }
    }
}
