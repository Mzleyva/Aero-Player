package com.aeroplayer.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.aeroplayer.R
import com.aeroplayer.ui.onboarding.OnboardingActivity

/**
 * Punto de entrada de la app.
 * - Aplica el tema guardado (claro/oscuro)
 * - Si es la primera vez → OnboardingActivity
 * - Si ya completó onboarding → MainActivity
 */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Aplicar tema ANTES de super para evitar flash
        val prefs = getSharedPreferences("aero_prefs", MODE_PRIVATE)

        // Migración: si existe la clave antigua "theme_light" y no existe aún "theme_mode", la migra
        if (!prefs.contains("theme_mode") && prefs.contains("theme_light")) {
            val wasLight = prefs.getBoolean("theme_light", false)
            prefs.edit().putString("theme_mode", if (wasLight) "light" else "dark").apply()
        }

        // v1.8.4: default dark para que el fondo sea siempre negro al inicio
        val themeMode = prefs.getString("theme_mode", "dark") ?: "dark"
        AppCompatDelegate.setDefaultNightMode(
            when (themeMode) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark"  -> AppCompatDelegate.MODE_NIGHT_YES
                else    -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )

        super.onCreate(savedInstanceState)

        val onboardingDone = prefs.getBoolean("onboarding_done", false)

        val target = if (onboardingDone) MainActivity::class.java
                     else               OnboardingActivity::class.java

        startActivity(Intent(this, target))
        // Transición suave sin flash
        overridePendingTransition(R.anim.fade_in, 0)
        finish()
    }
}
