package com.aeroplayer.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Busca carátulas de álbumes en múltiples fuentes:
 *  1. iTunes Search API  — rápida, sin API key, buena cobertura
 *  2. MusicBrainz + Cover Art Archive — open data, muy completa
 *  3. Deezer API — alternativa adicional
 *
 * Las carátulas descargadas se guardan en caché de disco para uso offline.
 */
object ArtworkProvider {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header("User-Agent", "AeroPlayer/1.0 (Android)")
                    .build()
            )
        }
        .build()

    // ── Caché de disco ────────────────────────────────────────────────────────
    private var cacheDir: File? = null

    fun init(context: Context) {
        cacheDir = File(context.cacheDir, "artwork_cache").also { it.mkdirs() }
    }

    private fun cacheKey(artist: String, album: String) =
        (artist + "_" + album).replace(Regex("[^a-zA-Z0-9_]"), "_").take(80)

    private fun readFromDiskCache(key: String): Bitmap? {
        val file = File(cacheDir, "$key.jpg")
        return if (file.exists()) runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
        else null
    }

    private fun writeToDiskCache(key: String, bitmap: Bitmap) {
        runCatching {
            val file = File(cacheDir, "$key.jpg")
            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
        }
    }

    // ── Búsqueda principal ────────────────────────────────────────────────────

    /**
     * Busca la carátula del álbum para [artist] + [album].
     * Intenta proveedores en cascada hasta encontrar una imagen.
     * @return Bitmap de la carátula o null si ningún proveedor la tiene.
     */
    suspend fun fetchArtwork(artist: String, album: String): Bitmap? =
        withContext(Dispatchers.IO) {
            if (artist.isBlank() && album.isBlank()) return@withContext null

            val key = cacheKey(artist, album)

            // 1. Caché de disco
            readFromDiskCache(key)?.let { return@withContext it }

            // 2. iTunes Search API
            fetchFromItunes(artist, album)?.let { bmp ->
                writeToDiskCache(key, bmp)
                return@withContext bmp
            }

            // 3. MusicBrainz + Cover Art Archive
            fetchFromMusicBrainz(artist, album)?.let { bmp ->
                writeToDiskCache(key, bmp)
                return@withContext bmp
            }

            // 4. Deezer
            fetchFromDeezer(artist, album)?.let { bmp ->
                writeToDiskCache(key, bmp)
                return@withContext bmp
            }

            null
        }

    // ── Proveedor 1: iTunes ───────────────────────────────────────────────────
    private fun fetchFromItunes(artist: String, album: String): Bitmap? = runCatching {
        val query = java.net.URLEncoder.encode("$artist $album", "UTF-8")
        val url = "https://itunes.apple.com/search?term=$query&media=music&entity=album&limit=1"
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val body = resp.body?.string() ?: return null

        // Extraer artworkUrl100 del JSON
        val match = Regex("\"artworkUrl100\":\"([^\"]+)\"").find(body)
        val artUrl = match?.groupValues?.get(1) ?: return null
        // Pedir imagen en mayor resolución (600x600)
        val hiResUrl = artUrl.replace("100x100", "600x600")

        downloadBitmap(hiResUrl)
    }.getOrNull()

    // ── Proveedor 2: MusicBrainz + Cover Art Archive ──────────────────────────
    private fun fetchFromMusicBrainz(artist: String, album: String): Bitmap? = runCatching {
        // Buscar release en MusicBrainz
        val q = java.net.URLEncoder.encode(
            "release:\"$album\" AND artist:\"$artist\"", "UTF-8"
        )
        val searchUrl = "https://musicbrainz.org/ws/2/release/?query=$q&limit=1&fmt=json"
        val resp = client.newCall(Request.Builder().url(searchUrl).build()).execute()
        val body = resp.body?.string() ?: return null

        // Extraer MBID del primer release
        val mbidMatch = Regex("\"id\":\"([a-f0-9\\-]{36})\"").find(body)
        val mbid = mbidMatch?.groupValues?.get(1) ?: return null

        // Descargar carátula de Cover Art Archive
        val coverUrl = "https://coverartarchive.org/release/$mbid/front-500"
        downloadBitmap(coverUrl)
    }.getOrNull()

    // ── Proveedor 3: Deezer ───────────────────────────────────────────────────
    private fun fetchFromDeezer(artist: String, album: String): Bitmap? = runCatching {
        val q = java.net.URLEncoder.encode("$artist $album", "UTF-8")
        val url = "https://api.deezer.com/search/album?q=$q&limit=1"
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val body = resp.body?.string() ?: return null

        val match = Regex("\"cover_xl\":\"([^\"]+)\"").find(body)
        val coverUrl = match?.groupValues?.get(1)?.replace("\\/", "/") ?: return null

        downloadBitmap(coverUrl)
    }.getOrNull()

    // ── Helper de descarga ────────────────────────────────────────────────────
    private fun downloadBitmap(url: String): Bitmap? = runCatching {
        val resp = client.newCall(Request.Builder().url(url).build()).execute()
        val bytes = resp.body?.bytes() ?: return null
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()

    // ── Buscar solo por canción (artista + título) ────────────────────────────
    suspend fun fetchArtworkByTrack(artist: String, title: String): Bitmap? =
        withContext(Dispatchers.IO) {
            val key = cacheKey(artist, title + "_track")
            readFromDiskCache(key)?.let { return@withContext it }

            // iTunes por nombre de canción
            runCatching {
                val q = java.net.URLEncoder.encode("$artist $title", "UTF-8")
                val url = "https://itunes.apple.com/search?term=$q&media=music&entity=song&limit=1"
                val resp = client.newCall(Request.Builder().url(url).build()).execute()
                val body = resp.body?.string() ?: return@runCatching null
                val match = Regex("\"artworkUrl100\":\"([^\"]+)\"").find(body)
                val artUrl = match?.groupValues?.get(1) ?: return@runCatching null
                downloadBitmap(artUrl.replace("100x100", "600x600"))
            }.getOrNull()?.also { writeToDiskCache(key, it) }
        }
}
