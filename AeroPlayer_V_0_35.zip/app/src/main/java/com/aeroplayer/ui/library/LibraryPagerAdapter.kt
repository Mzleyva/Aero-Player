package com.aeroplayer.ui.library

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class LibraryPagerAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {

    override fun getItemCount() = 5

    override fun createFragment(position: Int): Fragment = when (position) {
        0 -> FilesFragment()
        1 -> AlbumsFragment()
        2 -> ArtistsFragment()
        3 -> LikedFragment()
        4 -> PlaylistsFragment()
        else -> FilesFragment()
    }
}
