package com.aeroplayer.ui.player

import android.content.Intent
import android.app.ActivityOptions
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.aeroplayer.R
import com.aeroplayer.databinding.FragmentMiniPlayerBinding
import com.aeroplayer.service.PlayerController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions

class MiniPlayerFragment : Fragment() {

    private var _binding: FragmentMiniPlayerBinding? = null
    private val binding get() = _binding!!

    private val handler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            val pos = PlayerController.getCurrentPosition()
            val dur = PlayerController.getDuration()
            if (dur > 0) {
                binding.progressBar.progress = ((pos * 100) / dur).toInt()
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMiniPlayerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupControls()
        observePlayer()
    }

    private fun View.hapticTap() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun setupControls() {
        binding.btnPrev.setOnClickListener      { it.hapticTap(); PlayerController.previous() }
        binding.btnPlayPause.setOnClickListener { it.hapticTap(); PlayerController.playPause() }
        binding.btnNext.setOnClickListener      { it.hapticTap(); PlayerController.next() }

        // Tap anywhere on mini player (except buttons) → open full player
        binding.root.setOnClickListener {
            val options = ActivityOptions.makeCustomAnimation(
                requireContext(),
                R.anim.slide_up,
                R.anim.fade_out
            )
            startActivity(
                Intent(requireContext(), PlayerActivity::class.java),
                options.toBundle()
            )
        }
    }

    private fun observePlayer() {
        PlayerController.currentSong.observe(viewLifecycleOwner) { song ->
            if (song == null) {
                binding.root.visibility = View.GONE
                return@observe
            }
            binding.root.visibility = View.VISIBLE
            binding.tvTitle.text = song.title
            binding.tvArtist.text = song.artist

            // FIX: no llamar getAlbumArt() (síncrono/bloqueante) desde observe().
            // Primero consultar cache en memoria (O(1)); si hay hit, usarlo directamente.
            // Si no, dejar que Glide cargue desde URI de forma asíncrona.
            val cached = com.aeroplayer.utils.AlbumArtUtils.getCached(song.id)
            Glide.with(binding.ivAlbumArt)
                .load(cached ?: song.albumArtUri)
                .placeholder(R.drawable.ic_music_placeholder)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(binding.ivAlbumArt)
        }

        PlayerController.isPlaying.observe(viewLifecycleOwner) { playing ->
            binding.btnPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(progressRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(progressRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(progressRunnable)
        _binding = null
    }
}
