package com.aeroplayer.ui.library

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aeroplayer.R
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.aeroplayer.model.Song
import com.aeroplayer.service.PlayerController
import com.aeroplayer.ui.MainViewModel
import com.bumptech.glide.Glide
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

/**
 * Explorador de carpetas — navega el árbol de carpetas y reproduce una carpeta
 * completa como playlist. Permite asignar portada personalizada a cada carpeta.
 *
 * Entrada: "root_path" (String) — ruta raíz. Si null usa /storage/emulated/0.
 */
class FolderBrowserActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private lateinit var rv: RecyclerView
    private lateinit var tvPath: TextView
    private lateinit var adapter: FolderAdapter
    private var currentPath: String = "/storage/emulated/0"
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp get() = (this * resources.displayMetrics.density)

    // Prefs para portadas de carpetas
    private val coverPrefs by lazy { getSharedPreferences("folder_covers", MODE_PRIVATE) }

    private var pendingCoverFolder: String? = null
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val folder = pendingCoverFolder ?: return@registerForActivityResult
        if (uri != null) {
            // Persistir URI con permiso permanente
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION)
            coverPrefs.edit().putString(folder, uri.toString()).apply()
            adapter.notifyDataSetChanged()
            Snackbar.make(rv, "Portada asignada ✓", Snackbar.LENGTH_SHORT).show()
        }
        pendingCoverFolder = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.aeroplayer.ui.AeroThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)

        currentPath = intent.getStringExtra("root_path") ?: "/storage/emulated/0"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background_dark))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // ── Toolbar ───────────────────────────────────────────────────────────
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8.dp, 8.dp, 8.dp, 8.dp)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 56.dp
            )
        }
        val btnBack = ImageButton(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.text_primary))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { navigateUp() }
        }
        tvPath = TextView(this).apply {
            text = friendlyFolderName(currentPath)
            textSize = 16f
            setTextColor(getColor(R.color.text_primary))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginStart = 8.dp }
        }
        // Botón reproducir carpeta completa
        val btnPlayAll = ImageButton(this).apply {
            setImageResource(R.drawable.ic_play)
            imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.accent_blue))
            background = null
            layoutParams = LinearLayout.LayoutParams(48.dp, 48.dp)
            setOnClickListener { playCurrentFolder() }
        }
        toolbar.addView(btnBack)
        toolbar.addView(tvPath)
        toolbar.addView(btnPlayAll)
        root.addView(toolbar)

        // ── RecyclerView en grid 2 col para carpetas, 1 col para canciones ────
        rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@FolderBrowserActivity, 2).apply {
                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(pos: Int): Int =
                        if (adapter?.getItemViewType(pos) == FolderAdapter.TYPE_SONG) 2 else 1
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            setPadding(8.dp, 0, 8.dp, 80.dp)
            clipToPadding = false
        }
        adapter = FolderAdapter(
            onFolderClick    = { folder -> navigateTo(folder.path) },
            onFolderLongTap  = { folder -> showFolderOptions(folder) },
            onSongClick      = { song, all -> PlayerController.playSongs(all, all.indexOf(song)) },
            getCoverUri      = { path -> coverPrefs.getString(path, null)?.let { Uri.parse(it) } }
        )
        rv.adapter = adapter
        root.addView(rv)

        setContentView(root)

        // Observar canciones y renderizar carpeta actual
        viewModel.allSongs.observe(this) { refreshFolder() }
        refreshFolder()
    }

    private fun refreshFolder() {
        val songs = viewModel.allSongs.value
        tvPath.text = friendlyFolderName(currentPath)
        if (songs.isNullOrEmpty()) {
            // Mostrar estado de carga mientras el MediaStore escanea
            showLoadingState()
            return
        }
        hideLoadingState()
        val items = buildFolderItems(currentPath, songs)
        adapter.submitItems(items)
    }

    private var loadingView: android.view.View? = null
    private var loadingAnimator: android.animation.ObjectAnimator? = null

    private fun showLoadingState() {
        if (loadingView != null) return
        val container = rv.parent as? LinearLayout ?: return
        val dp = resources.displayMetrics.density

        val lv = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        // Ícono de música animado (pulso)
        val ivIcon = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_library)
            imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(R.color.accent_blue))
            layoutParams = LinearLayout.LayoutParams(
                (72 * dp).toInt(), (72 * dp).toInt()
            ).also { it.bottomMargin = (16 * dp).toInt() }
            alpha = 0.9f
        }

        // Animación de pulso en el ícono
        val animator = android.animation.ObjectAnimator.ofFloat(ivIcon, "scaleX", 1f, 1.12f, 1f).apply {
            duration = 900
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
        }
        val animatorY = android.animation.ObjectAnimator.ofFloat(ivIcon, "scaleY", 1f, 1.12f, 1f).apply {
            duration = 900
            repeatCount = android.animation.ValueAnimator.INFINITE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
        }
        android.animation.AnimatorSet().also {
            it.playTogether(animator, animatorY)
            it.start()
        }
        loadingAnimator = animator

        val tv = TextView(this).apply {
            text = "Cargando biblioteca…"
            textSize = 15f
            setTextColor(getColor(R.color.text_primary))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).also { it.topMargin = (8 * dp).toInt() }
        }
        val tvSub = TextView(this).apply {
            text = "Esto solo tarda la primera vez"
            textSize = 12f
            setTextColor(getColor(R.color.text_secondary))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).also { it.topMargin = (4 * dp).toInt() }
        }

        lv.addView(ivIcon)
        lv.addView(tv)
        lv.addView(tvSub)

        // Fade in suave
        lv.alpha = 0f
        lv.animate().alpha(1f).setDuration(300).start()

        container.addView(lv, container.indexOfChild(rv))
        rv.visibility = android.view.View.GONE
        loadingView = lv
    }

    private fun hideLoadingState() {
        loadingAnimator?.cancel()
        loadingAnimator = null
        loadingView?.let {
            it.animate().alpha(0f).setDuration(200).withEndAction {
                (it.parent as? LinearLayout)?.removeView(it)
            }.start()
            loadingView = null
        }
        rv.visibility = android.view.View.VISIBLE
    }

    private fun buildFolderItems(path: String, allSongs: List<Song>): List<FolderItem> {
        val subFolders = mutableSetOf<String>()
        val songsHere  = mutableListOf<Song>()

        allSongs.forEach { song ->
            val songDir = song.path.substringBeforeLast("/")
            if (songDir == path) {
                songsHere.add(song)
            } else if (songDir.startsWith("$path/")) {
                // Subcarpeta directa
                val relative = songDir.removePrefix("$path/")
                val direct   = relative.substringBefore("/")
                subFolders.add("$path/$direct")
            }
        }

        val items = mutableListOf<FolderItem>()

        // Subcarpetas primero, con conteo y primera carátula
        subFolders.sorted().forEach { subPath ->
            val subSongs = allSongs.filter { it.path.startsWith("$subPath/") ||
                    it.path.substringBeforeLast("/") == subPath }
            val cover = subSongs.firstOrNull()?.albumArtUri
            items.add(FolderItem.Folder(
                name      = subPath.substringAfterLast("/"),
                path      = subPath,
                songCount = subSongs.size,
                coverUri  = cover
            ))
        }

        // Canciones de esta carpeta
        songsHere.sortedBy { it.title.lowercase() }.forEach {
            items.add(FolderItem.SongEntry(it))
        }

        return items
    }

    private fun navigateTo(path: String) {
        currentPath = path
        refreshFolder()
    }

    private fun friendlyFolderName(path: String): String {
        return when {
            path == "/storage/emulated/0"          -> "Almacenamiento interno"
            path == "/storage/emulated/0/Music"    -> "Música"
            path == "/storage/emulated/0/Download" -> "Descargas"
            path.startsWith("/storage/") && !path.startsWith("/storage/emulated") ->
                "Tarjeta SD / ${path.substringAfterLast("/")}"
            else -> path.substringAfterLast("/").ifBlank { "/" }
        }
    }

    private fun navigateUp() {
        val parent = currentPath.substringBeforeLast("/")
        if (parent.isNotEmpty() && parent != currentPath && parent.length > 10) {
            navigateTo(parent)
        } else {
            finish()
        }
    }

    private fun playCurrentFolder() {
        val songs = viewModel.allSongs.value ?: return
        val folderSongs = songs.filter {
            it.path.startsWith("$currentPath/") ||
            it.path.substringBeforeLast("/") == currentPath
        }.sortedBy { it.title.lowercase() }

        if (folderSongs.isEmpty()) {
            Snackbar.make(rv, "No hay canciones en esta carpeta", Snackbar.LENGTH_SHORT).show()
            return
        }
        PlayerController.playSongs(folderSongs, 0,
            queueName = currentPath.substringAfterLast("/"))
    }

    private fun showFolderOptions(folder: FolderItem.Folder) {
        val options = arrayOf(
            "▶ Reproducir carpeta",
            "🔀 Reproducir en aleatorio",
            "🖼 Asignar portada",
            "➕ Agregar a playlist"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(folder.name)
            .setItems(options) { _, which ->
                val songs = (viewModel.allSongs.value ?: emptyList()).filter {
                    it.path.startsWith("${folder.path}/") ||
                    it.path.substringBeforeLast("/") == folder.path
                }.sortedBy { it.title.lowercase() }

                when (which) {
                    0 -> PlayerController.playSongs(songs, 0, queueName = folder.name)
                    1 -> PlayerController.playSongs(songs.shuffled(), 0, queueName = folder.name)
                    2 -> { pendingCoverFolder = folder.path; pickImage.launch("image/*") }
                    3 -> addFolderToPlaylist(songs, folder.name)
                }
            }
            .show()
    }

    private fun addFolderToPlaylist(songs: List<Song>, folderName: String) {
        if (songs.isEmpty()) {
            Snackbar.make(rv, "No hay canciones en esta carpeta", Snackbar.LENGTH_SHORT).show()
            return
        }
        // Mostrar selector de playlists obtenidas en background
        val db = com.aeroplayer.data.db.AppDatabase.getInstance(this)
        lifecycleScope.launch(Dispatchers.IO) {
            val playlists = db.playlistDao().getAllPlaylistsSync()
            withContext(Dispatchers.Main) {
                if (playlists.isEmpty()) {
                    Snackbar.make(rv, "Crea una playlist primero", Snackbar.LENGTH_LONG).show()
                    return@withContext
                }
                val names = playlists.map { it.name }.toTypedArray()
                com.google.android.material.dialog.MaterialAlertDialogBuilder(this@FolderBrowserActivity)
                    .setTitle("Añadir carpeta a playlist")
                    .setItems(names) { _, idx ->
                        val playlist = playlists[idx]
                        lifecycleScope.launch(Dispatchers.IO) {
                            var pos = 0
                            songs.forEach { song ->
                                db.playlistDao().insertSongToPlaylist(
                                    com.aeroplayer.data.db.PlaylistSongEntity(
                                        playlistId   = playlist.id,
                                        songId       = song.id,
                                        title        = song.title,
                                        artist       = song.artist,
                                        album        = song.album,
                                        path         = song.path,
                                        duration     = song.duration,
                                        albumArtUri  = song.albumArtUri?.toString(),
                                        position     = pos++
                                    )
                                )
                            }
                            withContext(Dispatchers.Main) {
                                Snackbar.make(rv,
                                    "${songs.size} canciones añadidas a '${playlist.name}'",
                                    Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    override fun onBackPressed() = navigateUp()
}

// ── Sealed model ──────────────────────────────────────────────────────────────
sealed class FolderItem {
    data class Folder(
        val name: String, val path: String,
        val songCount: Int, val coverUri: Uri?
    ) : FolderItem()
    data class SongEntry(val song: Song) : FolderItem()
}

// ── Adapter ───────────────────────────────────────────────────────────────────
class FolderAdapter(
    private val onFolderClick:   (FolderItem.Folder) -> Unit,
    private val onFolderLongTap: (FolderItem.Folder) -> Unit,
    private val onSongClick:     (Song, List<Song>)  -> Unit,
    private val getCoverUri:     (String) -> Uri?
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_FOLDER = 0
        const val TYPE_SONG   = 1
    }

    private val items = mutableListOf<FolderItem>()
    private val songs get() = items.filterIsInstance<FolderItem.SongEntry>().map { it.song }

    fun submitItems(list: List<FolderItem>) {
        val oldList = items.toList()
        items.clear()
        items.addAll(list)
        // DiffUtil para evitar el parpadeo total que causa notifyDataSetChanged
        val diff = androidx.recyclerview.widget.DiffUtil.calculateDiff(object :
            androidx.recyclerview.widget.DiffUtil.Callback() {
            override fun getOldListSize() = oldList.size
            override fun getNewListSize() = list.size
            override fun areItemsTheSame(o: Int, n: Int): Boolean {
                val a = oldList[o]; val b = list[n]
                return when {
                    a is FolderItem.Folder && b is FolderItem.Folder -> a.path == b.path
                    a is FolderItem.SongEntry && b is FolderItem.SongEntry -> a.song.id == b.song.id
                    else -> false
                }
            }
            override fun areContentsTheSame(o: Int, n: Int) = oldList[o] == list[n]
        })
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemViewType(pos: Int) =
        if (items[pos] is FolderItem.Folder) TYPE_FOLDER else TYPE_SONG

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        val dp  = ctx.resources.displayMetrics.density
        return if (viewType == TYPE_FOLDER) FolderVH(buildFolderCard(ctx, dp))
        else SongVH(buildSongRow(ctx, dp))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
        when (val item = items[pos]) {
            is FolderItem.Folder -> (holder as FolderVH).bind(item)
            is FolderItem.SongEntry -> (holder as SongVH).bind(item.song)
        }
    }

    private fun buildFolderCard(ctx: android.content.Context, dp: Float): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            val margin = (6 * dp).toInt()
            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also {
                it.setMargins(margin, margin, margin, margin)
            }
            setPadding(0, 0, 0, (4 * dp).toInt())
            // Ripple con esquinas redondeadas
            val rippleColor = android.content.res.ColorStateList.valueOf(0x33FFFFFF)
            val content = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF1A1A2A.toInt())
                cornerRadius = (14 * dp)
            }
            background = android.graphics.drawable.RippleDrawable(rippleColor, content, null)
            isClickable = true; isFocusable = true
            elevation = (2 * dp)
        }
    }

    private fun buildSongRow(ctx: android.content.Context, dp: Float): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (56 * dp).toInt()
            )
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
            background = android.util.TypedValue().also {
                ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, it, true)
            }.resourceId.let { ctx.getDrawable(it) }
            isClickable = true; isFocusable = true
        }
    }

    inner class FolderVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        fun bind(folder: FolderItem.Folder) {
            root.removeAllViews()
            val ctx = root.context
            val dp  = ctx.resources.displayMetrics.density

            // Carátula de carpeta
            val iv = android.widget.ImageView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (120 * dp).toInt()
                )
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFF1E1E2E.toInt()); cornerRadius = (12 * dp)
                }
                clipToOutline = true
            }
            val cover = getCoverUri(folder.path) ?: folder.coverUri
            Glide.with(iv)
                .load(cover)
                .placeholder(R.drawable.ic_library)
                .centerCrop()
                .into(iv)

            val tvName = android.widget.TextView(ctx).apply {
                text = folder.name
                textSize = 13f
                setTextColor(ctx.getColor(R.color.text_primary))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding((4 * dp).toInt(), (4 * dp).toInt(), (4 * dp).toInt(), 0)
            }
            val tvCount = android.widget.TextView(ctx).apply {
                text = "${folder.songCount} canción${if (folder.songCount != 1) "es" else ""}"
                textSize = 11f
                setTextColor(ctx.getColor(R.color.text_secondary))
                setPadding((4 * dp).toInt(), 0, (4 * dp).toInt(), (4 * dp).toInt())
            }
            root.addView(iv); root.addView(tvName); root.addView(tvCount)
            root.setOnClickListener { onFolderClick(folder) }
            root.setOnLongClickListener { onFolderLongTap(folder); true }

        }
    }

    inner class SongVH(val root: LinearLayout) : RecyclerView.ViewHolder(root) {
        fun bind(song: Song) {
            root.removeAllViews()
            val ctx = root.context
            val dp  = ctx.resources.displayMetrics.density

            val iv = android.widget.ImageView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    (40 * dp).toInt(), (40 * dp).toInt()
                ).also { it.marginEnd = (12 * dp).toInt() }
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                background = ctx.getDrawable(R.drawable.bg_album_art_small)
                clipToOutline = true
            }
            Glide.with(iv).load(song.albumArtUri).placeholder(R.drawable.ic_music_placeholder)
                .centerCrop().into(iv)

            val texts = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            texts.addView(android.widget.TextView(ctx).apply {
                text = song.title; textSize = 14f
                setTextColor(ctx.getColor(R.color.text_primary))
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })
            texts.addView(android.widget.TextView(ctx).apply {
                text = song.artist; textSize = 12f
                setTextColor(ctx.getColor(R.color.text_secondary))
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            })

            root.addView(iv); root.addView(texts)
            root.setOnClickListener {
                if (song.path.endsWith(".cue", ignoreCase = true)) {
                    root.context.startActivity(android.content.Intent(root.context,
                        com.aeroplayer.ui.CueSheetBrowserActivity::class.java)
                        .putExtra(com.aeroplayer.ui.CueSheetBrowserActivity.EXTRA_CUE_PATH, song.path))
                } else { onSongClick(song, songs) }
            }
        }
    }
}

// CUE sheet support: launch CueSheetBrowserActivity when user taps a .cue file
// Implemented below in the adapter click handler
