package com.aeroplayer

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.aeroplayer.utils.CrashLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AeroPlayerApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()

        CrashLogger.init(this)

        // FIX Android 11: crear el canal de notificación Media3 ANTES de que el
        // servicio arranque. En Android 11, si Media3 crea el canal con IMPORTANCE_DEFAULT
        // primero, el canal queda con sonido y no puede bajarse a IMPORTANCE_LOW después
        // (Android no permite bajar la importancia de un canal ya creado).
        // Solución: crear/reemplazar el canal en Application.onCreate(), que siempre
        // se ejecuta antes de cualquier Service.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val existing = nm.getNotificationChannel("default_channel_id")

            // FIX: si el canal ya existe con IMPORTANCE_DEFAULT (sonido), eliminarlo
            // y recrearlo con IMPORTANCE_LOW. Esto solo ocurre en actualizaciones desde
            // versiones anteriores donde Media3 creó el canal antes que nosotros.
            if (existing != null && existing.importance > NotificationManager.IMPORTANCE_LOW) {
                nm.deleteNotificationChannel("default_channel_id")
            }

            if (nm.getNotificationChannel("default_channel_id") == null) {
                val ch = NotificationChannel(
                    "default_channel_id",
                    "Reproducción de música",
                    NotificationManager.IMPORTANCE_LOW  // sin sonido ni vibración
                ).apply {
                    description = "Controles de reproducción de AeroPlayer"
                    setShowBadge(false)
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
        }

        appScope.launch(Dispatchers.IO) {
            com.aeroplayer.data.repository.ArtworkProvider.init(applicationContext)
            com.aeroplayer.data.repository.ArtistImageProvider.init(applicationContext)
        }
    }
}
